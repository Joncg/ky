<?php

// 潮流部门
$tideSection = array(
	11 => array('id' => '11', 'title' => '流行趋势', 'name' => 'Trend', 'en_name' => 'Latest Trends'),
	12 => array('id' => '12', 'title' => '时装发布', 'name' => 'Catwalk', 'en_name' => 'Catwalk'),
	13 => array('id' => '13', 'title' => 'T台趋势', 'name' => 'Tshape', 'en_name' => 'Runway Analysis'),
	15 => array('id' => '15', 'title' => '展会材料', 'name' => 'ShowStuff', 'en_name' => 'Trade Show'),
	17 => array('id' => '17', 'title' => '正在流行', 'name' => 'Invogue', 'en_name' => 'In Vogue'),
	18 => array('id' => '18', 'title' => '流行分析', 'name' => 'Populars', 'en_name' => 'Trend Analysis'),
	27 => array('id' => '27', 'title' => '手稿趋势', 'name' => 'ManuscriptTrend', 'en_name' => 'Manuscript'),
	29 => array('id' => '29', 'title' => '市场聚焦', 'name' => 'MarketFocus', 'en_name' => 'Fashion Focus'),
	19 => array('id' => '19', 'title' => '时尚杂志', 'name' => 'Magazine', 'en_name' => 'Magazine'),
	20 => array('id' => '20', 'title' => '品牌画册', 'name' => 'Brandinsp', 'en_name' => 'Brand Catalogue'),
	22 => array('id' => '22', 'title' => '时尚款式', 'name' => 'FashionStyle', 'en_name' => 'Silhouettes'),
	21 => array('id' => '21', 'title' => '街头时尚', 'name' => 'StreetFashion', 'en_name' => 'Street Style'),
	23 => array('id' => '23', 'title' => '高级陈列', 'name' => 'Visual', 'en_name' => 'Senior display'),
	16 => array('id' => '16', 'title' => '矢量款式', 'name' => 'VectorStyle', 'en_name' => 'Sketches'),
	24 => array('id' => '24', 'title' => '图案', 'name' => 'Patterns', 'en_name' => 'Patterns'),
	25 => array('id' => '25', 'title' => '配饰', 'name' => 'Accessory', 'en_name' => 'Accessories'),
	26 => array('id' => '26', 'title' => '书籍', 'name' => 'Book', 'en_name' => 'Books'),
	14 => array('id' => '14', 'title' => '企划方案', 'name' => 'LayoutPlan', 'en_name' => 'Design Project'),
	28 => array('id' => '28', 'title' => '秀场提炼', 'name' => 'ShowExtract', 'en_name' => 'Shows refining'),
	30 => array('id' => '30', 'title' => '婴童专区', 'name' => 'BabyZone', 'en_name' => 'Babies Wear')
);
//专栏
$specialColumn = array(
	1 => array('id' => '1', 'title' => '牛仔', 'name' => 'Cowboy'),
	//3=>array('id'=>'3','title'=>'运动','name'=>'Sport'),
	4 => array('id' => '4', 'title' => '内衣', 'name' => 'Underwear'),
	5 => array('id' => '5', 'title' => '毛织', 'name' => 'Woolens'),
	2 => array('id' => '2', 'title' => '裤子', 'name' => 'Pants'),
);
//类别（性别）
$sort = array(
	2 => array('id' => '2', 'title' => '女装', 'name' => 'Women'),
	1 => array('id' => '1', 'title' => '男装', 'name' => 'Men'),
	3 => array('id' => '3', 'title' => '童装', 'name' => 'Children'),
	4 => array('id' => '4', 'title' => '女童', 'name' => ''),
	5 => array('id' => '5', 'title' => '男童', 'name' => ''),
	6 => array('id' => '6', 'title' => '婴童', 'name' => ''),
);
//SEO相关内容

$seowords = array(
	0 => array('title' => '时装秀_服装设计图_服装设计_法国时装秀_时装设计_蝶讯网',
		'description' => '蝶讯网是国内最大、最权威、最全面的服装设计资讯资源网站，发布全球最新时装秀、服装设计图、法国时装秀和米兰、伦敦、纽约和巴黎时装周等时装秀场的时装发布会图片等。',
		'keywords' => '时装秀,时装发布会,服装设计,服装设计图,服装款式,时装杂志,米兰时装周,巴黎时装周,法国时装秀,时装图片'), //首页

	2 => array('title' => '女装设计_女装设计图_2012年春夏秋冬女装时装周_女装时装秀_蝶讯网',
		'description' => '蝶讯服装网女装设计栏目提供最权威、最及时的2012春夏和秋冬季巴黎、米兰、纽约、伦敦女装时装周全程动态，最全面的女装时装秀、女装设计图，每日更新大量时装周女装图片。',
		'keywords' => '女装设计,女装设计图,女装时装周,时装周女装,女装时装秀,时装秀,时装周'), //女装首页

	1 => array('title' => '男装设计图_男装时装周_男装时装秀_男装图片_蝶讯服装网',
		'description' => '蝶讯服装网男装设计图和男装图片栏目提供最新的2012春夏、秋冬季巴黎、米兰、纽约、伦敦男装时装周、男装时装秀等男装图片，每日更新大量时装周男装图片。',
		'keywords' => '男装图片,男装设计图,时装周男装,男装时装秀,时装周,时装秀,服装设计图'), //男首页

	3 => array('title' => '童装设计_童装设计图_儿童服装图片_童装图片_蝶讯服装网',
		'description' => '童装设计栏目提供中国、欧美、日本、韩国儿童服装品牌2012年最新童装图片和童装设计图、韩国童装图片，每日更新数千张春夏秋冬季品牌时尚男童装、女童装等儿童服装图片。',
		'keywords' => '童装设计,童装设计图,儿童服装图片,韩国童装图片,时尚男童装,时尚男女童装,童装图片'), //童首页
);
//专栏SEO
$specialcolumnseo = array(
	1 => array('title' => '牛仔裤图片_牛仔裤搭配_牛仔服装设计图_时尚牛仔裤设计_蝶讯服装网',
		'description' => '蝶讯服装网时尚牛仔裤设计频道，提供2012/2013年最时尚的牛仔裤图片、牛仔裤搭配技巧手册和牛仔服装设计图，并提供详细的2012、2013年牛仔裤流行趋势分析报告。',
		'keywords' => '牛仔裤图片,牛仔裤搭配,牛仔服装设计图,牛仔裤设计,时尚牛仔裤,牛仔裤流行趋势,牛仔流行趋势'), //首页

	4 => array('title' => '时尚内衣秀_品牌内衣图片_女士内衣图片_男士内衣图片_蝶讯内衣网',
		'description' => '蝶讯内衣网的内衣秀和内衣图片频道，专业为内衣设计师提供众多国际品牌内衣的时尚内衣图片、内衣设计图和内衣款式图，涵盖女士内衣图片、男士内衣图片及品牌内衣广告大片。',
		'keywords' => '内衣秀,时尚内衣秀,女士内衣,男士内衣,内衣图片,内衣发布会'), //女装首页

	5 => array('title' => '针织毛衫设计_时尚毛衫图片_针织毛衫图片_毛衫款式图_蝶讯服装网',
		'description' => '蝶讯针织毛衫设计网提供全球最新的时尚毛衫图片、针织毛衫图片和毛衫款式图，涵盖男装毛衫、女装毛衫和童装毛衫款式图片，众多国际品牌毛衫设计图及2012年毛衫流行趋势。',
		'keywords' => '毛衫图片,毛衫设计,针织毛衫图片,针织毛衫设计,时尚毛衫图片,针织衫图片'), //男首页

	2 => array('title' => '裤子款式图_裤子搭配_时尚裤子图片_2012年裤子流行趋势_蝶讯服装网',
		'description' => '蝶讯服装网品牌裤子和裤子图片频道，提供2012/2013年国际裤子品牌最新的时尚裤子图片、裤子款式图和裤子搭配图片，并提供详细的2012年裤子流行趋势分析报告。',
		'keywords' => '裤子款式图,裤子搭配,时尚裤子图片,裤子品牌,品牌裤子'), //童首页
);
include_once('../config/config.php');
$array = array(
	'TOKEN_ON' => false,
	'USER_AUTH_ON' => true,
	'USER_AUTH_TYPE' => 2, // 默认认证类型 1 登录认证 2 实时认证
	'USER_AUTH_KEY' => 'memId', // 用户认证SESSION标记
	'ADMIN_AUTH_KEY' => 'administrator',
	'USER_AUTH_MODEL' => 'Member', // 默认验证数据表模型
	'AUTH_PWD_ENCODER' => 'md5', // 用户认证密码加密方式
	'USER_AUTH_GATEWAY' => '/Public/login', // 默认认证网关
	'NOT_AUTH_MODULE' => '', // 默认无需认证模块
	'REQUIRE_AUTH_MODULE' => '', // 默认需要认证模块
	'REQUIRE_AUTH_IAKN' => array(''), // 需要初始化认证模块
	'REQUIRE_AUTH_LOGIN' => array('Member', 'Shopping', 'Favorites'), //需要登录认证模块
	'NOT_AUTH_ACTION' => '', // 默认无需认证操作
	'REQUIRE_AUTH_ACTION' => '', // 默认需要认证操作
	'GUEST_AUTH_ON' => FALSE, // 是否开启游客授权访问
	'GUEST_AUTH_ID' => 0, // 游客的用户ID
	//'TMPL_EXCEPTION_FILE'=> './Tpl/default/Public/exception.html',
	'SHOW_RUN_TIME' => true, // 运行时间显示
	'SHOW_ADV_TIME' => true, // 显示详细的运行时间
	'SHOW_DB_TIMES' => true, // 显示数据库查询和写入次数
	'SHOW_CACHE_TIMES' => true, // 显示缓存操作次数
	'SHOW_USE_MEM' => true, // 显示内存开销
	'RBAC_ROLE_TABLE' => 'sxxl_role',
	'RBAC_USER_TABLE' => 'sxxl_ref_member_role',
	'RBAC_ACCESS_TABLE' => 'sxxl_ref_access',
	'RBAC_NODE_TABLE' => 'sxxl_node',
	//前台独用缓存文件
	//'DATA_CACHE_PATH_INDEX'=>'./Conf/cache/indexdata/',

	'TIDE_SECTION' => $tideSection,
	'SPECIAL_COLUMN' => $specialColumn,
	"SEO_WOERDS" => $seowords,
	"SEO_SPECIALCOLUMN" => $specialcolumnseo,
	'SORT' => $sort,
	//缓存过期时间(自定义)
	//'CACHE_EXPIRE'=>3600,
	//跨域配置
	'CRM_HTTP' => 'http://nfs.crm.sxxl.cc/api/',
	'CRM_KEY' => 'WWW_JKHL===-JJIALKHLA',
	'SXXL_HTTP' => 'http://www.sxxl.cc/api/', //'http://www.sxxl.com',
	'SXXL_KEY' => 'WWW_JKHL===-JJIALKHLA',
	//日志
	'LOG_RECORD' => true,
	'LOG_RECORD_LEVEL' => array('EMERG'),
	//
	'URL_SEND_ENCODE_KEY' => 'WWW_JKHL===-JJIALKHLA',
	'BUY_DIEXUN' => 'http://buy.fashion.diexun.cc/api/login/',
	//今天结束时间，用于sql
	'TODAY_LAST_TIME' => mktime(23, 59, 59, date("m"), date("d"), date("Y")),
    'TMPL_ACTION_FAVORIES_SUCCESS'   => 'Public:favoriessuccess', // 收藏夹模块跳转对应的模板文件
    'TMPL_ACTION_FAVORIES_ERROR'     => 'Public:favorieserror', // 收藏夹模块跳转对应的模板文件

	//财富通相关参数
	'RETURN_URL' => "http://test.2012.sxxl.cn/index.php/Tenpayurl/ReturnUrl.shtml",
	'NOTIFY_URL' => "http://test.2012.sxxl.cn/index.php/Tenpayurl/NotifyUrl.shtml",
	'PARTNER' => "1213634901",
	'KEY' => "9b1525836252e3a0b9793df8fb393805",
);
return array_merge($config, $array);
