<?php
return array (
  'min' => 1566,
  'max' => 16072016,
  'todayCount' => 7043,
  'todayUpTime' => 1343696794,
  'totalUpTime' => 1343704621,
);
?>