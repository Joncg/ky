<?php
class index{
    protected $link;
    public function __construct() {
        $db_host="192.168.2.8";
        $db_user="root";
        $db_password="123456";
        $db_name="sxxl";
        $link = mysql_connect($db_host,$db_user,$db_password) or die("数据库联接失败!");
        $db = mysql_select_db($db_name,$link);
        mysql_query('SET NAMES utf8',$link);
        $this->link = $link;
    }

    public function create(){
        $this->invogue();
    }

    protected function invogue(){
        $page = $_GET['page'];
        $page = empty($page) ? 1 : $page;
        $pageSize = 10;
        $pageStart = ($page-1)*$pageSize;
        $sql = "SELECT PIC.id,PIC.menu_id FROM sxxl.sxxl_invogue_picture PIC
                LEFT JOIN sxxl_ref_invogue_picture_fashion PFA ON PFA.picture_id = PIC.id
                LEFT JOIN sxxl_attribute_fashion FA ON PFA.picture_id = FA.id
                LEFT JOIN sxxl_ref_invogue_picture_material PMA ON PMA.picture_id = PIC.id
                LEFT JOIN sxxl_attribute_material MA ON PMA.picture_id = MA.id
                LEFT JOIN sxxl_ref_invogue_picture_style PST ON PST.picture_id = PIC.id
                LEFT JOIN sxxl_attribute_style ST ON PST.style_id = ST.id
                LEFT JOIN sxxl_ref_invogue_picture_sort PSO ON PSO.picture_id = PIC.id
                LEFT JOIN sxxl_attribute_sort SO ON PSO.sort_id = SO.id
                LEFT JOIN sxxl_ref_invogue_picture_special_column PSC ON PSC.picture_id = PIC.id
                LEFT JOIN sxxl_special_column SC ON SC.id = PSC.special_column_id
                LEFT JOIN sxxl_attribute_area AR ON AR.no = PIC.area_no
                LEFT JOIN sxxl_attribute_season SE ON SE.id = PIC.season_id
                LEFT JOIN sxxl_attribute_designer DE ON DE.id = PIC.designer_id
                LEFT JOIN sxxl_attribute_book BOO ON BOO.id = PIC.book_id
                LEFT JOIN sxxl_attribute_brand BR ON BR.id = PIC.brand_id
                LEFT JOIN sxxl_attribute_detail DET ON DET.id = PIC.detail_id
                WHERE is_publish = 1 limit {$pageStart},$pageSize";
        $voList = mysql_query($sql,$this->link);
        echo $sql."</br>";

        $pageflog = false;
        $i=0;
        while($rs = mysql_fetch_array($voList)){
            $sql = "insert into sxxl_picture_index_map values(null,'{$rs['id']}','{$rs['menu_id']}')";
            echo $sql."</br>";
            mysql_query($sql,$this->link) or die("插入索引表失败！");
        }

        if($i>0) {
            $page++;
            echo "<script>window.location='?page={$page}';</script>";
        }
     }
 }

 $index = new index();
 $index->create();
 ?>