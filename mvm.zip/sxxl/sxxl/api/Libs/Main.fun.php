<?php

//error_reporting(E_ALL ^ E_NOTICE);	//�������
//error_reporting(0);	//�������д���
//����ʱ��
if (PHP_VERSION >= '5.1') {
	date_default_timezone_set('Asia/Shanghai');
}

if (!function_exists(setAddslashes_m)) {

	/**
	 * �ݹ鷽ʽ�ĶԱ����е������ַ�����ת��
	 * @param mixed $var
	 * @return bool
	 */
	function setAddslashes_m($var) {
		if (empty($var)) {
			return $var;
		} else {
			return is_array($var) ? array_map('setAddslashes_m', $var) : addslashes($var);
		}
	}

}
/* ���û�����ı�������ת������� */
if (!get_magic_quotes_gpc()) {
	$_GET = !empty($_GET) ? setAddslashes_m($_GET) : '';
	$_POST = !empty($_POST) ? setAddslashes_m($_POST) : '';
	$_COOKIE = setAddslashes_m($_COOKIE);
	$_REQUEST = setAddslashes_m($_REQUEST);
}

function preg_filters($sql_str) {
	$sql_str = strtolower($sql_str);
	return preg_match('/load_file|outfile| union| select/i', $sql_str);
}

if (is_array($_GET)) {
	foreach ($_GET as $k => $v) {
		if (preg_filters($v)) {
			echo '�Ƿ����룬��ȷ��������ӵ�ַ��лл��';
			exit;
		}
	}
}

/**
 * �滻·��
 * @param string $path
 * @return string
 */
function replace_path($path) {
	$path = str_replace('http://www.sxxl.com/App/sxxlAdmin/eWeb/', '', $path);
	$path = str_replace('http://www.sxxl.com/', '', $path);
	$path = str_replace('http://www.sxxl.cn/App/sxxlAdmin/eWeb/', '', $path);
	$path = str_replace('http://www.sxxl.cn/', '', $path);
	$path = str_replace('../', '', $path);
	$path = str_replace('/App/sxxlAdmin/eWeb/', '', $path);
	return $path;
}

/**
 * ���༭�����ݼ���ͼƬ�Ŵ�
 * @param string $content
 * @return string
 */
function parse_content($content) {
	$content = str_replace('bsrc>', 'bsrc="" />', $content);
	$content = str_replace('�ָ���.gif"', '�ָ���.gif" bsrc=""', $content);
	$content = str_replace('border=0>', 'border=0 bsrc="">', $content);
	$content = str_replace('download_rar.jpg">', 'download_rar.jpg" bsrc="">', $content);
	$pattern = "%<[img|IMG].*?[^b]src=\"([^\"]*?)\".*?bsrc=\"([^\"]*?)\".*?>%s";
	preg_match_all($pattern, $content, $matches);
	if (empty($matches[0])) {
		$pattern = "%<[img|IMG].*?[^b]src=\"([^\"]*?)\".*?>%s";
		preg_match_all($pattern, $content, $matches);
	}
	$target = array();
	if (isset($matches[0])) {
		foreach ($matches[0] as $key => $val) {
			if (stristr($matches[1][$key], 'download_rar.jpg') == false) {
				if (stristr($matches[1][$key], '�ָ���') == false) {
					$pattern = "%height=([0-9]{3,4})|width=([0-9]{3,4})%s";
					preg_match_all($pattern, $val, $size);
					$target[$key]["height"] = $size[1][0] ? $size[1][0] : $size[1][1];
					$target[$key]["width"] = $size[2][0] ? $size[2][0] : $size[2][1];
					$target[$key]["html"] = $val;
					$target[$key]["src"] = $matches[1][$key] ? show_pic_path(replace_path($matches[1][$key])) : '';
					$target[$key]["bsrc"] = $matches[2][$key] ? show_pic_path(replace_path($matches[2][$key])) : '';
				}
			}
		}
	}
	//echo "<pre>";
	//print_r($target);//exit;
	$result = $content;
	if ($target) {
		foreach ($target as $key => $val) {
			if ($val["html"]) {
				$width = $val["width"] ? " width=\"{$val["width"]}\"" : '';
				$height = $val["height"] ? " height=\"{$val["height"]}\"" : '';
				$onclick = $val["bsrc"] ? " onclick=\"onclickpic('{$val["bsrc"]}','','{$val["src"]}')\" style=\"cursor: pointer;\"" : '';
				$replace = $val["src"] ? "img src=\"{$val["src"]}\" {$width} {$height} alt='' {$onclick} /" : 'i></i';
				$result = @preg_replace($val["html"], $replace, $result);
			}
		}
	}
	$result = str_replace('www.sxxl.com', 'img1.f.sxxl.com', $result);
	$result = str_replace('hz.sxxl.com', 'img1.f.sxxl.com', $result);
	unset($matches, $target, $content, $replace);
	return $result;
}

/**
 * ���༭�����ݼ����µ�ͼƬ�Ŵ�Ч���빦��
 * @param string $content
 * @return string
 */
function parse_content_new($content) {
	$arr = array();
	$content = str_replace('bsrc>', 'bsrc="" />', $content);
	$content = str_replace('�ָ���.gif"', '�ָ���.gif" bsrc=""', $content);
	$content = str_replace('border=0>', 'border=0 bsrc="">', $content);
	/* $pattern = "%<[img|IMG].*?[^b]src=\"([^\"]*?)\".*?bsrc=\"([^\"]*?)\".*?>%s"; */
	//preg_match_all($pattern, $content, $matches);
	//if (empty($matches[0])) {
	/* ------��2010���Ŀ¼·���滻------- */
	$a_content = '/\<[a|A] (.*)\>(.*)\<\/[a|A]\>/';
	preg_match_all($a_content, $content, $a_arr);
	for ($i = 0; $i < count($a_arr[0]); $i++) {
		if (stristr($matches[1][$key], '.rar') !== false || stristr($matches[1][$key], '.zip') !== false) {
			$str = str_replace('http://www.sxxl.cn/', '', $down_url[1]); //�õ����ݿ���·��
		}
		$down_url = explode('"', $a_arr[0][$i]);  //�õ�·��
		$str = str_replace('http://img0.f.sxxl.com/', '', $down_url[1]); //�õ����ݿ���·��
		$url = show_pic_path($str);   //�ҵ�·��
		$url = str_replace($down_url[1], $url, $a_arr[0][$i]); //�滻�µ�·��
		$content = str_replace($a_arr[0][$i], $url, $content); //�滻�µ�·��
	}
	$pattern = "%<[img|IMG].*?[^b]src=\"([^\"]*?)\".*?>%s";
	preg_match_all($pattern, $content, $matches);
	//}
	//print_r($matches);
	$target = array();
	$pic_arr = array();
	$i = 0;
	if (isset($matches[0])) {
		foreach ($matches[0] as $key => $val) {
			if (stristr($matches[1][$key], '�ָ���') == false) {
				$pattern = "%height=([0-9]{4})|width=([0-9]{3})%s";
				preg_match_all($pattern, $val, $size);
				$target[$key]["height"] = $size[1][0] ? $size[1][0] : $size[1][1];
				$target[$key]["width"] = $size[2][0] ? $size[2][0] : $size[2][1];
				/* $val = str_replace('<IMG style="BORDER-BOTTOM-COLOR: #000000; FILTER: ; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000; BORDER-LEFT-COLOR: #000000" border=0 alt="" src="http://www.sxxl.cn/Files/images/download_rar.jpg">', '', $val);
				  $pic_pattern = "%<[img|IMG].*?>%s";
				  preg_match_all($pic_pattern, $val, $pic_new_arr);
				  if(!empty($pic_new_arr[0][0])){
				  $target[$key]["html"] = $pic_new_arr[0][0];
				  }else{
				  $target[$key]["html"] = $val;
				  } */
				$target[$key]["html"] = $val;
				if (stristr($matches[1][$key], 'download_rar.jpg') === false) {  //��ֹ�����ذ���ͼ��Ӱ��Ŵ����
					//����������
					$new_big_pic_arr = explode('bsrc="', $matches[0][$key]); //��ȡ��ͼƬ
					$new_big_pic_arr = str_replace('">', '', $new_big_pic_arr[1]);
					$pic_arr[$i]['sBigSrc'] = $matches[1][$key] ? show_pic_path(replace_path($new_big_pic_arr)) : '';
					$pic_arr[$i]['sSpic'] = $matches[1][$key] ? replace_path($matches[1][$key]) : '';
					$pic_arr[$i]['sBpic'] = replace_path($new_big_pic_arr);
					$i++;
				}
				//target[$key]["html"] = $new_pic_arr[1] != '' ? $new_pic_arr[1] : $new_pic_arr[0];
				$target[$key]["src"] = $matches[1][$key] ? show_pic_path(replace_path($matches[1][$key])) : '';
				$target[$key]["bsrc"] = $matches[1][$key] ? show_pic_path(replace_path($matches[1][$key])) : '';
			}
		}
	}
	//echo "<pre>";
	//print_r($pic_arr);//exit;
	unset($i);
	$arr['pic_arr'] = $pic_arr;
	$result = $content;
	$i = 0;
	if ($target) {
		foreach ($target as $key => $val) {
			if ($val["html"]) {
				$width = $val["width"] ? " width=\"{$val["width"]}\"" : '';
				$height = $val["height"] ? " height=\"{$val["height"]}\"" : '';
				//$onclick = $val["bsrc"] ? " onclick=\"onclickpic('{$val["bsrc"]}','','{$val["src"]}')\" style=\"cursor: pointer;\"" : '';
				if (stristr($val["src"], 'download_rar.jpg') === false) {  //��ֹ�����ذ���ͼ��Ӱ��Ŵ����
					$onclick = $val["bsrc"] ? " onclick=\"viewPic.setPic(" . $i . ")\" style=\"cursor: pointer;\"" : '';
					$i++;
				}
				$replace = $val["src"] ? "img src=\"{$val["src"]}\" {$width} {$height} alt='' {$onclick} /" : 'i></i';
				$result = @preg_replace($val["html"], $replace, $result);
			}
		}
	}
	//print_r($result);
	$result = str_replace('www.sxxl.com', 'img1.f.sxxl.com', $result);
	$result = str_replace('hz.sxxl.com', 'img1.f.sxxl.com', $result);
	unset($matches, $target, $content, $replace);
	$arr['result'] = $result;
	//echo $result."aaaa";
	return $arr;
}

/**
 * ����Cidȡ����
 * @param int $cid
 * @return array
 */
function getCidTable($cid) {
	if (intval($cid) < 1)
		return false;
	$db = 18 == $cid ? 'style_info.' : 'Product_Sxxlcn.';
	$arr = array();
	switch ($cid) {
		case 11: //��������
			$arr["table_info"] = $db . TB_InfoContext_LXQS;
			$arr["table_info_pic"] = $db . TB_InfoContentPic_LXQS;
			$arr["table_topic"] = $db . TB_INFO_LXQS_TREND;
			$arr["table_topic_pic"] = $db . TB_INFO_LXQS_TREND_PIC;
			$arr["table_topic_son"] = $db . TB_INFO_LXQS_TREND_STOPIC;
			$arr["table_topic_son_pic"] = $db . TB_INFO_LXQS_TREND_SPIC;
			$arr["table_topic_stype"] = $db . TB_INFO_LXQS_TREND_STYPE;
			break;
		case 12: //ʱװ����
		case 28: //�Ӿ�Ӫ��
			$arr["table_info"] = $db . TB_InfoContext_SZFB;
			$arr["table_info_pic"] = array(0 => $db . TB_InfoContentPic_SZFB, 1 => $db . 'info_szfb_expand_pic');
			$arr["table_topic"] = $db . TB_INFO_SZFB_TSHAPE;
			$arr["table_topic_pic"] = $db . TB_INFO_SZFB_TSHAPE_PIC;
			$arr["table_topic_son"] = $db . TB_INFO_SZFB_TSHAPE_STOPIC;
			$arr["table_topic_son_pic"] = $db . TB_INFO_SZFB_TSHAPE_SPIC;
			$arr["table_topic_stype"] = $db . TB_INFO_SZFB_TSHAPE_STYPE;
			break;
		case 13: //��������
			$arr["table_info"] = $db . TB_InfoContext_ZZLX;
			$arr["table_info_pic"] = $db . TB_InfoContentPic_ZZLX;
			$arr["table_topic"] = $db . TB_INFO_ZZLX_INVOGUE;
			$arr["table_topic_pic"] = $db . TB_INFO_ZZLX_INVOGUE_PIC;
			$arr["table_topic_son"] = $db . TB_INFO_ZZLX_INVOGUE_STOPIC;
			$arr["table_topic_son_pic"] = $db . TB_INFO_ZZLX_INVOGUE_SPIC;
			$arr["table_topic_stype"] = $db . TB_INFO_ZZLX_INVOGUE_STYPE;
			break;
		case 14: //�ָ�����
		case 16: //�����鼮
		case 17: //������־
		case 26: //�г��۽�
		case 27: //Ʒ�ƻ���
			$arr["table_info"] = $db . TB_InfoContext;
			$arr["table_info_pic"] = $db . TB_InfoContentPic;
		case 18:
			$arr["table_info"] = $db . 'info_ssks';
			$arr["table_info_pic"] = $db . 'info_ssks_pic';
			$arr["table_info_son"] = array(1 => $db . 'style_morepic_man', 2 => $db . 'style_morepic_woman', 3 => $db . 'style_morepic_kids');
		case 24: //ͼ���鼮
			$arr["table_info"] = $db . TB_INFO_PV_BOOK;
			$arr["table_info_pic"] = $db . TB_INFO_PV_BOOK_PIC;
			break;
		case 25: //����ͼ��
			$arr["table_info"] = $db . TB_INFO_PV_TREND;
			$arr["table_info_pic"] = $db . TB_INFO_PV_TREND_PIC;
			break;
		case 22: //����
		case 36: //��ͷʱ��
		case 37: //����/����
			$arr["table_info"] = $db . TB_InfoContext_LXQS;
			$arr["table_info_pic"] = $db . TB_InfoContentPic_LXQS;
			break;
		case 81: //ʱװ����--������
			$arr["table_info"] = $db . TB_InfoContext_SZFB;
			$arr["table_info_pic"] = $db . TB_InfoContentPic_SZFB;
			break;
		case 38: //Ӥͯ
			$arr["table_info"] = $db . TB_InfoContext;
			$arr["table_info_pic"] = $db . InfoContentPic;
			break;
		case 1320: //����ţ��
			$arr["table_info"] = $db . TB_INFO_ZZLX_HBNZ;
			$arr["table_info_pic"] = $db . TB_INFO_ZZLX_HBNZ_PIC;
			break;
		default:
			$arr["table_info"] = $db . TB_InfoContext;
			$arr["table_info_pic"] = $db . InfoContentPic;
			break;
	}
	$arr["table_click_count"] = $db . 'fs_click_count';
	return $arr;
}

/**
 * ����ָ����������
 * @param int $cid
 * @param int $tid
 * @return none
 */
function updateClickCount($cid, $tid) {
	global $mysql;
	if (empty($cid) && empty($tid))
		return false;
	$table_info = 'fs_click_count';
	$sql = "SELECT id FROM $table_info WHERE cid = '$cid' AND tid = '$tid'";
	$row = $mysql->getRow($sql);
	if ($row) {
		$s_date = date("H");
		$s_num = ($s_date >= 9 && $s_date <= 17) ? rand(2, 3) : 1;
		$mysql->update($table_info, "real_count=real_count+1,show_count=show_count + $s_num", "cid = '$cid' AND tid = '$tid'");
	} else {
		$mysql->insert($table_info, 'cid,tid', "'$cid','$tid'");
	}
}

/**
 * ��ȡ����
 * @param int $cid
 * @param int $tid
 * @return int
 */
function getClickCount($cid, $tid, $field=null) {
	global $mysql;
	if (empty($cid) && empty($tid))
		return false;
	$table_info = 'fs_click_count';
	$field = empty($field) ? 'show_count' : 'real_count';
	$sql = "SELECT $field FROM $table_info WHERE cid = '$cid' AND tid = '$tid'";
	$row = $mysql->getRow($sql);
	$count = 1;
	if ($row) {
		$count = $row[$field];
	}
	return $count;
}

#============================================================================
# BIG ת��Ϊ GBK
#----------------------------------------------------------------------------

Function big5ToGbk(& $fContents) {
	Return iconv("BIG5", "GBK", $fContents);
}

#============================================================================
# UTF-8 ת��Ϊ GB2312
#----------------------------------------------------------------------------

Function utf8ToGb(& $fContents) {
	Return iconv("UTF-8", "GB2312", $fContents);
}

#============================================================================
# UTF-8 ����������
#----------------------------------------------------------------------------

Function utf8ErrFilter(& $fContents) {
	$utf8ErrCode = chr(226) . chr(150) . chr(161);
	$fContents = str_replace($utf8ErrCode, "???", $fContents);
	Return $fContents;
}

#============================================================================
# �������ˣ�ʹ $_GET �� $_POST ��$q->record �ȱ�������ȫ   // ���PHP.ini �����ļ�����ħ�������Ļ�����
#----------------------------------------------------------------------------

Function varFilter(& $fStr) {
	if (is_array($fStr)) {
		foreach ($fStr AS $_arrykey => $_arryval) {
			if (is_string($_arryval)) {
				$fStr["$_arrykey"] = trim($fStr["$_arrykey"]);		  // ȥ���������˿ո�
				$fStr["$_arrykey"] = htmlspecialchars($fStr["$_arrykey"]);	   // ��������Ԫת�� HTML ��ʽ
				$fStr["$_arrykey"] = str_replace("javascript", "javascript ", $fStr["$_arrykey"]); // ��ֹ javascript
			} else if (is_array($_arryval)) {
				$fStr["$_arrykey"] = varFilter($_arryval);
			}
		}
	} else {
		$fStr = trim($fStr);		 // ȥ���������˿ո�
		$fStr = htmlspecialchars($fStr);	  // ��������Ԫת�� HTML ��ʽ
		$fStr = str_replace("javascript", "javascript ", $fStr); // ��ֹ javascript
	}
	Return $fStr;
}

#============================================================================
# �ָ������˵ı���
#----------------------------------------------------------------------------

Function varResume(& $fStr) {
	if (is_array($fStr)) {
		foreach ($fStr AS $_arrykey => $_arryval) {
			if (is_string($_arryval)) {
				$fStr["$_arrykey"] = str_replace("&quot;", "\"", $fStr);
				$fStr["$_arrykey"] = str_replace("&lt;", "<", $fStr);
				$fStr["$_arrykey"] = str_replace("&gt;", ">", $fStr);
				$fStr["$_arrykey"] = str_replace("&amp;", "&", $fStr);
				$fStr["$_arrykey"] = str_replace("javascript ", "javascript", $fStr);
			} else if (is_array($_arryval)) {
				$fStr["$_arrykey"] = varResume($_arryval);
			}
		}
	} else {
		$fStr = str_replace("&quot;", "\"", $fStr);
		$fStr = str_replace("&lt;", "<", $fStr);
		$fStr = str_replace("&gt;", ">", $fStr);
		$fStr = str_replace("&amp;", "&", $fStr);
		$fStr = str_replace("javascript ", "javascript", $fStr);
	}
	Return $fStr;
}

#============================================================================
# ת������֧��HTML�﷨
#----------------------------------------------------------------------------

Function trueHtml(& $fStr) {
	$fStr = varResume($fStr);
	$fStr = StripSlashes($fStr);
	Return $fStr;
}

#============================================================================
# �����С�����ֵ֮��������λ�����㲹��
#----------------------------------------------------------------------------

Function getRand($fMin, $fMax) {
	srand((double) microtime() * 1000000);
	$fLen = "%0" . strlen($fMax) . "d";
	Return sprintf($fLen, rand($fMin, $fMax));
}

#============================================================================
# ��ʾ������ֹ��ʽִ��
#----------------------------------------------------------------------------

Function halt($fStr) {
	echo "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>";
	echo "<html><head>";
	echo "<meta http-equiv='Content-Type' content='text/html; charset=gb2312>";
	echo "</head>";
	echo "<body leftmargin='20' topmargin='20' marginwidth='0' marginheight='0'>";
	echo $fStr;
	echo "</body>";
	echo "</html>";
	exit;
}

#============================================================================
# ��ȡ�ļ�����
#----------------------------------------------------------------------------

Function fileRead($fFileName) {
	return file_get_contents($fFileName);
}

#============================================================================
# д���ļ�����
#----------------------------------------------------------------------------

Function fileWrite($fFileName, $fContent) {
	ignore_user_abort(TRUE);  // �����û��ر���������������ʽ����ִ��
	$fp = fopen($fFileName, 'w');
	if (flock($fp, LOCK_EX)) {
		fwrite($fp, $fContent);
		flock($fp, LOCK_UN);
	}
	fclose($fp);
	ignore_user_abort(FALSE);  // �رպ����û��ر���������������ʽ���û���ֹ���ʶ�ֹͣ
	return;
}

#============================================================================
# ��û�Ȧ�б��������ɫ
#----------------------------------------------------------------------------

Function rowColor(& $fVar, $fColor1="", $fColor2="") {
	if (!isset($fVar)) {
		$fVar = $fColor1;
	} else {
		if ($fColor1 == $fVar) {
			$fVar = $fColor2;
		} else {
			$fVar = $fColor1;
		}
	}
	Return $fVar;
}

#============================================================================
# ��ת��Ϊ���Ӹ�ʽ
#----------------------------------------------------------------------------

function s2m($second) {
	return floor($second / 60) . "��" . ($second % 60) . "��";
}

#============================================================================
# ��ת��ΪСʱ��ʽ
#----------------------------------------------------------------------------

function s2h($second) {
	return floor($second / 3600) . "ʱ" . floor(($second % 3600) / 60) . "��";
}

#============================================================================
# �����ִ���ȡ����
# ����˵����
# $fStr����Ҫ�����ԭʼ�ִ���
# $fStart���ӵڼ������ֺ�ʼ��ȡ����ͷ��ʼ��ȡʹ�� 0
# $fLen����ȡ��������
# $fCode��ԭʼ�ִ��ı��뷽ʽ��Ĭ��Ϊ gb2312 �� big5��UTF-8 �� UTF-8 ���뷽ʽ��ȡ
#----------------------------------------------------------------------------

Function msubstr(& $fStr, $fStart, $fLen, $fCode = "") {
	$fCode = strtolower($fCode);
	switch ($fCode) {
		case "utf-8" :
			preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $fStr, $ar);
			if (func_num_args() >= 3) {
				if (count($ar[0]) > $fLen) {
					return join("", array_slice($ar[0], $fStart, $fLen)) . "...";
				}
				return join("", array_slice($ar[0], $fStart, $fLen));
			} else {
				return join("", array_slice($ar[0], $fStart));
			}
			break;
		default:
			$fStart = $fStart * 2;
			$fLen = $fLen * 2;
			$strlen = strlen($fStr);
			for ($i = 0; $i < $strlen; $i++) {
				if ($i >= $fStart && $i < ( $fStart + $fLen )) {
					if (ord(substr($fStr, $i, 1)) > 129)
						$tmpstr .= substr($fStr, $i, 2);
					else
						$tmpstr .= substr($fStr, $i, 1);
				}
				if (ord(substr($fStr, $i, 1)) > 129)
					$i++;
			}
			if (strlen($tmpstr) < $strlen)
				$tmpstr .= "...";
			Return $tmpstr;
	}
}

#============================================================================
# ������������ select ѡ��
# fSelectName��select �б���� Name
# fSelectArray���б��������У�key Ϊ option ��ֵ��var Ϊ option ��ʾ����
# fNowVal����ǰѡ�е� option ��ʹ�� key ֵ��Ӧ
# fFirstOption����һ�� option
# fJavaScript������Ҫ�� javascript ����
# fBgColorArr: �� option ����ɫ
#----------------------------------------------------------------------------

Function selectList($fSelectName, & $fSelectArray, $fNowVal = "", $fFirstOption = "", $fJavaScript = "", $fBgColorArr = array()) {
	## ������ָ��ָ���һ��Ԫ��
	if (is_array($fSelectArray))
		reset($fSelectArray);
	##
	if (!empty($fJavaScript))
		$fJavaScript = " onClick=\"" . $fJavaScript . "\"";
	$fSelectStr = "<SELECT ID =" . $fSelectName . "  NAME = " . $fSelectName . " " . $fJavaScript . ">";
	if (!empty($fFirstOption)) {
		$fFirstOption = $fFirstOption;
		$fSelectStr .= "<option value=\"\">" . $fFirstOption . "</option>";
	}
	while (list($key, $val) = @each($fSelectArray)) {
		$gbColor = "";
		$selected = "";
		if (!empty($fBgColorArr[$key]))
			$gbColor = "style=\"COLOR: #" . $fBgColorArr[$key] . "\"";
		if (( $fNowVal == $key ) && ( $fNowVal !== "" ))
			$selected = "SELECTED";
		$fSelectStr .= "<option value=\"" . $key . "\" " . $gbColor . " " . $selected . ">" . $val . "</option>\n";
	}
	$fSelectStr .= "</SELECT>";
	Return $fSelectStr;
}

#============================================================================
# ������������ gameSelect ѡ��
# fSelectName��select �б���� Name
# fSelectArray���б��������У�key Ϊ option ��ֵ��var Ϊ option ��ʾ����
# fNowVal����ǰѡ�е� option ��ʹ�� key ֵ��Ӧ
# fFirstOption����һ�� option
# fBgColorArr: �� option ����ɫ
#----------------------------------------------------------------------------

Function gameSelectList($fSelectName, & $fSelectArray1, & $fSelectArray2, & $fSelectArray3, $fNowVal = "", $fFirstOption = "", $fJavaScript = "") {
	## ������ָ��ָ���һ��Ԫ��
	if (is_array($fSelectArray1))
		reset($fSelectArray1);
	if (is_array($fSelectArray2))
		reset($fSelectArray2);
	if (is_array($fSelectArray3))
		reset($fSelectArray3);
	##
	if (!empty($fJavaScript))
		$fJavaScript = " onClick=\"" . $fJavaScript . "\"";
	$fSelectStr = "<SELECT NAME = " . $fSelectName . " " . $fJavaScript . ">";
	if (!empty($fFirstOption)) {
		$fSelectStr .= "<option value=\"\">" . $fFirstOption . "</option>";
	}
	$selectAction = False;
	while (list($key, $val) = @each($fSelectArray2)) {
		$selected = "";
		if (( $fNowVal == $key ) && ( $fNowVal !== "" ) && (!$selectAction)) {
			$selectAction = True;
			$selected = "SELECTED";
		}
		$fSelectStr .= "<option value=\"" . $key . "\" style=\"COLOR: GREEN\" " . $selected . ">" . $val . "</option>\n";
	}
	while (list($key, $val) = @each($fSelectArray3)) {
		$selected = "";
		if (( $fNowVal == $key ) && ( $fNowVal !== "" ) && (!$selectAction)) {
			$selectAction = True;
			$selected = "SELECTED";
		}
		$fSelectStr .= "<option value=\"" . $key . "\" style=\"COLOR: Blue\" " . $selected . ">" . $val . "</option>\n";
	}
	while (list($key, $val) = @each($fSelectArray1)) {
		$selected = "";
		if (( $fNowVal == $key ) && ( $fNowVal !== "" ) && (!$selectAction)) {
			$selectAction = True;
			$selected = "SELECTED";
		}
		$fSelectStr .= "<option value=\"" . $key . "\" " . $selected . ">" . $val . "</option>\n";
	}
	$fSelectStr .= "</SELECT>";
	Return $fSelectStr;
}

#=======================================================================================
#  ���������������еĵڼ���
#=======================================================================================

function weekOfTheYear($day='', $month='', $year='') {
	if ($day == '')
		$day = date('d');
	if ($month == '')
		$month = date('m');
	if ($year == '')
		$year = date('Y');
	$day0101 = mktime('0', '0', '0', '01', '01', $year);
	$today = mktime('0', '0', '0', $month, $day, $year);
	$week2sunday = 8 - date("w", $day0101);
	$week2sun = mktime('0', '0', '0', '01', $week2sunday, $year);
	$result = sprintf("%02d", floor((date("z", $today) - date("z", $week2sun)) / 7) + 2);
	Return $result;
}

#============================================================================
# ��ȡ��ʽ������ʱ���UNIXʱ�����
# fDateTime ����ʽΪ year-month-day hour:minute:second
# fAction��+ ��ǰʱ�����һ�� fDateTime ʱ�䣬- ��ǰʱ���ȥһ�� fDateTime ʱ��
#----------------------------------------------------------------------------

Function getTime($fDateTime, $fAction = "") {
	$year = substr($fDateTime, 0, 4);
	$month = substr($fDateTime, 5, 2);
	$day = substr($fDateTime, 8, 2);
	$hour = substr($fDateTime, 11, 2);
	$minute = substr($fDateTime, 14, 2);
	$second = substr($fDateTime, 17, 2);
	if ("+" == $fAction) {
		$year = date("Y", NOW_TIME) + substr($fDateTime, 0, 4);
		$month = date("m", NOW_TIME) + substr($fDateTime, 5, 2);
		$day = date("d", NOW_TIME) + substr($fDateTime, 8, 2);
		$hour = date("H", NOW_TIME) + substr($fDateTime, 11, 2);
		$minute = date("i", NOW_TIME) + substr($fDateTime, 14, 2);
		$second = date("s", NOW_TIME) + substr($fDateTime, 17, 2);
	} else if ("-" == $fAction) {
		$year = date("Y", NOW_TIME) - substr($fDateTime, 0, 4);
		$month = date("m", NOW_TIME) - substr($fDateTime, 5, 2);
		$day = date("d", NOW_TIME) - substr($fDateTime, 8, 2);
		$hour = date("H", NOW_TIME) - substr($fDateTime, 11, 2);
		$minute = date("i", NOW_TIME) - substr($fDateTime, 14, 2);
		$second = date("s", NOW_TIME) - substr($fDateTime, 17, 2);
	}

	Return mktime($hour, $minute, $second, $month, $day, $year);
}

#============================================================================
# ����Ƿ�һ���Ϸ��� $_SESSION ����
# $fStr��SESSION �����±�
# ��� $_SESSION �����Ѷ�����ֵ��Ϊ�շ��� True����֮���� False
#----------------------------------------------------------------------------

Function is_session($fStr) {
	if ((isset($_SESSION[$fStr])) && (!empty($_SESSION[$fStr]))) {
		return True;
	} else {
		return False;
	}
}

#============================================================================
# �����־�ļ�����д����־
# $fLogPath��	��־�ļ���·����������
# $fLogMaxSize����־�ļ������Size
# $fLog��		��־����
#----------------------------------------------------------------------------

Function doLog($fLogPath, $fLogMaxSize, $fLog) {
	if (!file_exists($fLogPath))
		fileWrite($fLogPath, '');
	if (filesize($fLogPath) > $fLogMaxSize) {
		fileWrite($fLogPath, '');
	}
	ignore_user_abort(TRUE);  // �����û��ر���������������ʽ����ִ��
	$fp = fopen($fLogPath, 'a');
	if (flock($fp, LOCK_EX)) {
		fwrite($fp, $fLog);
		flock($fp, LOCK_UN);
	}
	fclose($fp);
	ignore_user_abort(FALSE);  // �رպ����û��ر���������������ʽ���û���ֹ���ʶ�ֹͣ
}

#============================================================================
# ��ȡ��ʽ����Ľ����λ
# fVal �������λ
#----------------------------------------------------------------------------

Function numToMoney($fVal) {
	$len = strlen($fVal);
	if ($len > 3) {
		$num = "";
		for ($i = 0; $i < $len; $i++) {
			$num .= substr($fVal, $i, 1);
			if (0 == (($len - $i - 1) % 3)) {
				if (($len - $i - 1) > 0)
					$num .= ",";
			}
		}
	} else {
		$num = $fVal;
	}
	Return $num;
}

#============================================================================
# �����������ȡN������µ�����
# dealArray ������
# num ������
#----------------------------------------------------------------------------

function randArray($dealArray, $num) {
	if (!is_array($dealArray))
		Return "";
	if ($num > count($dealArray))
		Return $dealArray;
	if ($num <= 0)
		Return "";
	srand((float) microtime() * 10000000);
	$rand_keys = array_rand($dealArray, $num);
	if ($num == 1) {
		$resultArray[$rand_keys] = $dealArray[$rand_keys];
	} else {
		for ($j = 0; $j < $num; $j++) {
			$resultArray[$rand_keys[$j]] = $dealArray[$rand_keys[$j]];
		}
	}
	return $resultArray;
}

#============================================================================
# ���ݻ�Ա����֤�ţ���ȡ��ʽ���������ר���ʺ�
# fVal ������֤�ֺ�
#----------------------------------------------------------------------------

Function bankAccounts($fVal) {
	if (strlen($fVal) != 10)
		return False;
	$one = strtoupper(substr($fVal, 0, 1));
	$one = ord($one) - 64;
	if (($one < 1) || ($one > 26))
		return False;
	$one = sprintf("%02d", $one);
	$bankAccounts = $one . substr($fVal, 1);
	Return $bankAccounts;
	/*
	  if (strlen($fVal) != 9) return False;
	  Return $fVal;
	 */
}

#============================================================================
# ��ȡ��Ա����������Ѷ
#----------------------------------------------------------------------------

Function getAppraiseMsg($fAppraise_high, $fAppraise_middle, $fAppraise_bottom) {
	$appraiseTotal = $fAppraise_high + $fAppraise_middle + $fAppraise_bottom;
	if ($appraiseTotal > 0) {
		$appraise_high = floor($fAppraise_high / $appraiseTotal * 100);
	} else {
		$appraise_high = 0;
	}
	$appraise = c("���ۣ�") . $appraiseTotal . c(" �Σ��������ۣ�") . $appraise_high . "%";
	return $appraise;
}

#============================================================================
# ��ȡ��Ʒ����
#----------------------------------------------------------------------------

Function getWareType($fVal1, $fVal2 = 0) {
	$result = "";
	if (is_array($fVal1)) {
		while (list($key, $val) = @each($fVal1)) {
			if ($fVal2 == $key) {
				$checked = "checked";
			} else {
				$checked = "";
			}
			$result .= "<input type=\"radio\" name=\"wareType\" value=\"" . $key . "\" " . $checked . ">" . $val . " ";
		}
	}
	return $result;
}

#============================================================================
# �������飬��ȡradio�б�
# $fVal1:��ѡ������;$fVal2:����;$fVal3:ѡ��ֵ(��ȱʡ)
#----------------------------------------------------------------------------

Function arrToRadioList($fVal1, $fVal2, $fVal3 = 0) {
	$result = "";
	if (is_array($fVal2)) {
		while (list($key, $val) = @each($fVal2)) {
			if ($fVal3 == $key) {
				$checked = "checked";
			} else {
				$checked = "";
			}
			$result .= "<input type=\"radio\" name=\"" . $fVal1 . "\" value=\"" . $key . "\" class=\"noborder\" " . $checked . ">" . $val . " ";
		}
	}
	return $result;
}

#============================================================================
# ��ȡSQL���� in ����е��б�
#----------------------------------------------------------------------------

Function getSQLWhereInList($fVal) {
	if (!is_array($fVal)) {
		return False;
	}
	reset($fVal);
	$theWhere = "(";
	while (list($key, $val) = @each($fVal)) {
		$theWhere .= $key . ",";
	}
	$theWhere = substr($theWhere, 0, -1);
	if ("" == $theWhere) {
		return False;
	}
	$theWhere .= ")";
	return $theWhere;
}

#============================================================================
# �жϵ�ǰ��Ա����
#----------------------------------------------------------------------------

Function chkLang($fVal1, $fVal2="") {
	if (empty($fVal2)) {
		$language = $_SERVER["HTTP_ACCEPT_LANGUAGE"];
	} else {
		$language = $fVal2;
	}
	$len1 = strlen($language);
	$language = str_replace($fVal1, "", $language);
	$len2 = strlen($language);
	if ($len1 == $len2) {
		return False;
	} else {
		return True;
	}
}

// ��ȡ IP ��ַ
function GetIP() {
	if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
		$ip = getenv("HTTP_CLIENT_IP");
	else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
		$ip = getenv("HTTP_X_FORWARDED_FOR");
	else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
		$ip = getenv("REMOTE_ADDR");
	else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
		$ip = $_SERVER['REMOTE_ADDR'];
	else
		$ip = "unknown";
	return($ip);
}

/**
 * ���ش�����Ϣ
 */
function sendback($msg='', $url='') {
	if ($msg != '' && $url == '') {
		echo "<script>alert(\"$msg\");window.location='javascript:history.back()';</script>";
	} else if ($msg == '' && $url != '') {
		@header("Location:{$url}");
	} else {
		echo "<script>alert(\"$msg\");window.location='$url';</script>";
	}
	exit;
}

// �������Ƿ��Ѹ�ֵ����δ����ʾ��������һҳ
function checkUserVar($name) {
	if (!isset($name) || (empty($name))) {
		sendback("$name ����δ���û�ֵ�����򷵻���һҳ");
	}
}

// ������ʾ��Ϣ
function sendalert($reson) {
	echo "<script>alert(\"$reson\");</script>";
}

// ʱ���
function MicroTimer() {
	$mtime = microtime();
	$mtime = explode(' ', $mtime);
	$mtime = $mtime[1] + $mtime[0];
	return $mtime;
}

/* * ************************************************************************************
 * ���ܣ�		��ȡ�洢ͼƬ��·�����ļ���������չ����
 * ����ֵ��	�洢ͼƬ��·�����ļ���������չ����
 * ������		$Cid	int		�������ĸ����ģ��ɼ�������function GetCategory��
 * 			$p		bool	true:��̨�����ĸ�Ŀ¼�¡�false:��̨������eWebĿ¼���ϴ�
 * 			$GetName bool	true:�Զ���ȡ�ļ���	false:ֻ����·�����������Զ����ɵ��ļ���;
 * 			$debug  bool	false:����������·���ĶԻ��� true:��������·���ĶԻ���
 * ************************************************************************************* */

function Get_Path($Cid='', $p=false, $GetName=true, $debug=false) {
	global $mysql;
	$Cid = substr($Cid, 0, 2);
	switch ($Cid) {
		case 11:
			$pProductTypeIDStr = "Trend";
			break;
		case 12:
			$pProductTypeIDStr = "CatWalk";
			break;
		case 13:
		case 28:
			$pProductTypeIDStr = "InVogue";
			break;
		case 14:
			$pProductTypeIDStr = "DesignTrend";
			break;
		case 15:
		case 26:
			$pProductTypeIDStr = "WindowPhoto";
			break;
		case 16:
			$pProductTypeIDStr = "HotBook";
			break;
		case 17:
		case 27:
			$pProductTypeIDStr = "FashionMagazine";
			break;
		case 18:
			$pProductTypeIDStr = "Style";
			break;
		case 19:
			$pProductTypeIDStr = "Pattern";
			break;
		case 20:
			$pProductTypeIDStr = "Vectorgraph";
			break;
		case 21:
			$pProductTypeIDStr = "Original";
			break;
		case 22:
			$pProductTypeIDStr = "Accessory";
			break;
		case 23:
			$pProductTypeIDStr = "Homewear";
			break;
		case 24:
			$pProductTypeIDStr = "P_book";
			break;
		case 25:
			$pProductTypeIDStr = "P_trend";
			break;
		case 36:
			$pProductTypeIDStr = "streetspot";
			break;
		case 37:
			$pProductTypeIDStr = "fabric";
			break;
		case 120:
			$pProductTypeIDStr = "About";
			break;
		default:
			$pProductTypeIDStr = "News";
			break;
	}
	$Path = ($p) ? "../../" : "../../../";
	//$Path .= date("Y") . '/' . date('md').'/';
	$Path .= '2012_3/' . date('md') . '/';
	$cCid = 127;
	$NowTime = time();

	$sql = "SELECT ID, CountDir, Count FROM " . TB_PICCOUNT . " WHERE Cid = $cCid LIMIT 0, 1";
	$res = $mysql->arrQuery($sql);
	if (count($res) < 1) {
		$CountDir = 1;
		$Path .= $CountDir . '/';
		$sql = "INSERT INTO " . TB_PICCOUNT . " (Count, CountDir, Cid, DirName, AddTime) VALUES
							(1, $CountDir, {$cCid}, '{$Path}', {$NowTime})";
		$mysql->query($sql);
	} else {
		if ($res[0]['Count'] >= 1500) {
			$sCountDir = $res[0]['CountDir'] + 1;
			$Path .= $sCountDir . '/';
			$sql = "UPDATE " . TB_PICCOUNT . " SET CountDir = $sCountDir, Count = 1 WHERE Cid = $cCid";
		} else {
			$sCount = $res[0]['Count'] + 1;
			$Path .= $res[0]['CountDir'] . '/';
			$sql = "UPDATE " . TB_PICCOUNT . " SET Count = $sCount WHERE Cid = $cCid";
		}
		//$mysql->query($sql);
	}

	dir_create($Path);
	$sName = date("YmdHis") . rand(10000, 99999);
	$Path .= "{$sName}";
	return $Path;
}

/* * ************************************************************************************
 * ���ܣ�		��ͼƬ�洢���ĸ�Ŀ¼��
 * ����ֵ��	����ͼƬ�洢��·��
 * ������		$Path	���ĸ�Ŀ¼�´����洢ͼƬ��·��
 * 			$Cid	���
 * ************************************************************************************* */

function IsChk($Path, $rescount) {
	//Ŀ¼���ڣ�����Ŀ¼���ļ���С��ָ����;
	global $mysql;
}

/* * ************************************************************************************
 * ���ܣ�		ͼƬ�洢�����ݿ���
 * ����ֵ��	��
 * ������		$TypeID		���
 * 			$InfoContextID	��ʱͼƬ�洢������ID
 * 			$savefile	ͼƬ�洢��·�����ļ���
 * 			$ADMINUSER	�����Ĺ����û�
 * 			size	�Ǵ�ͼƬ����СͼƬ
 * 			job_no	����ƥ���ͼ��Сͼ�洢��ͬһ����¼��
 * ************************************************************************************* */

function Pic_Save($TypeID, $InfoContextID, $savefile, $ADMINUSER, $size = 'small', $job_no = '') {
	global $mysql;
	$regtime = time();
	$fieldName = ( $size == "small" ) ? "PicSmall" : "PicBig";

	if ($TypeID == 13 || $TypeID == 28) {
		$table_info = TB_InfoContext_ZZLX;
		$table_pic = TB_InfoContentPic_ZZLX;
	} elseif ($TypeID == 1188) {
		$table_info = 'info_lxqs_trend';
		$table_pic = 'info_lxqs_trend_pic';
	} elseif ($TypeID == 1199) {
		$table_info = 'info_lxqs_trend_stopic';
		$table_pic = 'info_lxqs_trend_spic';
	} elseif ($TypeID == 1288) {
		$table_info = 'info_szfb_tshape';
		$table_pic = 'info_szfb_tshape_pic';
	} elseif ($TypeID == 1299) {
		$table_info = 'info_szfb_tshape_stopic';
		$table_pic = 'info_szfb_tshape_spic';
	} elseif ($TypeID == 1388) {
		$table_info = 'info_zzlx_invogue';
		$table_pic = 'info_zzlx_invogue_pic';
	} elseif ($TypeID == 1399) {
		$table_info = 'info_zzlx_invogue_stopic';
		$table_pic = 'info_zzlx_invogue_spic';
	} elseif ($TypeID == 4399) {
		$table_info = "info_taqs_tshape_stopic";
		$table_pic = "info_taqs_tshape_spic";
	} elseif ($TypeID == 4388) {
		$table_info = "info_taqs_tshape";
		$table_pic = "info_taqs_tshape_pic";
	} elseif ($TypeID == 11 || $TypeID == 22 || $TypeID == 36 || $TypeID == 37) {
		$table_info = TB_InfoContext_LXQS;
		$table_pic = TB_InfoContentPic_LXQS;
	} elseif ($TypeID == 12 || $TypeID == 81) {
		$table_info = TB_InfoContext_SZFB;
		$table_pic = TB_InfoContentPic_SZFB;
	} elseif ($TypeID == 24) {
		$table_info = TB_INFO_PV_BOOK;
		$table_pic = TB_INFO_PV_BOOK_PIC;
	} elseif ($TypeID == 25) {
		$table_info = TB_INFO_PV_TREND;
		$table_pic = TB_INFO_PV_TREND_PIC;
	} elseif ($TypeID == 45) {	  //����ţ��
		$table_info = TB_INFO_TA_ZTTA;
		$table_pic = TB_INFO_TA_ZTTA_PIC;
	} elseif ($TypeID == 1320) {	  //����ţ��
		$table_info = TB_INFO_ZZLX_HBNZ;
		$table_pic = TB_INFO_ZZLX_HBNZ_PIC;
	} else {
		$table_info = TB_InfoContext;
		$table_pic = InfoContentPic;
	}
	$isExists = false;
	$TypeID = substr($TypeID, 0, 2);
	if (!empty($job_no)) {
		$sql = "SELECT Count(JobNo) AS counter  FROM " . $table_pic . " WHERE JobNo = '{$job_no}'";
		$mysql->query($sql);
		if ($mysql->nextRecord()) {
			$isExists = ($mysql->r('counter') >= 1);
		}
	}
	if ($isExists == true) {
		$sql = "UPDATE " . $table_pic . " SET {$fieldName} = '{$savefile}',CategoryID='{$TypeID}' WHERE JobNo = '{$job_no}'";
		$JobNoSql = "UPDATE " . $table_pic . " SET JobNo = '' WHERE InfoID='{$InfoContextID}'";
	} else {
		$sql = "INSERT INTO " . $table_pic . "
						(CategoryID,
						InfoID,
				{$fieldName},
						JobNo,
						nUpDateTime,
						UserName)
							values
						('{$TypeID}',
						'{$InfoContextID}',
						'{$savefile}',
						'{$job_no}',
				{$regtime},
						'{$ADMINUSER}')";
	}
	$mysql->query($sql);
	if (!empty($JobNoSql)) {
		$mysql->query($JobNoSql);
	}
}

/* * ************************************************************************************
 * ���ܣ�		�����ID��������Ӧ�������������
 * ����ֵ��	�����������
 * ������		$Cid	���
 * ************************************************************************************ */

function GetCategory($Cid) {
	switch ($Cid) {
		case 11:
			return "��������";
			break;
		case 12:
			return "ʱװ����";
			break;
		case 13:
			return "��������";
			break;
		case 28:
			return "����";
			break;
		case 14:
			return "�ָ�����";
			break;
		case 15:
			return "�㳡/����";
			break;
		case 26:
			return "�г��۽�";
			break;
		case 16:
			return "�����鼮";
			break;
		case 17:
			return "������־";
			break;
		case 27:
			return "Ʒ�ƻ���";
			break;
		case 18:
			return "��ʽ";
			break;
		case 19:
			return "ͼ��";
			break;
		case 20:
			return "ʸ��ͼ";
			break;
		case 22:
			return "����";
			break;
		case 23:
			return "�Ҿӷ�";
			break;
		case 24:
			return "�鼮ͼ��";
			break;
		case 25:
			return "����ͼ��";
			break;
		case 36:
			return "��ͷʱ��";
			break;
		case 37:
			return "����/����";
			break;
		case 40:
			return "���ͼ��";
			break;
		case 45:
			return "����ͼ��";
			break;
		default:
			return false;
			break;
	}
}

/* * ************************************************************************************
 * ���ܣ�	��ʾ��ʾ��Ϣ
 * ����ֵ��	��
 * ������	$Title		Ҫ��ʾ�ڱ���ͷ������Ϣ
 * 			$Context	Ҫ��ʾ������
 * 			$Alink		Ҫ���ص�ҳ���ַ
 * *********************************************************************************** */

function ShowMsg($Title, $Context, $Alink) {
	echo <<<EOT
<table style="border: 1px solid #39867B;" cellSpacing="1" cellPadding="1"  width="60%" align="center" border="0">
<tbody>
	<tr style="background: url(../../Files/pic/topBar_bg.gif)">
		<td height="25">
		<p align="center"><b>&nbsp;{$Title}</b></p></td>
	</tr>
	<tr>
		<td height="160" style="background-color: #F6F3F3;">
		<p align="center"><font size="3">{$Context}</font></p></td>
	</tr>
EOT;
	if (Alink != "") {
		echo <<<EOT
	<tr>
		<td height="25" style="background-color: #F6F3F3;">
		<p align="center">
		<input type="button" value=" �� �� " name="B3" class="s02" onclick="window.location='{$Alink }'"></td>
	</tr>
EOT;
	}
	echo "</tbody></table>";
}

/* * ***********************************************************
  isManageRight �жϺ�̨�û��Ƿ���¼�������Ȩ��
 * ************************************************************ */

function isManageRight($UserName, $RightID) {
	global $mysql;
	$sql = "select RightID from " . TB_AdminUser . " where RightID like '%$RightID%' and UserName='$UserName'";
	$mysql->query($sql);
	if (!$mysql->nextRecord()) {
		sendback('�Բ�����û��ִ�д˳����Ȩ��,����ϵ��������ͨ');
	}
}

/* * ************************************************************************************
 * ���ܣ�	�ж���ʾʱ��
 * ����ֵ��	true:���³�����ʾͼƬ	false:���ϳ�����ʾͼƬ
 * ������	$PicTime	ͼƬ��ʱ��
 * *********************************************************************************** */

function PicPath($PicTime) {
	$ChkTime = "2007-07-10";
	$ChkTime = strtotime($ChkTime);
	if ($PicTime > $ChkTime) {
		return "true";
	} else {
		return "false";
	}
}

/* * ************************************************************************************
 * ���ܣ�	��¼��־
 * ����ֵ��	void
 * ������
 * *********************************************************************************** */

function LoginLog($pUserName, $pUserType, $cpu_info, $hd_info, $net_info, $pc_id, $pc_name, $soft_ver='', $pc_type='',$login_ip='') {
	global $mysql;
	$regtime = date("Y-m-d H:i:s");
	$LoginIP = $login_ip ? $login_ip : $_SERVER["REMOTE_ADDR"];
	$ipads = $_SERVER['HTTP_USER_AGENT'];
	/* 	if(strstr($ipads, 'iPad')) {
	  $cpu_info = $hd_info = $net_info = $pc_id = $pc_name = 'iPad';
	  } */
	$sql = "insert into " . TB_LoginLog . "
							(UserName,UserType,LoginIP,cpu_info,hd_info,
								net_info,pc_id,pc_name,soft_ver,pc_type,UpdateTime)
					values ('$pUserName', '$pUserType', '$LoginIP', '$cpu_info', '$hd_info',
								'$net_info', '$pc_id','$pc_name','$soft_ver','$pc_type', '$regtime')";
	$mysql->query($sql);
	if ($pUserType == "user") {
		$mysql->query("update " . TB_VIPClient . " set LoginLog=LoginLog+1, nLoginTime = unix_timestamp(CURRENT_TIMESTAMP) where UserName='$pUserName'");
	}
	if ($pUserType == "admin") {
		$mysql->query("update " . TB_AdminUser . " set LoginLog=LoginLog+1 where UserName='$pUserName'");
	}
}

/* * ************************************************************************************
 * ���ܣ�	�û�CPU��Ϣ��Ӳ����Ϣ��������Ϣ�������������Ϣ�Ĵ洢
 * ����ֵ��	void
 * ������
 * ��ע���˺���ֻ��������¼��Ч
 * *********************************************************************************** */

function user_pcid_info($UserName, $cpu_info, $hd_info, $net_info, $pc_id, $pc_name) {
	global $mysql;
	$ipads = $_SERVER['HTTP_USER_AGENT'];
	/* if(strstr($ipads, 'iPad')) {
	  $cpu_info = $hd_info = $net_info = $pc_id = $pc_name = 'iPad';
	  } */
	$sSQL = " where UserName='$UserName' ";
	$sSQL = $sSQL . " and cpu_info = '$cpu_info'";
	$sSQL = $sSQL . " and net_info = '$net_info'";
	$sSQL = $sSQL . " and pc_name = '$pc_name'";
	$mysql->query("select ID from UserPcidInfo " . $sSQL);
	if (!($mysql->nextRecord())) {
		$sql = "insert into UserPcidInfo
						(UserName,cpu_info,hd_info,net_info,pc_id,pc_name)
					values (
						'$UserName', '$cpu_info', '$hd_info', '$net_info','$pc_id','$pc_name')";
		$mysql->query($sql);
	}
}

/* * ************************************************************************************
 * ���ܣ�	�û�CPU��Ϣ��Ӳ����Ϣ��������Ϣ�������������Ϣ�Ĵ洢
 * ����ֵ��	void
 * ������
 * ��ע���˺���ֻ��ҳ���¼��Ч
 * *********************************************************************************** */

function user_info($UserName, $cpu_info, $hd_info, $net_info, $pc_name) {
	global $mysql;
	$ipads = $_SERVER['HTTP_USER_AGENT'];
	/* if(strstr($ipads, 'iPad')) {
	  $cpu_info = $hd_info = $net_info = $pc_id = $pc_name = 'iPad';
	  } */
	$sSQL = " where UserName='$UserName' ";
	$sSQL = $sSQL . " and cpu_info = '$cpu_info'";
	$sSQL = $sSQL . " and hd_info = '$hd_info'";
	$sSQL = $sSQL . " and net_info = '$net_info'";
	$sSQL = $sSQL . " and pc_name = '$pc_name'";
	$mysql->query("select ID from user_info " . $sSQL);
	if (!($mysql->nextRecord())) {
		$sql = "insert into " . TB_UserInfo . "
						(UserName,cpu_info,hd_info,net_info,pc_name)
					values (
						'$UserName', '$cpu_info', '$hd_info', '$net_info', '$pc_name')";
		$mysql->query($sql);
	}
}

//*********************************************
//CheckVipRight �жϻ�Ա��״̬
//*********************************************/
function CheckVipRight1($aryAll, $aryUser) {
	$countAryAll = count($aryAll);
	for ($i = 0; $i < $countAryAll; $i++) {
		$check = 1;
		#if($aryAll[$i]["pc_id"]!=$aryUser["pc_id"] || $aryAll[$i]["pc_id"]==''){
		if ($aryAll[$i]["cpu_check"]) {
			if (trim($aryAll[$i]["cpu_info"]) != trim($aryUser["cpu_info"])) {
				continue;
			}
		}
//		if($aryAll[$i]["hd_check"]) {
//			if(trim($aryAll[$i]["hd_info"])!=trim($aryUser["hd_info"])) {
//				continue;
//			}
//		}
		if ($aryAll[$i]["net_check"]) {
			if (trim($aryAll[$i]["net_info"]) != trim($aryUser["net_info"])) {
				continue;
			}
		}
		#}
		if ($check)
			return 1;
	}
	return 0;
}

//*********************************************
//ShowVipRight �жϻ�Ա��״̬��vip���͵����յ�
//*********************************************/
function ShowVipRight($UserName) {
	global $mysql, $net_info, $Pc_ID, $cpu_info, $hd_info;
	$mysql2 = new MySql(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
	$sql = "select nUpdateTime,nVipType,nValidTime,VipRight,buy_click,gift_click,biz_staff,crm_staff From " . TB_VIPClient . " where UserName='$UserName'  ";
	$mysql->query($sql);
	if ($mysql->nextRecord()) {
		$Return['nUpdateTime'] = $mysql->record['nUpdateTime'];
		$nVipType = $mysql->record['nVipType'];
		$nVipTime = date("Y-m-d", $mysql->record['nValidTime']);
		$Return["gift_click"] = $mysql->record['gift_click'];
		$Return["buy_click"] = $mysql->record['buy_click'];
		//�����û����ĸ���Ŀ��Ȩ�� 211=Ůװ����������
		$Return["sVipRight"] = $mysql->record['VipRight'];
		$Return["crm_staff"] = $mysql->record['crm_staff'];
		$Return["biz_staff"] = $mysql->record['biz_staff'];
		$nTime = time();
		if ($nVipType > 1) {
			if ($nTime > $mysql->record['nValidTime']) {
				$expired = "�ѹ���";
			} else {
				//���Ϊ1��δ����
				$Return["sVipTime"] = 1;
				$ExpiredDate = "";
			}
		}

		$ipads = $_SERVER['HTTP_USER_AGENT'];
		/* if(strstr($ipads, 'iPad')) {
		  $cpu_info = $hd_info = $net_info = $pc_id = $pc_name = 'iPad';
		  } */
		$aryUser = array("cpu_info" => $cpu_info, "hd_info" => $hd_info, "net_info" => $net_info, 'pc_id' => $Pc_ID);
		//print_r($aryUser);
		//ͨ����ǰ�û���ҵ��Ա��Ϣ��ȡ��ɫ���ж��Ƿ��÷��������Ա������ǿͷ�������ͨ�����ã����ü�������Ϣ
		$arr_role = $mysql2->selectOne("select roleid from crm_fs.crm_member_bak where username='" . $Return["crm_staff"] . "'");
		$roleid = isset($arr_role['roleid']) ? $arr_role['roleid'] : '';

		if ($Return["biz_staff"]) {
			$arr_role_kf = $mysql2->selectOne("select roleid from crm_fs.crm_member_bak where username='" . $Return["biz_staff"] . "'");
			$roleid_kf = isset($arr_role_kf['roleid']) ? $arr_role_kf['roleid'] : '';
		}
		//echo "select roleid from crm_fs.crm_member_bak where username='".$Return["crm_staff"]."'"."<br>";
		//echo '$roleid = '.$roleid;
		//�ж���������¼������ҳ���¼
		$arr_nvip = array(2, 3, 4, 5, 10);
		$role_free = array('7', '9', '16', '23', '24');
		if (in_array($nVipType, $arr_nvip) AND (in_array($roleid_kf, $role_free) || in_array($roleid, $role_free))) {
			$Return["sVipNet"] = 1;
		} else {
			if (!empty($Pc_ID)) {
				//print_r($aryUser);
				$aryAll = $mysql2->arrQuery("select pc_id,cpu_info,hd_info,net_info,net_check,hd_check,cpu_check from UserPcidInfo where UserName='$UserName' and StatusLog='1' ");
				if (count($aryAll)) {
					if (CheckVipRight1($aryAll, $aryUser)) {
						$Return["sVipNet"] = 1;
					} else {
						$authorization = "<a href='#' onclick=\"ShowModal('noVip');\"><font color=#FF0000>δ��Ȩ</font></a>";
						$authorization_buy = "δ��Ȩ";
					}
				} else {
					$authorization = "<a href='#' onclick=\"ShowModal('noVip');\"><font color=#FF0000>δ��Ȩ</font></a>";
					$authorization_buy = "δ��Ȩ";
				}
			} else {
				if ($UserName == 'jackie18' && in_array($_SERVER['REMOTE_ADDR'], array('210.177.71.65'))) {
					$Return["sVipNet"] = 1;
				} else {
					if (empty($net_info)) {
						$NetInfo = "<font color=#FF0000>[δ��װ���]</font>";
					} else {
						//$mysql2->query("select net_info from user_info where UserName='$UserName' and net_info='$net_info' and StatusLog='1' ");
						$aryAll = $mysql2->arrQuery("select cpu_info,hd_info,net_info,net_check,hd_check,cpu_check from user_info where UserName='$UserName' and StatusLog='1' ");
						if (count($aryAll)) {
							if (CheckVipRight1($aryAll, $aryUser)) {
								$Return["sVipNet"] = 1;
							} else {
								$authorization = "<a href='#' onclick=\"ShowModal('noVip');\"><font color=#FF0000>����δ��Ȩ</font></a>";
								$authorization_buy = "����δ��Ȩ";
							}
						} else {
							$authorization = "<a href='#' onclick=\"ShowModal('noVip');\"><font color=#FF0000>����δ��Ȩ</font></a>";
							$authorization_buy = "����δ��Ȩ";
						}
					}
				}
			}
		}
//������ҳ���¼����
		$sVipType = array(
			0 => "���", 1 => "���", 2 => "��װ����vip", 3 => "Ůװ����vip", 4 => "ͯװ����vip", 5 => "��ʯ����vip", 6 => "��װvip", 7 => "Ůװvip", 8 => "ͯװvip", 9 => "��ʯvip", 10 => "��������vip", 11 => "����vip"
		);
		//VIP���ͣ���װVIP��ŮװVIP������VIP��
		$Return["sVipType"] = $nVipType;
		$ApplyVip = ($nVipType == 0 || $nVipType == 1) ? "  <a href='/App/user/UserModify.php?apply=tryout' title='����VIP����'>����VIP����</a>" : "";

		if ($nVipType > 5) {
			$h24 = time() - 86400;
			$sql = 'SELECT uid FROM ' . TB_VIPClient . " WHERE UserName = '$UserName'";
			$uInfo = $mysql->getRow($sql);
			$sql = "SELECT count(1) as c FROM fs_member_message WHERE send_uid='{$uInfo['uid']}' AND reply_id>0 AND is_see=0 AND is_show = 0";
			$row1 = $mysql->getRow($sql);
			$sql = "SELECT count(1) as c FROM fs_member_message WHERE send_uid='{$uInfo['uid']}' AND is_system=1 AND is_see=0 AND is_show = 0";
			$row2 = $mysql->getRow($sql);
			$mtotal = $row1['c'] + $row2['c'];
			if ($mtotal > 0) {
				$mailstr = "&nbsp;(<a href='/member/?act=information&oct=message&l=inbox&see=0' style='color: red;'><strong>��Ϣ{$mtotal}��</strong></a>)";
			}
		}

		$Return['sVipWord_buy']['power'] = iconv('GBK', 'UTF-8', $sVipType[$nVipType]);
		$Return['sVipWord_buy']['expire'] = iconv('GBK', 'UTF-8', $ExpiredDate . $expired);
		$Return['sVipWord_buy']['netinfo'] = iconv('GBK', 'UTF-8', trim($authorization) != "" ? 'no_power' : (trim($NetInfo) != "" ? 'δ��װ���' : ''));
		$Return['sVipWord_buy']['mail_count'] = $mtotal;
		$Return['sVipWord_buy']['vip'] = iconv('GBK', 'UTF-8', $ApplyVip);
		$Return["sVipWord"] = "����Ȩ��[" . $sVipType[$nVipType] . $authorization . "]," . $ExpiredDate . $expired . $NetInfo . " <i><a href='/member'>�ҵĵ�Ѷ</a></i>" . $ApplyVip . $mailstr;
		Return $Return;
	}
}

/* * ********************************************************
 *  �ж��û��Ƿ������Ȩ��,����͡�ShowVipRight�������ʹ��
 * �����ʺϡ���ʽ��ר�����ж�
 * ********************************************************* */

function VipTitleRight($UserName, $Sex, $Cid, $ShowVip) {
	if ($ShowVip["sVipNet"] != 1) {
		return "����δ��Ȩ";
	}
	if ($ShowVip["sVipTime"] != 1) {
		return "Ȩ���ѹ���";
	}
	//ʱװ������81��12��һ����Ȩ��
	if ($Cid == 81)
		$Cid = 12;
	$ThisRight = $Sex . $Cid;
	$AllRight = explode(",", $ShowVip["sVipRight"]);
	if (empty($ThisRight) || !in_array($ThisRight, $AllRight)) {
		return "��û�д���Ŀ��Ȩ��";
	}
	return "true";
}

function FindFile($Cid) {
	$FileArr = array(
		"11" => "/App/popular/trend",
		"12" => "/App/fashion/catwalk",
		"13" => "/App/popular/invogue",
		"14" => "/App/book/designtrend",
		"15" => "/App/book/showcase",
		"16" => "/App/book/book",
		"17" => "/App/book/magazine",
		"18" => "/App/style/style",
		"19" => "/App/style/printing",
		"20" => "/App/style/vector",
		"21" => "/App/style/original",
		"22" => "/App/popular/accessory",
		"23" => "/App/popular/homewear",
		"28" => "/App/popular/display"
	);
	return $FileArr[$Cid];
}

/* * ************************************************************************************
 * ���ܣ�	���û����ʵ��������+1����
 * ����ֵ��	void
 * ������
 * *********************************************************************************** */

function AccessCount($InfoID) {
	global $mysql, $Cid;
	if ($Cid == 13 || $Cid == 28) {
		$table = TB_InfoContext_ZZLX;
	} elseif ($Cid == 11 || $Cid == 22) {
		$table = TB_InfoContext_LXQS;
	} elseif ($Cid == 12 || $Cid == 81) {
		$table = TB_InfoContext_SZFB;
	} elseif ($Cid == 24) {
		$table = TB_INFO_PV_BOOK;
	} elseif ($Cid == 25) {
		$table = TB_INFO_PV_TREND;
	} elseif (18 == $Cid) {
		mysql_select_db("style_info");
		$table = info_ssks;
	} elseif (36 == $Cid) {
		$table = TB_InfoContext_LXQS;
	} elseif (37 == $Cid) {
		$table = TB_InfoContext_LXQS;
	} else {
		$table = TB_InfoContext;
	}
	$s_date = date("h");
	if ($s_date >= 9 && $s_date <= 17) {
		$s_num = rand(2, 3);
	} else {
		$s_num = 1;
	}
	if ($Cid == 13) {
		$sql = "UPDATE " . $table . " SET AccessCount = AccessCount + 1, mycount = mycount + {$s_num} WHERE ID='{$InfoID}'";
	} else {
		$sql = "UPDATE " . $table . " SET AccessCount = AccessCount + 1, mycount = mycount + {$s_num} WHERE ID=\'{$InfoID}\'";
		$add_time = time();
		$sql = "INSERT INTO " . DB_DATABASE . ".tmp_sql (query_sql, add_time) VALUES('$sql', $add_time)";
	}
	try {
		$mysql->query($sql);
	} catch (Exception $e) {
		return false;
	}
}

/* * ************************************************************************************
 * ���ܣ�	�û������������
 * ����ֵ��	void
 * ������
 * *********************************************************************************** */

function Feedback($UserName, $UrlAddress, $Contact, $Content, $MailTo="admin@sxxl.com,sxxl@sxxl.com") {
	global $mysql;
	$UrlAddress = $_SERVER["HTTP_REFERER"];
	$Subject = "���ʷ���������� �û������ʼ�";
	$AddTime = time();
	$IpAddress = $_SERVER["REMOTE_ADDR"];
	if (empty($Content) || empty($Contact)) {
		sendalert("������������ϵ��ʽ����Ϊ�գ�");
		echo "<script type='text/javascript'>window.location='/App/service/suggestion.php';</script>";
		exit;
	}
	$UrlAddress = empty($UrlAddress) ? $_SERVER["SCRIPT_NAME"] : $UrlAddress;
	$sql = "INSERT INTO " . TB_Feedback . " (IpAddress, UrlAddress, AddTime, Contact, Content,UserName) VALUES ('{$IpAddress}', '{$UrlAddress}', {$AddTime}, '{$Contact}', '{$Content}', '{$UserName}')";
	$mysql->query($sql);
	//�����ʼ���
//	$MailContent = "�û���{$UserName}
//	��ϵ��ʽ��{$Contact}
//	�ύ�����ҳ�棺{$UrlAddress}
//	����/�������ݣ�
//	    {$Content}";
//	mail($MailTo, $Subject, $MailContent);
	$subject = "���ʷ���������� �û������ʼ�(www.sxxl.cn)";
	$time = date("Y-m-d H:i:s");
	$message = "
					�û���{$UserName}
	��ϵ��ʽ��{$Contact}
	�ύ�����ҳ�棺{$UrlAddress}
	����/�������ݣ�
			{$Content}
	����ʱ�䣺{$time}";
	$from = "yxy@sxxl.com";
	$to = array("yxy@sxxl.com"); //�ռ��˵ĵ�ַ(���Ͷ�������ں�̨���ӣ�);
	$to_arr = "yxy@yxy.com";   //�ʼ�ͷ�ϵ��ռ���;
	$params["host"] = "mail.sxxl.com";	//�ʼ�������;
	$params["port"] = 25;	   //�ʼ��˿�;
	$params["helo"] = exec("mail.sxxl.com");  //��
	$params["auth"] = TRUE;
	$params["user"] = $from;
	$params["pass"] = "yxyyxy";
	$send_params["recipients"] = $to;  //�ռ���;
	$send_params["headers"] = array(//�ʼ�ͷ��Ϣ;
		"From: '�ͻ�����' <{$from}>",
		"To: {$to_arr}",
		"Subject: {$subject}"
	);
	$send_params["body"] = "{$message}";   //�ʼ�����;
	$smtp = smtp::connect($params);
	if ($smtp->send($send_params)) {
		return true;
	} else {
		print_r($smtp->errors);
		exit;
		return false;
	}
}

function SearchSave($SearchType='Keyword', $arrParameter) {
	global $mysql;
	$UserName = $arrParameter["UserName"];
	$SearchType = $SearchType;
	$Keyword = $arrParameter["Keyword"];

	$SearchResult = $arrParameter["SearchResult"];
	$SeasonID = $arrParameter["SeasonID"];
	$Cid = $arrParameter["Cid"];

	$CityID = $arrParameter["CityID"];
	$ClassID = $arrParameter["ClassID"];
	$BookID = $arrParameter["BookID"];

	$DesignerID = $arrParameter["DesignerID"];
	$BrandID = $arrParameter["BrandID"];
	$Sex = $arrParameter["Sex"];

	$SearchTime = time();
	$SearchIP = $_SERVER["REMOTE_ADDR"];
	$SearchUrl = $_SERVER["HTTP_REFERER"];
	if ($SearchType == 'Keyword') {
		$sql = "INSERT INTO SearchKeyword (UserName, SearchType, SearchUrl, Keyword, SearchResult, SearchTime, SearchIP)
							VALUES (
								'{$UserName}',
								'0',
								'{$SearchUrl}',
								'{$Keyword}',
								'{$SearchResult}',
				{$SearchTime},
								'{$SearchIP}'
							)";
		$mysql->query($sql);
	} else {
		$sql = "INSERT INTO SearchKeyword (UserName, SearchType, Cid, SearchUrl, SeasonID, CityID, ClassID, BookID, DesignerID, BrandID, SearchResult, Sex, SearchTime, SearchIP)
							VALUES (
								'{$UserName}',
								'1',
								'{$Cid}',
								'{$SearchUrl}',
								'{$SeasonID}',
								'{$CityID}',
								'{$ClassID}',
								'{$BookID}',
								'{$DesignerID}',
								'{$BrandID}',
								'{$SearchResult}',
								'{$Sex}',
				{$SearchTime},
								'{$SearchIP}'
							)";
		$mysql->query($sql);
	}
}

function PhpAlert($Title='ϵͳ��ʾ', $Message='ϵͳ��ʾ', $Confirm="ȷ��", $Width=400, $Height=50) {
	if (!empty($Confirm)) {
		$str1 .= "<tr><td height='40px' align='center' style='background-color:#EEF2F6;'>";
		$str1 .= "{$Confirm}";
		$str1 .= "</td></tr>";
	}
	$str = <<<str
	<center>
	<div style='width:{$Width}; height:{$Height}; border:1px solid #EFEFEF' id='Alert'>
	<table width='{$Width}'>
	<tr><td height='25px' align='left' style='background-color:#F7F7F7;'>
			{$Title}
	</td></tr>
	<tr><td height='60px' align='left' style='padding-left: 20px;'>
			{$Message}
	</td></tr>
			{$str1}
	</table>
	</div>
	</center>
str;
	echo $str;
}

function show_pic_path($str, $flog = '') {
	//����ͼƬ�ַ����ж�ͼƬ����ʲôĿ¼��!2007_data�»���2008_data��data��
	//����ͼƬ
	$str = str_replace('/data_brand/../../', '', $str);
	$str = str_replace('http://www.sxxl.com', '', $str);
	$str = str_replace('http://hz.sxxl.com', '', $str);
	$str = str_replace('http://edit.sxxl.cn', '', $str);
	$str = str_replace('/App/sxxlAdmin/eWeb', '', $str);

	$group_domain = array(
		array(
			//news/ 0
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//data/ 1
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//data_brand/ 2
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2007_data/ 3
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2009_data/ 4
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2009_data2/ 5
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2010_2/ 6
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img4.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img4.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img4.f.sxxl.com/',
		),
		array(
			//2011 7
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img4.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img4.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img4.f.sxxl.com/',
		),
		array(
			//2010 8
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2009,2009_data2 9
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2011_2 10
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2012 11
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
			'http://img2.f.sxxl.com/',
			'http://img3.f.sxxl.com/',
			'http://img1.f.sxxl.com/',
		),
		array(
			//2012_2 12
			'http://img5.f.sxxl.com/',
			'http://img6.f.sxxl.com/',
			'http://img7.f.sxxl.com/',
			'http://img8.f.sxxl.com/',
			'http://img5.f.sxxl.com/',
			'http://img6.f.sxxl.com/',
			'http://img7.f.sxxl.com/',
			'http://img8.f.sxxl.com/',
			'http://img5.f.sxxl.com/',
			'http://img5.f.sxxl.com/',
		),
		'2012_3' => array(
			//2012_2 13
			'http://img5.f.sxxl.com/',
			'http://img6.f.sxxl.com/',
			'http://img7.f.sxxl.com/',
			'http://img8.f.sxxl.com/',
			'http://img5.f.sxxl.com/',
			'http://img6.f.sxxl.com/',
			'http://img7.f.sxxl.com/',
			'http://img8.f.sxxl.com/',
			'http://img5.f.sxxl.com/',
			'http://img5.f.sxxl.com/',
		)
	);
	$str = str_replace("../", "", $str);
	//$old_str	= (empty($flog)?'/news/':'/data/') . $str;
	$old_str = $str;
	if (strstr($str, "2007_data/") || strstr($str, "2009_data/") || strstr($str, "2009_data2/") || strstr($str, '2009/') || strstr($str, '2010/') || strstr($str, '2010_2/') || strstr($str, '2011/') || strstr($str, '2011_2/') || strstr($str, '2012/') || strstr($str, '2012_2/') || strstr($str, '2012_3/')) {
		//$s_str = "../../" . $str;
		$s_str = $str;

		if (strstr($s_str, '2011_2/')) {
			$img_d = $group_domain[10][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}
		if ((strstr($s_str, '2011/') && stripos($s_str, '2011/') < 5)) {
			$img_d = $group_domain[7][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}
		if (strstr($s_str, '2010_2/')) {
			$img_d = $group_domain[6][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}
		if (strstr($s_str, '2010/') && stripos($s_str, '2010/') < 5) {
			$img_d = $group_domain[8][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}
		if ((strstr($s_str, '2009/') && stripos($s_str, '2009/') < 5) || strstr($s_str, '2009_data2/') || strstr($s_str, '2009_data/')) {
			//$s_str = 'http://img0.f.sxxl.com/' . $s_str;
			$img_d = $group_domain[9][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}

		if (strstr($s_str, '2007_data/')) {
			$img_d = $group_domain[3][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}
		if (strstr($s_str, '2012/')) {
			$img_d = $group_domain[11][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}
		if (strstr($s_str, '2012_2/')) {
			$img_d = $group_domain[12][rand(0, 9)];
			$s_str = $img_d . $s_str;
			return $s_str;
		}
		if (strstr($s_str, '2012_3/')) {
			$tmp_dir = date('YmdH');
			$tmp_dir1 = $tmp_dir - 1;
			$tmp_dir2 = $tmp_dir1 - 1;
			if (strstr($s_str, '/' . $tmp_dir) || strstr($s_str, '/' . $tmp_dir1) || strstr($s_str, '/' . $tmp_dir2)) {
				$s_str = 'http://img0.f.sxxl.com/' . $s_str;
			} else {
				$img_d = $group_domain['2012_3'][rand(0, 9)];
				$s_str = $img_d . $s_str;
			}
			return $s_str;
		}
	} else {
		$s_str = $old_str;
		if (strstr($s_str, 'data_brand/')) {
			$img_d = $group_domain[2][rand(0, 9)];
			$s_str = $img_d . $s_str;
		} else if (strstr($s_str, 'data/')) {
			$img_d = $group_domain[1][rand(0, 9)];
			$s_str = $img_d . $s_str;
		} else if (strstr($s_str, 'pattern/') || strstr($s_str, 'v/') || strstr($s_str, 'm/') || strstr($s_str, 'w/') || strstr($s_str, 'c/')) {
			$img_d = $group_domain[1][rand(0, 9)];
			$s_str = $img_d . 'data/' . $s_str;
		} else if (strstr($s_str, 'news/')) {
			$img_d = $group_domain[0][rand(0, 9)];
			$s_str = $img_d . $s_str;
		} else {
			$img_d = $group_domain[0][rand(0, 9)];
			$s_str = $img_d . 'news/' . $s_str;
		}
	}
	return $s_str;
}

/**
 * ��ȡ����·��
 * @param string �ļ�·��
 * @return string
 */
function get_down_path($str, $type=null) {
	if ($type) {
		$path = 'http://download.sxxl.com/download_new.php?d=' . $str;
	} else {
		$path = 'http://download.sxxl.com/download.php?d=' . $str;
	}
	return $path;
}

/**
 * ��ȡ��������
 * @param array $info ����
 * @return string
 */
function get_down_url($info) {
	global $ShowVip, $mysql;
	$file_table = DB_DATABASE . '.fs_download';
	$info["type"] = empty($info["type"]) ? 0 : $info["type"];
	$where = "cid = '{$info["cid"]}' AND tid = '{$info["tid"]}' AND stype = '{$info["type"]}'";
	$sql = "SELECT file_path FROM $file_table WHERE $where";
	$row = $mysql->getRow($sql);
	$link = '';
	if ($row) {
		$ip = !isset($_SERVER["HTTP_CDN_SRC_IP"]) ? get_ip() : $_SERVER["HTTP_CDN_SRC_IP"];
		$txt = "cid={$info["cid"]}&id={$info["tid"]}&type={$info["type"]}&username={$_COOKIE["SxxlUserNameLogin"]}&ip=" . md5($ip);
		$code = urlencode(authcode($txt, 'ENCODE'));
		if ($ShowVip["sVipType"] > 5) {
			$down_url = !empty($row["file_path"]) ? get_down_path($code, 1) : '';
			$link = "<a href='{$down_url}' title='������ȫ��ͼƬ�������'><img src='/Files/images/download.jpg' alt='ͼƬ�������' /></a>";
		}
	}
	return $link;
}

function dir_path($dirpath) {
	$dirpath = str_replace('\\', '/', $dirpath);
	if (substr($dirpath, -1) != '/')
		$dirpath = $dirpath . '/';
	return $dirpath;
}

function dir_create($path, $mode = 777) {
	if (is_dir($path))
		return TRUE;
	$dir = str_replace(WWWURL, '', $path);
	if (substr($path, -5) != ".html") {
		$dir = dir_path($dir);
	}
	$temp = explode('/', $dir);
	$cur_dir = "";
	$max = count($temp) - 1;
	for ($i = 0; $i < $max; $i++) {
		$cur_dir .= $temp[$i] . "/";
		if (is_dir($cur_dir))
			continue;
		mkdir($cur_dir, 0777);
		@chmod($cur_dir, 0777);
	}
	return is_dir($path);
}

/**
 * ����������ͳ��
 * @param int $cid  ��ĿID��������ĿIDѡ�����ݱ�
 * @param int $tid  ����ID
 * @param int $sid  ����ID
 */
function addpv($cid, $tid, $sid = '') {
	global $mysql;
	switch ($cid) {
		case 11:
			$table = TB_INFO_LXQS_TREND;
			break;
		case 12:
			$table = TB_INFO_SZFB_TSHAPE;
			break;
		case 13:
			$table = TB_INFO_ZZLX_INVOGUE;
			break;
		default:
			$table = TB_INFO_LXQS_TREND;
			break;
	}
	$sql = "UPDATE {$table} SET AccessCount = AccessCount + 1, mycount = mycount + 1 WHERE ID='{$tid}'";
	$mysql->query($sql);
}

/**
 * ȡ�õ�ǰ�����û���IP��ַ
 * @return string
 */
function get_ip() {
	if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$onlineip = getenv('HTTP_CLIENT_IP');
	} elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$onlineip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$onlineip = getenv('REMOTE_ADDR');
	} elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$onlineip = $_SERVER['REMOTE_ADDR'];
	} else {
		$onlineip = 'unknown';
	}
	return $onlineip;
}

/**
 * �ַ�������
 * @param   $string     ����ܵ��ַ�
 * @param   $operation  ���ܻ����
 * @param   $key        ��վ����key����ֹ�ƽ�
 * @return  string
 */
function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {
	$ckey_length = 4;
	$key = md5($key ? $key : '^D@i#e$X%u^n$');
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length) : substr(md5(microtime()), -$ckey_length)) : '';

	$cryptkey = $keya . md5($keya . $keyc);
	$key_length = strlen($cryptkey);

	$string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb), 0, 16) . $string;
	$string_length = strlen($string);

	$result = '';
	$box = range(0, 255);

	$rndkey = array();
	for ($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}

	for ($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}

	for ($a = $j = $i = 0; $i < $string_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}

	if ($operation == 'DECODE') {
		if ((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc . str_replace('=', '', base64_encode($result));
	}
}

/**
 * ͼƬ�ӷ���ˮӡ
 * @param string $bigpic ͼƬԭʼURL
 * @param int ��Աע��ʱ��(��ˮӡ����)
 * @return string ��ˮӡͼƬ��ʱ��ַ
 */
function addwatermark($bigpic, $vipid) {
	if (empty($bigpic))
		return false;
	$bigpic = str_replace('../', '', $bigpic);
	if (!file_exists(ROOT_PATH . $bigpic)) {
		$new_tmp_pic = show_pic_path($bigpic);
	} else {
		$bigpic = str_replace("../", "", $bigpic);
		$big_pic_arr = explode("/", $bigpic);
		$new_pic_url = $big_pic_arr[count($big_pic_arr) - 1];
		$new_pic_url = substr($new_pic_url, 0, -4);
		$new_pic_url = md5($new_pic_url . $vipid) . '.jpg';
		$middle_path = date("Ymd");
		$new_pic_dir = 'tmp_images/' . $middle_path . '/' . $big_pic_arr[count($big_pic_arr) - 4] . '/' . $big_pic_arr[count($big_pic_arr) - 3] . '/' . $big_pic_arr[count($big_pic_arr) - 2];
		if (!file_exists(ROOT_PATH . $new_pic_dir)) {
			dir_create(ROOT_PATH . $new_pic_dir, 0777);
		}
		$new_pic_path = $new_pic_dir . '/' . $new_pic_url;
		if (!file_exists(ROOT_PATH . $new_pic_path)) {
			@copy(ROOT_PATH . $bigpic, ROOT_PATH . $new_pic_path);
			IWaterMark(ROOT_PATH . $new_pic_path, 0, "", $vipid . rand(100, 999), 1, "#C6C6C6");
		}
		$new_tmp_pic = 'http://www.sxxl.cn/' . $new_pic_path;
	}
	return $new_tmp_pic;
}

/**
 * ��ͼƬ��ˮӡ
 * @param string $groundImage ��Ҫ��ˮӡ��ԭͼ
 * @param int $waterPos ��ˮӡ��λ��
 * @param string $waterImage ͼƬˮӡ�ĵ�ַ
 * @param string $waterText ����ˮӡ����
 * @param string $textFont �����С
 * @param string $textColor ����ɫ
 */
function IWaterMark($groundImage, $waterPos=0, $waterImage="", $waterText="", $textFont=5, $textColor="#FF0000") {
	$isWaterImage = FALSE;
	$formatMsg = "�ݲ�֧�ָ��ļ���ʽ������ͼƬ����������ͼƬת��ΪGIF��JPG��PNG��ʽ��";

	//��ȡˮӡ�ļ�
	if (!empty($waterImage) && file_exists($waterImage)) {
		$isWaterImage = TRUE;
		$water_info = getimagesize($waterImage);
		$water_w = $water_info[0]; //ȡ��ˮӡͼƬ�Ŀ�
		$water_h = $water_info[1]; //ȡ��ˮӡͼƬ�ĸ�

		switch ($water_info[2]) {//ȡ��ˮӡͼƬ�ĸ�ʽ
			case 1:$water_im = imagecreatefromgif($waterImage);
				break;
			case 2:$water_im = imagecreatefromjpeg($waterImage);
				break;
			case 3:$water_im = imagecreatefrompng($waterImage);
				break;
			default:die($formatMsg);
		}
	}

	//��ȡ����ͼƬ
	if (!empty($groundImage) && file_exists($groundImage)) {
		$ground_info = getimagesize($groundImage);
		$ground_w = $ground_info[0]; //ȡ�ñ���ͼƬ�Ŀ�
		$ground_h = $ground_info[1]; //ȡ�ñ���ͼƬ�ĸ�

		switch ($ground_info[2]) {//ȡ�ñ���ͼƬ�ĸ�ʽ
			case 1:$ground_im = imagecreatefromgif($groundImage);
				break;
			case 2:$ground_im = imagecreatefromjpeg($groundImage);
				break;
			case 3:$ground_im = imagecreatefrompng($groundImage);
				break;
			default:die($formatMsg);
		}
	} else {
		die("��Ҫ��ˮӡ��ͼƬ�����ڣ�");
	}

	//ˮӡλ��
	if ($isWaterImage) {//ͼƬˮӡ
		$w = $water_w;
		$h = $water_h;
		$label = "ͼƬ��";
	} else {//����ˮӡ
		$temp = imagettfbbox(ceil($textFont * 2.5), 0, "/usr/X11R6/lib/X11/fonts/truetype/simsun.ttc", $waterText); //ȡ��ʹ�� TrueType ������ı��ķ�Χ
		$w = $temp[2] - $temp[6];
		$h = $temp[3] - $temp[7];
		unset($temp);
		$label = "��������";
	}
	if (($ground_w < $w) || ($ground_h < $h)) {
		echo "��Ҫ��ˮӡ��ͼƬ�ĳ��Ȼ���ȱ�ˮӡ" . $label . "��С���޷�����ˮӡ��";
		return;
	}
	switch ($waterPos) {
		case 0://���
			$posX = rand(0, ($ground_w - $w));
			$posY = rand(0, ($ground_h - $h));
			break;
		case 1://1Ϊ���˾���
			$posX = 0;
			$posY = 0;
			break;
		case 2://2Ϊ���˾���
			$posX = ($ground_w - $w) / 2;
			$posY = 0;
			break;
		case 3://3Ϊ���˾���
			$posX = $ground_w - $w;
			$posY = 0;
			break;
		case 4://4Ϊ�в�����
			$posX = 0;
			$posY = ($ground_h - $h) / 2;
			break;
		case 5://5Ϊ�в�����
			$posX = ($ground_w - $w) / 2;
			$posY = ($ground_h - $h) / 2;
			break;
		case 6://6Ϊ�в�����
			$posX = $ground_w - $w;
			$posY = ($ground_h - $h) / 2;
			break;
		case 7://7Ϊ�׶˾���
			$posX = 0;
			$posY = $ground_h - $h;
			break;
		case 8://8Ϊ�׶˾���
			$posX = ($ground_w - $w) / 2;
			$posY = $ground_h - $h;
			break;
		case 9://9Ϊ�׶˾���
			$posX = $ground_w - $w;
			$posY = $ground_h - $h;
			break;
		default://���
			$posX = rand(0, ($ground_w - $w));
			$posY = rand(0, ($ground_h - $h));
			break;
	}

	//�趨ͼ��Ļ�ɫģʽ
	imagealphablending($ground_im, true);

	if ($isWaterImage) {//ͼƬˮӡ
		imagecopy($ground_im, $water_im, $posX, $posY, 0, 0, $water_w, $water_h); //����ˮӡ��Ŀ���ļ�
	} else {//����ˮӡ
		if (!empty($textColor) && (strlen($textColor) == 7)) {
			$R = hexdec(substr($textColor, 1, 2));
			$G = hexdec(substr($textColor, 3, 2));
			$B = hexdec(substr($textColor, 5));
		} else {
			die("ˮӡ������ɫ��ʽ����ȷ��");
		}
		imagestring($ground_im, $textFont, $posX, $posY, $waterText, imagecolorallocate($ground_im, $R, $G, $B));
	}

	//����ˮӡ���ͼƬ
	@unlink($groundImage);
	switch ($ground_info[2]) {//ȡ�ñ���ͼƬ�ĸ�ʽ
		case 1:imagegif($ground_im, $groundImage);
			break;
		case 2:imagejpeg($ground_im, $groundImage, 80);
			break;
		case 3:imagepng($ground_im, $groundImage);
			break;
		default:die($errorMsg);
	}

	//�ͷ��ڴ�
	if (isset($water_info))
		unset($water_info);
	if (isset($water_im))
		imagedestroy($water_im);
	unset($ground_info);
	imagedestroy($ground_im);
}

/**
 * ����ip��ַ����
 * @param int $ip �ͻ���IP��ַ
 * @param string $username �ͻ����û���
 */
function insert_ip($ip, $username) {
	global $mysql;
	$now_time = strtotime("now");
	$befor_time = $now_time - 3600;
	$ip_arr = explode('.', $ip);
	$user_name_sql = empty($username) ? " AND username = ''" : "";
	$sql = "SELECT id,ip1,ip2,ip3,ip4,add_time,username FROM tmp_ip_addtmp WHERE ip1=" . $ip_arr[0] . " AND ip2=" . $ip_arr[1] . " AND ip3=" . $ip_arr[2] . " AND add_time >= $befor_time AND add_time <= $now_time$user_name_sql  GROUP BY ip4";
	$ip_more = $mysql->arrQuery($sql);
	if (count($ip_more) > 2) {
		echo "����ϵ�ͷ���";
		foreach ($ip_more as $k => $v) {
			$sql = "SELECT id FROM tmp_ip_address WHERE ip1=" . $v['ip1'] . " AND ip2=" . $v['ip2'] . " AND ip3=" . $v['ip3'] . " AND ip4=" . $v['ip4'] . " AND add_time=" . $v['add_time'] . "";
			$insert_ip = $mysql->selectOne($sql);
			if (empty($insert_ip['id'])) {
				$sql = "INSERT INTO tmp_ip_address SET ip1=" . $v['ip1'] . ",ip2=" . $v['ip2'] . ",ip3=" . $v['ip3'] . ",ip4=" . $v['ip4'] . ",add_time=" . $v['add_time'] . ",username='" . $v['username'] . "'";
				$mysql->query($sql);
			}
		}
		die();
	} else {
		$sql = "INSERT INTO tmp_ip_addtmp SET ip1=" . $ip_arr[0] . ",ip2=" . $ip_arr[1] . ",ip3=" . $ip_arr[2] . ",ip4=" . $ip_arr[3] . ",username='" . $username . "',add_time=" . $now_time . "";
		$mysql->query($sql);
	}
	$sql = "DELETE FROM tmp_ip_addtmp WHERE add_time < $befor_time";
	$mysql->query($sql);
}

/**
 * @��curlԶ�̵�������
 * 
 */
function getCurlDate($url, $datas) {
	$datas['time'] = time() + 300;
	$post_data['data'] = urlencode(authcode(serialize($datas), "ENCODE", NEW_SXXL_KEY));
	$url = NEW_SXXL . $url;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	// ������POST����Ŷ��
	curl_setopt($ch, CURLOPT_POST, 1);
	// ��post�ı�������
	//var_dump($post_data);exit;
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	$output = curl_exec($ch);
	curl_close($ch);
	return json_decode($output, true);
}

?>
