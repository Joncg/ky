<?php

define('IN_SXXL', true);
error_reporting(0);
require('../include/common.inc.php');
require('../include/class.json.php');


// 客户端登录跳转
if (isset($_REQUEST['act']) && 'loginSuccess' == substr($_REQUEST['act'], 0, 12)) {
	$s = unserialize(authcode(substr($_REQUEST['act'], 12), 'DECODE', URL_SEND_ENCODE_KEY));
	if ($s['time'] < $_SERVER['REQUEST_TIME']) {
		echo ' 登录超时 ';
		exit;
	}
	$cookietime = 0;
	setcookie("cpu_info", $s['cpu_id'], $cookietime, "/", COOKIE_DOMAIN);
	setcookie("hd_info", $s['hd_id'], $cookietime, "/", COOKIE_DOMAIN);
	setcookie("net_info", $s['mac_id'], $cookietime, "/", COOKIE_DOMAIN);
	setcookie("pc_name", $s['computer_name'], $cookietime, "/", COOKIE_DOMAIN);
	setcookie("SxxlUserNameLogin", $s['username'], $cookietime, "/", COOKIE_DOMAIN);
	setcookie("Pc_ID", $s['Pc_ID'], $cookietime, "/", COOKIE_DOMAIN); //软件登录标识
	
	$login_ip = $_SERVER["REMOTE_ADDR"];
	newPcLoginLog($s['username'], $s['time'], $s['computer_name'], $s['cpu_id'], $s['hd_id'], $s['mac_id'], $login_ip, '', $s['softver'], '0',$s['Pc_ID']);
	
	header('Location: http://www.sxxl.com/');
	exit;
}

$str = trim($_REQUEST['post']);
$p = unserialize(authcode($str, 'DECODE', URL_SEND_ENCODE_KEY));

$json = new Json();
if (!isset($p['username'])) {
	$r = array(
		'status' => 0,
		'uri' => '',
		'info' => iconv('gbk', 'utf-8', '参数错误'));
	echo $json->encode($r);
	exit;
}
if ($_SERVER['REQUEST_TIME'] > $p['time']) { //查询超时
	$r = array(
		'status' => 0,
		'uri' => '',
		'info' => iconv('gbk', 'utf-8', '查询超时'));
	echo $json->encode($r);
	exit;
}

if (chkLogin($p['username'], $p['password'])) {
	$s = unserialize($p['clientinfo']);
	
	// -- 多网卡、多硬盘 --start
	$hd_id_arr = explode(';', $s['hd_id']); //硬盘ID数组
	$mac_id_arr = explode(';', $s['mac_id']); //网卡ID数组
	$isv_hd_id = $isv_mac_id = $nov_hd_id = $nov_mac_id = '';
	$update_time = date('Y-m-d H:i:s');
	$update_time_add = time();
	$s['computer_name'] = iconv('UTF-8', 'GBK', $s['computer_name']);

	foreach ($hd_id_arr as $k => $hd_id) {
		if (!$hd_id)
			continue;
		foreach ($mac_id_arr as $km => $mac_id) {
			$nov_hd_id = $hd_id;
			$nov_mac_id = $mac_id;

			$sSQL = " where UserName='{$p['username']}' ";
			$sSQL = $sSQL . " and cpu_info = '{$s['cpu_id']}'";
			//$sSQL = $sSQL . " and hd_info = '$hd_id'";
			$sSQL = $sSQL . " and net_info = '$mac_id'";
			$sSQL = $sSQL . " and pc_name = '{$s['computer_name']}'";
			$sSQL = "select ID,StatusLog from UserPcidInfo " . $sSQL;

			if (!$info = $mysql->getRow($sSQL)) {
				//插入前，为了兼容客户更换计算机名，设置网卡cookie
				$sSQL = "SELECT StatusLog, cpu_info, net_info FROM UserPcidInfo WHERE UserName='{$p['username']}' AND cpu_info = '{$s['cpu_id']}' AND StatusLog = 1 AND net_info = '$mac_id'";
				$nowinfo = $mysql->getRow($sSQL);
				if ($nowinfo['StatusLog']) {
					//如果有相同计算机名和网卡，就把网卡信息给cookie中
					$isv_hd_id = $hd_id;
					$isv_mac_id = $mac_id;
				}
				$sql = "insert into UserPcidInfo
								(UserName,cpu_info,hd_info,net_info,pc_id,pc_name,soft_ver, add_time)
							values (
								'{$p['username']}', '{$s['cpu_id']}', '$hd_id', '$mac_id','','{$s['computer_name']}','{$p['softver']}', '$update_time_add')";
				$mysql->query($sql);
			} else {
				//插入前，为了兼容客户更换计算机名，设置网卡cookie
				$sSQL = "SELECT StatusLog, cpu_info, net_info FROM UserPcidInfo WHERE UserName='{$p['username']}' AND cpu_info = '{$s['cpu_id']}' AND StatusLog = 1 AND net_info = '$mac_id'";
				$nowinfo = $mysql->getRow($sSQL);
				if ($nowinfo['StatusLog']) {
					//如果有相同计算机名和网卡，就把网卡信息给cookie中
					$isv_hd_id = $hd_id;
					$isv_mac_id = $mac_id;
				}
				// 更新登录时间,方便后台查看
				$sql = "update UserPcidInfo set add_time='{$update_time_add}' where ID='{$info['ID']}' ";
				$mysql->query($sql);
			}
		}
	}
	$s['hd_id'] = $isv_hd_id ? $isv_hd_id : $nov_hd_id;
	$s['mac_id'] = $isv_mac_id ? $isv_mac_id : $nov_mac_id;
	// -- 多网卡、多硬盘  --end
	// 记录登录日志
	LoginLog($p['username'], "user", $s['cpu_id'], $s['hd_id'], $s['mac_id'], '', $s['computer_name'], $p['softver'],'', $p['login_ip']);
	

	
	$s['Pc_ID'] = 2; //软件登录标识
	$s['username'] = $p['username'];
	$s['time'] = $_SERVER['REQUEST_TIME'] + 1000; //登录key值有效期
	$authkey = urlencode(authcode(serialize($s), 'ENCODE', URL_SEND_ENCODE_KEY));
	$r = array(
		'status' => 2,
		'uri' => 'http://www.sxxl.com/api/client/index.php?act=loginSuccess' . $authkey,
		'info' => iconv('gbk', 'utf-8', '成功登录'));
} else {
	$r = array(
		'status' => 0,
		'uri' => '',
		'info' => iconv('gbk', 'utf-8', '帐号或密码错误'));
}
echo $r = $json->encode($r);
exit;

function chkLogin($UserName, $PassWord) {
	global $mysql;
	$PassWord = md5($PassWord);
	$sql = "SELECT UserName FROM " . TB_VIPClient . " WHERE UserName = '{$UserName}' AND PassWord = '{$PassWord}'";
	$mysql->query($sql);

	if (!$mysql->nextRecord()) {
		return false;
	} else {
		return true;
	}
}

function newPcLoginLog($user, $login_time, $computer_name, $cpu_id, $storage_id, $mac_id, $login_ip, $computer_type, $client_version, $login_type, $pc_id) {
	$member_id = getUserMessage($user);
	$member_message = getUserMess($user);
	$logdata['member_id'] = $member_id ? $member_id : "";
	$logdata['login_time'] = $login_time ? $login_time : "";
	$logdata['computer_name'] = $computer_name ? $computer_name : "";
	$logdata['cpu_id'] = $cpu_id ? $cpu_id : "";
	$logdata['storage_id'] = $storage_id ? $storage_id : "";
	$logdata['mac_id'] = $mac_id ? $mac_id : "";
	$logdata['login_ip'] = $login_ip ? $login_ip : "";
	$logdata['computer_type'] = $computer_type ? $computer_type : "";
	$logdata['client_version'] = $client_version ? $client_version : "";
	$logdata['login_type'] = $login_type ? $login_type : "";
	//写入授权表
	$pcright['UserName'] = $user;
	$pcright['cpu_info'] = $cpu_id;
	$pcright['net_info'] = $mac_id;
	$pcright['storage_id'] = $storage_id;
	$pcright['computer_name'] = $computer_name;
	$host = $_SERVER['HTTP_HOST'];
	$arrhost = explode('.', $host);
	$cookie_path = "." . $arrhost[1] . "." . $arrhost[2];

	setcookie("pc_id_new", authcode($pc_id, 'ENCODE'), 0, "/", $cookie_path);

	setcookie("computer_name", authcode($computer_name, 'ENCODE'), 0, "/", $cookie_path);

	setcookie("mac_id", authcode($mac_id, 'ENCODE'), 0, "/", $cookie_path);

	setcookie("cpu_id", authcode($cpu_id, 'ENCODE'), 0, "/", $cookie_path);

	setcookie("storage_id", authcode($storage_id, 'ENCODE'), 0, "/", $cookie_path);

	setcookie("loginUser", authcode($user, 'ENCODE'), 0, "/", $cookie_path);

	setcookie("loginUserName", authcode($member_message['name'], 'ENCODE'), 0, "/", $cookie_path);

	setcookie("lastLoginTime", authcode($member_message['final_login_time'], 'ENCODE'), 0, "/", $cookie_path);

	setcookie("login_count", authcode($member_message['login_count'], 'ENCODE'), 0, "/", $cookie_path);

	setcookie("memId", authcode($member_id, 'ENCODE'), 0, "/", $cookie_path);


	getCurlDate("pcRight", $pcright);
	$data = getCurlDate("pcLoingLog", $logdata);
	if ($data['status']) {
		return true;
	} else {
		return false;
	}
}

//获取新网站会员表中的用户信息
function getUserMessage($name) {
	$userdata['name'] = $name;
	$data = getCurlDate("getNewMemberMemberId", $userdata);
	if ($data)
		return $data;
	else
		return false;
}

//用户信息
function getUserMess($name) {
	$userdata['name'] = $name;
	$data = getCurlDate("getNewMember", $userdata);
	if ($data)
		return $data;
	else
		return false;
}

?>