<?php
class MySql {

	var $Host     = ''; ## database system host
	var $Database = '';  // 'sxxltest';	 ## database name
	var $User     = '';	 ## database user
	var $Password = '';	 ## database password

	#============================================================================
	# ��������: ���ò���
	#----------------------------------------------------------------------------
	var $AutoFree    = false;		## true: �Զ��ͷ�
	var $Debug       = false;		## true: ��ʾ������Ѷ
	var $HaltOnError = 'yes';	    ## "yes"   : ��ʾ�����ж�ִ��
	## "no"    : ���Դ��󣬼���ִ��
	## "report": ��ʾ���󣬼���ִ��
	var $ReportError = false;       ## true: ������ϸ������Ų�������Ա��
	var $PconnectOn  = false;		## true: ʹ�� pconnect ������ʹ�� connect
	var $resultType = MYSQL_ASSOC;

	#============================================================================
	# ��������: ��ѯ������� �� ��ǰ����
	#----------------------------------------------------------------------------
	var $record = Array();
	var $Row;
	var $QueryStr = '';

	#============================================================================
	# ��������: ������� �� ������Ѷ
	#----------------------------------------------------------------------------
	var $Errno = 0;
	var $Error = '';
	var $isHalt = 1;

	#============================================================================
	# ��������: �����Ͽ������� ������Ѷ
	#----------------------------------------------------------------------------
	var $Type     = 'MySQL';
	var $Revision = '1.0';
	var $Company  = 'www.sxxl.com';
	var $AdminMail= 'sxxl@sxxl.com';

	#============================================================================
	# ˽������: ����ID ��ѯID
	#----------------------------------------------------------------------------
	var $LinkID  = 0;
	var $QueryID = 0;
	#============================================================================
	# ˽������: ����ID ��ѯID
	#----------------------------------------------------------------------------
	var $insertLog = 0;  //0:�����������¼��1�����������¼��
	#============================================================================
	# ��������: ������
	#----------------------------------------------------------------------------
	function __construct($Host='', $User='', $Password='', $Database='',$HaltError="yes") {
		$this->Host		= empty($Host) ? DB_HOST : $Host;
		$this->User		= empty($User) ? DB_USER : $User;
		$this->Password = empty($Password) ? DB_PASSWORD : $Password;
		$this->Database	= empty($Database) ? DB_DATABASE : $Database;
		$this->HaltOnError   = (isset($HaltError))?$HaltError:$HaltOnError;
		$this->connect();
	}

	#============================================================================
	# ��������: һЩ����ı���
	#----------------------------------------------------------------------------
	function getLinkID() {
		return $this->LinkID;
	}

	function getQueryID() {
		return $this->QueryID;
	}
	#============================================================================
	# ��������: �����ݿ�
	#----------------------------------------------------------------------------
	function select_database($db) {
		@mysql_select_db($db,$this->LinkID) or $this->halt('���ݿ��л�ʧ��');
	}
	#============================================================================
	# ��������: �������Ͽ�
	#----------------------------------------------------------------------------
	function connect() {
		/*---------- �������ӣ�ѡ�����Ͽ� ----------*/
		if ( $this->LinkID == 0 ) {
			// ��������
			if ( $this->PconnectOn ) {
				$this->LinkID = @mysql_pconnect($this->Host, $this->User, $this->Password);
			} else {
				$this->LinkID = @mysql_connect($this->Host, $this->User, $this->Password);
			}
			// ���Ӵ���
			if ( $this->LinkID == 0 ) {
				if ( $this->Debug ) {
					$msg = "connect('$this->Host', '$this->User', '$this->Password') ����ʧ�ܣ�";
				} else {
					$msg = '�Բ������ڻ���������·���ϣ���ʱ�޷�������������ڴ�����';
				}
				$this->halt($msg);
				return false;
			}
			// ѡ�����Ͽ�ʱ����
			if ( !@mysql_select_db($this->Database, $this->LinkID) ) {
				$this->halt("�޷������ݿ�'".$this->Database."'��");
				return false;
			}
			if (!defined(DB_CHARSET)) {
				mysql_query('SET NAMES ' . DB_CHARSET);
			}
			//mysql_query("SET NAMES 'utf8'");
		}
		return $this->LinkID;
	}

	#============================================================================
	# ��������: �ͷŲ�ѯ���
	#----------------------------------------------------------------------------
	function free() {
		@mysql_free_result($this->QueryID);
		$this->QueryID = 0;
	}

	#============================================================================
	# ��������: ִ�в�ѯ
	#----------------------------------------------------------------------------
	function query($str) {
		if ( $str == '' ) return false;

		if ( !$this->connect() ) return false;

		/*------- �²�ѯ���ͷ�ǰ�εĲ�ѯ��� -------*/
		if ( $this->QueryID ) {
			$this->free();
		}

		$str = varResume($str);	// �ָ������˵ı���,��ԭ��ʵ��ֵ

		$this->QueryStr = $str;

		$debugMsg = "����: ���";
		$debugMsg = $debugMsg;
		if ( $this->Debug ) printf($debugMsg." = %s<br>\n", $this->QueryStr);

		$this->QueryID = @mysql_query($this->QueryStr, $this->LinkID);
		$this->Row   = 0;
		if ( !$this->QueryID ) {
			$this->halt("�����ѯ:".$this->QueryStr);
			return false;
		} else {
			if($this->insertLog)$this->SqlLog($this->QueryStr);
			return $this->QueryID;
		}
	}

	function arrQuery($sql,$mType=MYSQL_ASSOC) {
		$this->query($sql);
		if (!is_resource($this->QueryID)) {
			return false;
		}
		$this->get_all_data = array();
		while ($row = mysql_fetch_array($this->QueryID,$mType)) {
			$this->get_all_data[] = $row;
		}
		return $this->get_all_data;
	}
	#============================================================================
	# ��������: ��ò�ѯ���
	#----------------------------------------------------------------------------
	function nextRecord($mType=MYSQL_ASSOC) {
		if ( !$this->QueryID ) {
			$this->halt('ִ�д��󣺲�ѯ��Ч��');
			return false;
		}

		$this->record = @mysql_fetch_array($this->QueryID,$mType);
		if ("" != $this->record) {
			foreach($this->record as $key => $val) {
				$this->record[$key] = $val; // �Զ��� ���� ���Ը�ʽ����ת��
			}
			$this->record = varFilter($this->record);	// ȡ����ֵ���а�ȫ����
		}

		$this->Row += 1;

		$stat = is_array($this->record);

		if ( !$stat && $this->AutoFree ) {
			$this->free();
		}
		return $stat;
	}

	#============================================================================
	# ��������: ��ò����ID
	#----------------------------------------------------------------------------
	function insertId() {
		if( $result = mysql_insert_id($this->LinkID) ) {
			return $result;
		} else {
			return false;
		}
	}

	#============================================================================
	# ��������: ���Է���
	#----------------------------------------------------------------------------
	function insert($table, $field, $value) {
		$str = "insert into ".$table;
		if ( $field != "" ) $str .= "(".$field.")";
		$str .= " values(".$value.")";
		if ( $this->query($str) ) {
			return true;
		} else {
			return false;
		}
	}

	function replace($table, $field, $value) {
		$str = "replace into ".$table;
		if ( $field != "" ) $str .= "(".$field.")";
		$str .= " values(".$value.")";
		if ( $this->query($str) ) {
			return true;
		} else {
			return false;
		}
	}

	function select($table, $field="*", $condition="", $order="", $limit="") {
		$str = "select ".$field." from ".$table;
		if ( $condition != "" ) $str.=" where ".$condition;
		if ( $order != "" ) $str.=" order by ".$order;
		if ( $limit != "" ) $str.=" limit ".$limit;
		if ( $this->query($str) ) {
			return true;
		} else {
			return false;
		}
	}

	function update($table, $value, $condition="") {
		$str = "update ".$table." set ".$value;
		if ( $condition != "" ) $str.=" where ".$condition;
		if ( $this->query($str) ) {
			return true;
		} else {
			return false;
		}
	}

	function delete($table, $condition="") {
		$str = "delete from ".$table;
		if ( $condition != "" ) $str.=" where ".$condition;
		if ( $this->query($str) ) {
			return true;
		} else {
			return false;
		}
	}

	function selectOne($str) {
		if ( $this->query($str) ) {
			if ( $this->nextRecord() ) {
				return $this->record;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	function count($table, $field="*", $condition="") {
		if ( $condition != "" ) $strC=" where ".$condition;
		$str = "select count(".$field.") from ".$table.$strC;
		$this->query($str);
		$this->nextRecord();
		return $this->record[0];
	}

	function nextData() {
		if ( $this->nextRecord() ) {
			return $this->record;
		}else {
			return false;
		}
	}

	#============================================================================
	# ��������: ���SQL���ִ�к���Ӱ�������
	#----------------------------------------------------------------------------
	function affectedRows() {
		return @mysql_affected_rows($this->LinkID);
	}

	function numRows() {
		return @mysql_num_rows($this->QueryID);
	}

	function numFields() {
		return @mysql_num_fields($this->QueryID);
	}
	function fetchArray($mType=MYSQL_ASSOC) {
		return @mysql_fetch_array($this->QueryID,$mType);
	}

	#============================================================================
	# ��������: ���Է���
	#----------------------------------------------------------------------------
	function nr() {
		return $this->numRows();
	}

	function np() {
		print $this->numRows();
	}

	function r($name) {
		if ( isset($this->record[$name]) ) {
			return $this->record[$name];
		}
	}

	function p($name) {
		if ( isset($this->record[$name]) ) {
			print $this->record[$name];
		}
	}

	#============================================================================
	# ��������: ���ұ�
	#----------------------------------------------------------------------------
	function tableNames() {
		$this->connect();
		$h = @mysql_query("show tables", $this->LinkID);
		if ( $this->Debug ) printf("����: ��� = %s<br>\n", "'show tables'");
		$i = 0;
		while ( $info = @mysql_fetch_row($h) ) {
			$return[$i]["table_name"]      = $info[0];
			$return[$i]["tablespace_name"] = $this->Database;
			$return[$i]["database"]        = $this->Database;
			$i++;
		}
		@mysql_free_result($h);
		return $return;
	}

	#============================================================================
	# ��������: ������
	#----------------------------------------------------------------------------
	function halt($msg) {
		$this->Error = @mysql_error($this->LinkID);
		$this->Errno = @mysql_errno($this->LinkID);
		if ( $this->HaltOnError == 'no' ) return;

		$this->haltmsg($msg);
		if ( $this->HaltOnError != 'report' ) die(' ϵͳ���Ͽⷢ�����󣬵�ǰ�����ѱ���ֹ��');
	}

	function haltmsg($msg) {
		$message = '<br><br>���Ժ򣡣���<div style="display:none">';
		$message .= "<b></b> " . $msg . "<br>";
		$message .= "<b></b><br />: " .  $this->Errno." (".$this->Error.")<br>";
		$message .= '</div>';
		echo $message;
		exit;
	}

	/**
	 * ����SQL��䣬�õ�SQL������������SQL���
	 *
	 * @param string $sql_item
	 * @return  array $tableArray[0]:select|insert|update|delete, 1:tablename,2:sql
	 */
	function parseSql($sql_item) {
		$sql_string = strtolower(trim($sql_item));
		$tableArray = array();
		$tableAry = array();
		preg_match("/^(\w*)/i",$sql_string,$tableArray);
		$tableArray[2] = $sql_item;
		switch($tableArray[0]) {
			case "select":
				preg_match("/^(\w*).*from\s*(\w*)/i",$sql_string,$tableAry);
				$tableArray[1] = $tableAry[2];
				break;
			case "update":
				preg_match("/^(\w*).*?(\w*)\s*set/i",$sql_string,$tableAry);
				$tableArray[1] = $tableAry[2];
				break;
			case "insert":
				preg_match("/^(\w*).*?into\s*(\w*)/i",$sql_string,$tableAry);
				$tableArray[1] = $tableAry[2];
				break;
			case "delete":
				preg_match("/^(\w*).*?from\s*(\w*)/i",$sql_string,$tableAry);
				$tableArray[1] = $tableAry[2];
				break;
			default:
				$tableArray[1] = '';
		}
		return $tableArray;
	}

	function SqlLog($sql_item) {
		global $SxxlB2bUser;
		if($SxxlB2bUser!="") {
			$tableArray = $this->parseSql($sql_item);
			if($tableArray[0] =='update' || $tableArray[0] =='delete') {
				$old_db=$this->Database;
				$this->select_database(B2B_LOG);
				$tbl_name=PRE_USER.date('Ym');
				$sql="CREATE TABLE if not exists `".$tbl_name."` (
	 					`id` int(11) NOT NULL auto_increment,
	  					`operate` varchar(10) NOT NULL,
	  					`tbl_name` varchar(50) NOT NULL,
	  					`sqlstr` text NOT NULL,
	  					`user_name` varchar(20) NOT NULL,
	  					`post_time` int(11) NOT NULL,
	  					PRIMARY KEY  (`id`)
						) ENGINE=MyISAM ;";
				$this->query($sql);
				$sql="insert into `".$tbl_name."`(operate,tbl_name,sqlstr,admin_user,post_time)";
				$sql.=" values('".$tableArray[0]."','".$tableArray[1]."','".mysql_escape_string($tableArray[2])."','$SxxlB2bUser',".time().")";
				$this->query($sql);
				$this->select_database($old_db);
			}
		}
	}

	/**
	 * ��ȡSQLִ�е�ȫ�������
	 * @param string $sql ��Ҫִ�е�SQL���
	 * @return �ɹ�: array ʧ��: false ��: NULL
	 */
	function getAll($sql) {
		if (!$this->query($sql)) {
			return false;
		}
		$this->record = array();
		while ($rows = @mysql_fetch_array($this->QueryID, $this->resultType)) {
			$this->record[] = $rows;
		}
		if (is_resource($this->QueryID)) {
			$this->free();
		}
		if (!is_array($this->record) || empty($this->record)) {
			return NULL;
		}
		return $this->record;
	}

	/**
	 * ��ȡһ�м�¼ add author: baln
	 * @param string $sql
	 * @param bool $limited
	 * @return array
	 */
	function getRow($sql, $limited = false) {
		if ($limited == true) {
			$sql = trim($sql . ' LIMIT 1');
		}
		$res = $this->query($sql);
		if ($res !== false) {
			return mysql_fetch_assoc($res);
		}
		else {
			return false;
		}
	}

	/**
	 * ��ȡ���м�¼ add author: baln
	 * @param string $sql ��Ҫִ�е�SQL���
	 * @return �ɹ�: array ʧ��: false ��: NULL
	 */
	function getCol($sql, $field = '', $limit = false) {
		$sql = $limit == true ? $sql . ' LIMIT 1' : $sql;
		if (!$this->query($sql)) {
			return false;
		}
		$this->record = array();
		while($row = @mysql_fetch_array($this->QueryID, $this->resultType)) {
			if (trim($field) != '') {
				$this->record[] = $row[$field];
			} else {
				$this->record[] = current($row);
			}
		}
		if (is_resource($this->QueryID)) {
			$this->free();
		}
		if (!is_array($this->record) || empty($this->record)) {
			return NULL;
		}
		return $this->record;
	}

	/**
	 * ��ȡ������¼
	 * @param string $sql ��Ҫִ�е�SQL���
	 * @return �ɹ�: $this->record ʧ��:false ��:NULL
	 */
	function getOne($sql, $field = '') {
		if (!$this->query($sql)) {
			return false;
		}
		$this->record = array();
		$row = @mysql_fetch_array($this->QueryID, $this->resultType);

		if (is_resource($this->QueryID)) {
			$this->free();
		}
		if (!is_array($row) || empty($row)) {
			return NULL;
		}
		if (trim($field) != '') {
			$this->record = $row[$field];
		}
		else {
			$this->record = current($row);
		}
		return $this->record;
	}

	/**
	 * ��ȡָ�������ļ�¼
	 * @param string $table ����
	 * @param string $field �ֶ�
	 * @param string $where ����(������WHERE,Ĭ��Ϊ��)
	 * @param array $order ��������(��ʽ:array('id'=>true)ID˳����;array('id'=false)ID��������)
	 * @param int $limit ��¼����(��ȡ��������¼,������LIMIT,Ĭ��Ϊ��)
	 * @return �ɹ�:�����,ʧ��:false
	 */
	function getRecord($table, $field = '*', $where = '', $order = array(), $limit = '') {
		if (empty($table)) return false;
		$sql  = "SELECT $field FROM " . $table;
		$jw = strrpos(strtolower(trim(substr($where, 0, 4))), 'and') !== false ? '1 ' : '';
		$sql .= trim($where) != '' ? " WHERE $jw $where " : '';
		if (is_array($order) && !empty($order)) {
			$key = key($order);
			$sql .= " ORDER BY $key " . $order[$key];
		}
		$sql .= trim($limit) != '' ? " LIMIT $limit " : '';
		if (trim($limit) == 1) {
			return $this->getRow($sql);
		}
		return $this->getAll($sql);
	}

	/**
	 * ��ȡָ�������ļ�¼
	 * @param string $table ����
	 * @param string $field �ֶ�
	 * @param string $where ����(������WHERE,Ĭ��Ϊ��)
	 * @param array $order ��������(��ʽ:array('id'=>ASC)ID˳����;array('id'=DESC)ID��������)
	 * @param int $offset ��ȡ����
	 * @param int $start ��ʼ��¼
	 * @return �ɹ�:�����,ʧ��:false
	 */
	function getRecordLimit($table, $field = '*', $where = '', $order = array(), $offset = 1, $start = 0) {
		if (empty($table)) return false;
		$sql  = "SELECT $field FROM " . $table;
		$jw = strrpos(strtolower(trim(substr($where, 0, 4))), 'and') !== false ? '1 ' : '';
		$sql .= trim($where) != '' ? " WHERE $jw $where " : '';
		if (is_array($order) && !empty($order)) {
			$key = key($order);
			$sql .= " ORDER BY $key " . $order[$key];
		}
		$sql .= " LIMIT $start, $offset";
		return $this->getAll($sql);
	}

	/**
	 * ��ȡJOIN��ѯ��¼
	 */
	function getJoinLimit($table, $joinArr = array(), $field = '*', $where = '', $group_by='', $having='', $order = array(), $offset = 0, $start = 0) {
		if (empty($table)) return false;
		$sql = "SELECT $field FROM " . $table;
		if ($joinArr) {
			$sql .= implode(' ', $joinArr);
		}
		$jw = strrpos(strtolower(trim(substr($where, 0, 4))), 'and') !== false ? '1 ' : '';
		$sql .= trim($where) != '' ? " WHERE $jw $where " : '';
		$sql .= !empty($group_by) ? " GROUP BY $group_by " : '';
		$sql .= !empty($having) ? " HAVING $having " : '';
		if (is_array($order) && !empty($order)) {
			$key = key($order);
			$sql .= " ORDER BY $key " . $order[$key];
		}
		$sql .= !empty($offset) ? " LIMIT $start, $offset" : '';
		return $this->getAll($sql);
	}

	function getJoinCount($table, $joinArr = array(), $where = '', $group_by='', $having='') {
		if (empty($table)) return false;
		//$sql  = !empty($group_by) ? 'SELECT COUNT(1) AS c FROM (' : '';
		$sql = "SELECT COUNT(1) FROM " . $table;
		if ($joinArr) {
			$sql .= implode(' ', $joinArr);
		}
		$jw = strrpos(strtolower(trim(substr($where, 0, 4))), 'and') !== false ? '1 ' : '';
		$sql .= trim($where) != '' ? " WHERE $jw $where" : '';
		$sql .= !empty($group_by) ? " GROUP BY $group_by " : '';
		$sql .= !empty($having) ? " HAVING $having " : '';
		//$sql .= !empty($group_by) ? ')T' : '';
		if ($group_by) {
			$row = count($this->getAll($sql));
		}
		else {
			$row = $this->getOne($sql);
		}
		if ($row === NULL || $row === false) {
			return $row;
		}
		if (is_array($row)) {
			return (int)current($row);
		}
		return (int)$row;
	}

	/**
	 * �Զ�ִ�в���(INSERT/REPLACE/UPDATE)
	 * @param string $table ����
	 * @param array $arrField �ֶ�����(����: array('id' => 7, 'username' => 'baln')
	 * @param string $mode ִ�в�����ģʽ(INSERT/UPDATE)
	 * @param mixed $where ��������
	 * @return �ɹ�:Ӱ������ ʧ��:false
	 */
	function autoExecute($table, $arrField, $mode = 'INSERT', $where = '') {
		if ($table == '' || !is_array($arrField) || empty($arrField)) {
			return false;
		}
		$sets = $this->getSets($table, $arrField);

		$contStr = '';
		if (is_array($where) && !empty($where)) {
			$conts = $this->getSets($table, $where);
			$contStr = implode(' AND ', $conts);
		}
		else {
			$contStr = $where;
		}
		$sql = '';
		if (is_array($sets) && !empty($sets)) {
			if ($mode == 'INSERT') {
				$sql = 'INSERT INTO ' . $table . ' SET ' . implode(', ', $sets);
			}
			elseif ($mode == 'REPLACE') {
				$sql = 'REPLACE INTO ' . $table . ' SET ' . implode(', ', $sets);
			}
			else if($mode == 'UPDATE' && !empty($contStr)) {
				$jw = strripos(trim(substr($contStr, 0, 4)), 'and') !== false ? '1 ' : '';
				$sql = 'UPDATE ' . $table . ' SET ' . implode(', ', $sets) . ' WHERE ' . $jw . $contStr;
			}
			else {
				return false;
			}
			return $this->query($sql);
		}
		else {
			return false;
		}
	}

	/**
	 * ����������ѯĳ������COUNT
	 * @param string $table ����
	 * @param mixed $where �ֶ�����(����: array('id' => 7, 'username' => 'baln')��
	 * @param array $noField �ֶ�����(������)
	 * @return �ɹ�:int ʧ��:false ��:NULL
	 */
	function getCount($table, $where = '', $field = 'COUNT(1)') {
		if ($table == '') {
			return false;
		}
		$sql = '';
		$jw = strripos(trim(substr($where, 0, 4)), 'and') !== false ? '1 ' : '';
		$where = !empty($where) ? ' WHERE ' . $jw  . $where : '';
		$field = empty($field) ? 'COUNT(1)' : $field;
		$sql = 'SELECT ' . $field . ' AS C FROM ' . $table . $where;
		$row = $this->getOne($sql);
		if ($row === NULL || $row === false) {
			return $row;
		}
		if (is_array($row)) {
			return (int)current($row);
		}
		return (int)$row;
	}

	/**
	 * ��������
	 */
	function inserts($table, $arrField) {
		return $this->autoExecute($table, $arrField, 'INSERT');
	}

	/**
	 * ��������
	 */
	function replaces($table, $arrField) {
		return $this->autoExecute($table, $arrField, 'REPLACE');
	}

	/**
	 * ��������
	 */
	function updates($table, $arrField, $where = '') {
		return $this->autoExecute($table, $arrField, 'UPDATE', $where);
	}

	/**
	 * ɾ������
	 * @param string $table ����
	 * @param mixed $where WHERE����
	 * @return �ɹ�:Ӱ���¼�� ʧ��:false
	 */
	function deletes($table, $where) {
		if (empty($table) || empty($where)) {
			return false;
		}
		$sql = '';
		if (!empty($where)) {
			$jw = strripos(trim(substr($where, 0, 4)), 'and') !== false ? '1 ' : '';
			$sql = 'DELETE FROM ' . $table . ' WHERE ' . $jw . $where;
		}
		return $this->query($sql);
	}

	/**
	 * ����������ѯĳ������COUNT
	 */
	function counts($table, $where = '', $field = '') {
		$field = empty($field) ? 'COUNT(1)' : $field;
		return $this->getCount($table, $where, $field);
	}

	/**
	 * ����SET�Ĳ���
	 * @param array $info
	 * @return array
	 */
	function getSets($table, $info) {
		if (empty($info) || !is_array($info)) return false;
		$fields = $this->getFields($table);
		foreach ($info as $key => $val) {
			if (in_array($key, $fields)) {
				$sets[] = $key . " = '" . $this->escapeString($val) . "'";
			}
		}
		return $sets;
	}

	/**
	 * ���˴��� SQL �����ʹ�õ��ַ����е������ַ�
	 * @param string $str ��Ҫ���˴������ַ���
	 * @return string
	 */
	function escapeString($str) {
		if (get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str, $this->LinkID);
	}

	/**
	 * ��ȡĳ������ȫ���ֶ��� add author: baln
	 * @param string $table ����
	 * @return array
	 */
	function getFields($table) {
		if (empty($table)) return false;
		return $this->getCol('DESC ' . $table);
	}
}
?>