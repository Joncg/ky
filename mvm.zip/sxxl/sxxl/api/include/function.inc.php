<?php

/**
 * ���ú�����
 * @author baln
 * @id function.inc.php 2010-12-01 15:48
 */

/**
 * �ݹ鷽ʽ�ĶԱ����е������ַ�����ת��
 * @param mixed $var
 * @return bool
 */
function setAddslashes($var) {
	if (empty($var)) {
		return $var;
	} else {
		return is_array($var) ? array_map('setAddslashes', $var) : addslashes($var);
	}
}

/**
 * �ݹ鷽ʽ�ĶԱ����е������ַ�ȥ��ת��
 * @param mixed $var
 * @return bool
 */
function setStripslashes($var) {
	if (empty($var)) {
		return $var;
	} else {
		return is_array($var) ? array_map('setStripslashes', $var) : stripslashes($var);
	}
}

/**
 * �����ļ�����ʼ����
 * @param string $file �ļ���
 * @return bool or object
 */
function load($file, $dir = '') {
	$lib	= ROOT_PATH . 'include/' . $file . '.class.php';
	$model	= MODEL_PATH . ($dir ? $dir . '/' : '') . $file . '.class.php';
	//echo $model."<br>";
	$inc	= '';
	if (is_file($lib)) {
		$inc = $lib;
	}
	else if (is_file($model)) {
		$inc = $model;
	}
	if ($inc == '') return false;
	if (!(include_once $inc)) return false;
	$classname = ucwords(strtolower($file));
	if (is_object($classname)) {
		return true;
	}
	else {
		return new $classname();
	}
}

/**
 * ��������Ajax�ļ�ͷ��
 * @param string $charset ����
 * @param string $type �ĵ�����
 */
function ajaxHead($charset = 'utf-8', $type = 'text/html') {
	dheader("Pragma:no-cache\r\n");
	dheader("Cache-Control:no-cache\r\n");
	dheader("Expires:0\r\n");
	dheader("Content-type: {$type};charset={$charset}");
}

/**
 * ��ȡ$_GET,$_POST,$_COOKIE,$_REQUESTֵ
 * @param string $k
 * @param string $var
 * @return string
 */
function getgpc($k, $type='GP') {
	$type = strtoupper($type);
	switch($type) {
		case 'G': $var = &$_GET;
			break;
		case 'P': $var = &$_POST;
			break;
		case 'C': $var = &$_COOKIE;
			break;
		default:
			if(isset($_GET[$k])) {
				$var = &$_GET;
			} else {
				$var = &$_POST;
			}
			break;
	}
	return isset($var[$k]) ? $var[$k] : NULL;
}

/**
 * �Զ��� header ���������ڹ��˿��ܳ��ֵİ�ȫ����
 * @param string $string ����
 */
function dheader($string, $replace = true, $http_response_code = 0) {
	$string = str_replace(array("\r", "\n"), array('', ''), $string);
	if(empty($http_response_code) || PHP_VERSION < '4.3' ) {
		@header($string, $replace);
	} else {
		@header($string, $replace, $http_response_code);
	}
	if(preg_match('/^\s*location:/is', $string)) {
		exit();
	}
}

/**
 * ��ȡ�ϴ��ļ���·��
 * @return string
 */
function getFilePath() {
	$path = '2012/' . date('md') . '/' . date('dH') . '/';
	return $path;
}

/**
 * ��ȡ�ϴ��ļ���
 * @return string
 */
function getFileName() {
//	list($usec) = explode(' ', microtime());
//	$usec = substr($usec, 2, 5);
//	$file_name = time() . $usec;
	$file_name = date("YmdHis") . rand(10000, 99999);
	return $file_name;
}

/**
 * �ļ��ϴ�
 * @return array
 */
function uploadImage() {
    require_once(ROOT_PATH . '/include/class.uploads.php');
    if($_FILES) {
        $upPath = getFilePath();
        $upload = new Uploads('jpg|jpeg|gif|bmp|png');
        $files = $upload->saveAsTimeStr($upPath);
    }
    return $files;
}

/**
 * ȡ���ļ���׺
 * @param string $filename �ļ���
 * @return string
 */
function fileExt($filename) {
	return strtolower(trim(substr($filename, strrpos($filename, '.')+1)));
}

/**
 * �����ַ�����ȡ����
 * @param string $str ��Ҫ��ȡ���ַ���
 * @param int $length ��ȡ�����ַ�
 * @param string $charset �ַ�������,Ĭ��Ϊ gb2312 �� big5,UTF-8 �� UTF-8 ���뷽ʽ��ȡ
 * @param string $tab ����ַ�
 * @return string
 */
function cutStr($str, $length, $start = 0, $charset = '', $tab='...') {
	$charset = strtolower($charset);
	if ($charset == 'utf-8') {
		preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $str, $ar);
		if(func_num_args() >= 3) {
			if (count($ar[0]) > $length) {
				return implode("", array_slice($ar[0], $start, $length)) . $tab;
			}
			return implode("", array_slice($ar[0], $start, $length));
		} else {
			return implode("", array_slice($ar[0], $start));
		}
		break;
	}
	else {
		$start = $start * 2;
		$length = $length * 2;
		$strlen = strlen($str);
		$tmpstr = '';
		for ( $i = 0; $i < $strlen; $i++ ) {
			if ( $i >= $start && $i < ( $start+$length ) ) {
				if ( ord(substr($str, $i, 1)) > 129 ) $tmpstr .= substr($str, $i, 2);
				else $tmpstr .= substr($str, $i, 1);
			}
			if ( ord(substr($str, $i, 1)) > 129 ) $i++;
		}
		if ( strlen($tmpstr) < $strlen ) $tmpstr .= $tab;
		return $tmpstr;
	}
}

/**
 * д���ļ�����
 * @param string $filename �ļ���
 * @param string $content ����
 */
function writeFile($filename, $content) {
	ignore_user_abort(true); // �����û��ر���������������ʽ����ִ��
	@file_put_contents($filename, $content, LOCK_EX);
	ignore_user_abort(false); // �رպ����û��ر���������������ʽ���û���ֹ���ʶ�ֹͣ
	return true;
}

/**
 * ɾ���ļ�
 * @param string $filename �ļ�·��+�ļ���
 * @return bool
 */
function deleteFile($filename) {
	$filename = ROOT_PATH . str_replace(ROOT_PATH, '', $filename);
	return @unlink($filename);
}

/**
 * ��ȡ�����ļ�����·��
 * @param string $cache_name
 * @return void
 */
function getCacheFile($cache_name) {
	if (empty($cache_name)) return false;
	$path = ROOT_PATH . 'Tmpl_cache/cache/';
	makeDir($path);
	return $path . $cache_name . '.php';
}

/**
 * ��������ļ�
 * @param string $file_name
 */
function clearCache($file_name) {
	$dir = ROOT_PATH . 'Tmpl_cache/cache/';
	if (is_dir($dir)) {
		$dh = opendir($dir);
		if ($dh) {
			while (($file = readdir($dh)) !== false) {
				if (stristr($file, $file_name)) {
					deleteFile($dir.$file);
				}
			}
			closedir($dh);
		}
	}
}

/**
 * д�뾲̬�����ļ�
 * @param string $cache_name �ļ���,������׺
 * @param array $caches ����
 */
function writeStaticCache($cache_name, $caches) {
	$cache_file_path = getCacheFile($cache_name);
	$content = "<?php\r\n\$data = " . var_export($caches, true) . ';';
	return writeFile($cache_file_path, $content);
}

/**
 * ��ȡ��̬�����ļ�
 * @param string $cache_name �ļ���,������׺
 */
function readStaticCache($cache_name) {
	$cache_file_path = getCacheFile($cache_name);
	if (file_exists($cache_file_path)) {
		require $cache_file_path;
		return $data;
	} else {
		return false;
	}
}

/**
 * ȡ�õ�ǰ�����û���IP��ַ
 * @return string
 */
function getIps() {
	if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$onlineip = getenv('HTTP_CLIENT_IP');
	} elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$onlineip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$onlineip = getenv('REMOTE_ADDR');
	} elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$onlineip = $_SERVER['REMOTE_ADDR'];
	} else {
		$onlineip = 'unknown';
	}
	return $onlineip;
}

/**
 * ���ص�ǰʱ���
 * @return int
 */
function getTimes() {
	return time();
}

/**
 * ����������Ϣ��ʾ
 * @param string $msg ������ʾ
 * @param string $url ��תҳ��
 */
function showAlert($msg='', $url='') {
	if ($msg != '' && $url == '') {
		echo "<script>alert(\"$msg\");window.location='javascript:history.back()';</script>";
	} else if ($msg == '' && $url != '') {
		dheader("Location:{$url}");
	} else {
		echo "<script>alert(\"$msg\");window.location='$url';</script>";
	}
	exit;
}

/**
 * ҳ�������ʾ
 * @param string $msg ������ʾ
 * @param array $url ҳ����ת��ַ;
 * @param int $times ��תʱ�� ��
 * @param bool $auto_redirect �Ƿ��Զ���ת
 */
function showAdminMsg($msg, $url, $times = 2, $auto_redirect = true) {
	$url = trim($url) != '' ? trim($url) : 'javascript:history.go(-1)';
	if ($times < 1) {
		echo "<script>window.location='{$url}';</script>";
	}
	$times = intval($times) * 1000;
	$GLOBALS['smarty']->assign('times', $times);
	$GLOBALS['smarty']->assign('msg', $msg);
	$GLOBALS['smarty']->assign('url', $url);
	$GLOBALS['smarty']->assign('auto_redirect', $auto_redirect);
	$GLOBALS['smarty']->display(ROOT_PATH . '/Tmpl/sxxlAdmin/message.tpl.html');
	exit;
}

//��ȡ��ǰҳ��URL
function currentUrl() {
	return $_SERVER["REQUEST_URI"];
}

/**
 * ����Cookieֵ
 * @param string $var Cookie��
 * @param string $value Cookieֵ
 * @param int $life ����ʱ��
 * @param string $domain ��Ч����
 * @param bool $httponly
 */
function setCookies($var, $value = '', $life = 0, $domain = '', $httponly = false) {
	$path = '/';
	$secure = $_SERVER['SERVER_PORT'] == 443 ? 1 : 0;
	$timestamp = getTimes();
	$life = $life > 0 ? $timestamp + $life : ($life < 0 ? $timestamp - 31536000 : 0);
	if(PHP_VERSION < '5.2.0') {
		setcookie($var, $value, $life, $path, $domain, $secure);
	} else {
		setcookie($var, $value, $life, $path, $domain, $secure, $httponly);
	}
}

/**
 * ��ȡCookieֵ
 * @param string $var Cookie��
 * @return string
 */
function getCookies($var) {
	return isset($_COOKIE[$var]) ? $_COOKIE[$var] : false;
}

/**
 * �������ˣ�ʹ $_GET �� $_POST ��$q->record �ȱ�������ȫ   // ���PHP.ini �����ļ�����ħ�������Ļ�����
 */
Function var_filter (& $str) {
	if (is_array($str)) {
		foreach ( $str AS $_arrykey => $_arryval ) {
			if ( is_string($_arryval) ) {
				$str["$_arrykey"] = trim($str["$_arrykey"]); // ȥ���������˿ո�
				$str["$_arrykey"] = htmlspecialchars($str["$_arrykey"]); // ��������Ԫת�� HTML ��ʽ
				$str["$_arrykey"] = str_replace("javascript", "javascript ", $str["$_arrykey"]); // ��ֹ javascript
			}else if (is_array($_arryval)) {
				$str["$_arrykey"] = var_filter($_arryval);
			}
		}
	} else {
		$str = trim($str); // ȥ���������˿ո�
		$str = htmlspecialchars($str); // ��������Ԫת�� HTML ��ʽ
		$str = str_replace("javascript", "javascript ", $str); // ��ֹ javascript
	}
	return $str;
}

/**
 * �ָ������˵ı���
 */
Function var_resume (& $str) {
	if (is_array($str)) {
		foreach ( $str AS $_arrykey => $_arryval ) {
			if ( is_string($_arryval) ) {
				$str["$_arrykey"] = str_replace("&quot;", "\"", $str);
				$str["$_arrykey"] = str_replace("&lt;", "<", $str);
				$str["$_arrykey"] = str_replace("&gt;", ">", $str);
				$str["$_arrykey"] = str_replace("&amp;", "&", $str);
				$str["$_arrykey"] = str_replace("javascript ", "javascript", $str);
			}else if (is_array($_arryval)) {
				$str["$_arrykey"] = var_resume($_arryval);
			}
		}
	} else {
		$str = str_replace("&quot;", "\"", $str);
		$str = str_replace("&lt;", "<", $str);
		$str = str_replace("&gt;", ">", $str);
		$str = str_replace("&amp;", "&", $str);
		$str = str_replace("javascript ", "javascript", $str);
	}
	return $str;
}

/**
 * ȡ�õ�ǰ��������ʱ��
 * @return int
 */
function get_time() {
	return time();
}

/**
 * ����Ŀ¼��
 * @param string $folder Ŀ¼
 * @param int $mode ����ģʽ
 * @return bool
 */
function makeDir($folder, $mode = 0777) {
	if (is_dir($folder) || @mkdir($folder, $mode)) return true;
	if (!makeDir(dirname($folder), $mode)) return false;
	return @mkdir($folder, $mode);
}

function is_ie() {
	$useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
	if((strpos($useragent, 'opera') !== false) || (strpos($useragent, 'konqueror') !== false)) return false;
	if(strpos($useragent, 'msie ') !== false) return true;
	return false;
}

/**
 * �����ļ�
 * @param string $filepath �ļ�·��
 * @param string $filename �ļ���
 */
function file_down($filepath, $filename = '') {
	if(!$filename) $filename = basename($filepath);
	if(is_ie()) $filename = rawurlencode($filename);
	$filetype = fileExt($filename);
	$filesize = sprintf("%u", filesize($filepath));
	if(ob_get_length() !== false) @ob_end_clean();
	dheader('Pragma: public');
	dheader('Last-Modified: '.gmdate('D, d M Y H:i:s') . ' GMT');
	dheader('Cache-Control: no-store, no-cache, must-revalidate');
	dheader('Cache-Control: pre-check=0, post-check=0, max-age=0');
	dheader('Content-Transfer-Encoding: binary');
	dheader('Content-Encoding: none');
	//dheader('Content-type: application/x-zip-compressed');
	dheader('Content-type: '.$filetype);
	dheader('Content-Disposition: attachment; filename="'.$filename.'"');
	dheader('Content-length: '.$filesize);
	readfile($filepath);
	exit;
}

/**
 * @param $file_name string Ҫ�������ļ��������磺mail-list.csv
 * @param $content string Ҫ�����csv��ʽ�����ݣ��ö��ŷָ����ֶ�
 * @return null
 */
function output_csv($file_name, $content) {
	//$content = "\xEF\xBB\xBF" . $content; //����BOM
	if(empty($file_name)) {
		$file_name = date("Ymd")."csv";
	}
	dheader( "Cache-Control: public" );
	dheader( "Pragma: public" );
	dheader( "Content-type: text/csv" ) ;
	dheader( "Content-Disposition: attchment; filename={$file_name}" ) ;
	dheader( "Content-Length: ". strlen( $content ) );
	echo $content;
	exit;
}

/**
 * �ʼ����ͺ���
 * @param string $mail_to ���͸�˭
 * @param array $info �ʼ�����
 * @return bool
 */
function sendMail($mail_to, $mail_subject, $mail_content) {
	require ROOT_PATH . '/include/class.smtp.php';
	$time = date("Y-m-d H:i:s");
	$server = "mail.sxxl.com"; //SMTP������
	$port = 25;//SMTP�������˿�
	$user = "noreply@sxxl.com"; //SMTP���������û��ʺ�
	$password = "mysxxl888"; //SMTP���������û�����
	$sendmail = "noreply@sxxl.com"; //SMTP���������û�����
	$mail_to = $mail_to; //���͸�˭
	$mail_subject = $mail_subject; //�ʼ�����
	$mail_content = $mail_content; //�ʼ�����

	$mail = new Smtp($server, 25, $user, $password);
	$is_send = $mail->send($mail_to, $mail_subject, $mail_content, $sendmail);
	if ($is_send) {
		return true;
	}
	else {
		return $mail->errorMsg();
	}
}

/**
 * ���ຯ��
 */
function multi($num, $perpage, $curpage, $mpurl='', $maxpages = 0, $page = 10, $autogoto = TRUE, $simple = FALSE) {
	global $maxpage;
	$mpurl = $_SERVER['REQUEST_URI'];
	if (substr($mpurl, -1, 1) == "&") {
		$tStrlen = strlen($mpurl);
		$mpurl = substr($mpurl, 0, $tStrlen-1);
	}
	$str_find = strrpos( $mpurl, "&page" );
	if ( isset($_GET["page"]) ) {
		$str_sub = substr( $mpurl, $str_find );
		$mpurl = str_replace( $str_sub, "", $mpurl );
	}
	$ajaxtarget = !empty($_GET['ajaxtarget']) ? " ajaxtarget=\"".htmlspecialchars($_GET['ajaxtarget'])."\" " : '';

	$shownum = $showkbd = TRUE;
	$lang['prev'] = '<';
	$lang['next'] = '>';

	$multipage = '';
	$mpurl .= strpos($mpurl, '?') ? '&amp;' : '?';
	$realpages = 1;
	if($num > $perpage) {
		$offset = 2;

		$realpages = @ceil($num / $perpage);
		$pages = $maxpages && $maxpages < $realpages ? $maxpages : $realpages;

		if($page > $pages) {
			$from = 1;
			$to = $pages;
		} else {
			$from = $curpage - $offset;
			$to = $from + $page - 1;
			if($from < 1) {
				$to = $curpage + 1 - $from;
				$from = 1;
				if($to - $from < $page) {
					$to = $page;
				}
			} elseif($to > $pages) {
				$from = $pages - $page + 1;
				$to = $pages;
			}
		}

		$multipage = ($curpage - $offset > 1 && $pages > $page ? '<a href="'.$mpurl.'page=1" class="first"'.$ajaxtarget.'>1 ...</a>' : '').
				($curpage > 1 && !$simple ? '<a href="'.$mpurl.'page='.($curpage - 1).'" class="prev"'.$ajaxtarget.'>'.$lang['prev'].'</a>' : '');
		for($i = $from; $i <= $to; $i++) {
			$multipage .= $i == $curpage ? '<strong>'.$i.'</strong>' :
					'<a href="'.$mpurl.'page='.$i.($ajaxtarget && $i == $pages && $autogoto ? '#' : '').'"'.$ajaxtarget.'>'.$i.'</a>';
		}

		$multipage .= ($to < $pages ? '<a href="'.$mpurl.'page='.$pages.'" class="last"'.$ajaxtarget.'>... '.$realpages.'</a>' : '').
				($curpage < $pages && !$simple ? '<a href="'.$mpurl.'page='.($curpage + 1).'" class="next"'.$ajaxtarget.'>'.$lang['next'].'</a>' : '').
				($showkbd && !$simple && $pages > $page && !$ajaxtarget ? '<kbd><input type="text" name="custompage" size="3" onkeydown="if(event.keyCode==13) {window.location=\''.$mpurl.'page=\'+this.value; return false;}" /></kbd>' : '');

		$multipage = $multipage ? '<div class="pages">'.($shownum && !$simple ? '<em>&nbsp;'.$num.'&nbsp;</em>' : '').$multipage.'</div>' : '';
	}
	$maxpage = $realpages;
	return $multipage;
}

/**
 * ��ȡ����ƴ������ĸ
 * @param <type> $s0 ����ĺ���
 * @return <type>    ����ƴ������ĸ
 */
function getfirstchar($s0) {
	$firstchar_ord=ord(strtoupper($s0{0}));
	if(($firstchar_ord>=65 and $firstchar_ord<=91)or($firstchar_ord>=48 and $firstchar_ord<=57)) return $s0{0};
	//$s=iconv("UTF-8","gb2312", $s0);
	$s=$s0;
	$asc=ord($s{0})*256+ord($s{1})-65536;
	if($asc>=-20319 and $asc<=-20284)return "A";
	if($asc>=-20283 and $asc<=-19776)return "B";
	if($asc>=-19775 and $asc<=-19219)return "C";
	if($asc>=-19218 and $asc<=-18711)return "D";
	if($asc>=-18710 and $asc<=-18527)return "E";
	if($asc>=-18526 and $asc<=-18240)return "F";
	if($asc>=-18239 and $asc<=-17923)return "G";
	if($asc>=-17922 and $asc<=-17418)return "H";
	if($asc>=-17417 and $asc<=-16475)return "J";
	if($asc>=-16474 and $asc<=-16213)return "K";
	if($asc>=-16212 and $asc<=-15641)return "L";
	if($asc>=-15640 and $asc<=-15166)return "M";
	if($asc>=-15165 and $asc<=-14923)return "N";
	if($asc>=-14922 and $asc<=-14915)return "O";
	if($asc>=-14914 and $asc<=-14631)return "P";
	if($asc>=-14630 and $asc<=-14150)return "Q";
	if($asc>=-14149 and $asc<=-14091)return "R";
	if($asc>=-14090 and $asc<=-13319)return "S";
	if($asc>=-13318 and $asc<=-12839)return "T";
	if($asc>=-12838 and $asc<=-12557)return "W";
	if($asc>=-12556 and $asc<=-11848)return "X";
	if($asc>=-11847 and $asc<=-11056)return "Y";
	if($asc>=-11055 and $asc<=-10247)return "Z";
	return null;
}
?>