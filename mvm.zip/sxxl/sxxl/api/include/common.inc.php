<?php
if (!defined('IN_SXXL')) {
    exit('Hacking attempt');
}
$Arr = array();

//����ʱ��
if (PHP_VERSION >= '5.1') {
    date_default_timezone_set('Asia/Shanghai');
}
define('ROOT_PATH', str_replace('/api/include/common.inc.php', '', str_replace('\\', '/', __FILE__)));
define('MODEL_PATH', ROOT_PATH . 'model/');

//���������ļ�
require_once(ROOT_PATH . '/api/Config/config.php');

//�������ݿⳣ��
require_once(ROOT_PATH . '/api/Config/DB.conf.php');

//ͼ������
//require_once(ROOT_PATH . 'api/include/ta.conf.php');

//�������ĿMeta�ļ�
//require_once(ROOT_PATH . 'api/Config/meta.php');

//���빫�ú�����
require_once(ROOT_PATH . '/api/Libs/Main.fun.php');

//����ͨ�ú�����
require_once(ROOT_PATH . '/api/include/function.inc.php');

//����ͨ�ú�����
require_once(ROOT_PATH . '/api/include/function.main.php');

//���볣��
require_once(ROOT_PATH . '/api/Config/config_define.php');

header('Cache-control: private');
header('Content-type: text/html; charset=' . SXXL_CHARSET);

/* ���� Smarty ����
$ar   = array();
$flog = PATH_SEPARATOR == ':' ? '/' : '\\'; // Linux OR Windows system
$ar[] = explode($flog, getcwd());
foreach($ar as $arr => $arv);
$path = $arv[count($arv)-1];
$tmpPath = explode('/', ROOT_PATH);
$rpath = $tmpPath[count($tmpPath)-2];
$path = $path == $rpath ? '' : $path . '/';

makeDir(ROOT_PATH . "Tmpl_c/{$path}");
makeDir(ROOT_PATH . "Tmpl_cache/{$path}");

require_once(ROOT_PATH . 'include/Smarty/Smarty.class.php');
$smarty = $Tpl = new Smarty();
$smarty->template_dir   = ROOT_PATH . "Tmpl/{$path}";
$smarty->compile_dir    = ROOT_PATH . "Tmpl_c/{$path}";
$smarty->cache_dir      = ROOT_PATH . "Tmpl_cache/{$path}";
$smarty->left_delimiter = '{{';
$smarty->right_delimiter= '}}';
unset($ar, $flog, $path);
*/
//�������ݿ���
require_once(ROOT_PATH . '/api/include/class.mysql.php');
$mysql = new MySql(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);

foreach(array('_COOKIE', '_POST', '_GET') as $_request) {
	if(is_array($$_request)){
		foreach($$_request as $_key => $_value) {
			$_key{0} != '_' && $$_key = $_value;
		}
	}
}

if (!empty($_COOKIE["SxxlUserNameLogin"])) {
	$UserName = $_COOKIE["SxxlUserNameLogin"];
	$ShowVip = ShowVipRight($UserName);
	$Arr["UserName"] = $UserName;
	$Arr["ShowVipRight"] = $ShowVip["sVipWord"];
	$Arr["sVipType"] = $ShowVip["sVipType"];
	$Arr["SoftLogin"] = $_COOKIE["Pc_ID"];	//�Ƿ���������¼
	$userInfo = array();
	$userInfo = $ShowVip;
	$userInfo["user_name"] = $_COOKIE["SxxlUserNameLogin"];
	$userInfo["pc_name"] = $_COOKIE["pc_name"];
	$userInfo["cpu_info"] = $_COOKIE["cpu_info"];
	$userInfo["hd_info"] = $_COOKIE["hd_info"];
	$userInfo["net_info"] = $_COOKIE["net_info"];
	$userInfo["pc_id"] = $_COOKIE["Pc_ID"];
	$sql = 'SELECT uid,city,crm_staff FROM '.TB_VIPClient." WHERE UserName = '$UserName'";
	$Arr["info_user"] = $info = $mysql->getRow($sql);
	$userInfo['uid'] = $info['uid'];
	$power=$ShowVip['sVipWord_buy']['netinfo'];
	$Arr["diexun_buy_login"]= "<script type='text/javascript' src='".BUY_DIEXUN.urlencode(base64_encode(authcode('user_name='.$UserName.'&time='.time().'&vip_words='.$power,'ENCODE',URL_SEND_ENCODE_KEY)))."' ></script>";
}
$f = getgpc('f') ? getgpc('f') : "" ;
//$smarty->assign('f', $f);
//ͷ������
$Arr["noticeName"] = '';
/*if (isset($info["city"])) {
	if (trim($info["city"]) == '��ݸ') {
		$Arr["noticeName"] = 'notice_dg';
	}
	if (trim($info["city"]) == '����') {
		$Arr["noticeName"] = 'notice_hz';
	}
	if (trim($info["city"]) == '����') {
		$Arr["noticeName"] = 'notice_jx';
	}
	if (trim($info["city"]) == '����') {
		$Arr["noticeName"] = 'notice_gz';
	}
}*/
$Arr["noticeName"] = 'notice';
//if (in_array($info['crm_staff'], array('meiyipeng','ylf'))) {
//if ($info['crm_staff'] == 'meiyipeng' || $info['crm_staff'] == 'ylf') {
//	$Arr["noticeName"] = 'notice_dg';
//}

//if (isset($info["city"]) && (trim($info["city"]) == '��ݸ' || trim($info["city"]) == '����' || trim($info["city"]) == '����' || trim($info["city"]) == '����' || trim($info["city"]) == '����')) {
//	$Arr["copyrightShow"] = 1;
//}

if($path == 'style') {
	if($Sex==4 || $Sex==5) $Sex='';
}
$message_pop = $_COOKIE["message_pop"];
if ($message_pop != true) {
	setcookie("message_pop", "true", 0, "/");
}

/*ָ�����򵯳���
$cfile = ROOT_PATH . 'clients_list.txt';
if (is_file($cfile)) {
	$cdata = file_get_contents($cfile);
	$cdataArr = explode("\n", $cdata);
	if ($cdataArr) {
		foreach ($cdataArr as $key => $val) {
			$cdataArr[$key] = trim($val);
		}
	}
	if (in_array($userInfo["user_name"], $cdataArr)) {
		$is_show = true;
	}
}*/
if (isset($userInfo["pc_name"]) && $userInfo["user_name"] && $is_show) {
	$table = DB_DATABASE . '.fs_secret_msg';
	$dosubmit = !empty($_REQUEST["dosubmit"]) ? $_REQUEST["dosubmit"] : '';
	if ($dosubmit) {
		$info = $_GET;
		$info["username"] = $userInfo["user_name"];
		$info["pc_name"] = $userInfo["pc_name"];
		$info["add_ip"] = GetIP();
		$info["add_time"] = time();
		$sql = "SELECT id FROM $table WHERE username = '{$userInfo["user_name"]}' AND pc_name = '{$userInfo["pc_name"]}'";
		$is_exist = $mysql->getRow($sql);
		if (!$is_exist) {
			$field = 'username, pc_name, company, contact, address, tel, moblie, add_ip, add_time, crm_staff';
			$value = "'{$info["username"]}', '{$info["pc_name"]}', '{$info["company"]}', '{$info["contact"]}', '{$info["address"]}', '{$info["tel"]}', '{$info["moblie"]}', '{$info["add_ip"]}', '{$info["add_time"]}', '{$Arr["info_user"]["crm_staff"]}'";
			$mysql->insert($table, $field, $value);
		}
	}
	//��ȡ�û���Ϣ
	/*$sql = 'SELECT crm_staff FROM ' . TB_VIPClient . " WHERE UserName = '{$_COOKIE["SxxlUserNameLogin"]}'";
	$user_info = $mysql->getRow($sql);

	$sql = "SELECT brid FROM crm_fs.crm_member_branch WHERE username='{$user_info["crm_staff"]}'";
	$rows = $mysql->arrQuery($sql);
	$brids = array();
	if ($rows) {
		foreach ($rows as $key => $val) {
			$brids[$key] = $val["brid"];
		}
	}*/
	$sql = "SELECT id FROM $table WHERE username = '{$userInfo["user_name"]}' AND pc_name = '{$userInfo["pc_name"]}'";
	$is_exist = $mysql->getRow($sql);
	$is_show = false;
	if (empty($is_exist)) {
//		if (in_array(5, $brids) || in_array(23, $brids) || in_array(24, $brids) || in_array(25, $brids) ||
//			in_array(12, $brids) || in_array(40, $brids) || in_array(41, $brids) || in_array(42, $brids) || in_array(44, $brids)) {
//			$is_show = true;
//		}
		$is_show = true;
	}
	$Arr["is_secret_show"] = $is_show;
}
//�����Ա�
$searchSexArr = array(1 => '��װman1',2 => 'Ůװwoman2',3 => 'ͯװkids3',4 => 'Ůͯkids4',5 => '��ͯkids5', 6 => 'Ӥͯkids6');
//�Ա�
$sexArr = array(2 => 'Ůװ', 1 => '��װ', 5 => '��ͯ', 4 => 'Ůͯ', 6 => 'Ӥͯ');
//Ȩ��
$viptypeArr = array(0=>"���",1=>"���",2=>"��װ����vip",3=>"Ůװ����vip",4=>"ͯװ����vip",5=>"��ʯ����vip",6=>"��װvip",7=>"Ůװvip",8=>"ͯװvip",9=>"��ʯvip",10=>"��������vip",11=>"����vip");