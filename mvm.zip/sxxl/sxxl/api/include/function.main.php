<?php
/**
 * �ļ��ϴ�
 * @return array
 */
function upload_image() {
    require_once(ROOT_PATH . '/include/class.upload.php');
    if($_FILES) {
        $up_path = Get_Path('', true);
        $upload = new RUpload();
        $files = $upload->save_as_timestr($up_path);
    }
    return $files;
}

/**
 * �Ա�ֵת���ַ�
 * @param string $val
 * @return string
 */
function getSexStr($val) {
	if (empty($val)) return false;
	$rArr = array();
	$vals = explode(',', $val);
	if (in_array('1', $vals)) $rArr[] = '��';
	if (in_array('2', $vals)) $rArr[] = 'Ů';
	if (in_array('3', $vals)) $rArr[] = 'ͯ';
	if (in_array('4', $vals)) $rArr[] = '��ͯ';
	if (in_array('5', $vals)) $rArr[] = 'Ůͯ';
	return implode(',', $rArr);
}

/**
 * ��дURL��ַ
 * @param string $app
 * @param array	 $params ��������
 * @return string
 */
function rewriteUri($app, $params) {
	extract($params);
	if (empty($act)) return false;
	$uri = '';
	switch ($app) {
		case 'member':
			$uri = '/member/?act=' . $act;
			$uri .= !empty($oct) ? ('&oct=' . $oct) : '';
			$uri .= !empty($l) ? ('&l=' . $l) : '';
			$uri .= !empty($del) ? ('&del='.$del) : '';
			$uri .= !empty($mid) ? ('&mid='.$mid) : '';
			break;
		case 'search':
			$uri = '/search/?act=' . $act;
			$uri .= !empty($cid) ? ('&cid=' . $cid) : '';
			$uri .= !empty($brand) ? ('&brand=' . $brand) : '';
			$uri .= !empty($season) ? ('&season=' . $season) : '';
			$uri .= !empty($q) ? ('&q=' . $q) : '';
			$uri .= !empty($qs) ? ('&qs=' . $qs) : '';
			break;
		case 'invogue':
			$uri = '/invogue/?act=' . $act;
			$uri .= !empty($gender) ? ('&gender=' . $gender) : '';
			$uri .= !empty($tb) ? ('&tb=' . $tb) : '';
			$uri .= !empty($ts) ? ('&ts=' . $ts) : '';
			break;
		case 'catwalk':
			$uri = '/catwalk/?act=' . $act;
			$uri .= !empty($gender) ? ('&gender=' . $gender) : '';
			$uri .= !empty($tb) ? ('&tb=' . $tb) : '';
			$uri .= !empty($ts) ? ('&ts=' . $ts) : '';
			break;
		case 'pattern':
			$uri  = '/pattern/?act=' . $act;
			$uri .= !empty($fl) ? ('&fl=' . $fl) : '';
			$uri .= !empty($tx_big) ? ('&tx_big=' . $tx_big) : '';
			$uri .= !empty($tx_small) ? ('&tx_small=' . $tx_small) : '';
			$uri .= !empty($gy) ? ('&gy=' . $gy) : '';
			$uri .= !empty($bw) ? ('&bw=' . $bw) : '';
			$uri .= !empty($ks) ? ('&ks=' . $ks) : '';
			$uri .= !empty($gs) ? ('&gs=' . $gs) : '';
			$uri .= !empty($sex) ? ('&sex=' . $sex) : '';
			$uri .= !empty($wt) ? ('&wt=' . $wt) : '';
			$uri .= !empty($xh) ? ('&xh=' . $xh) : '';
			$uri .= !empty($other) ? ('&other=' . $other) : '';
			break;
		case 'style':
		case 'column_style':
	    case 'business_style':
			if (!in_array($act, array('column_style','business_style'))) {
				$uri  = '/style/?act=' . $act;
			}
			else {
				$uri  = '?1=1';
			}
			$uri .= !empty($gender) ? ('&gender=' . $gender) : '';
			$uri .= !empty($tb) ? ('&tb=' . $tb) : '';
			$uri .= !empty($ts) ? ('&ts=' . $ts) : '';
			$uri .= !empty($tm) ? ('&tm=' . $tm) : '';
			$uri .= !empty($bc) ? ('&bc=' . $bc) : '';
            $uri .= !empty($region) ? ('&region=' . $region) : '';
            $uri .= !empty($season) ? ('&season=' . $season) : '';
			$uri .= !empty($brand) ? ('&brand=' . $brand) : '';
			$uri .= !empty($color) ? ('&color=' . $color) : '';
			$uri .= !empty($is_detail) ? ('&is_detail=' . $is_detail) : '';
			$uri .= !empty($bdetail) ? ('&bdetail=' . $bdetail) : '';
			$uri .= !empty($detail) ? ('&detail=' . $detail) : '';
			$uri .= !empty($sid) ? ('&sid=' . $sid) : '';
			$uri .= !empty($kid) ? ('&kid=' . $kid) : '';
			$uri .= !empty($bkey) ? ('&bkey=' . $bkey) : '';
			$uri .= !empty($skey) ? ('&skey=' . $skey) : '';
			$uri .= !empty($tid) ? ('&tid=' . $tid) : '';
			$uri .= !empty($pid) ? ('&pid=' . $pid) : '';
			$uri .= !empty($top) ? ('&top=' . $top) : '';
			break;
		case 'cowboy':
			$uri  = '/cowboy/?act=' . $act;
			$uri .= !empty($oct) ? ('&oct=' . $oct) : '';
			$uri .= !empty($gender) ? ('&gender=' . $gender) : '';
			$uri .= !empty($tb) ? ('&tb=' . $tb) : '';
			$uri .= !empty($class) ? ('&class=' . $class) : '';
			$uri .= !empty($tid) ? ('&tid=' . $tid) : '';
			$uri .= !empty($fl) ? ('&fl=' . $fl) : '';
			$uri .= !empty($tx_big) ? ('&tx_big=' . $tx_big) : '';
			$uri .= !empty($tx_small) ? ('&tx_small=' . $tx_small) : '';
			$uri .= !empty($gy) ? ('&gy=' . $gy) : '';
			$uri .= !empty($bw) ? ('&bw=' . $bw) : '';
			$uri .= !empty($ks) ? ('&ks=' . $ks) : '';
			$uri .= !empty($gs) ? ('&gs=' . $gs) : '';
			$uri .= !empty($sex) ? ('&sex=' . $sex) : '';
			$uri .= !empty($wt) ? ('&wt=' . $wt) : '';
			$uri .= !empty($xh) ? ('&xh=' . $xh) : '';
			$uri .= !empty($other) ? ('&other=' . $other) : '';
			break;
	}
	return $uri;
}

/**
 * ����$cid��ȡ����Ŀ����Ϣ
 * @param int $cid
 * @return array
 */
function getColumnInfo($cid, $type = '') {
	$cid = intval($cid);
	$db = 18 == $cid ? 'style_info.' : 'Product_Sxxlcn.';
	$rArr = array();
	switch ($cid) {
		case 11:
			$rArr["table"] = $db . 'info_lxqs_trend';
			$rArr["table_pic"] = $db . 'info_lxqs_trend_pic';
			$rArr["table_son"] = $db .'info_lxqs_trend_stopic';
			$rArr["table_son_pic"] = $db .'info_lxqs_trend_spic';
			$rArr["name"] = '��������';
			$rArr['detail_href'] = '/App/popular/trend_detail.php?id=';
			$rArr["href"] = '/App/popular/trend.php';
			break;
		case 12:
			$rArr["table"] = $db . 'info_szfb';
			$rArr["table_pic"] = empty($type) ? $db .'info_szfb_pic' : $db .'info_szfb_expand_pic';
			$rArr["name"] = 'ʱװ����';
			$rArr['detail_href'] = '/App/fashion/catwalk_detail.php?ID=';
			$rArr["href"] = '/App/fashion/catwalk.php';
			break;
		case 1299:
			$rArr["table"] = $db . 'info_szfb_tshape';
			$rArr["table_pic"] = $db . 'info_szfb_tshape_pic';
			$rArr["table_cat"] = $db . 'info_szfb_tshape_stype';
			$rArr["table_son"] = $db .'info_szfb_tshape_stopic';
			$rArr["table_son_pic"] = $db .'info_szfb_tshape_spic';
			$rArr["name"] = 'ʱװ����-T̨���Ʒ���';
			$rArr['detail_href'] = '/App/fashion/tshape_trend.php?id=';
			$rArr["href"] = '/App/fashion/tshape.php?Sex=2';
			break;
		case 13:
			$rArr["table"] = $db . 'info_zzlx';
			$rArr["table_pic"] = $db .'info_zzlx_pic';
			$rArr["name"] = '��������';
			$rArr['detail_href'] = '/App/popular/invogue_detail.php?ID=';
			$rArr["href"] = '/App/popular/invogue.php';
			break;
		case 1318:
			$rArr["table"] = $db . TB_INFO_ZZLX_INVOGUE;
			$rArr["table_pic"] = $db . TB_INFO_ZZLX_INVOGUE_PIC;
			$rArr["table_son"] = $db .TB_INFO_ZZLX_INVOGUE_STOPIC;
			$rArr["table_son_pic"] = $db .TB_INFO_ZZLX_INVOGUE_SPIC;
			$rArr["name"] = '���з���';
			$rArr['detail_href'] = '/App/popular/invogue_lxfx_topic.php?id=';
			$rArr["href"] = '/App/popular/invogue.php?sTypeID=1318';
			break;
		case 1320:
			$rArr["table"] = $db . 'info_zzlx_hbnz';
			$rArr["table_pic"] = $db .'info_zzlx_hbnz_pic';
			$rArr["name"] = '�������� - ����ţ��';
			$rArr['detail_href'] = '/App/popular/invogue_detail.php?sTypeID=1320&ID=';
			$rArr["href"] = '/App/popular/invogue.php?dynamic=gn&sTypeID=1320&Sex=2';
			break;
		case 14:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = '�ָ�����';
			$rArr['detail_href'] = '/App/book/designtrend_detail.php?ID=';
			$rArr["href"] = '/App/book/designtrend.php';
			break;
		case 15:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = '�㳡����';
			$rArr['detail_href'] = '/App/book/showcase_detail.php?ID=';
			$rArr["href"] = '/App/book/showcase.php?Sex=2';
			break;
		case 16:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = '�鼮';
			$rArr['detail_href'] = '/App/book/book_detail.php?ID=';
			$rArr["href"] = '/App/book/book.php';
			break;
		case 17:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = 'ʱװ��־';
			$rArr['detail_href'] = '/App/book/magazine_detail.php?ID=';
			$rArr["href"] = '/App/book/magazine.php';
			break;
		case 18:
			$rArr["table"] = $db . 'fs_ssks';
			$rArr["table_extend"] = $db . 'fs_ssks_extend';
			$rArr["table_attr"] = $db . 'fs_ssks_attr';
			$rArr["table_pic"] = $db . 'fs_ssks_pic';
			$rArr["table_pic_extend"] = $db . 'fs_ssks_pic_extend';
			$rArr["table_pic_cat"] = $db . 'fs_ssks_pic_cat';
			$rArr["table_pic_attr"] = $db . 'fs_ssks_pic_attr';
			$rArr["table_pic_attach"] = $db . 'fs_ssks_pic_attach';
			$rArr["table_pic_attach_cat"] = $db . 'fs_ssks_pic_attach_cat';
			$rArr["table_pic_attach_attr"] = $db . 'fs_ssks_pic_attach_attr';
			$rArr["table_fav"] = $db . 'favorite_ks';
			$rArr["name"] = 'ʱ�п�ʽ';
			$rArr["href"] = '/style';
			$rArr['detail_href'] = '/style/?act=theme_detail&tid=';
			break;
		case 19:
			$rArr["table"] = $db . 'info_taqs_tshape';
			$rArr["table_pic"] = $db . 'info_taqs_tshape_pic';
			$rArr["table_son"] = $db .'info_taqs_tshape_stopic';
			$rArr["table_son_pic"] = $db .'info_taqs_tshape_spic';
			$rArr["name"] = 'ͼ�� - ͼ������';
			$rArr['detail_href'] = '/pattern/?act=trends_detail&fid=';
			$rArr["href"] = '/pattern/?act=trends';
			break;
		case 20:
			$rArr["table_pic"] = $db . 'InfoPV';
			$rArr["name"] = 'ͼ�� - ʸ��ӡ��';
			$rArr["href"] = '/pattern/?act=prints&stype=2';
			break;
		case 22:
			$rArr["table"] = $db . 'info_lxqs';
			$rArr["table_pic"] = $db . 'info_lxqs_pic';
			$rArr["name"] = '����';
			$rArr['detail_href'] = '/App/popular/accessory_detail.php?ID=';
			$rArr["href"] = '/App/popular/accessory.php';
			break;
		case 23:
			$rArr["table"] = $db . 'info_ny';
			$rArr["table_pic"] = $db . 'info_ny_pic';
			$rArr["table_pic_attach"] = $db . 'info_ny_morepic_pic';
			
			$rArr["name"] = '����';
			$rArr['detail_href'] = 'http://neiyi.sxxl.com/homewear_detail.php?ID=';
			$rArr["href"] = 'http://neiyi.sxxl.com';
		
//			$rArr["table"] = $db . '';
//			$rArr["table_pic"] = $db . '';
//			$rArr["name"] = '����';
//			$rArr['detail_href'] = 'http://neiyi.sxxl.com/homewear_detail.php?ID=';
//			$rArr["href"] = 'http://neiyi.sxxl.com';
			break;
		case 24:
			$rArr["table"] = $db . 'info_pv_book';
			$rArr["table_pic"] = $db . 'info_pv_book_pic';
			$rArr["name"] = 'ͼ�� - ͼ���鼮';
			$rArr['detail_href'] = '/pattern/?act=theme_detail&cid=24&id=';
			$rArr["href"] = '/pattern/?act=books';
			break;
		case 26:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = '�г��۽�';
			$rArr['detail_href'] = '/App/book/focus_detail.php?ID=';
			$rArr["href"] = '/App/book/focus.php';
			break;
		case 27:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = 'Ʒ�ƻ���';
			$rArr['detail_href'] = '/App/book/album_detail.php?ID=';
			$rArr["href"] = '/App/book/album.php';
			break;
		case 28:
			$rArr["table"] = $db . 'info_zzlx';
			$rArr["table_pic"] = $db . 'info_zzlx_pic';
			$rArr["name"] = '�Ӿ�Ӫ��';
			$rArr['detail_href'] = '/App/popular/display_detail.php?ID=';
			$rArr["href"] = '/App/popular/display.php';
			break;
		case 37:
			$rArr["table"] = $db . 'fs_cowboy';
			$rArr["table_pic"] = $db . 'fs_cowboy_pic';
			$rArr["table_extend"] = $db . 'fs_cowboy_extend';
			$rArr["table_attr"] = $db . 'fs_cowboy_attr';
			$rArr["table_pic_extend"] = $db . 'fs_cowboy_pic_extend';
			$rArr["table_pic_cat"] = $db . 'fs_cowboy_pic_cat';
			$rArr["table_pic_attr"] = $db . 'fs_cowboy_pic_attr';
			$rArr["name"] = 'ţ�� - ����/����';
			$rArr['detail_href'] = '/cowboy/?act=fabacc&oct=detail&tid=';
			$rArr["href"] = '/cowboy/?act=fabacc';
			break;
		case 33:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["name"] = '�˶� - �г��۽�';
			$rArr['detail_href'] = '/App/column/sport_detail.php?sType=focus&ID=';
			$rArr["href"] = '/App/column/sport.php?sType=focus&Sex=2';
			break;
		case 36:
			$rArr["table"] = $db . 'info_lxqs';
			$rArr["table_pic"] = $db . 'info_lxqs_pic';
			$rArr["name"] = '��ͷʱ��';
			$rArr['detail_href'] = '/App/popular/streetspot_detail.php?ID=';
			break;
		case 3801:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = 'Ӥͯר��';
			$rArr['detail_href'] = '/App/kids/kids_baby_detail.php?sTypeID=3801&ID=';
			$rArr["href"] = '/App/kids/kids_baby.php?state=baby';
			break;
		case 3802:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = 'Ӥͯר��';
			$rArr['detail_href'] = '/App/kids/kids_baby_detail.php?sTypeID=3802&ID=';
			$rArr["href"] = '/App/kids/kids_baby.php?state=baby';
			break;
		case 3803:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = 'Ӥͯר��';
			$rArr['detail_href'] = '/App/kids/kids_baby_detail.php?sTypeID=3803&ID=';
			$rArr["href"] = '/App/kids/kids_baby.php?state=baby';
			break;
		case 38:
			$rArr["table"] = $db . 'InfoContext';
			$rArr["table_pic"] = $db . 'InfoContextPictureFile';
			$rArr["name"] = 'Ӥͯר��';
			$rArr['detail_href'] = '/App/kids/kids_baby_detail.php?sTypeID=3803&ID=';
			$rArr["href"] = '/App/kids/kids_baby.php?state=baby';
			break;
		case 40:
			$rArr["table"] = $db . 'info_ta_lgta_topic';
			$rArr["table_pic"] = $db . 'info_ta_lgta_pic';
			$rArr["name"] = 'ͼ�� - ���ͼ��';
			$rArr['detail_href'] = '/pattern/?act=inspiration_detail&id=';
			$rArr["href"] = '/pattern/?act=inspiration';
			break;
		case 42:
			$rArr["table_pic"] = $db . 'info_ta_mlyh';
			$rArr["name"] = 'ͼ�� - ����ӡ�� - �������';
			$rArr["href"] = '/pattern/?act=prints&stype=1';
			break;
		case 43:
			$rArr["table"] = $db . 'info_taqs_tshape';
			$rArr["table_pic"] = $db . 'info_taqs_tshape_pic';
			$rArr["table_son"] = $db .'info_taqs_tshape_stopic';
			$rArr["table_son_pic"] = $db .'info_taqs_tshape_spic';
			$rArr["name"] = 'ͼ������';
			$rArr["href"] = '/pattern';
			$rArr['detail_href'] = '/pattern/?act=trends_detail&fid=';
			break;
		case 45:
			$rArr["table"] = $db . 'info_ta_ztta';
			$rArr["table_pic"] = $db . 'info_ta_ztta_pic';
			$rArr["name"] = 'ͼ������';
			$rArr['detail_href'] = '/pattern/?act=theme_detail&cid=45&id=';
			$rArr["href"] = '/pattern/?act=theme';
			break;
		default:
			break;
	}
	return $rArr;
}

/**
 * ��ȡmeta��title��keyword,urlHere��ֵ
 * @param string $app
 * @param array $params
 */
function getMetas($app, $params, $str = '') {
	extract($params);
	$title	= '';
	$keywords = '';
	$description = '';
	$urlHere = '<a href="/index.php" title="������ҳ">��ҳ</a>';
	switch ($app) {
		case 'member':
			$name = '�ҵĵ�Ѷ';
			$urlHere .= " &gt; <a href='/member' title='{$name}'>{$name}</a>";
			$title      = $name . '_' . $GLOBALS['Meta']['index']['title'];
			$keywords   = $GLOBALS['Meta']['index']['keyword'] . ',' . $name;
			$description= $name . ',' . $GLOBALS['Meta']['index']['description'];
			if ($act) {
				$title		= $GLOBALS['menuArr'][$act]['menuName'] . '_' . $title;
				$keywords  .= ',' . $GLOBALS['menuArr'][$act]['menuName'];
				$description= $GLOBALS['menuArr'][$act]['menuName'] . ',' . $description;
			}
			if ($oct) {
				$title		= $GLOBALS['menuArr'][$oct]['menuName'] ? ($GLOBALS['menuArr'][$oct]['menuName'] . '_' . $title) : $title;
				$keywords  .= $GLOBALS['menuArr'][$oct]['menuName'] ? (',' . $GLOBALS['menuArr'][$oct]['menuName']) : '';
				$description= $GLOBALS['menuArr'][$oct]['menuName'] ? ($GLOBALS['menuArr'][$oct]['menuName'] . ',' . $description) : $description;
			}
			if ($l) {
				$title		= $GLOBALS['menuArr'][$l]['menuName'] . '_' . $title;
				$keywords  .= ',' . $GLOBALS['menuArr'][$l]['menuName'];
				$description= $GLOBALS['menuArr'][$l]['menuName'] . ',' . $description;
			}
			break;
		case 'search':
			$name = '����';
			$url = rewriteUri('search', array('act'=>$act,'q'=>$q));
			$urlHere .= " &gt; <a href='{$url}' title='{$name}'>{$name}</a>";
			$title      = $name . '_' . $GLOBALS['Meta']['index']['title'];
			$keywords   = $GLOBALS['Meta']['index']['keyword'] . ',' . $name;
			$description= $name . ',' . $GLOBALS['Meta']['index']['description'];
			if ($cid) {
				$info = $GLOBALS['cidArr'][$cid];
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('search', array('act'=>$act,'gender'=>$gender,'cid'=>$cid, 'q'=>$q));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			break;
		case 'catwalk':
			$cInfo = getColumnInfo(12);
			$urlHere .= " &gt; <a href='{$cInfo["href"]}' title='{$cInfo["name"]}'>{$cInfo["name"]}</a>";
			$title      = $GLOBALS["Meta"]["catwalk"]["title"];
			$keywords   = $GLOBALS["Meta"]["catwalk"]["keyword"];
			$description= $GLOBALS["Meta"]["catwalk"]["description"];
			if ($act == 'search_pic') {
				$tname = 'ʱװ����ϸ������';
				$title		= $tname . '_' . $title;
				$keywords  .= ',' . $tname;
				$description= $tname . ',' . $description;
				$urlHere .= " &gt; <a href='/catwalk/?act=search_pic&gender={$gender}' title=$tname>ʱװ����ϸ������</a>";
			}
			if ($tb) {
				//���ദ��
				$CT = load('class_type');
				$info = $CT->getInfo($tb, 'TypeName,Cid', 'Cid', 1);
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('catwalk', array('act'=>$act,'gender'=>$gender,'tb'=>$tb));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			if ($ts) {
				//���ദ��
				$CT = load('class_type');
				$info = $CT->getInfo($ts, 'TypeName,Cid', 'Cid', 1);
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('catwalk', $params);
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			break;
		case 'invogue':
			$cInfo = getColumnInfo(13);
			$urlHere .= " &gt; <a href='{$cInfo["href"]}' title='{$cInfo["name"]}'>{$cInfo["name"]}</a>";
			$title      = $GLOBALS["Meta"]["invogue"]["title"];
			$keywords   = $GLOBALS["Meta"]["invogue"]["keyword"];
			$description= $GLOBALS["Meta"]["invogue"]["description"];
			if ($act == 'search_pic') {
				$title		= '��������ϸ������' . '_' . $title;
				$keywords  .= ',' . '��������ϸ������';
				$description= '��������ϸ������' . ',' . $description;
				$urlHere .= " &gt; <a href='/invogue/?act=search_pic&gender={$gender}' title='��������ϸ������'>��������ϸ������</a>";
			}
			if ($tb) {
				//���ദ��
				$CT = load('class_type');
				$info = $CT->getInfo($tb, 'TypeName,Cid', 'Cid', 1);
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('invogue', array('act'=>$act,'gender'=>$gender,'tb'=>$tb));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			if ($ts) {
				//���ദ��
				$CT = load('class_type');
				$info = $CT->getInfo($ts, 'TypeName,Cid', 'Cid', 1);
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('invogue', $params);
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			break;
		case 'style':
			$cInfo = getColumnInfo(18);
			$urlHere .= " &gt; <a href='{$cInfo["href"]}/?act=index' title='{$cInfo["name"]}'>{$cInfo["name"]}</a>";
			$title      = $GLOBALS["Meta"]["style"]["title"];
			$keywords   = $GLOBALS["Meta"]["style"]["keyword"];
			$description= $GLOBALS["Meta"]["style"]["description"];
			if ($gender) {
//				$title		= $GLOBALS["genderArr"][$gender]["name"] . '_' . $title;
//				$keywords  .= ',' . $GLOBALS["genderArr"][$gender]["name"];
//				$description= $GLOBALS["genderArr"][$gender]["name"] . ',' . $description;
				$title		= $title;
				$keywords  .= ',' . $GLOBALS["genderArr"][$gender]["name"];
				$description= $GLOBALS["genderArr"][$gender]["name"] . ',' . $description;
//				$urlHere .= " &gt; <a href='{$GLOBALS["genderArr"][$gender]["href"]}' title='{$GLOBALS["genderArr"][$gender]["name"]}'>{$GLOBALS["genderArr"][$gender]["name"]}</a>";
			}
			if ($tb) {
				$info = $GLOBALS['typeArrb'][$tb];
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('style', array('act'=>$act,'gender'=>$gender,'tb'=>$tb));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			if ($ts) {
				$info = $GLOBALS['typeArrs'][$ts];
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('style', array('act'=>$act,'gender'=>$gender,'tb'=>$tb,'ts'=>$ts));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			if ($tm) {
				$info = $GLOBALS['typeArrm'][$tm];
				$title		= $info['TypeName'] . '_' . $title;
				$keywords  .= ',' . $info['TypeName'];
				$description= $info['TypeName'] . ',' . $description;
				$url = rewriteUri('style', array('act'=>$act,'gender'=>$gender,'tb'=>$tb,'ts'=>$ts));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['TypeName']}'>{$info['TypeName']}</a>";
			}
			if ($region) {
				$info = $GLOBALS['regionArr'][$region];
				$title		= $info['attr_name'] . '_' . $title;
				$keywords  .= ',' . $info['attr_name'];
				$description= $info['attr_name'] . ',' . $description;
				$url = rewriteUri('style', array('act'=>$act,'gender'=>$gender,'tb'=>$tb,'ts'=>$ts,'region'=>$region));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['attr_name']}'>{$info['attr_name']}</a>";
			}
			if ($sid) {
				$info = $GLOBALS['styleArr'][$sid];
				$title		= $info['attr_name'] . '_' . $title;
				$keywords  .= ',' . $info['attr_name'];
				$description= $info['attr_name'] . ',' . $description;
				$url = rewriteUri('style', array('act'=>$act,'gender'=>$gender,'tb'=>$tb,'ts'=>$ts,'sid'=>$sid));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['attr_name']}'>{$info['attr_name']}</a>";
			}
			if ($kid) {
				$info = $GLOBALS['keyArr'][$kid];
				$title		= $info['attr_name'] . '_' . $title;
				$keywords  .= ',' . $info['attr_name'];
				$description= $info['attr_name'] . ',' . $description;
				$url = rewriteUri('style', array('act'=>$act,'gender'=>$gender,'tb'=>$tb,'ts'=>$ts,'kid'=>$kid));
				$urlHere .= " &gt; <a href='{$url}' title='{$info['attr_name']}'>{$info['attr_name']}</a>";
			}
			break;
		case 'pattern':
			$urlHere .= " &gt; <a href='/pattern/' title='ͼ��'>ͼ��</a>";
			$title      = $GLOBALS["Meta"]["prints"]["title"];
			$keywords   = $GLOBALS["Meta"]["prints"]["keyword"];
			$description= $GLOBALS["Meta"]["prints"]["description"];
			if ($act) {
				$tmpArr = array('trends'=>array('name'=>'ͼ������', 'href'=>'/pattern/?act=trends'),
								'theme'=>array('name'=>'ͼ������', 'href'=>'/pattern/?act=theme'),
								'books'=>array('name'=>'ͼ���鼮', 'href'=>'/pattern/?act=books'),
								'inspiration'=>array('name'=>'���ͼ��', 'href'=>'/pattern/?act=inspiration'),
								'prints'=>array('name'=>'����ӡ��', 'href'=>'/pattern/?act=prints'),
								'practical'=>array('name'=>'ͼ��ͼ��', 'href'=>'/pattern/?act=practical'),
								'search'=>array('name'=>'ͼ������', 'href'=>'/pattern/index.php?act=search'));
				if ($tmpArr[$act]) {
				//	$title		= $tmpArr[$act]["name"] . '_' . $title;
					$title		= $title;
					$keywords  .= ',' . $tmpArr[$act]["name"];
					$description= $tmpArr[$act]["name"] . ',' . $description;
					$urlHere .= " &gt; <a href='{$tmpArr[$act]["href"]}' title='{$tmpArr[$act]["name"]}'>{$tmpArr[$act]["name"]}</a>";
				}
			}
			if ($fl) {
				$CT = load('class_type');
				$tmInfo = $CT->getOneInfo($fl);
				$title		= $tmInfo["TypeName"] . '_' . $title;
				$keywords  .= ',' . $tmInfo["TypeName"];
				$description= $tmInfo["TypeName"] . ',' . $description;
			}
			if ($class) {
				$CT = load('class_type');
				$tmInfo = $CT->getOneInfo($class);
				$title		= $tmInfo["TypeName"] . '_' . $title;
				$keywords  .= ',' . $tmInfo["TypeName"];
				$description= $tmInfo["TypeName"] . ',' . $description;
			}
			if ($class_id) {
				$CT = load('class_type');
				$tmInfo = $CT->getOneInfo($class_id);
				$title		= $tmInfo["TypeName"] . '_' . $title;
				$keywords  .= ',' . $tmInfo["TypeName"];
				$description= $tmInfo["TypeName"] . ',' . $description;
			}
			if ($tx_big) {
				$CT = load('class_type');
				$tmInfo = $CT->getOneInfo($tx_big);
				$title		= $tmInfo["TypeName"] . '_' . $title;
				$keywords  .= ',' . $tmInfo["TypeName"];
				$description= $tmInfo["TypeName"] . ',' . $description;
				if ($tx_small) {
					$tmInfo = $CT->getOneInfo($tx_small);
					$title		= $tmInfo["TypeName"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["TypeName"];
					$description= $tmInfo["TypeName"] . ',' . $description;
				}
			}
			if ($gy) {
				$CTA = load('class_ta_att');
				$tmInfo = $CTA->getOneInfo($gy);
				$title		= $tmInfo["att_name"] . '_' . $title;
				$keywords  .= ',' . $tmInfo["att_name"];
				$description= $tmInfo["att_name"] . ',' . $description;
			}
			if ($bw) {
				$CTA = load('class_ta_att');
				$tmInfo = $CTA->getOneInfo($bw);
				$title		= $tmInfo["att_name"] . '_' . $title;
				$keywords  .= ',' . $tmInfo["att_name"];
				$description= $tmInfo["att_name"] . ',' . $description;
			}
			if ($ks) {
				$CTA = load('class_ta_att');
				$tmInfo = $CTA->getOneInfo($ks);
				$title		= $tmInfo["att_name"] . '_' . $title;
				$keywords  .= ',' . $tmInfo["att_name"];
				$description= $tmInfo["att_name"] . ',' . $description;
			}
			break;
			case 'cowboy':
				$urlHere .= " &gt; <a href='/App/column/jeans.php' title='ţ��ר��'>ţ��ר��</a>";
				$title      = $GLOBALS["Meta"]["jeans"]["title"];
				$keywords   = $GLOBALS["Meta"]["jeans"]["keyword"];
				$description= $GLOBALS["Meta"]["jeans"]["description"];
				if ($act) {
					$tmpArr = array('fabacc'=>array('name'=>'����/����', 'href'=>'/cowboy/?act=fabacc&gender='.$gender),
									'streetspot'=>array('name'=>'��ͷʱ��', 'href'=>'/cowboy/?act=streetspot&gender='.$gender),
									'pattern'=>array('name'=>'ţ��ͼ��', 'href'=>'/cowboy/?act=pattern&sex='.$sex),
									);
					if ($tmpArr[$act]) {
						$title		= $tmpArr[$act]["name"] . '_' . $title;
						$keywords  .= ',' . $tmpArr[$act]["name"];
						$description= $tmpArr[$act]["name"] . ',' . $description;
						$urlHere .= " &gt; <a href='{$tmpArr[$act]["href"]}' title='{$tmpArr[$act]["name"]}'>{$tmpArr[$act]["name"]}</a>";
					}
				}
				if (($act =="fabacc" || $act =="streetspot") && $tb) {
					$cType = load('class_type');
					$cid = $act = "fabacc" ? 3702 : 3602;
					$catArr = $cType->getClassType($cid, $gender, 1, $fileCache);
					$title		= $catArr[$tb]['TypeName'] . '_' . $title;
					$keywords  .= ',' . $catArr[$tb]['TypeName'];
					$description= $catArr[$tb]['TypeName'] . ',' . $description;
				}
				if ($fl) {
					$CT = load('class_type');
					$tmInfo = $CT->getOneInfo($fl);
					$title		= $tmInfo["TypeName"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["TypeName"];
					$description= $tmInfo["TypeName"] . ',' . $description;
				}
				if ($class) {
					$CT = load('class_type');
					$tmInfo = $CT->getOneInfo($class);
					$title		= $tmInfo["TypeName"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["TypeName"];
					$description= $tmInfo["TypeName"] . ',' . $description;
				}
				if ($class_id) {
					$CT = load('class_type');
					$tmInfo = $CT->getOneInfo($class_id);
					$title		= $tmInfo["TypeName"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["TypeName"];
					$description= $tmInfo["TypeName"] . ',' . $description;
				}
				if ($tx_big) {
					$CT = load('class_type');
					$tmInfo = $CT->getOneInfo($tx_big);
					$title		= $tmInfo["TypeName"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["TypeName"];
					$description= $tmInfo["TypeName"] . ',' . $description;
					if ($tx_small) {
						$tmInfo = $CT->getOneInfo($tx_small);
						$title		= $tmInfo["TypeName"] . '_' . $title;
						$keywords  .= ',' . $tmInfo["TypeName"];
						$description= $tmInfo["TypeName"] . ',' . $description;
					}
				}
				if ($gy) {
					$CTA = load('class_ta_att');
					$tmInfo = $CTA->getOneInfo($gy);
					$title		= $tmInfo["att_name"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["att_name"];
					$description= $tmInfo["att_name"] . ',' . $description;
				}
				if ($bw) {
					$CTA = load('class_ta_att');
					$tmInfo = $CTA->getOneInfo($bw);
					$title		= $tmInfo["att_name"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["att_name"];
					$description= $tmInfo["att_name"] . ',' . $description;
				}
				if ($ks) {
					$CTA = load('class_ta_att');
					$tmInfo = $CTA->getOneInfo($ks);
					$title		= $tmInfo["att_name"] . '_' . $title;
					$keywords  .= ',' . $tmInfo["att_name"];
					$description= $tmInfo["att_name"] . ',' . $description;
				}
				if ($gender) {
					$sexArr = array(2 => 'Ůװ', 1 => '��װ',3=>'ͯװ', 5 => '��ͯ', 4 => 'Ůͯ', 6 => 'Ӥͯ');
					$title		= $sexArr[$gender] . '_' . $title;
					$keywords  .= ',' . $sexArr[$gender];
					$description= $sexArr[$gender] . ',' . $description;
				}
				if ($tid) {
					//����ģ���ļ�
					$cowboy = load('cowboy');
					if($act == "fabacc"){
						$themeInfo = $cowboy->getThemeInfo($tid, 'A.title,A.gender,A.class_city,A.class_season,A.display_time');
						$themeTitle = $themeInfo['title'];
					}elseif($act == "streetspot"){
						$themeInfo = $cowboy->getThemeInfo($tid, 'A.Title,A.Sex,A.ClassCity,A.nrelease_time,A.ClassCity', 'streetspot');
						$themeTitle = $themeInfo['Title'];
					}elseif($act == "pattern"){
						$theme_detail = load("pattern_theme");
						$zt_table = TB_INFO_PV_BOOK;
						$zt_pagesize = 0;
						$theme_detail->set_var("Title",$zt_pagesize,$zt_table);  //��������ͼ��һЩ����
						$zt_str_where = " AND ID='{$tid}'";
						$zt_data = $theme_detail->get_ztta_content($zt_str_where);
						$themeTitle =  $zt_data['Title'];
					}
					$title		= $themeTitle . '_' . $title;
					$keywords  .= ',' . $themeTitle;
					$description= $themeTitle . ',' . $description;
					$urlHere .= '> ' . $themeTitle;
				}
				break;
			default:
				$title      = $GLOBALS["Meta"]["index"]["title"];
				$keywords   = $GLOBALS["Meta"]["index"]["keyword"];
				$description= $GLOBALS["Meta"]["index"]["description"];
				break;
	}
    if (!empty($str)) {
        $title = $str . '_' . $title;
        $keywords  = $str . ',' . $keywords;
        $description = $str . $description;
        $urlHere .= ' &gt; ' . $str;
    }
	return array('title'=>$title, 'urlHere'=>$urlHere, 'keywords'=>$keywords, 'description'=>$description);
}

/**
 * ��ѡ��״̬������ɾ��ѡ�в���
 * @param string $app
 * @param array $params ��������
 * @return string
 */
function getChioceStr($app, $params) {
	extract($params);
	$html = '';
	switch ($app) {
		case 'pattern':
			if (empty($act)) return false;
			if ($fl) {
				$CT = load('class_type');
				$html .= '<span>���ͣ�';
				$bigInfo = $CT->getOneInfo($fl);
				$bigInfo["url"] = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>$tx_small, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>0,'gs'=>$gs,'sex'=>$sex,'xh'=>$xh));
				$html .= '<a href="' . $bigInfo["url"] . '">' . $bigInfo["TypeName"] . '</a>';
				$html .= '</span>';
			}
			if ($wt) {
				$html .= '<span>���ͣ�';
				$url = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>0, 'tx_small'=>0, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>0,'gs'=>$gs,'sex'=>$sex,'xh'=>0));
				$html .= '<a href="' . $url . '">λͼͼ��</a>';
				$html .= '</span>';
			}
			if ($tx_big) {
				$CT = load('class_type');
				$html .= '<span>ͼ�Σ�';
				$bigInfo = $CT->getOneInfo($tx_big);
				$bigInfo["url"] = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>0, 'tx_small'=>0, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>$fl,'gs'=>$gs,'sex'=>$sex,'wt'=>$wt));
				$html .= '<a href="' . $bigInfo["url"] . '">' . $bigInfo["TypeName"] . '</a>';
				if ($tx_small) {
					$smallInfo = $CT->getOneInfo($tx_small);
					$smallInfo["url"] = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>0, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>$fl,'gs'=>$gs,'sex'=>$sex,'xh'=>$xh,'wt'=>$wt));
					$html .= ' <a href="' . $smallInfo["url"] . '">' . $smallInfo["TypeName"] . '</a>';
				}
				$html .= '</span>';
			}
			if ($gy) {
				$CTA = load('class_ta_att');
				$html .= '<span>���գ�';
				$gyInfo = $CTA->getOneInfo($gy);
				$gyInfo["url"] = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>$tx_small, 'gy'=>0, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>$fl,'gs'=>$gs,'sex'=>$sex,'xh'=>$xh));
				$html .= '<a href="' . $gyInfo["url"] . '">' . $gyInfo["att_name"] . '</a>';
				$html .= '</span>';
			}
			if ($bw) {
				$CTA = load('class_ta_att');
				$html .= '<span>��λ��';
				$bwInfo = $CTA->getOneInfo($bw);
				$bwInfo["url"] = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>$tx_small, 'gy'=>$gy, 'bw'=>0, 'ks'=>$ks, 'fl'=>$fl,'gs'=>$gs,'sex'=>$sex,'xh'=>$xh));
				$html .= '<a href="' . $bwInfo["url"] . '">' . $bwInfo["att_name"] . '</a>';
				$html .= '</span>';
			}
			if ($ks) {
				$CTA = load('class_ta_att');
				$html .= '<span>��ʽ��';
				$bwInfo = $CTA->getOneInfo($ks);
				$bwInfo["url"] = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>$tx_small, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>0, 'fl'=>$fl,'gs'=>$gs,'sex'=>$sex,'xh'=>$xh));
				$html .= '<a href="' . $bwInfo["url"] . '">' . $bwInfo["att_name"] . '</a>';
				$html .= '</span>';
			}
			if ($gs) {
				$html .= '<span>��ʽ��';
				$tmpArr = array('cdr'=>'AI/CDR��ʽ','psd'=>'PSD��ʽ');
				$url = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>$tx_small, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>$fl,'gs'=>0,'sex'=>$sex,'xh'=>$xh));
				$html .= '<a href="' . $url . '">' . $tmpArr[$gs] . '</a>';
				$html .= '</span>';
			}
			if ($sex) {
				$html .= '<span>�Ա�';
				$tmpArr = array('1'=>'��','2'=>'Ů','3'=>'ͯ');
				$url = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>$tx_small, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>$fl,'gs'=>$gs,'sex'=>0,'xh'=>$xh));
				$html .= '<a href="' . $url . '">' . $tmpArr[$sex] . '</a>';
				$html .= '</span>';
			}
			if ($xh) {
				$html .= '<span>���ࣺ';
				$tmpArr = array(''=>'����ͼ��','410102010101'=>'�ۺ��廨','410102010102'=>'����廨','410102010103'=>'�����廨','410102010104'=>'�°��廨');
				$url = rewriteUri('pattern', array('act'=>$act, 'tx_big'=>$tx_big, 'tx_small'=>$tx_small, 'gy'=>$gy, 'bw'=>$bw, 'ks'=>$ks, 'fl'=>$fl,'gs'=>$gs,'sex'=>$sex,'xh'=>0));
				$html .= '<a href="' . $url . '">' . $tmpArr[$xh] . '</a>';
				$html .= '</span>';
			}
		case 'style':
		case 'column_style':
		case 'business_style':
			if ($tb) {
				$html .= '<span>���ࣺ';
				$url = rewriteUri($app, array_merge($params, array('tb'=>0,'ts'=>0,'tm'=>0)));
				$html .= '<a href="' . $url . '">' . $GLOBALS["typeArrb"][$tb]["TypeName"] . '</a>';
				if ($ts) {
					if($act == 'business_style'){
						$url = rewriteUri($app, array_merge($params, array('tb'=>0,'ts'=>0,'tm'=>0)));
					}else{
						$url = rewriteUri($app, array_merge($params, array('tb'=>$tb,'ts'=>0,'tm'=>0)));
					}
					$html .= '<a href="' . $url . '">' . $GLOBALS["typeArrs"][$ts]["TypeName"] . '</a>';
				}
				if ($tm) {
					$url = rewriteUri($app, array_merge($params, array('tb'=>$tb,'ts'=>$ts,'tm'=>0)));
					$html .= '<a href="' . $url . '">' . $GLOBALS["typeArrm"][$tm]["TypeName"] . '</a>';
				}
				$html .= '</span>';
			}
			if ($brand) {
				$html .= '<span>Ʒ�ƣ�';
				$url = rewriteUri($app, array_merge($params, array('brand'=>0)));
				$CA = load('class_admin');
				$brand = $CA->getBrandInfo($brand, 'BrandName');
				$html .= '<a href="' . $url . '">' . $brand["BrandName"] . '</a>';
				$html .= '</span>';
			}
			if ($season) {
				$html .= '<span>���ȣ�';
				$url = rewriteUri($app, array_merge($params, array('season'=>0)));
				$html .= '<a href="' . $url . '">' . $GLOBALS["seasonArr"][$season]["SeasonName"] . '</a>';
				$html .= '</span>';
			}
			if ($color) {
				$html .= '<span>��ɫ��';
				$url = rewriteUri($app, array_merge($params, array('color'=>0)));
				$html .= '<a href="' . $url . '">' . $GLOBALS["colorArr"][$color]["attr_name"] . '</a>';
				$html .= '</span>';
			}
			if ($region) {
				$html .= '<span>����';
				$url = rewriteUri($app, array_merge($params, array('region'=>0)));
				$html .= '<a href="' . $url . '">' . $GLOBALS["regionArr"][$region]["attr_name"] . '</a>';
				$html .= '</span>';
			}
			if ($sid) {
				$html .= '<span>���';
				$url = rewriteUri($app, array_merge($params, array('sid'=>0)));
				$html .= '<a href="' . $url . '">' . $GLOBALS["styleArr"][$sid]["attr_name"] . '</a>';
				$html .= '</span>';
			}
			if ($kid) {
				$html .= '<span>�ؼ��ʣ�';
				$url = rewriteUri($app, array_merge($params, array('kid'=>0)));
				$html .= '<a href="' . $url . '">' . $GLOBALS["keyArr"][$kid]["attr_name"] . '</a>';
				$html .= '</span>';
			}
			break;
	}
	return $html;
}

/**
 * �������û��Ƿ��½����Ȩ
 * @param string $uname �û���
 * @param string $netid ������ַ
 * @return no
 */
function checkAdminLogin($uname, $netid) {
	global $mysql;
	if (trim($uname) == '') showAdminMsg('�Բ������½��������', '/AdminLoos.php');
	//��֤�û��Ƿ���Ȩ
	$netid = trim($netid);
	$impower = 0;
	if ($netid && $netid != 'undefined') {
		$data = $mysql->getRecord(DB_DATABASE . '.' . TB_AdminLoginLog, 'UserName', "UserName='{$uname}' AND net_info='{$netid}'", '', 1);
		if ($data) $impower = 1;
	}
	if ($impower == 0) showAdminMsg('�Բ�������˺��ѱ�������', '/AdminLoos.php', 5);
}

/**
 * �������û��Ƿ��½����Ȩ
 * @param int $uid �û�ID
 * @param int $pid Ȩ��ID
 * @return no
 */
function checkModelPower($uid, $pid) {
	global $mysql;
	$impower = 0;
	$data = $mysql->getRecord(DB_DATABASE . '.' . TB_AdminUser, 'RightID', "uid='{$uid}'", '', 1);
	if ($data) {
		$powerArr = explode(',', $data["RightID"]);
		if (in_array($pid, $powerArr)) $impower = 1;
	}
	if ($impower == 0) showAdminMsg('�Բ�����û�д�ģ���Ȩ�ޣ�');
}

/**
 * ��Ⲣ�����û�Ȩ����Ϣ
 * @param int $cid
 * @param int $sex
 * @return array
 */
function checkVip($cid = '', $sex = ''){
	global $ShowVip;
	//if (empty($cid) || empty($sex)) return false;
	$uName = getgpc("SxxlUserNameLogin", 'C');
	$rArray = array();
	$rArray["vipType"] = 0; //��Ա����(0:�ο͡�1:��ѡ�2:���á�3:��ʽ)
	$rArray["isPower"] = FALSE; //�Ƿ���Ȩ
	$rArray["isExpire"] = FALSE; //�Ƿ����
	$rArray["isColumn"] = FALSE; //��Ŀ�Ƿ���Ȩ��,�˴�Ϊtrueʱ�����ʾisPower,isExpire��Ϊ1
	if(!empty($uName)) {
		$rArray["vipType"] = 1;
		if (empty($ShowVip)) $ShowVip = ShowVipRight($uName);
		if (!empty($ShowVip["sVipNet"])) $rArray["isPower"] = TRUE;
		if (!empty($ShowVip["sVipTime"])) $rArray["isExpire"] = TRUE;
		if ($rArray["isPower"] && $rArray["isExpire"]) {
			$sex = $sex == 4 || $sex == 5 ? 3 : $sex;
			//Ϊ�������Ա����Ŀ��һ�����۵Ĵ���
			$noSex	= array('string'=>array(23,34,28),
							'array'=>array(23=>'504',34=>'503',28=>'528'));
			if (in_array($cid, $noSex["string"])) {
				$rightStr = $noSex["array"][$cid];
			}
			else {
				$rightStr = $sex . $cid;
			}
			$rightArr = explode(',', $ShowVip["sVipRight"]);
			//����û�û����ĿȨ�ޣ����û�����������Ϊ1�����
			if (in_array($rightStr, $rightArr)) {
				$rArray["isColumn"] = true;
				$vt = $ShowVip['sVipType'];
				if (in_array($vt, array(2,3,4,5,10))) {
					$rArray["vipType"] = 2;
				}
				elseif (in_array($vt, array(6,7,8,9,11))) {
					$rArray["vipType"] = 3;
				}
			}
		}
	}
	return $rArray;
}

/**
 * ��ʾ��Ŀ��Ȩ��ҳ��
 * @param int $cid
 * @param int $sex
 * @return void
 */
function checkVipError($cid, $sex) {
	global $smarty,$Arr;
	$Arr["rightArr"] = $rightArr = checkVip($cid, $sex);
	if (!$rightArr["isColumn"]) {
		$abouts = array('19'=>'ͼ����Ŀ�Ƴ���ʸ��ͼ���Ƿ�װͼ����һ�֣�����ͬ����ʸ��ͼ�θ���ͼ�������ԭ�ļ����ͻ����Ժܷ�������ص��Լ��ĵ����У���AI��cdr.pdf��ʸ���ļ���ʽ����������ļ�����ֱ��Ӧ���ڷ�װ�ư棬ӡȾ�Լ��������ӵĹ��գ����ʦ�����Ը��ݸ��˵ķ�����Ҫ�޸ĳ�����������Ʒ��ʸ���ļ����������������վ�������ǲ�����ģ�ϣ�����ܴ������ø���ı�����Ϊ���Ĺ�������������');
		$columns = array();
		$columns["about"] = $abouts[$cid];
		$columns["countTheme"] = '111';
		$columns["countPic"] = '111111';
		$Arr["columns"] = $columns;
		if(is_array($Arr)) {
			foreach($Arr as $k => $v) {
				$smarty->assign($k, $v);
			}
		}
		$smarty->display(ROOT_PATH . 'Tmpl/public/vip_error.tpl.html');
		exit;
	}
	else {
		return $rightArr;
	}
}

/**
 * ��ʾ������Ȩ��ҳ��
 * @param int $cid
 * @param int $sex
 * @param int $info ������Ϣ����
 * @return void
 */
function checkVipDetail($cid, $sex, $info) {
	global $smarty,$Arr;
	$Arr["rightArr"] = $rightArr = checkVip($cid, $sex);
	if (!$rightArr["isColumn"]) {
		//��ʱ��ʾ�˴������ڸ�Ϊֻ���������Ϣ
		$abouts = array('19'=>'ͼ����Ŀ�Ƴ���ʸ��ͼ���Ƿ�װͼ����һ�֣�����ͬ����ʸ��ͼ�θ���ͼ�������ԭ�ļ����ͻ����Ժܷ�������ص��Լ��ĵ����У���AI��cdr.pdf��ʸ���ļ���ʽ����������ļ�����ֱ��Ӧ���ڷ�װ�ư棬ӡȾ�Լ��������ӵĹ��գ����ʦ�����Ը��ݸ��˵ķ�����Ҫ�޸ĳ�����������Ʒ��ʸ���ļ����������������վ�������ǲ�����ģ�ϣ�����ܴ������ø���ı�����Ϊ���Ĺ�������������');
		$columns = array();
		$columns["about"] = $abouts[$cid];
		$Arr["columns"] = $columns;
		//---------------------------------
		$info["sexStr"] = getSexStr($info["sex"]);
		$info["displayTime"] = date('Y-m-d', $info['time']);
		if ($info["cityId"]) {
			$all = cacheCity();
			$info["cityStr"] = $all[$info["cityId"]]["CityName"];
		}
		if ($info["seasonId"]) {
			$all = cacheSeason();
			$info["seasonStr"] = $all[$info["seasonId"]]["SeasonName"];
		}
		if ($info["bookId"]) {
			$all = cacheBook();
			$info["bookStr"] = $all[$info["bookId"]]["BookName"];
		}
		$Arr["info"] = $info;//������Ϣ
		if(is_array($Arr)) {
			foreach($Arr as $k => $v) {
				$smarty->assign($k, $v);
			}
		}
		$smarty->display(ROOT_PATH . 'Tmpl/public/detail_vip_error.tpl.html');
		exit;
	}
	else {
		return $rightArr;
	}
}

/**
 * ͼƬ�鿴Ȩ��
 * @param $limit  ��$limit����¼
 * @param $vipRight �Ƿ�����ĿȨ��
 * @param $isFree  �Ƿ����ͼƬ
 * @return string
 */
function getPicPower($limit, $rightArr, $isFree, $type='') {
	//if (empty($rightArr) || empty($isFree)) return false;
	$type = empty($type) ? 'S' : $type;
	$rstr = 0;
	//if((getgpc('page') > 5 && $rightArr["vipType"] == 2 && $rightArr["isColumn"])) $rstr = 0; //���û�Աֻ�ɲ鿴ǰ5ҳͼƬ(����)
	if ($rightArr["isColumn"]) $rstr = 1;
	//elseif((getgpc('page') <= 1 && $type == 'B' && $limit < 5)) $rstr = 1;
	elseif((getgpc('page') <= 1 && $type == 'S')) $rstr = 1;
	elseif($isFree == '11' || $isFree == '0') $rstr = 1;
	return $rstr;
}

/**
 * ����Ȩ�޻�ȡͼƬ��ַ,��û�н��ޣ�����ʾ��Ȩ��ͼƬ
 * @param string $src ͼƬ���·��
 * @param int $isPower Ȩ�ޱ�ʶ
 * @return string
 */
function showPicPower($src, $isPower) {
	$path = '';
	if ($src && $isPower) {
		$path = show_pic_path($src);
	}
	else {
		$path = '/Files/images/novip.jpg';
	}
	return $path;
}

/**
 * ����memcache����
 * @param array $config ���ò���
 * @return memcached
 */
function loadMemcache($config = array()) {
	require_once ROOT_PATH . 'include/class.memcached.php'; // װ�� memcache
	//  ѡ������
	$options = array(
			'servers' => isset($config["servers"]) ? $config["servers"] : array('127.0.0.1:11211'), //memcached ����ĵ�ַ���˿ڣ����ö������Ԫ�ر�ʾ��� memcached ����
			'debug' => isset($config["debug"]) ? $config["debug"] : false,  //�Ƿ�� debug
			'compress_threshold' => isset($config["compress_threshold"]) ? $config["compress_threshold"] : 10240,  //���������ֽڵ�����ʱ����ѹ��
			'persistant' => isset($config["persistant"]) ? $config["persistant"] : false  //�Ƿ�ʹ�ó־�����
	);
	return new memcached($options);
}

/**
 * ҳ�������ʾ
 * @param string $msg ������ʾ
 * @param array $links ҳ����ת��ַ array('text'=>'������ʾ', 'href'=>'index.php');
 * @param int $times ��תʱ��
 * @param bool $auto_redirect �Ƿ��Զ���ת
 */
function showError($msg, $links = array(), $times = 2, $auto_redirect = true) {
	global $smarty;
	if (empty($links)) {
		$links[0]['text'] = '������һҳ';
		$links[0]['href'] = 'javascript:history.go(-1)';
	}
	if ($times < 1) {
		echo "<script>window.location='{$links[0]['href']}';</script>";
	}
	$smarty->assign('times', $times);
	$smarty->assign('msg',   $msg);
	$smarty->assign('title', $msg);
	$smarty->assign('links', $links);
	$smarty->assign('default_url', $links[0]['href']);
	$smarty->assign('auto_redirect', $auto_redirect);
	$smarty->display(ROOT_PATH . 'Tmpl/public/error.tpl.html');
	exit;
}

/**
 * �����������
 * @param bool $put
 * @return array
 */
function cacheCity($put = false) {
	global $mysql;
	$data = readStaticCache('cache_city_array');
	if ($data == false || $put == true) {
		$res = $mysql->getRecord(TB_ClassCity, 'ID,CityID,CityName,city_english', 'IsDisplay = 2', array('OrderByID'=>'ASC'));
		if (!$res) return false;
		$data = array();
		foreach ($res as $val) {
			$data[$val["CityID"]] = $val;
		}
		writeStaticCache('cache_city_array', $data);
	}
	return $data;
}

/**
 * ���漾������
 * @param bool $put
 * @return array
 */
function cacheSeason($put = false) {
	global $mysql;
	$data = readStaticCache('cache_season_array');
	if ($data == false || $put == true) {
		$res = $mysql->getRecord(TB_ClassSeason, 'ID,SeasonID,SeasonName,SeasonName_en', 'IsDisplay = 2', array('OrderByID'=>'ASC'));
		if (!$res) return false;
		$data = array();
		foreach ($res as $val) {
			$data[$val["SeasonID"]] = $val;
		}
		writeStaticCache('cache_season_array', $data);
	}
	return $data;
}

/**
 * ����Ʒ������
 * @param bool $put
 * @return array
 */
function cacheBrand($put = false) {
	global $mysql;
	$data = readStaticCache('cache_brand_array');
	if ($data == false || $put == true) {
		$res = $mysql->getRecord(TB_ClassBrand, 'ID,BrandID,BrandName,BrandName_en', 'IsDisplay = 2', array('OrderByID'=>'ASC'));
		if (!$res) return false;
		$data = array();
		foreach ($res as $val) {
			$data[$val["BrandID"]] = $val;
		}
		writeStaticCache('cache_brand_array', $data);
	}
	return $data;
}

/**
 * �������ʦ����
 * @param bool $put
 * @return array
 */
function cacheDesigner($put = false) {
	global $mysql;
	$data = readStaticCache('cache_designer_array');
	if ($data == false || $put == true) {
		$res = $mysql->getRecord(TB_ClassDesigner, 'ID,DesignerID,DesignerName,DesignerName_en', 'IsDisplay = 2', array('OrderByID'=>'ASC'));
		if (!$res) return false;
		$data = array();
		foreach ($res as $val) {
			$data[$val["DesignerID"]] = $val;
		}
		writeStaticCache('cache_designer_array', $data);
	}
	return $data;
}

/**
 * ������������
 * @param bool $put
 * @return array
 */
function cacheBook($put = false) {
	global $mysql;
	$data = readStaticCache('cache_book_array');
	if ($data == false || $put == true) {
		$res = $mysql->getRecord(TB_ClassBook, 'ID,BookID,BookName,BookName_en', 'IsDisplay = 2', array('OrderByID'=>'ASC'));
		if (!$res) return false;
		$data = array();
		foreach ($res as $val) {
			$data[$val["BookID"]] = $val;
		}
		writeStaticCache('cache_book_array', $data);
	}
	return $data;
}

/**
 * �����������
 * @param bool $put
 * @return array
 */
function cacheClassType($field=null, $put = false) {
	global $mysql;
	$field = empty($field) ? 'Cid' : 'ID';
	$data = readStaticCache('cache_class_type_array'.$field);
	if ($data == false || $put == true) {
		$res = $mysql->getRecord(DB_DATABASE . '.' . TB_ClassType, 'ID,Cid,Parent,TypeName,images,Sex', 'IsDisplay = 2', array('OrderID'=>'ASC'));
		if (!$res) return false;
		$data = array();
		foreach ($res as $val) {
			$data[$val["$field"]] = $val;
		}
		writeStaticCache('cache_class_type_array'.$field, $data);
	}
	return $data;
}

/**
 * ����ͼ����������
 * @param bool $put
 * @return array
 */
function cacheTaAttr($put = false) {
	global $mysql;
	$data = readStaticCache('cache_ta_attr_array');
	if ($data == false || $put == true) {
		$res = $mysql->getRecord(DB_DATABASE . '.' . TB_CLASS_TA_ATT, 'id,parent_id,att_name,images', 'is_display = 1', array('order_id'=>'ASC'));
		if (!$res) return false;
		$data = array();
		foreach ($res as $val) {
			$data[$val["id"]] = $val;
		}
		writeStaticCache('cache_ta_attr_array', $data);
	}
	return $data;
}

/**
 * ��������µ��������ݱ��浽������±�
 * @param array $data
 * @return bool
 * @author xieweijun@sxxl.com
 */
function recentlyUpdateTheme($data){
	global $mysql;
	$table = "Product_Sxxlcn.fs_member_recently_update_theme";
	$where = "tid = '{$data['tid']}' and cid = '{$data['cid']}'";
	if (!is_array($data)) return false;
	$dateDiff = floor((time()-$data['display_time']) / 86400);
	if((($data['cid'] == 18 && $data['is_display'] == 1)|| $data['is_display'] == 2) && $data['title_img'] && $dateDiff<30){
		if($mysql->getCount($table, $where, "count(id)")){
			if (!$mysql->update($table, "display_time = '{$data['display_time']}'", $where)) {
				return false;
			}
		}else{
			if (!$mysql->inserts($table, $data)) {
				return false;
			}
		}
	}
	unset($data);
	return true;
}