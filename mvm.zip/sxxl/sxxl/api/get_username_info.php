<?php
define('IN_SXXL', true);
require_once( './include/common.inc.php');
global $mysql;
global $flog;
$pinfo = unserialize(authcode(urldecode($_REQUEST['post']),"DECODE",'WWW_JKHL===-JJIALKHLA'));
if ($pinfo['time'] > time()) {
	if($pinfo['username']){
		$cpu_info= trim($pinfo['cpu_id']);
		$hd_info = trim($pinfo['hd_id']);
		$net_info = trim($pinfo['mac_id']);
		$username = $pinfo['username'];
		$flog_sql1 ="SELECT * FROM user_info WHERE UserName='".$username."'and StatusLog='1'";//user_info
		$flog_query1 = $mysql->query($flog_sql1);
		while($row1=mysql_fetch_array($flog_query1)){
			$cpu_check = $row1['cpu_check'] == '1' ? ( trim($row1['cpu_info'])== $cpu_info? '1':'0'):'1';
			if($cpu_check=='0'){
				continue;
			}
			$hd_check = $row1['hd_check'] == '1' ? ( trim($row1['hd_info'])== $hd_info? '1':'0'):'1';
			if($hd_check=='0'){
				continue;
			}
			$net_check = $row1['net_check'] == '1' ? ( trim($row1['net_info'])== $net_info? '1':'0'):'1';
			if( $cpu_check && $hd_check && $net_check){
				$flog=1;
				break;
			}
		}
		if($flog != '1'){
			$flog_sql2 ="SELECT * FROM UserPcidInfo WHERE UserName='".$username."'and StatusLog='1'";
			$flog_query2 = $mysql->query($flog_sql2);
			while($row2=mysql_fetch_array($flog_query2)){   //net_check,hd_check,cpu_check
				$cpu_check = $row2['cpu_check'] == '1' ? ( trim($row2['cpu_info'])== $cpu_info? '1':'0'):'1';
				if($cpu_check=='0'){
					continue;
				}
				$hd_check = $row2['hd_check'] == '1' ? ( trim($row2['hd_info'])== $hd_info? '1':'0'):'1';
				if($hd_check=='0'){
					continue;
				}
				$net_check = $row2['net_check'] == '1' ? ( trim($row2['net_info'])== $net_info? '1':'0'):'1';
				if( $cpu_check && $hd_check && $net_check){
					$flog=1;
					break;
				}
			}
		}
		$sql = "SELECT RealName,Sex,JobName,Email,moblie,Tel,Address,Company,nUpdateTime,nVipType,LoginLog,nValidTime,RegIP,province,city,county,crm_staff,biz_staff FROM " . TB_VIPClient . " WHERE UserName = '".$pinfo['username']."'";
		$query = $mysql->query($sql);
		$row = mysql_fetch_array($query, $mysql);
		$row['flog'] = $flog;
		echo json_encode($row);
	}else{
		echo json_encode('-2');
	}
}else{
	echo json_encode('-1');
}
//超过时间，不允许执行下面
//解析不了正常的参数，不能执行下面
//SELECT * FROM UserPcidInfo WHERE UserName='diexun_tech'
//SELECT * FROM user_info WHERE UserName='diexun_tech'
 
	
	
	//取这个上用户的所有授权的电脑
	//取出当前用户的电脑硬件信息
	//循环授权的电脑，判断本电脑是否授权的电脑；
	

?>
