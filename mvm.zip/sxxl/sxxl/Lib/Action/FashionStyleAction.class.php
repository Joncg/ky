<?php

class FashionStyleAction extends TideSectionAction {

	public function _initialize() {
		$this->cid = 22;
		$this->cache = Cache::getInstance();
		parent::_initialize();
	}

	protected function index() {
		$bid = $this->param['bid'];
		if ($bid) {
			$this->redirect('brandSearch', array('bid' => $bid));
		}
		//品牌系列
		$map = array();
		$map["{$this->tableArr['subject_original']}.menu_id"] = $this->cid;
		$soid = $this->getSoid();
		if ($soid) {
			$map['fs.sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
		}
		$map['is_publish'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));
		$order = array('publish_time' => 'desc', $this->tableArr['subject_original'] . '.id' => 'desc');
		$join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,season_id,brand_id";

		$cache_key = md5("FashionStyle::index::" . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . '::' . serialize($map));
		$themeList = trim($_GET['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$themeList) {
			$themeList = $this->modelT->join($join)->where($map)->field($field)->order($order)->limit(8)->select();
			//echo $this->modelT->getLastSql()."</br>";
			if ($themeList) {
				foreach ($themeList as $key => $val) {
					$themeList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
					$themeList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
					$themeList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
					$themeList[$key]['url'] = U('/' . MODULE_NAME . '/themeDetail', array('soid' => $soid, 'tid' => $val['id']));
					$themeList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);
				}
			}
			$this->cache->set($cache_key, $themeList, C('CACHE_TIME_SHORT'));
		}

		$Arr['themeList'] = $themeList;
		$Arr['specialChildMenus'] = $this->getSpecialChildMenu();

		$this->assign($Arr);
		$this->display();
	}

	protected function getPictureListByAjax() {
		import('@.ORG.Search');
		$search = new Search();
		$search->setSortMode(SPH_SORT_EXTENDED, 'publish_time desc,picture_id desc');
		$search->setPageSize(12);
		$search->setPage(1);

		$search->setFilterRange('publish_time', strtotime('1990-01-01 00:00:00'), C('TODAY_LAST_TIME'));

		$cid = $this->sid == 4 ? 102 : $this->cid; //内衣.时尚款式 menu_id=102
		$map['menu_id'] = $cid;
		$search->setFilter('menu_id', array($cid));

		$soid = $this->getSoid();
		if ($soid) {
			$map['sort_id'] = $soid == 3 ? array('eq', 4) : $soid;
			if ($soid == 3)
				$search->setFilter('sort_id', $this->childrenSoids);
			else
				$search->setFilter('sort_id', array($soid));
		}

		$ano = $this->param['ano'];
		if ($ano) {
			$anoTmp = dechex($ano);
			if (substr($anoTmp, -4, 4) === '0000') {
				$map['area_no'] = array(array('egt', $ano), array('elt', $ano + 65535));
				$search->setFilterRange('area_no', $ano, $ano + 65535);
			} elseif (substr($anoTmp, -2, 2) === '00') {
				$map['area_no'] = array(array('egt', $ano), array('elt', $ano + 256));
				$search->setFilterRange('area_no', $ano, $ano + 256);
			} else {
				$map['area_no'] = $ano;
				$search->setFilter('area_no', array($ano));
			}
		}

		$cache_key = md5("FashionStyle::getPictureListByAjax::" . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . "::" . serialize($map));
		$pictureListHtml = trim($_REQUEST['cache']) == 'false' ? '' : unserialize($this->cache->get($cache_key));
		if (!$pictureListHtml) {
			$rows = $search->query();
			$count = intval($rows['total_found']); //下面做分页之用
			if ($count > 0) {
				$field = 'picture_id,small_picture_url,big_picture_url,menu_id,publish_time,season_id,brand_id,area_no';
				$ids = array();
				foreach ($rows['matches'] as $k => $v)
					$ids[] = $v['id'];

				$voList = $search->getPicInfoByIds($ids, $field);
				$pictureListHtml = '<ul>';
				if ($voList) {
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
						$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
						$voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
						$voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
						$voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
						$voList[$key]['brandUrl'] = U('/' . MODULE_NAME . '/pictureList', array('bid' => $val['brand_id']));

						$pictureListHtml .= '<li>';

						$pictureListHtml .= '<a href="javascript:void(0);" onclick="viewPic.setPic(' . $key . ');return false;" class="picBox">';
						$pictureListHtml .= '<img src="' . $voList[$key]['pic_small'] . '" alt="" width="187" height="250" />';
						$pictureListHtml .= '</a>';

						$pictureListHtml .= '<div class="persondiv">';
						$pictureListHtml .= '<strong class="left"><a href="' . $voList[$key]['brandUrl'] . '">' . $voList[$key]['brandStr'] . '</a></strong>';
						$pictureListHtml .= '<span class="right onright">' . $voList[$key]['areaStr'] . '</span>';
						$pictureListHtml .= '</div>';

						$pictureListHtml .= '<div class="timeBox">';
						$pictureListHtml .= '<span class="left">' . $voList[$key]['seasonStr'] . '</span>';
						$pictureListHtml .= '<span class="right onright">' . $voList[$key]['publish_time'] . '</span>';
						$pictureListHtml .= '</div>';

						$pictureListHtml .= "</li>";

						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['picture_id'];
						$picList[$key]['sCid'] = $this->cid;
						$picList[$key]['sPidNo'] = $val['picture_id'];
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}
				}

				$pictureListHtml .= '<span class="clear"></span>';
				$pictureListHtml .= '</ul>';

				$jsonData = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
				$pictureListHtml .= '<script type="text/javascript">var pageData = ' . $jsonData . ';</script>';
				$this->cache->set($cache_key, serialize($pictureListHtml), C('CACHE_TIME_SHORT'));
			}
		}
		//dump($voList);
		exit($pictureListHtml); //$pictureListHtml);
	}

	protected function getPictureListByAjaxBak() {
		$map = array();
		$map["{$this->tableArr['picture_original']}.menu_id"] = $this->cid;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));
		$soid = $this->getSoid();
		if ($soid) {
			$map['fs.sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
			$join[] = "{$this->tableArr['ref_picture_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_original']}.id";
		}

		$ano = $this->param['ano'];
		if ($ano) {
			$anoTmp = dechex($ano);
			if (substr($anoTmp, -4, 4) === '0000') {
				$map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
			} elseif (substr($anoTmp, -2, 2) === '00') {
				$map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
			} else {
				$map['area_no'] = $ano;
			}
		}

		$cache_key = md5("FashionStyle::getPictureListByAjax::" . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . "::" . serialize($map));
		$pictureListHtml = trim($_REQUEST['cache']) == 'false' ? '' : unserialize($this->cache->get($cache_key));
		if (!$pictureListHtml) {
			$order = array('publish_time' => 'desc', $this->tableArr['picture_original'] . '.id' => 'desc');
			$field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,publish_time,brand_id,area_no,season_id";
			$voList = $this->modelP->join($join)->where($map)->field($field)->order($order)->limit(12)->select();
			//echo $this->modelP->getLastSql()."</br>";
			$pictureListHtml = '<ul>';
			if ($voList) {
				foreach ($voList as $key => $val) {
					$voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
					$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
					$voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
					$voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
					$voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
					$voList[$key]['brandUrl'] = U('/' . MODULE_NAME . '/pictureList', array('bid' => $val['brand_id']));

					$pictureListHtml .= '<li>';

					$pictureListHtml .= '<a href="javascript:void(0);" onclick="viewPic.setPic(' . $key . ');return false;" class="picBox">';
					$pictureListHtml .= '<img src="' . $voList[$key]['pic_small'] . '" alt="" width="187" height="250" />';
					$pictureListHtml .= '</a>';

					$pictureListHtml .= '<div class="persondiv">';
					$pictureListHtml .= '<strong class="left"><a href="' . $voList[$key]['brandUrl'] . '">' . $voList[$key]['brandStr'] . '</a></strong>';
					$pictureListHtml .= '<span class="right onright">' . $voList[$key]['areaStr'] . '</span>';
					$pictureListHtml .= '</div>';

					$pictureListHtml .= '<div class="timeBox">';
					$pictureListHtml .= '<span class="left">' . $voList[$key]['seasonStr'] . '</span>';
					$pictureListHtml .= '<span class="right onright">' . $voList[$key]['publish_time'] . '</span>';
					$pictureListHtml .= '</div>';

					$pictureListHtml .= "</li>";

					$picList[$key]['sTid'] = 0;
					$picList[$key]['sPid'] = $val['id'];
					$picList[$key]['sCid'] = $this->cid;
					$picList[$key]['sPidNo'] = $val['id'];
					$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
					$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
					$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
				}
			}

			$pictureListHtml .= '<span class="clear"></span>';
			$pictureListHtml .= '</ul>';

			$jsonData = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB));
			$pictureListHtml .= '<script type="text/javascript">var pageData = ' . $jsonData . ';</script>';
			$this->cache->set($cache_key, serialize($pictureListHtml), C('CACHE_TIME_SHORT'));
		}
		//dump($voList);
		exit($pictureListHtml); //$pictureListHtml);
	}

	protected function themeList() {
		$Arr['specialChildMenus'] = $this->getSpecialChildMenu();
		$this->assign($Arr);
		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,season_id,brand_id,pv_count";
		$order = array('publish_time' => 'desc', $this->tableArr['subject_original'] . '.id' => 'desc');
		$this->relationArr = false;
		$this->tListRows = 20;
		$this->themeDataList($field, $map, $order);
		$this->display('theme_list');
	}

	protected function pictureList() {
		$Arr = array();
		$soid = $this->getSoid();
		$bid = $this->param['bid'];
		if ($bid) {
			$this->redirect('brandSearch', array('bid' => $bid, 'soid' => $soid));
		}

		$Arr['specialChildMenus'] = $this->getSpecialChildMenu();
		$stid = $this->param['stid'];
		if ($stid) {
			$this->areas = $Arr['areaTab'] = $this->getPictureSiftByStyle($stid, 'area');
			$this->fashions = $Arr['fashionTab'] = $this->getPictureSiftByStyle($stid, 'fashion');
			$this->keywords = $Arr['keywordTab'] = $this->getPictureSiftByStyle($stid, 'keyword');
		}
		$field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,brand_id,season_id,area_no,publish_time";
		$order = array('publish_time' => 'desc', $this->tableArr['picture_original'] . '.id' => 'desc');
		$this->relationArr = false;
		$this->pListRows = 20;
		$page = intval($_GET['p']);
		/*
		  if($page < 501){
		  $this->pictureDataList($field, $map, $order);
		  } else { */
		$this->pictureDataListBySphinx();
		//}
		$Arr['chioceStr'] = $this->getFashionStyleChioceStr();

		$this->assign($Arr);
		$this->display('picture_list');
	}

	protected function brandSearch() {
		$Arr = array();

		$bid = $this->param['bid'];
		$stid = $this->param['stid'];
		$soid = $this->getSoid();
		if ($bid) {
			$Arr['specialChildMenus'] = $this->getSpecialChildMenu();
			$this->styles = F('styleList', '', C('DATA_CACHE_PATH'));
			/*
			  $styles = M('RefMenuStyle')->where("menu_id = '{$this->cid}'")->field('style_id')->findAll();
			  $style_ids = array();
			  foreach ($styles as $key => $val) {
			  if (!is_array($this->styles[$val['style_id']]) || $this->styles[$val['style_id']]['parent_id'] != 0)
			  continue;
			  $style_ids[] = $val['style_id'];
			  }
			 *
			 */

			$styles = $this->getSpecialChildMenu();
			$style_ids = array();
			foreach ($styles as $key => $val) {
				$style_ids[] = $val['id'];
			}

			import('@.ORG.Search');
			$search = new Search();
			$search->setSortMode();
			$pageSize = 100;
			$page = intval($_GET['p']) < 1 ? 1 : intval($_GET['p']);
			$search->setPageSize($pageSize);
			$search->setPage($page);

			if ($style_ids) {
				$search->setFilter('style_id', $style_ids);
			}
			if ($bid) {
				$search->setFilter('brand_id', array($bid));
			}
			if ($soid) {
				if ($soid == 3)
					$search->setFilter('sort_id', $this->childrenSoids);
				else
					$search->setFilter('sort_id', array($soid));
			}
			$search->h_cl->SetGroupBy("style_id", SPH_GROUPBY_ATTR, "@count desc");
			$r = $search->query();
			$style_nums = array();
			foreach ($r['matches'] as $k => $v) {
				$style_nums[(int) $v['attrs']['@groupby']] = (int) $v['attrs']['@count'];
			}

			$styleTab = array();
			foreach ($style_ids as $key => $val) {
				if (!isset($style_nums[$val]))
					continue;

				$styleTab[$key]['id'] = $val;
				$styleTab[$key]['name'] = $this->styles[$val]['name'];
				$styleTab[$key]['url'] = U('/' . MODULE_NAME . '/brandSearch', array('bid' => $bid, 'stid' => $val));
				$styleTab[$key]['selected'] = $stid == $val ? true : false;
			}
			$Arr['styleTab'] = $styleTab;
		}
		else
			$this->redirect('pictureList', $this->param);

		$field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,brand_id,season_id,area_no,publish_time";
		$order = array('publish_time' => 'desc', $this->tableArr['subject_original'] . '.id' => 'desc');
		$this->relationArr = false;
		$this->pListRows = 20;
		$page = intval($_GET['p']);
		/*
		  if($page < 501)
		  $this->pictureDataList($field, $map, $order);
		  else
		 */
		$this->pictureDataListBySphinx();

		$this->assign($Arr);
		$this->display('picture_list');
	}

	protected function detail() {
		if ($this->param['stid']) {
			$map = $join = array();
			$detailTab = M('RefStyleDetail')->field('detail_id')->where(array('style_id' => $this->param['stid']))->group('detail_id')->findAll();
			//echo M('RefStyleDetail')->getLastSql();
			if ($detailTab) {
				$map['ps.style_id'] = $this->param['stid'];
				$join['0'] = "{$this->tableArr['ref_picture_subsidiary_style_original']} ps on ps.picture_id={$this->tableArr['picture_subsidiary_original']}.id";
				$soid = $this->getSoid();
				if ($soid) {
					$map['fs.sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
					$join['1'] = "{$this->tableArr['ref_subsidiary_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_subsidiary_original']}.id";
				}

				$map['is_publish'] = 1;
				$map['is_detail'] = 1;
				$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));
				$cache_key = md5(serialize($map));
				$cache_path = C('CACHE_PATH_FILE') . "indexdata/fashionStyledetail/";
				$detailTabTmp = trim($_REQUEST['cache']) == 'false' ? '' : F('fashionStyledetail' . $cache_key, '', $cache_path);
				if (empty($detailTabTmp)) {
					foreach ($detailTab as $key => $val) {
						$map['pd.detail_id'] = $val['detail_id'];
						$join['2'] = "{$this->tableArr['ref_picture_subsidiary_detail_original']} pd on pd.picture_id={$this->tableArr['picture_subsidiary_original']}.id";
						$detail_id_tmp = M($this->tableArr['picture_subsidiary'])->join($join)->where($map)->getField("{$this->tableArr['picture_subsidiary_original']}.id as id");
						if ($detail_id_tmp > 0) {
							$detailTabTmp[$val['detail_id']]['id'] = $val['detail_id'];
							$name = M('AttributeDetail')->getField('`name`', array('id' => $val['detail_id']));
							$detailTabTmp[$val['detail_id']]['name'] = $name;
							$detailTabTmp[$val['detail_id']]['url'] = U('/' . MODULE_NAME . '/detail', array_merge($this->param, array('deid' => $val['detail_id'])));
						}
					}
					F('fashionStyledetail' . $cache_key, $detailTabTmp, $cache_path);
				}
				$this->details = $Arr['detailTab'] = $detailTabTmp;
				unset($detailTab, $detailTabTmp, $join, $map);
			}
		}

		$field = "{$this->tableArr['picture_subsidiary_original']}.id,big_picture_url,small_picture_url,publish_time";
		$order = array('publish_time' => 'desc', $this->tableArr['picture_subsidiary_original'] . '.id' => 'desc');
		$this->relationArr = false;
		$this->pListRows = 20;
		//$this->detailPictureDataList($field, '', $order);
        $this->detailPictureDataListBySphinx($field, $map, $order);
		$this->assign($Arr);
		$this->display();
	}

	/**
	 * 主题列表分页
	 * @param type $field
	 * @param type $map
	 * @param type $sortBy
	 * @param type $asc
	 * @return type
	 */
	protected function themeDataList($field, $map, $order) {
		$cid = $this->sid == 4 ? 102 : $this->cid; //内衣.时尚款式 menu_id=102

		if ($cid)
			$map[$this->tableArr['subject_original'] . '.menu_id'] = $cid;
		if ($this->cmid)
			$map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;
		//时尚杂志特殊处理
		$soid = $this->getSoid();
		if ($soid) {
			$map['fs.sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
			$join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
		}
		if ($this->sid && $this->sid != 4) {
			$map['fsc.special_column_id'] = $this->sid;
			$join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
		}

		$map['is_publish'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));

		$seid = $this->param['seid'];
		if ($seid)
			$map['season_id'] = $seid;

		$ano = $this->param['ano'];
		if ($ano) {
			$anoTmp = dechex($ano);
			if (substr($anoTmp, -4, 4) === '0000') {
				$map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
			} elseif (substr($anoTmp, -2, 2) === '00') {
				$map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
			} else {
				$map['area_no'] = $ano;
			}
		}

		$bid = $this->param['bid'];
		$brandStr = $this->param['brandStr'];
		if (!$bid && $brandStr != '') {
			$bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
			$bid = intval($bid);
			if ($bid) {
				$map['brand_id'] = $bid;
				$this->assign('bid', $bid);
			}
		} elseif ($bid) {
			$map['brand_id'] = $bid;
			$brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
			$this->assign('brandStr', $brandStr);
		}

		/*
		  $coid = $this->param['coid'];
		  if ($coid) {
		  $join[] = "{$this->tableArr['ref_subject_color_original']} sc on sc.subject_id={$this->tableArr['subject_original']}.id";
		  $map['sc.color_id'] = $coid;
		  }
		 *
		 */

		$page = $_REQUEST['p'];
		$page = $page ? $page : 1;
		$cache_key = md5('FashionStyle::themeDataList::' . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . '::' . $page . '::' . serialize($map));
		$Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$Arr) {
			//$count = $this->modelT->join($join)->where($map)->count();
			//echo $this->modelT->getlastsql();
			import("ORG.Util.DataCount");
			$count = DataCount::getCount($this->tableArr['subject'], $map, $join);
			if ($count > 0) {
				import("ORG.Util.Page");
				//echo $count;
				$p = new Page($count, $this->tListRows);
				$voList = $this->modelT->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
				//echo $this->modelT->getLastSql();
				if ($voList) {
					foreach ($voList as $key => $val) {
						if ($val['season_id']) {
							$voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
						}
						if ($val['area_no']) {
							$voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
						}
						if ($val['brand_id']) {
							$voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
						}
						$voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid, 'soid' => $soid, 'tid' => $val['id']));
						$voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
						$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
						//$voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
					}
				}
				$Arr['listArr'] = $voList;
				$Arr['pageStr'] = $p->showOne();
			}
			$page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr, C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
		}

		$this->assign($Arr);
	}

	protected function themeInfo($tid) {
		$tid = intval($tid);

		if (!$tid)
			$this->error('参数错误！');

		$cid = $this->sid == 4 ? 102 : $this->cid;
		if ($cid)
			$map[$this->tableArr['subject_original'] . '.menu_id'] = $cid;
		$soid = intval($_GET['soid']);
		$map[$this->tableArr['subject_original'] . '.id'] = $tid;
		$map['is_publish'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));

		$soid = $this->getSoid();
		if ($soid) {
			$map['fs.sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
			$join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
		}
		if ($this->sid && $this->sid != 4) {
			$map['fsc.special_column_id'] = $this->sid;
			$join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
		}

		$field = $this->tableArr['subject_original'] . '.id,title,publish_time,season_id,area_no,show_edit,brand_id';
		$cache_key = md5("FashionStyle::themeInfo::" . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . '::' . serialize($map));
		$info = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$info) {
			$info = $this->modelT->join($join)->relation($this->relationArr)->field($field)->where($map)->find();
			//echo $this->modelT->getLastSql()."</br>";exit;
			if (!$info) {
				$this->error('参数错误！');
			}

			$info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
			$soid = $soid ? $soid : $this->soid;
			if (!$soid) {
				$soid = M($this->tableArr['ref_subject_sort'])->getField("sort_id", "subject_id='{$tid}'");
			}
			$info['sortStr'] = $this->sorts[$soid]['title'];
			$info['areaStr'] = $this->areas[$info['area_no']]['name'];
			$info['seasonStr'] = $this->seasons[$info['season_id']]['en_name'];
			$info['brandStr'] = $this->brands[$info['brand_id']]['name']; //品牌灵感需用到
			$info['brandUrl'] = U('/' . MODULE_NAME . '/themeList', array('soid' => $soid, 'bid' => $info['brand_id']));
			$info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']) : '';
			$this->cache->set($cache_key, $info);
		}

		//权限验证
		parent::withoutPermission('', $info);
		return $info;
	}

	/**
	 * get theme picture list
	 * @param $tid intval
	 * @return array
	 */
	protected function themePicture($tid) {
		$tid = intval($tid);
		$this->assign('tid', $tid);

		if (!$tid)
			$this->error('参数错误！');

		$order = array('page_no' => 'desc');
		$field = 'id,small_picture_url,big_picture_url,brand_id,publish_time';

        $cid = $this->sid == 4 ? 102 : $this->cid;
		$map['menu_id'] = $cid;
		$map['is_publish'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));
		$map['subject_id'] = $tid;

		$page = intval($_REQUEST['p']);
		$page = $page ? $page : 1;
		$cache_key = md5('FashionStyle::themePicture::' . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . '::' . $page . '::' . serialize($map));
		$Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$Arr) {
			$count = $this->modelP->where($map)->count();
			//echo $this->modelP->getLastSql();
			if ($count > 0) {
				import("ORG.Util.Page");
				$p = new Page($count, $this->pListRows);
				$voList = $this->modelP->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
				//echo $this->modelP->getLastSql()."</br>";
				if ($voList) {
					$picList = array();
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
						$voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);
						$_brand_name = '';
						$_brand_name = M('AttributeBrand')->where('id=' . $val['brand_id'])->getField('name');
						$voList[$key]['brand_name'] = $_brand_name;

						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['id'];
						$picList[$key]['sCid'] = $cid;
						$picList[$key]['sPidNo'] = $val['id'];
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}
				}
				$Arr['listArr'] = $voList;
				$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
				$Arr['pageStr'] = $p->showOne();
				$Arr['picNum'] = $count;
			}
			$this->cache->set($cache_key, $Arr, C('DATA_CACHE_TIME'));
		}

		$this->assign($Arr);
	}

	/**
	 * 图片列表分页
	 * @param type $field
	 * @param type $map
	 * @param type $sortBy
	 * @param type $asc
	 * @return type
	 */
	protected function pictureDataList($field, $map, $order) {
		//时间筛选项
		$this->setDateSift();

		$cid = $this->sid == 4 ? 102 : $this->cid; //内衣.时尚款式 menu_id=102

		if ($cid)
			$map[$this->tableArr['picture_original'] . '.menu_id'] = $cid;
		if ($this->cmid)
			$map[$this->tableArr['picture_original'] . '.child_menu_id'] = $this->cmid;

		$soid = $this->getSoid();
		if ($soid) {
			$map['fs.sort_id'] = $soid == 3 ? array('egt', $soid) : $soid;
			$join[] = "{$this->tableArr['ref_picture_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_original']}.id";
		}

		if ($this->sid && $this->sid != 2 && $this->sid != 4) {
			$map['fsc.special_column_id'] = $this->sid;
			$join[] = "{$this->tableArr['ref_picture_column_original']} as fsc on fsc.picture_id = {$this->tableArr['picture_original']}.id";
		}

		$map['is_publish'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));

		$seid = $this->param['seid'];
		if ($seid)
			$map['season_id'] = $seid;

		$deid = $this->param['deid'];
		if ($deid)
			$map['detail_id'] = $deid;

		$ano = $this->param['ano'];
		if ($ano) {
			$anoTmp = dechex($ano);
			if (substr($anoTmp, -4, 4) === '0000') {
				$map['area_no'] = array(array('egt', $ano), array('elt', $ano + 65535));
			} elseif (substr($anoTmp, -2, 2) === '00') {
				$map['area_no'] = array(array('egt', $ano), array('elt', $ano + 256));
			} else {
				$map['area_no'] = $ano;
			}
		}

		$bid = $this->param['bid'];
		$brandStr = $this->param['brandStr'];
		if (empty($bid) && $brandStr != '') {
			$bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
			$bid = intval($bid);
			$bid ? $map['brand_id'] = $bid : '';
		} elseif ($bid) {
			$map['brand_id'] = $bid;
			$brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
			$this->assign('brandStr', $brandStr);
		}

		//款式
		$stid = $this->param['stid'];
		$stid = $stid ? $stid : ($this->sid == 2 ? 128 : 0);
		if ($stid) {
			$join[] = "{$this->tableArr['ref_picture_style_original']} ps ON ps.picture_id={$this->tableArr['picture_original']}.id";
			$map['ps.style_id'] = $stid;
		}

		$coid = $this->param['coid'];
		if ($coid) {
			$join[] = "{$this->tableArr['ref_picture_color_original']} pc ON pc.picture_id={$this->tableArr['picture_original']}.id";
			$map['pc.color_id'] = $coid;
		}

		$maid = $this->param['maid'];
		if ($maid) {
			$join[] = "{$this->tableArr['ref_picture_material_original']} pm ON pm.picture_id={$this->tableArr['picture_original']}.id";
			$map['pm.material_id'] = $maid;
		}

		//风格
		$faid = $this->param['faid'];
		if ($faid) {
			$join[] = "{$this->tableArr['ref_picture_fashion_original']} pf ON pf.picture_id={$this->tableArr['picture_original']}.id";
			$map['pf.fashion_id'] = $faid;
		}

		//配饰
		$acid = $this->param['acid'];
		if ($acid) {
			$join[] = "{$this->tableArr['ref_picture_acc_original']} sa ON sa.picture_id={$this->tableArr['picture_original']}.id";
			$map['sa.acc_id'] = $acid;
		}

		//关键词
		$kid = $this->param['kid'];
		if ($kid) {
			$join[] = "{$this->tableArr['ref_picture_keyword_original']} sk ON sk.picture_id={$this->tableArr['picture_original']}.id";
			$map['sk.keyword_id'] = $kid;
		}

		$page = intval($_REQUEST['p']);
		$page = $page ? $page : 1;
		$cache_key = md5("FashionStyle::pictureDataList::" . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . "::" . $page . serialize($map));
		$Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$Arr) {
			//取得满足条件的记录数
			//$count = $this->modelP->join($join)->where($map)->count();
			//echo $this->modelP->getlastsql();
			import("ORG.Util.DataCount");
			$count = DataCount::getCount($this->tableArr['picture'], $map, $join);
			if ($count > 0) {
				import("ORG.Util.Page");
				//创建分页对象
				$p = new Page($count, $this->pListRows);
				//分页查询数据
				$voList = $this->modelP->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
				//echo $this->modelP->getlastsql();
				if ($voList) {
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']); //show_pic_power($val['small_picture_url'], $this->isRightS);
						$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
						if ($val['season_id']) {
							$voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
						}
						if ($val['area_no']) {
							$voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
						}
						if ($val['brand_id']) {
							$voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
						}
						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['id'];
						$picList[$key]['sCid'] = $cid;
						$picList[$key]['sPidNo'] = $val['id'];
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}
				}
				$Arr['listArr'] = $voList;
				$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
				$Arr['pageStr'] = $p->showOne();
			}
			$page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr, C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
		}

		$this->assign($Arr);
	}

	/**
	 * 500页后shpinx图片列表分页
	 */
	protected function pictureDataListBySphinx() {
		import('@.ORG.Search');
		$search = new Search();
		$search->setSortMode(SPH_SORT_EXTENDED, 'publish_time desc,picture_id desc');
		$pageSize = 20;
		$page = intval($_GET['p']) < 1 ? 1 : intval($_GET['p']);
		$search->setPageSize($pageSize);
		$search->setPage($page);

		$map = array(); //作缓存key值之用
		$cid = $this->sid == 4 ? 102 : $this->cid; //内衣.时尚款式 menu_id=102

		if ($cid) {
			$map['menu_id'] = $cid;
			$search->setFilter('menu_id', array($cid));
		}

		if ($this->cmid) {
			$map['child_menu_id'] = $this->cmid;
			$search->setFilter('child_menu_id', array($this->cmid));
		}

		$search->setFilterRange('publish_time', strtotime('1990-01-01 00:00:00'), C('TODAY_LAST_TIME'));

		$soid = $this->getSoid();
		if ($soid) {
			$map['sort_id'] = $soid == 3 ? array('eq', 4) : $soid;
			if ($soid == 3)
				$search->setFilter('sort_id', $this->childrenSoids);
			else
				$search->setFilter('sort_id', array($soid));
		}

		if ($this->sid && $this->sid != 2 && $this->sid != 4) {
			$map['column_id'] = $this->sid;
			$search->setFilter('column_id', array($this->sid));
		}

		$seid = $this->param['seid'];
		if ($seid) {
			$map['season_id'] = $seid;
			$search->setFilter('season_id', array($seid));
		}

		$deid = $this->param['deid'];
		if ($deid) {
			$map['detail_id'] = $deid;
			$search->setFilter('detail_id', array($deid));
		}

		$ano = $this->param['ano'];
		if ($ano) {
			$anoTmp = dechex($ano);
			if (substr($anoTmp, -4, 4) === '0000') {
				$map['area_no'] = array(array('egt', $ano), array('elt', $ano + 65535));
				$search->setFilterRange('area_no', $ano, $ano + 65535);
			} elseif (substr($anoTmp, -2, 2) === '00') {
				$map['area_no'] = array(array('egt', $ano), array('elt', $ano + 256));
				$search->setFilterRange('area_no', $ano, $ano + 256);
			} else {
				$map['area_no'] = $ano;
				$search->setFilter('area_no', array($ano));
			}
		}

		$bid = $this->param['bid'];
		$brandStr = $this->param['brandStr'];
		if (empty($bid) && $brandStr != '') {
			$bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
			$bid = intval($bid);
			$bid ? $search->setFilter('brand_id', array($bid)) : '';
			$map['brand_id'] = $bid;
		} elseif ($bid) {
			$map['brand_id'] = $bid;
			$search->setFilter('brand_id', array($bid));
			$brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
			$this->assign('brandStr', $brandStr);
		}

		//款式
		$stid = $this->param['stid'];
		$stid = $stid ? $stid : ($this->sid == 2 ? 128 : 0);
		if ($stid) {
			$map['style_id'] = $stid;
			$search->setFilter('style_id', array($stid));
		}

		$coid = $this->param['coid'];
		if ($coid) {
			$map['color_id'] = $coid;
			$search->setFilter('color_id', array($coid));
		}

		$maid = $this->param['maid'];
		if ($maid) {
			$map['material_id'] = $maid;
			$search->setFilter('material_id', array($maid));
		}

		//风格
		$faid = $this->param['faid'];
		if ($faid) {
			$map['fashion_id'] = $faid;
			$search->setFilter('fashion_id', array($faid));
		}
		//配饰
		$acid = $this->param['acid'];
		if ($acid) {
			$map['acc_id'] = $acid;
			$search->setFilter('acc_id', array($acid));
		}

		//关键词
		$kid = $this->param['kid'];
		if ($kid) {
			$map['keyword_id'] = $kid;
			$search->setFilter('keyword_id', array($kid));
		}

		$cache_key = md5("FashionStyle::pictureDataListBySphinx::" . $this->isRightS . "::" . $this->isRightB . '::' . $this->soid . '::' . $this->sid . "::" . $page . '::' . serialize($map));
		$Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$Arr) {
			$rows = $search->query();
			$count = intval($rows['total_found']); //下面做分页之用
			$Arr['listArr'] = array();
			$picList = array();
			$Arr['total'] = intval($rows['total_found']);
			$Arr['runTime'] = $rows['time'];

			if ($count > 0) {
				import("ORG.Util.Page");
				$p = new Page($count, $pageSize);
				foreach ($_REQUEST as $key => $val) {
					if (!is_array($val)) {
						$p->parameter .= "$key=" . urlencode($val) . "&";
					}
				}

				$field = 'picture_id,small_picture_url,big_picture_url,menu_id,publish_time,season_id,brand_id,area_no';
				$ids = array();
				foreach ($rows['matches'] as $k => $v)
					$ids[] = $v['id'];

				$voList = $search->getPicInfoByIds($ids, $field);
				if ($voList) {
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);
						$voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);

						if ($val['season_id']) {
							$voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
						}

						if ($val['area_no']) {
							$voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
						}

						if ($val['brand_id']) {
							$voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
							//$voList[$key]['brandStr'] = $brandList[$val['brand_id']]['name'];
						}

						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['picture_id'];
						$picList[$key]['sCid'] = $val['menu_id'];
						$picList[$key]['sPidNo'] = $val['picture_id'];
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}

					$Arr['listArr'] = $voList;
					$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
					$Arr['pageStr'] = $p->showOne();
				}
			}
			$page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr, C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
		}

		$this->assign($Arr);
	}

	/**
	 * 图片列表分页(时尚款式细节专用)
	 * @param type $field
	 * @param type $map
	 * @param type $sortBy
	 * @param type $asc
	 * @return type
	 */
	protected function detailPictureDataList($field, $map, $order) {
		if ($this->cid)
			$map[$this->tableArr['picture_subsidiary_original'] . '.menu_id'] = $this->cid;
		if ($this->cmid)
			$map[$this->tableArr['picture_subsidiary_original'] . '.child_menu_id'] = $this->cmid;
		$soid = $this->getSoid();
		if ($soid) {
			$map['fs.sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
			$join[] = "{$this->tableArr['ref_subsidiary_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_subsidiary_original']}.id";
		}
		if ($this->sid) {
			$map['fs.special_column_id'] = $this->sid;
			$join[] = "{$this->tableArr['ref_subsidiary_column_original']}} as fs on fs.picture_id = {$this->tableArr['picture_subsidiary_original']}.id";
		}
		$map['is_publish'] = 1;
		$map['is_detail'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));

		$stid = $this->param['stid'];
		if ($stid) {
			$join[] = "{$this->tableArr['ref_picture_subsidiary_style_original']} ps on ps.picture_id={$this->tableArr['picture_subsidiary_original']}.id";
			$map['ps.style_id'] = $stid;
		}

		$deid = $this->param['deid'];
		if ($deid) {
			$join[] = "{$this->tableArr['ref_picture_subsidiary_detail_original']} pd on pd.picture_id={$this->tableArr['picture_subsidiary_original']}.id";
			$map['pd.detail_id'] = $deid;
		}

		$coid = $this->param['coid'];
		if ($coid) {
			$join[] = "{$this->tableArr['ref_picture_subsidiary_color_original']} pc ON pc.picture_id={$this->tableArr['picture_subsidiary_original']}.id";
			$map['pc.color_id'] = $coid;
		}

		$page = intval($_REQUEST['p']);
		$page = $page ? $page : 1;
		$cache_key = MD5('FashionStyle::detailPictureDataList::' . $page . '::' . $this->isRightS . '::' . $this->isRightB . '::' . $this->soid . '::' . $this->sid . '::' . serialize($map));
		$Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$Arr) {
			//取得满足条件的记录数
			//$count = M($this->tableArr['picture_subsidiary'])->join($join)->where($map)->count();
			//echo $this->modelP->getlastsql();
			import("ORG.Util.DataCount");
			$count = DataCount::getCount($this->tableArr['picture_subsidiary'], $map, $join);
			if ($count > 0) {
				import("ORG.Util.Page");
				//创建分页对象
				$p = new Page($count, $this->pListRows);
				//分页查询数据
				$voList = M($this->tableArr['picture_subsidiary'])->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
				//echo M($this->tableArr['picture_subsidiary'])->getlastsql();
				if ($voList) {
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']); //show_pic_power($val['small_picture_url'], $this->isRightS);
						$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';

						if ($deid)
							$voList[$key]['detailStr'] = $this->details[$deid]['name'];
						else {
							$deidTmp = M($this->tableArr['ref_picture_subsidiary_detail'])->getField('detail_id', array('picture_id' => $val['id']));
							//echo  M($this->tableArr['ref_picture_subsidiary_detail'])->getLastSql().'<br/>';
							$voList[$key]['detailStr'] = $this->details[$deidTmp]['name'];
						}

						if ($stid) {
							$voList[$key]['styleStr'] = $this->styles[$stid]['name'];
							$voList[$key]['styleUrl'] = U('/' . MODULE_NAME . '/detail', array('stid' => $stid));
						} else {
							$stidTmp = M($this->tableArr['ref_picture_subsidiary_style'])->getField('style_id', array('picture_id' => $val['id']));
							$voList[$key]['styleStr'] = $this->styles[$stidTmp]['name'];
							$voList[$key]['styleUrl'] = U('/' . MODULE_NAME . '/detail', array('stid' => $stidTmp));
						}

						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['id'];
						$picList[$key]['sCid'] = $this->cid;
						$picList[$key]['sPidNo'] = $val['id'];
						$picList[$key]['sDetail'] = 1;
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}
				}
				$Arr['listArr'] = $voList;
				$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB));
				$Arr['pageStr'] = $p->showOne();
			}
			$page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr, C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
		}
		$this->assign($Arr);
	}

	/**
	 * 图片列表分页(时尚款式细节专用)
	 * @param type $field
	 * @param type $map
	 * @param type $sortBy
	 * @param type $asc
	 * @return type
	 */
	protected function detailPictureDataListBySphinx($field, $map, $order) {
		import('@.ORG.Search');
		$search = new Search();
		$search->setSortMode(SPH_SORT_EXTENDED, 'publish_time desc,id desc');
		$pageSize = $this->pListRows;
		$page = intval($_GET['p']) < 1 ? 1 : intval($_GET['p']);
		$search->setPageSize($pageSize);
		$search->setPage($page);

		if ($this->cid){
			$map[$this->tableArr['picture_subsidiary_original'] . '.menu_id'] = $this->cid;
            $search->setFilter('menu_id', array($this->cid));
        }
		if ($this->cmid){
			$map[$this->tableArr['picture_subsidiary_original'] . '.child_menu_id'] = $this->cmid;
            $search->setFilter('child_menu_id', array($this->cmid));
        }
		$soid = $this->getSoid();
		if ($soid) {
			$map['fs.sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
			if ($soid == 3){
				$search->setFilter('sort_id', $this->childrenSoids);
            }else{
				$search->setFilter('sort_id', array($soid));
            }
		}
		if ($this->sid) {
			$map['fs.special_column_id'] = $this->sid;
            $search->setFilter('special_column_id', array($this->sid));
		}

		$map['is_detail'] = 1;
        $search->setFilter('is_detail', array(1));
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));
        $search->setFilterRange('publish_time',strtotime('2004-01-01'),C('TODAY_LAST_TIME'));

		$stid = $this->param['stid'];
		if ($stid) {
			$map['ps.style_id'] = $stid;
            $search->setFilter('style_id', array($stid));
		}

		$deid = $this->param['deid'];
		if ($deid) {
			$map['pd.detail_id'] = $deid;
            $search->setFilter('detail_id', array($deid));
		}

		$coid = $this->param['coid'];
		if ($coid) {
			$map['pc.color_id'] = $coid;
            $search->setFilter('color_id', array($coid));
		}
        $search->setFilterRange('detail_id', 1, 99999);

		$cache_key = MD5('FashionStyle::detailPictureDataList::' . $page . '::' . $this->isRightS . '::' . $this->isRightB . '::' . $this->soid . '::' . $this->sid . '::' . serialize($map));
		$Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
		if (!$Arr) {
			//取得满足条件的记录数
			$rows = $search->query('','sxxl_style_picture_subsidiary');
//            echo '<pre>';
//            print_r($rows);
			$count = intval($rows['total_found']); //下面做分页之用
            if($count > 0){
				import("ORG.Util.Page");
				$p = new Page($count, $pageSize);
				$ids = array();
				foreach ($rows['matches'] as $k => $v)
					$ids[] = $v['id'];

                $voList = $this->getDetailInfoByIds($ids,$field);
				if ($voList) {
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']); //show_pic_power($val['small_picture_url'], $this->isRightS);
						$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';

						if ($deid)
							$voList[$key]['detailStr'] = $this->details[$deid]['name'];
						else {
							$deidTmp = M($this->tableArr['ref_picture_subsidiary_detail'])->getField('detail_id', array('picture_id' => $val['id']));
							//echo  M($this->tableArr['ref_picture_subsidiary_detail'])->getLastSql().'<br/>';
							$voList[$key]['detailStr'] = $this->details[$deidTmp]['name'];
						}

						if ($stid) {
							$voList[$key]['styleStr'] = $this->styles[$stid]['name'];
							$voList[$key]['styleUrl'] = U('/' . MODULE_NAME . '/detail', array('stid' => $stid));
						} else {
							$stidTmp = M($this->tableArr['ref_picture_subsidiary_style'])->getField('style_id', array('picture_id' => $val['id']));
							$voList[$key]['styleStr'] = $this->styles[$stidTmp]['name'];
							$voList[$key]['styleUrl'] = U('/' . MODULE_NAME . '/detail', array('stid' => $stidTmp));
						}

						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['id'];
						$picList[$key]['sCid'] = $this->cid;
						$picList[$key]['sPidNo'] = $val['id'];
						$picList[$key]['sDetail'] = 1;
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}
				}
				$Arr['listArr'] = $voList;
				$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB));
				$Arr['pageStr'] = $p->showOne();
			}
			$page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr, C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
		}
		$this->assign($Arr);
	}

	protected function themeDetail($tid = '') {
		$this->assign('jumpUrl', 'javascript:window.close();');
		$this->relationArr = array('SubjectExtend');
		$tid = intval($tid);

		$tid = $tid ? $tid : intval($_GET['tid']);
		$themeInfo = $this->themeInfo($tid);
		//dump($themeInfo);
		if ($themeInfo['show_edit'] == 1)
			$this->getShowContent($themeInfo);
		else
			$this->themePicture($tid);

		$this->updateThemePvCount($tid);

		$this->assign('info', $themeInfo);
		$this->display(MODULE_NAME . '/theme_detail');
	}

	protected function setCmid() {
		$this->cmid = intval($_GET['cmid']);
		$this->assign('cmid', $this->cmid);
	}

	public function getPicFt() {
		$pid = intval($_REQUEST['pid']);
		if ($pid < 1)
			exit('failure');

		$field = 'big_picture_url,small_picture_url';
		$orgPic = $this->modelP->field($field)->where("id='{$pid}'")->find();

		$orgSmallSrc = show_pic_power($orgPic["small_picture_url"], $this->isRightS);
		$orgBigSrc = show_pic_power($orgPic["big_picture_url"], $this->isRightB);
		$data = "<li id='ft0' onclick='viewPic.imgFtChoose(0)' class='fta current'><img onclick='viewPic.loadPicFt(\"{$orgBigSrc}\")' alt='' src='{$orgSmallSrc}' title='' /></li>";
		$map['is_publish'] = 1;
		$map['picture_id'] = $pid;
		$arrPicList = M($this->tableArr['subsidiary'])->field($field)->where($map)->findAll();
		if ($arrPicList) {
			$i = 1;
			foreach ($arrPicList as $key => $val) {
				$smallSrc = show_pic_power($val["small_picture_url"], $this->isRightS);
				$bigSrc = show_pic_power($val["big_picture_url"], $this->isRightB);
				$data .= "<li id='ft{$i}' onclick='viewPic.imgFtChoose($i)' class='fta'><img onclick='viewPic.loadPicFt(\"{$bigSrc}\")' alt='' src='{$smallSrc}' title='' /></li>";
				++$i;
			}
		}

		exit($arrPicList ? $data : '');
	}

	protected function setCidSift() {
		$sMap['menu_id'] = $this->sid == 4 ? 102 : $this->cid;
		$this->cmid ? $sMap['child_menu_id'] = $this->cmid : '0';
		$soid = $this->getSoid();
		if ($soid) {
			$sMap['sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
		}

		$this->sid && $this->sid != 2 && $this->sid != 4 ? $sMap['special_column_id'] = $this->sid : '';

		$fieldArr = array('season_id_list', 'area_no_list', 'brand_id_list');
		//$fieldArr[] = 'fashion_id_list';//风格
		//$fieldArr[] = 'style_id_list';//款式
		//$fieldArr[] = 'color_id_list';//颜色
		//$fieldArr[] = 'detail_id_list';//细节
        $cache_key = md5('FashionStyle::'.'setcidsift::'. $this->sid . serialize($this->param) .'::'.serialize($sMap));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr) {
            $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
            $this->areas = $siftArr['area_no_list'];
            $this->seasons = $siftArr['season_id_list'];
            $Arr['brands'] = $this->brands = $siftArr['brand_id_list'];
            //$Arr['fashions'] = $this->fashions = $siftArr['fashion_id_list'];
            //$Arr['styles'] = $this->styles = $siftArr['style_id_list'];
            //颜色
            $colors = F('colorList', '', C('DATA_CACHE_PATH'));
            preg_match("/[^\.\/]+\.[^\.\/]+$/", $_SERVER['SERVER_NAME'], $m);
            foreach ($colors as $key => $val) {
                $title_pic = $colors[$val['id']]['url'];
                $colors[$key]['title_pic'] = 'http://img9.f.sxxl.com/' . $title_pic;
                $colors[$key]['url'] = U('/' . MODULE_NAME . "/pictureList", array('soid' => intval($this->param['soid']), 'coid' => $val['id']));
            }
            //dump($colors);
            $Arr['colors'] = $this->colors = $colors;

            //细节
            $Arr['details'] = $this->details = F('detailList', '', C('DATA_CACHE_PATH'));

            if ($this->seasons) {
                $seasonsTmp = $this->seasons;
                uasort($seasonsTmp, "cmp");
                $Arr['seasons'] = $seasonsTmp;
                unset($seasonsTmp);
            }
            if ($this->areas) {
                $Arr['areaHtml'] = $this->getAreaOption($this->param['ano']);
            }

            $Arr['letters'] = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
            $this->cache->set($cache_key, $Arr);
        }
		$Arr['config'] = $config;
		$this->assign($Arr);
	}

	protected function setParam() {
		$this->param = array('cmid' => intval($this->cmid));

		$soid = intval($_REQUEST['soid']);
		$soid = $this->sid ? $soid : ($this->soid == 3 && $soid > 2 ? $soid : $this->soid);
		if ($soid)
			$this->param = array_merge($this->param, array('soid' => $soid));

		$seid = intval($_REQUEST['seid']);
		if ($seid)
			$this->param = array_merge($this->param, array('seid' => $seid));

		$stid = intval($_REQUEST['stid']);
		if (!$stid) {
			if ($this->sid == 1) {//牛仔专栏如未选择款式则默认选中牛仔款式
				$stid = 211;
			} else if ($this->sid == 2) {
				$stid = 128;
			}
		}

		if ($stid)
			$this->param = array_merge($this->param, array('stid' => $stid));

		$ano = intval($_REQUEST['ano']);
		if ($ano)
			$this->param = array_merge($this->param, array('ano' => $ano));

		$bid = intval($_REQUEST['bid']);
		if ($bid)
			$this->param = array_merge($this->param, array('bid' => $bid));

		$coid = intval($_REQUEST['coid']);
		if ($coid)
			$this->param = array_merge($this->param, array('coid' => $coid));

		$faid = intval($_REQUEST['faid']);
		$faid = $faid ? $faid : ($this->cmid == 68 ? 4 : ($this->cmid == 69 ? 6 : 0));
		if ($faid)
			$this->param = array_merge($this->param, array('faid' => $faid));

		$deid = intval($_REQUEST['deid']);
		if ($deid)
			$this->param = array_merge($this->param, array('deid' => $deid));

		$maid = intval($_REQUEST['maid']);
		if ($maid)
			$this->param = array_merge($this->param, array('maid' => $maid));

		$brandStr = trim($_REQUEST['brandStr']);
		if ($brandStr)
			$this->param = array_merge($this->param, array('brandStr' => $brandStr));

		$act = trim($_REQUEST['act']);
		if ($act)
			$this->param = array_merge($this->param, array('act' => $act));

		$kid = intval($_REQUEST['kid']);
		if ($kid)
			$this->param = array_merge($this->param, array('kid' => $kid));
	}

	protected function getShowContent($themeInfo) {
		if (!$themeInfo['id'])
			$this->error('参数错误！');

		$field = 'id,small_picture_url,big_picture_url';

		$map['is_publish'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));
		$map['subject_id'] = $themeInfo['id'];
		$count = $this->modelP->where($map)->count();
		//echo $this->modelP->getLastSql();
		if ($count > 0) {
			import("ORG.Util.Page");
			$voList = $this->modelP->where($map)->field($field)->order(array('publish_time' => 'desc', 'id' => 'desc'))->findAll();
		}
		$picList = array();
		$parse_arr = parse_content(stripslashes($themeInfo['content']));
		$Arr['detailhtml'] = $parse_arr['result'];

		if ($parse_arr['pic_arr']) {
			//$i = 0;
			foreach ($parse_arr['pic_arr'] as $key => $val) {
				$picList[$key]['sTid'] = $themeInfo['id'];
				$picList[$key]['sPid'] = 0;
				$picList[$key]['sSex'] = $themeInfo['sort_id'];
				$picList[$key]['sCid'] = $this->cid;
				$picList[$key]['sPicNo'] = 0;
				$picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
				$picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
				$picList[$key]['sSpic'] = $val['sSpic'];
				$picList[$key]['sBpic'] = $val['sBpic'];
				if ($voList) {
					foreach ($voList as $ke => $va) {
						if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
							//echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
							$picList[$key]['sPid'] = $va['id'];
							$picList[$key]['sSex'] = $va['sort_id'];
							$picList[$key]['sPicNo'] = $va['id'];
						}
					}
				}
			}
		}

		$Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)); //放大图片
		$Arr['picNum'] = $count; //主题下载处需要用到
		$this->assign($Arr);
	}

	//时尚款式已选筛选属性
	protected function getFashionStyleChioceStr() {
		$chioceStr = ""; //<a href="" class="current">白领丽人</a><a href="">钉珠绣花</a>
		$ano = $this->param['ano'];
		$stid = $this->param['stid'];
		$soid = $this->getSoid();
		if ($ano) {
			$name = $this->areas[$ano]['name'];
			$chioceStr .= '<a href="' . U('/' . MODULE_NAME . '/pictureList', array('soid' => $soid, 'stid' => $stid, 'ano' => 0)) . '" title="' . $name . '">' . $name . '</a>';
		}

		$faid = $this->param['faid'];
		if ($faid) {
			$name = $this->fashions[$faid]['name']; //M('AttributeFashion')->getField('`name`', array('id' => $faid));
			$chioceStr .= '<a href="' . U('/' . MODULE_NAME . '/pictureList', array('soid' => $soid, 'stid' => $stid, 'faid' => 0)) . '" title="' . $name . '">' . $name . '</a>';
		}

		$kid = $this->param['kid'];
		if ($kid) {
			$name = $this->keywords[$kid]['name']; //M('AttributeKeyword')->getField('name', array('id' => $kid));
			$chioceStr .= '<a href="' . U('/' . MODULE_NAME . '/pictureList', array('soid' => $soid, 'stid' => $stid, 'kid' => 0)) . '" title="' . $name . '">' . $name . '</a>';
		}

		return $chioceStr != '' ? '<span>您已选择：</span>' . $chioceStr : '';
	}

	/*
	 * @根据图片款式搜索过滤风格
	 * @$stid intval 款式ID
	 */

	protected function getPictureSiftByStyle($stid, $tag) {
		if (!in_array($tag, array('fashion', 'keyword', 'area'))) {
			return;
		}

		$table_info_arr = array(
			'fashion' => array('model' => M('refStyleFashion'), 'field' => 'fashion_id', 'ex' => 'id', 'param' => 'faid'),
			'keyword' => array('model' => M('refStyleKeyword'), 'field' => 'keyword_id', 'ex' => 'id', 'param' => 'kid'),
			'area' => array('model' => M('refStyleArea'), 'field' => 'area_no', 'ex' => 'no', 'param' => 'ano'),
		);

		import("ORG.Util.DataCount");
		$map = array();
		$map['menu_id'] = $this->sid == 4 ? 102 : $this->cid;
		$map['style_id'] = $stid;
		$soid = $this->getSoid();
		$map['sort_id'] = $soid == 3 ? array('egt', 3) : $soid;
		$tab = $table_info_arr[$tag]['model']->field($table_info_arr[$tag]['field'])->where($map)->findAll();
		$tab = $this->arrayUnique($tab, $table_info_arr[$tag]['field']);
		if ($tab) {
			$soid = $this->getSoid();
			foreach ($tab as $key => $val) {
				$id = $val[$table_info_arr[$tag]['field']];
				$tabTmp[$id][$table_info_arr[$tag]['ex']] = $id;
				$name = M('Attribute' . ucwords($tag))->getField('`name`', array($table_info_arr[$tag]['ex'] => $id));
				$tabTmp[$id]['name'] = $name;
				$tabTmp[$id]['url'] = U('/' . MODULE_NAME . '/pictureList', array('soid' => $soid, 'stid' => $stid, $table_info_arr[$tag]['param'] => $id));
			}
			$tab = $tabTmp;
			unset($tabTmp);
		}
		return $tab;
	}

	/*
	 * 根据各栏目需求获性别ID
	 */

	protected function getSoid() {
		$soid = $this->param['soid'];
		if ($soid)
			$soid = $this->soid == 3 && !in_array($soid, array(4, 5, 6)) ? 4 : (in_array($soid, array(1, 2, 3, 4, 5, 6)) ? $soid : 2);
		else
			$soid = $this->sid ? 2 : ($this->soid == 3 ? 4 : $this->soid);

		$this->assign('soid', $soid);
		return $soid;
	}

    /**
     * 去掉二维数组中的重复值
     * @param type $array2D
     * @param type $field
     * @return type
     */
	function arrayUnique($array2D, $field) {
		//echo $field;
		foreach ($array2D as $v) {
			$v = join(",", $v);  //降维,也可以用implode,将一维数组转换为用逗号连接的字符串
			$temp[] = $v;
		}
		$temp = array_unique($temp); //去掉重复的字符串,也就是重复的一维数组
		foreach ($temp as $k => $v) {
			$array = explode(",", $v);
			$temp2[$k][$field] = $array[0];   //再将拆开的数组重新组装
		}
		return $temp2;
	}

    protected function getDetailInfoByIds($ids,$field){
        if(empty($field)){
            $field = 'id,big_picture_url,small_picture_url,publish_time';
        }
		$row = M($this->tableArr['picture_subsidiary'])->where( 'id in('.implode(',',$ids).')' )->field($field)->order(array('publish_time'=>'desc','id'=>'desc'))->select();
        //echo $MODEL->getLastSql()."<br/>";
		return $row;
    }
}

