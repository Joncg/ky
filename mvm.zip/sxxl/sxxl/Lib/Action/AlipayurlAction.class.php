<?php

class AlipayurlAction extends CommonAction {

	public function returnUrl() {
		require_once("./Public/pay/alipay/alipay.config.php");
		require_once("./Public/pay/alipay/lib/alipay_notify.class.php");
		$alipayNotify = new AlipayNotify($aliapy_config);
		$verify_result = $alipayNotify->verifyReturn();
		if ($verify_result) {//验证成功
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//请在这里加上商户的业务逻辑程序代码
			//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
			//获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表
			$out_trade_no = $infoorder['order_id'] = $_GET['out_trade_no']; //获取订单号
			$trade_no = $_GET['trade_no'];  //获取支付宝交易号
			$total_fee = $infoorder['total_fee'] = $_GET['total_fee'];  //获取总价格
			$infoorder['type'] = 1;//财富通为2，支付宝为1
			if ($_GET['trade_status'] == 'TRADE_FINISHED' || $_GET['trade_status'] == 'TRADE_SUCCESS') {
				D('MemberOrders')->where(array("vip_number" => $out_trade_no))->save(array('status'=>1,'payment_type'=>1));
				getCurlDate('newwww.php?act=onlinepay', $infoorder);
				redirect("http://2012.sxxl.com/Shopping/oderSuccess.shtml");
				//判断该笔订单是否在商户网站中已经做过处理
				//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
				//如果有做过处理，不执行商户的业务程序
			} else {
				//echo "trade_status=" . $_GET['trade_status'];
			}
			//$this->display('Public:pay_success');

			//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		} else {
			//验证失败
			//如要调试，请看alipay_notify.php页面的verifyReturn函数，比对sign和mysign的值是否相等，或者检查$responseTxt有没有返回true
			echo "验证失败";
		}
	}

	public function notifyUrl() {
		require_once("./Public/pay/alipay/alipay.config.php");
		require_once("./Public/pay/alipay/lib/alipay_notify.class.php");

//计算得出通知验证结果
		$alipayNotify = new AlipayNotify($aliapy_config);
		$verify_result = $alipayNotify->verifyNotify();

		if ($verify_result) {//验证成功
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//请在这里加上商户的业务逻辑程序代
			//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
			//获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
			$out_trade_no = $infoorder['order_id'] = $_POST['out_trade_no'];  //获取订单号
			$trade_no = $_POST['trade_no'];   //获取支付宝交易号
			$total_fee = $infoorder['total_fee'] = $_POST['total_fee'];   //获取总价格
			$infoorder['type'] = 1;
			if ($_POST['trade_status'] == 'TRADE_FINISHED') {
				
				D('MemberOrders')->where(array("vip_number" => $out_trade_no))->save(array('status'=>1,'payment_type'=>1));
				getCurlDate('newwww.php?act=onlinepay', $infoorder);
				//判断该笔订单是否在商户网站中已经做过处理
				//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
				//如果有做过处理，不执行商户的业务程序
				//注意：
				//该种交易状态只在两种情况下出现
				//1、开通了普通即时到账，买家付款成功后。
				//2、开通了高级即时到账，从该笔交易成功时间算起，过了签约时的可退款时限（如：三个月以内可退款、一年以内可退款等）后。
				//调试用，写文本函数记录程序运行情况是否正常
				//logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
			} else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {

				D('MemberOrders')->where(array("vip_number" => $out_trade_no))->save(array('status'=>1,'payment_type'=>1));
				getCurlDate('newwww.php?act=onlinepay', $infoorder);
				//判断该笔订单是否在商户网站中已经做过处理
				//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
				//如果有做过处理，不执行商户的业务程序
				//注意：
				//该种交易状态只在一种情况下出现——开通了高级即时到账，买家付款成功后。
				//调试用，写文本函数记录程序运行情况是否正常
				logResult("订单号：".$out_trade_no."异步调用成功!");
			}

			//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——

			echo "success";  //请不要修改或删除
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		} else {
			//验证失败
			echo "fail";

			//调试用，写文本函数记录程序运行情况是否正常
			//logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
		}
	}

}