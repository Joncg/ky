<?php
class ChildrenFashionStyleAction extends FashionStyleAction {

    public function _initialize() {
		$this->soid = 3; //初始值3为取 之前按3定义的一些数据
        parent::_initialize();
    }

    public function index() {
        $this->assign('specialChildMenus',$this->getSpecialChildMenu());
        parent::index();
    }

    public function getPictureListByAjax() {
        parent::getPictureListByAjax();
    }

    public function themeList() {
        $this->assign('specialChildMenus',$this->getSpecialChildMenu());
        parent::themeList();
    }

    public function themeDetail($tid = '') {
        parent::themeDetail($tid);
    }

    public function pictureList() {
        parent::pictureList();
    }

    public function brandSearch() {
        parent::brandSearch();
    }

    public function detail() {
        parent::detail();
    }

    protected function getSpecialChildMenu() {
		//echo $this->action_name;
        $soid = parent::getSoid();
        $stid = $this->param['stid'];
        $specialChildMenu[4] = array(
            array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1,4,27,8,15,5)),
                'thirdMenu'=>
                array(
                    array('id'=>4,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>4)),'selected'=>$stid == 4),
                    array('id'=>27,'name'=>'长T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>27)),'selected'=>$stid == 27),
                    array('id'=>8,'name'=>'短T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>8)),'selected'=>$stid == 8),
                    array('id'=>15,'name'=>'马球衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>15)),'selected'=>$stid == 15),
                    array('id'=>5,'name'=>'吊带','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>5)),'selected'=>$stid == 5),
                )
            ),
            array('id'=>178,'name'=>'裙子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>178)),'selected'=>in_array($stid,array(178,187,183,182,185,184,181)),
                'thirdMenu'=>
                array(
                    array('id'=>187,'name'=>'连衣裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>187)),'selected'=>$stid == 187),
                    array('id'=>183,'name'=>'吊带连衣裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>183)),'selected'=>$stid == 183),
                    array('id'=>182,'name'=>'衬衫式连衣裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>182)),'selected'=>$stid == 182),
                    array('id'=>185,'name'=>'多层裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>185)),'selected'=>$stid == 185),
                    array('id'=>184,'name'=>'短裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>184)),'selected'=>$stid == 184),
                    array('id'=>181,'name'=>'背带裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>181)),'selected'=>$stid == 181),
                 )
            ),
            array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66,74,84,92,70,67,85,69)),
                'thirdMenu'=>
                array(
                    array('id'=>74,'name'=>'宫廷式','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>74)),'selected'=>$stid == 74),
                    array('id'=>84,'name'=>'套头','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>84)),'selected'=>$stid == 84),
                    array('id'=>92,'name'=>'长袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>92)),'selected'=>$stid == 92),
                    array('id'=>70,'name'=>'短袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>70)),'selected'=>$stid == 70),
                    array('id'=>67,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>67)),'selected'=>$stid == 67),
                    array('id'=>85,'name'=>'娃娃装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>85)),'selected'=>$stid == 85),
                    array('id'=>69,'name'=>'吊带衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>69)),'selected'=>$stid == 69),
                 )
            ),
            array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95,96,102,126,114,109)),
                'thirdMenu'=>
                array(
                    array('id'=>96,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>96)),'selected'=>$stid == 96),
                    array('id'=>102,'name'=>'短袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>102)),'selected'=>$stid == 102),
                    array('id'=>126,'name'=>'长袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>126)),'selected'=>$stid == 126),
                    array('id'=>114,'name'=>'披肩','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>114)),'selected'=>$stid == 114),
                    array('id'=>109,'name'=>'毛衣裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>109)),'selected'=>$stid == 109),
                )
            ),
            array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'selected'=>in_array($stid,array(128,150,132,151,137,129,130)),
                'thirdMenu'=>
                array(
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150)),'selected'=>$stid == 150),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132)),'selected'=>$stid == 132),
                    array('id'=>151,'name'=>'中裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>151)),'selected'=>$stid == 151),
                    array('id'=>137,'name'=>'连体裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>137)),'selected'=>$stid == 137),
                    array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>129)),'selected'=>$stid == 129),
                    array('id'=>130,'name'=>'打底裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>130)),'selected'=>$stid == 130),
                )
            ),
            array('id'=>278,'name'=>'大衣风衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>278)),'selected'=>in_array($stid,array(278,289,286)),
                'thirdMenu'=>
                array(
                    array('id'=>289,'name'=>'风衣(春秋)','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>289)),'selected'=>$stid == 289),
                    array('id'=>286,'name'=>'大衣（羊绒）','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>286)),'selected'=>$stid == 286),
                )
            ),
            array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'selected'=>in_array($stid,array(211,232,227,224,214)),
                'thirdMenu'=>
                array(
                    array('id'=>232,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>232)),'selected'=>$stid == 232),
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227)),'selected'=>$stid == 227),
                    array('id'=>224,'name'=>'裙子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>224)),'selected'=>$stid == 224),
                    array('id'=>214,'name'=>'短裤—七分裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>214)),'selected'=>$stid == 214),
                )
            ),
            array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>29)),'selected'=>in_array($stid,array(29,37,53,55,40)),
                'thirdMenu'=>
                array(
                    array('id'=>37,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>37)),'selected'=>$stid == 37),
                    array('id'=>53,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>53)),'selected'=>$stid == 53),
                    array('id'=>55,'name'=>'西装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>55)),'selected'=>$stid == 55),
                    array('id'=>40,'name'=>'披肩','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>40)),'selected'=>$stid == 40),
                 )
            ),
            array('id'=>264,'name'=>'棉衣羽绒','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>264)),'selected'=>in_array($stid,array(264,267,270,269)),
                'thirdMenu'=>
                array(
                    array('id'=>267,'name'=>'棉服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>267)),'selected'=>$stid == 267),
                    array('id'=>270,'name'=>'羽绒服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>270)),'selected'=>$stid == 270),
                    array('id'=>269,'name'=>'羽绒背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>269)),'selected'=>$stid == 269),
                )
            ),
            array('id'=>276,'name'=>'卫衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>276)),'selected'=>in_array($stid,array(276,278,284,279)),
                'thirdMenu'=>
                array(
                    array('id'=>278,'name'=>'开衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>278)),'selected'=>$stid == 278),
                    array('id'=>284,'name'=>'套头','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>284)),'selected'=>$stid == 284),
                    array('id'=>279,'name'=>'连帽','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>279)),'selected'=>$stid == 279),
                )
            ),
            array('id'=>242,'name'=>'皮草','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>242)),'selected'=>in_array($stid,array(242,243,251,244)),
                'thirdMenu'=>
                array(
                    array('id'=>243,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>243)),'selected'=>$stid == 243),
                    array('id'=>251,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>251)),'selected'=>$stid == 251),
                    array('id'=>250,'name'=>'裙子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>250)),'selected'=>$stid == 250),
                )
            ),
            array('id'=>152,'name'=>'运动','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152,155,167,157,174,165,158,166,175)),
                'thirdMenu'=>
                array(
                    array('id'=>155,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>155)),'selected'=>$stid == 155),
                    array('id'=>167,'name'=>'羽绒棉服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>167)),'selected'=>$stid == 167),
                    array('id'=>157,'name'=>'短T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>157)),'selected'=>$stid == 157),
                    array('id'=>174,'name'=>'长T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>174)),'selected'=>$stid == 174),
                    array('id'=>165,'name'=>'套装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>165)),'selected'=>$stid == 165),
                    array('id'=>158,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>158)),'selected'=>$stid == 158),
                    array('id'=>166,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>166)),'selected'=>$stid == 166),
                    array('id'=>175,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>167)),'selected'=>$stid == 175),
                )
            ),
            array('id'=>310,'name'=>'套装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>310)),'selected'=>in_array($stid,array(310,311,313)),
                'thirdMenu'=>
                array(
                    array('id'=>311,'name'=>'大童（5-12）','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>311)),'selected'=>$stid == 311),
                    array('id'=>313,'name'=>'中小童（1-5岁）','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>313)),'selected'=>$stid == 313),
                )
            ),
            array('id'=>367,'name'=>'亲子装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>367)),'selected'=>$stid == 367),
            array('id'=>360,'name'=>'礼服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>360)),'selected'=>$stid == 360),
        );

        $specialChildMenu[5] = array(
            array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1,4,27,8,15,5)),
                'thirdMenu'=>
                array(
                    array('id'=>4,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>4)),'selected'=>$stid == 4),
                    array('id'=>27,'name'=>'长T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>27)),'selected'=>$stid == 27),
                    array('id'=>8,'name'=>'短T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>8)),'selected'=>$stid == 8),
                    array('id'=>15,'name'=>'马球衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>15)),'selected'=>$stid == 15),
                 )
            ),
            array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66,74,84,92,70,67,85,69)),
                'thirdMenu'=>
                array(
                    array('id'=>92,'name'=>'长袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>92)),'selected'=>$stid == 92),
                    array('id'=>70,'name'=>'短袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>70)),'selected'=>$stid == 70),
                    array('id'=>67,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>67)),'selected'=>$stid == 67),
                )
            ),
            array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95,96,102,126,114,109)),
                'thirdMenu'=>
                array(
                    array('id'=>96,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>96)),'selected'=>$stid == 96),
                    array('id'=>102,'name'=>'短袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>102)),'selected'=>$stid == 102),
                    array('id'=>126,'name'=>'长袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>126)),'selected'=>$stid == 126),
                )
            ),
            array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'selected'=>in_array($stid,array(128,150,132,151,137,129,130)),
                'thirdMenu'=>
                array(
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150)),'selected'=>$stid == 150),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132)),'selected'=>$stid == 132),
                    array('id'=>151,'name'=>'中裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>151)),'selected'=>$stid == 151),
                )
            ),
            array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'selected'=>in_array($stid,array(211,232,227,235,214)),
                'thirdMenu'=>
                array(
                    array('id'=>232,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>232)),'selected'=>$stid == 232),
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227)),'selected'=>$stid == 227),
                    array('id'=>235,'name'=>'中裤/短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>235)),'selected'=>$stid == 235),
                )
            ),
            array('id'=>303,'name'=>'外套夹克','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>303)),'selected'=>in_array($stid,array(303,307,305,304,308,306)),
                'thirdMenu'=>
                array(
                    array('id'=>307,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>307)),'selected'=>$stid == 307),
                    array('id'=>305,'name'=>'夹克','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>305)),'selected'=>$stid == 305),
                    array('id'=>304,'name'=>'衬衫外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>304)),'selected'=>$stid == 304),
                    array('id'=>308,'name'=>'西装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>308)),'selected'=>$stid == 308),
                    array('id'=>306,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>306)),'selected'=>$stid == 306),
                 )
            ),
            array('id'=>264,'name'=>'棉衣羽绒','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>264)),'selected'=>in_array($stid,array(264,267,270,269)),
                'thirdMenu'=>
                array(
                    array('id'=>267,'name'=>'棉服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>267)),'selected'=>$stid == 267),
                    array('id'=>270,'name'=>'羽绒服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>270)),'selected'=>$stid == 270),
                    array('id'=>269,'name'=>'羽绒背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>269)),'selected'=>$stid == 269),
                )
            ),
            array('id'=>276,'name'=>'卫衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>276)),'selected'=>in_array($stid,array(276,278,284,279)),
                'thirdMenu'=>
                array(
                    array('id'=>278,'name'=>'开衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>278)),'selected'=>$stid == 278),
                    array('id'=>284,'name'=>'套头','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>284)),'selected'=>$stid == 284),
                    array('id'=>279,'name'=>'连帽','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>279)),'selected'=>$stid == 279),
                )
            ),
            array('id'=>152,'name'=>'运动','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152,155,167,157,174,165,158,166,175)),
                'thirdMenu'=>
                array(
                    array('id'=>155,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>155)),'selected'=>$stid == 155),
                    array('id'=>167,'name'=>'羽绒棉服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>167)),'selected'=>$stid == 167),
                    array('id'=>157,'name'=>'短T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>157)),'selected'=>$stid == 157),
                    array('id'=>174,'name'=>'长T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>174)),'selected'=>$stid == 174),
                    array('id'=>165,'name'=>'套装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>165)),'selected'=>$stid == 165),
                    array('id'=>158,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>158)),'selected'=>$stid == 158),
                    array('id'=>166,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>166)),'selected'=>$stid == 166),
                    array('id'=>175,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>175)),'selected'=>$stid == 175),
                )
            ),
            array('id'=>310,'name'=>'套装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>310)),'selected'=>in_array($stid,array(310,311,313)),
                'thirdMenu'=>
                array(
                    array('id'=>311,'name'=>'大童（5-12）','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>311)),'selected'=>$stid == 311),
                    array('id'=>313,'name'=>'中小童（1-5岁）','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>313)),'selected'=>$stid == 313),
                )
            ),
            array('id'=>367,'name'=>'亲子装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>367)),'selected'=>$stid == 367),
            array('id'=>360,'name'=>'礼服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>360)),'selected'=>$stid == 360),
        );

        return $specialChildMenu[$soid];
    }

	public function downloadzip() {
		parent::downloadzip();
	}
}
