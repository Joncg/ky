<?php
class ChildrenTshapeAction extends TshapeAction {

    public function _initialize() {
        $this->soid = 3;
        parent::_initialize();
    }

	public function index() {
        $this->folderList();
	}

	public function folderDetail() {
        $this->pListRows = 20;
        parent::folderDetail();
	}

	public function folderList(){
        parent::folderList();
	}

	public function downloadzip() {
        parent::downloadzip();
    }
}
