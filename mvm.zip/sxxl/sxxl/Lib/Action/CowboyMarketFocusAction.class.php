<?php
class CowboyMarketFocusAction extends TideSectionAction {

    public function _initialize() {
        $this->cid = 29;
        $this->sid = 1;
        parent::_initialize();
    }

	public function index() {
        $this->themeList();
	}

    public function themeList(){
		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,book_id,season_id,area_no,pv_count";

        $order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->tListRows = 8;
		$this->themeDataList($field, $map, $order);
		$this->display('theme_list');
    }

	public function themeDetail($tid = '') {
        $this->assign('jumpUrl', 'javascript:window.close();');
        $this->pListRows = 20;
        $this->relationArr = array('SubjectExtend');
        $tid = intval($tid);

        $tid = $tid ? $tid : intval($_GET['tid']);
        $themeInfo = $this->themeInfo($tid);
        //dump($themeInfo);
        if ($themeInfo['show_edit'] == 1)
            $this->getShowContent($themeInfo);
        else
            $this->themePicture($tid);

        $this->updateThemePvCount($tid);

        $this->assign('info', $themeInfo);
        $this->display(MODULE_NAME . '/theme_detail');
	}


    /**
     * 主题列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeDataList($field, $map, $order) {
        $cid = $this->cid;
        if ($cid)
            $map[$this->tableArr['subject_original'] . '.menu_id'] = $cid;
        if ($this->cmid)
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;
        //时尚杂志特殊处理
        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }
       if ($this->sid) {
            $map['fsc.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
        }

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $seid = $this->param['seid'];
        if ($seid)
            $map['season_id'] = $seid;

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }
        }

        $stid = $this->param['stid'];
        if ($map['sst.style_id'] || $stid) {
            $join[] = "{$this->tableArr['ref_subject_style_original']} sst on sst.subject_id={$this->tableArr['subject_original']}.id";
            $map['sst.style_id'] ? '' : $map['sst.style_id'] = $stid;
        }

        //$count = $this->modelT->join($join)->where($map)->count();
        //echo $this->modelT->getlastsql();
        import("ORG.Util.DataCount");
        $count = DataCount::getCount($this->tableArr['subject'],$map,$join);
        $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
        $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
        if ($count > 0) {
            import("ORG.Util.Page");
            $p = new Page($count, $this->tListRows);
            $voList = $this->modelT->relation($this->relationArr)->useindex($this->index)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $this->modelT->getLastSql();
            if ($voList) {
                foreach ($voList as $key => $val) {
                    if ($val['season_id'])
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                    if ($val['area_no'])
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];

                    $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'soid'=>$soid,'tid' => $val['id']));
                    $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                    $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                    $voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
                }
            }
            //模板赋值显示
            $this->assign('listArr', $voList);
            //分页显示
            $page = $p->showOne();
            $this->assign("pageStr", $page);
        }
    }

    protected function themeInfo($tid) {
        $tid = intval($tid);

        if (!$tid)
            $this->error('参数错误！');

        $cid = $this->cid;
        if($cid)
            $map['menu_id'] = $cid;

        $map['id'] = $tid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $field = 'id,title,title_picture_url,publish_time,season_id,area_no,show_edit,lable_id';
        $info = $this->modelT->relation($this->relationArr)->field($field)->where($map)->find();
        //echo $this->modelT->getLastSql()."</br>";exit;
        $info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
        $soid = intval($_GET['soid']);
        $soid = $soid ? $soid : $this->soid;
        if(!$soid)
            $soid = M($this->tableArr['ref_subject_sort'])->getField("sort_id","subject_id='{$tid}'");

        $info['sortStr'] = $this->sorts[$soid]['title'];
        $info['areaStr'] = $this->areas[$info['area_no']]['name'];
        $info['seasonStr'] = $this->seasons[$info['season_id']]['en_name'];
        $info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']): '';

        //权限验证
        $this->withoutPermission('',$info);

        return $info;
    }

    /**
     * get theme picture list
     * @param $tid intval
     * @return array
     */
    protected function themePicture($tid) {
        $tid = intval($tid);
        $this->assign('tid', $tid);

        if (!$tid)
            $this->error('参数错误！');

        $order = array('publish_time' => 'desc');

        $field = 'id,small_picture_url,big_picture_url,page_no';
        $order = array('page_no' => 'asc');

        $cid = $this->cid;
        if ($cid)
            $map['menu_id'] = $cid;
        //if($this->cmid) $map['child_menu_id'] = $this->cmid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $tid;
        $count = $this->modelP->where($map)->count();
        //echo $this->modelP->getLastSql();
        if ($count > 0) {
            import("ORG.Util.Page");
            $p = new Page($count, $this->pListRows);
            $voList = $this->modelP->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $this->modelP->getLastSql()."</br>";
            if ($voList) {
                $picList = array();
                foreach ($voList as $key => $val) {
                    $voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
                    $voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);

                    $picList[$key]['sTid'] = 0;
                    $picList[$key]['sPid'] = $val['id'];
                    $picList[$key]['sCid'] = $cid;
                    $picList[$key]['sPidNo'] = $val['id'];
                    $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                    $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                    $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                }
            }
            //var_dump($picList);
            $this->assign('jsonData', json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)));
            //模板赋值显示
            $this->assign('listArr', $voList);
            //分页显示
            $this->assign('pageStr', $p->showOne());
            //主题下载处需要用到
            $this->assign('picNum', $count);
        }
    }

    protected function setCmid() {
        $this->cmid = intval($_GET['cmid']);
        $this->assign('cmid', $this->cmid);
    }

    protected function setCidSift() {
        $sMap['menu_id'] = $this->cid;
        $this->cmid ? $sMap['child_menu_id'] = $this->cmid : '';
        $soid = $this->getSoid();
        if($soid){
            $sMap['sort_id'] = $soid == 3 ? array('egt',3) : $soid;
        }
        $this->sid ? $sMap['special_column_id'] = $this->sid : '';
        $fieldArr = array('season_id_list','area_no_list');
        $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
        $this->seasons = $siftArr['season_id_list'];
        $this->areas = $siftArr['area_no_list'];

        if ($this->seasons) {
            $seasonsTmp = $this->seasons;
            uasort($seasonsTmp, "cmp");
            $Arr['seasons'] = $seasonsTmp;
            unset($seasonsTmp);
        }
        if ($this->areas) {
            $Arr['areaHtml'] = $this->getAreaOption($this->param['ano']);
        }
        $this->assign($Arr);
    }

    protected function setParam() {
        $this->param = array('cmid' => intval($this->cmid));

        $soid = intval($_REQUEST['soid']);
        if ($soid)
            $this->param = array_merge($this->param, array('soid' => $soid));

        $seid = intval($_REQUEST['seid']);
        if ($seid)
            $this->param = array_merge($this->param, array('seid' => $seid));

        $stid = intval($_REQUEST['stid']);
        if ($stid)
            $this->param = array_merge($this->param, array('stid' => $stid));

        $ano = intval($_REQUEST['ano']);
        if ($ano)
            $this->param = array_merge($this->param, array('ano' => $ano));
    }

    protected function getShowContent($themeInfo) {
        if (!$themeInfo['id'])
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url';

        $cid = $this->cid;
        if ($cid)
            $map['menu_id'] = $cid;

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $themeInfo['id'];
        $count = $this->modelP->where($map)->count();
        //echo $this->modelP->getLastSql();
        if ($count > 0) {
            import("ORG.Util.Page");
            $voList = $this->modelP->where($map)->field($field)->order(array('publish_time' => 'desc','id'=>'desc'))->findAll();
        }
        $picList = array();
        $parse_arr = parse_content($themeInfo['content']);
        $Arr['detailhtml'] = $parse_arr['result'];

        if ($parse_arr['pic_arr']) {
            //$i = 0;
            foreach ($parse_arr['pic_arr'] as $key => $val) {
                $picList[$key]['sTid'] = $themeInfo['id'];
                $picList[$key]['sPid'] = 0;
                $picList[$key]['sSex'] = $themeInfo['sort_id'];
                $picList[$key]['sCid'] = $cid;
                $picList[$key]['sPicNo'] = 0;
                $picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
                $picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
                $picList[$key]['sSpic'] = $val['sSpic'];
                $picList[$key]['sBpic'] = $val['sBpic'];
                if ($voList) {
                    foreach ($voList as $ke => $va) {
                        if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
                            //echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
                            $picList[$key]['sPid'] = $va['id'];
                            $picList[$key]['sSex'] = $va['sort_id'];
                            $picList[$key]['sPicNo'] = $va['id'];
                        }
                    }
                }
            }
        }

        $Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB)); //放大图片
        $Arr['picNum'] = $count;//主题下载处需要用到
        $this->assign($Arr);
    }

    /*
     * 根据各栏目需求获性别ID
     */
    protected function getSoid() {
        $soid = $this->param['soid'];
        if ($soid)
            $soid = in_array($soid, array(1, 2)) ? $soid : 2;
        else
            $soid = $this->sid ? 2 : $this->soid;
        $this->assign('soid', $soid);
        return $soid;
    }

	public function downloadzip() {
		parent::downloadzip();
	}

}

