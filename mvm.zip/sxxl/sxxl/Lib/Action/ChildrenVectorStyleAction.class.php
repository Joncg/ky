<?php
class ChildrenVectorStyleAction extends VectorStyleAction {

    public function _initialize() {
        $this->soid = 3;
        parent::_initialize();
    }

	public function index() {
        $this->childMenus = $this->getSpecialChildMenu();
        parent::index();
	}

    protected function getSpecialChildMenu() {
        $soid = parent::getSoid();
        $stid = $this->param['stid'];
        $specialChildMenu[4] = array(
            array('id'=>295,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>295)),'selected'=>in_array($stid,array(295))
            ),
			array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66))
            ),
			array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1))
            ),
			array('id'=>152,'name'=>'运动装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152))
            ),
			array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>29)),'selected'=>in_array($stid,array(29))
            ),
			#array('id'=>95,'name'=>'针织衫','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95))),
			array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>150)),'selected'=>in_array($stid,array(150))
            ),
			array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>132)),'selected'=>in_array($stid,array(132))
            ),
			array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>129)),'selected'=>in_array($stid,array(129))
            ),
			array('id'=>178,'name'=>'裙装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>178)),'selected'=>in_array($stid,array(178))
            ),
			array('id'=>310,'name'=>'套装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>310)),'selected'=>in_array($stid,array(310))
            ),
			array('id'=>363,'name'=>'连体装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>363)),'selected'=>in_array($stid,array(363))
            ),
			array('id'=>350,'name'=>'配饰','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>350)),'selected'=>in_array($stid,array(350))
            ),
			array('id'=>524,'name'=>'泳装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>524)),'selected'=>in_array($stid,array(524))
            ),
        );
		$specialChildMenu[5] = array(
            array('id'=>295,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>295)),'selected'=>in_array($stid,array(295))
            ),
			array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66))
            ),
			array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1))
            ),
			array('id'=>152,'name'=>'运动装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152))
            ),
			array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>29)),'selected'=>in_array($stid,array(29))
            ),
			#array('id'=>95,'name'=>'针织衫','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95))),
			array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>150)),'selected'=>in_array($stid,array(150))
            ),
			array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>132)),'selected'=>in_array($stid,array(132))
            ),
			array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>129)),'selected'=>in_array($stid,array(129))
            ),
			array('id'=>310,'name'=>'套装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>310)),'selected'=>in_array($stid,array(310))
            ),
			array('id'=>350,'name'=>'配饰','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>350)),'selected'=>in_array($stid,array(350))
            ),
			array('id'=>524,'name'=>'泳装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>524)),'selected'=>in_array($stid,array(524))
            ),
        );
		$specialChildMenu[6] = array(
            array('id'=>295,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>295)),'selected'=>in_array($stid,array(295))
            ),
			array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66))
            ),
			array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1))
            ),
			array('id'=>152,'name'=>'运动装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152))
            ),
			array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>29)),'selected'=>in_array($stid,array(29))
            ),
			#array('id'=>95,'name'=>'针织衫','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95))),
			array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>150)),'selected'=>in_array($stid,array(150))
            ),
			array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>132)),'selected'=>in_array($stid,array(132))
            ),
			array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>129)),'selected'=>in_array($stid,array(129))
            ),
			array('id'=>178,'name'=>'裙装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>178)),'selected'=>in_array($stid,array(178))
            ),
			array('id'=>310,'name'=>'套装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>310)),'selected'=>in_array($stid,array(310))
            ),
			array('id'=>363,'name'=>'连体装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>363)),'selected'=>in_array($stid,array(363))
            ),
			array('id'=>350,'name'=>'配饰','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>350)),'selected'=>in_array($stid,array(350))
            ),
			array('id'=>524,'name'=>'泳装','url'=>U('/'.MODULE_NAME."/index",array('soid'=>$soid,'stid'=>524)),'selected'=>in_array($stid,array(524))
            ),
        );

        return $specialChildMenu[$soid];
    }

	public function downloadzip() {
        parent::downloadzip();
    }
	
	public function vectorStyleisTryPic(){
		parent::vectorStyleisTryPic();
	}
}