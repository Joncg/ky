<?php

class MenVectorStyleAction extends VectorStyleAction {

	public function _initialize() {
		$this->soid = 1;
		parent::_initialize();
	}

	public function index() {
		$this->childMenus = $this->getSpecialChildMenu();
		parent::index();
	}

	protected function getSpecialChildMenu() {
		$soid = parent::getSoid();
		$stid = $this->param['stid'];
		$specialChildMenu = array(
			array('id' => 309, 'name' => '夹克', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 309)), 'selected' => in_array($stid, array(309))
			),
			array('id' => 275, 'name' => '棉衣', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 275)), 'selected' => in_array($stid, array(275))
			),
			array('id' => 263, 'name' => '皮革', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 263)), 'selected' => in_array($stid, array(263))
			),
			array('id' => 295, 'name' => '马甲', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 295)), 'selected' => in_array($stid, array(295))
			),
			array('id' => 66, 'name' => '衬衫', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 66)), 'selected' => in_array($stid, array(66))
			),
			array('id' => 95, 'name' => '毛衫', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 95)), 'selected' => in_array($stid, array(95))
			),
			array('id' => 128, 'name' => '裤子', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 128)), 'selected' => in_array($stid, array(128))
			),
			array('id' => 1, 'name' => 'T恤', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 1)), 'selected' => in_array($stid, array(1))
			),
			array('id' => 276, 'name' => '卫衣', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 276)), 'selected' => in_array($stid, array(276))
			),
			array('id' => 152, 'name' => '运动', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 152)), 'selected' => in_array($stid, array(152))
			),
			array('id' => 368, 'name' => '户外服', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 368)), 'selected' => in_array($stid, array(368))
			),
			array('id' => 369, 'name' => '尼克服', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 369)), 'selected' => in_array($stid, array(369))
			),
			array('id' => 284, 'name' => '大衣/风衣', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 284)), 'selected' => in_array($stid, array(284))
			),
			array('id' => 300, 'name' => '西装', 'url' => U('/' . MODULE_NAME . "/index", array('soid' => $soid, 'stid' => 300)), 'selected' => in_array($stid, array(300))
			),
		);

		return $specialChildMenu;
	}

	public function downloadzip() {
		parent::downloadzip();
	}
	public function vectorStyleisTryPic(){
		parent::vectorStyleisTryPic();
	}
}