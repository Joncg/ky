<?php

class FavoritesAction extends CommonAction {

	function _initialize() {
		parent::_initialize();
		$this->modelF = D('MemberFavoritesFiled');
		$this->modelL = D('MemberFavorites');
		$pageInfo = parent::getPageInfo($params);
		$this->assign($pageInfo);
	}

	public function index() {
		$this->folder();
	}

	private function folder() {
		import("ORG.Util.Page");
		$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
		import('ORG.Util.Input');
		$Arr['filed_name'] = $filed_name = Input::getVar($_GET['filed_name']);
		if ($filed_name)
			$map['filed_name'] = array('like', "%{$filed_name}%");
		$count = $this->modelF->where($map)->count();
		//创建分页对象
		$p = new Page($count, 8);
		$voList = $this->modelF->where($map)->field('*')->order(array('id' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->findAll();
		if ($voList) {
			foreach ($voList as $key => $val) {
				$voList[$key]['picNum'] = $this->folderCount($val['id']);
				$voList[$key]['add_time'] = $val['add_time'] ? date('Y-m-d', $val['add_time']) : '';
			}
		}
		$Arr['voList'] = $voList;
		$Arr['page'] = $p->showOne();
		$Arr['pageTop'] = $p->showTwo();
		$Arr['currentTagB'] = 'FavoritesIndex';
		$this->assign($Arr);
		Cookie::set('_currentFolderUrl_', __SELF__);
		$this->display('Member/favorites');
	}

	private function folderCount($id) {
		$id = intval($id);
		if (empty($id))
			return false;
		$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
		$map['filed_id'] = $id;
		$count = $this->modelL->where($map)->count();
		return intval($count);
	}

	public function folderInfo() {
		$id = intval($_REQUEST['id']);
		if ($_POST) {
			import('ORG.Util.Input');
			$cinfo = array();
			$cinfo['filed_name'] = Input::getVar($_POST['filed_name']);
			$cinfo['filed_describe'] = Input::getVar($_POST['filed_desc']);
			if ($id) {
				$cinfo['id'] = $id;
				$this->modelF->save($cinfo);
				//echo $this->modelF->getlastsql();exit;
				$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
				$this->assign('waitSecond', 0);
				$this->success('信息保存成功！', false, true);
			} else {
				$cinfo['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
				$cinfo['add_time'] = time();
				$this->modelF->add($cinfo);
				//$this->assign('jumpUrl', 'javascript:self.parent.history.go(-1);');
				$this->assign('jumpUrl', "self.parent.location='/Favorites/index.shtml';");
				$this->assign('waitSecond', 0);
				$this->assign('special_jump', '1');
				$this->success('文件夹添加成功', false, true);
			}
		}
		if ($id) {
			$info = $this->modelF->field('id,filed_name,filed_describe')->find($id);
			$this->assign('info', $info);
		}
		$this->display('Member/folder_info');
	}

	public function folderDel() {
		$id = intval($_REQUEST['id']);
		if ($id) {
			$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
			$row = $this->modelL->where(array_merge($map, array('filed_id' => $id)))->select();
			if ($row) {
				$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
				$this->assign('waitSecond', 0);
				$this->error('请先删除文件夹里的图片!', false, true);
			} else {
				if (intval($_REQUEST['dosubmit'])) {
					$map['id'] = $id;
					$row = $this->modelF->where($map)->delete();
					if ($row) {
						$message = '删除成功!';
						$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
						$this->assign('waitSecond', 0);
						$this->success($message, false, true);
					} else {
						$message = '删除失败,请稍候再试!';
						$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
						$this->assign('waitSecond', 0);
						$this->error($message, false, true);
					}
				} else {
					$this->assign('id', $id);
					$this->display('Member/folder_del');
				}
			}
		} else {
			$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
			$this->assign('waitSecond', 0);
			$this->error('参数有误', false, true);
		}
	}

	public function folderDetail() {
		import("ORG.Util.Page");
		$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
		$fid = intval($_GET['fid']);
		if ($fid) {
			$map['filed_id'] = $fid;
			$Arr['currentTagB'] = 'FavoritesIndex';
		} else {
			$Arr['currentTagB'] = 'FavoritesFolderDetail';
		}
		setcookie("picList", '', -3600, "/");
		$count = $this->modelL->where($map)->count();
		//创建分页对象
		$p = new Page($count, 8);
		$voList = $this->modelL->where($map)->field('*')->order(array('id' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->findAll();
		if ($voList) {
			foreach ($voList as $key => $val) {
				$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);
				$voList[$key]['collect_time'] = $val['collect_time'] ? date('Y-m-d', $val['collect_time']) : '';

				$picList[$key]['sTid'] = 0;
				$picList[$key]['sTid'] = 0;
				$picList[$key]['sPid'] = $val['id'];
				$picList[$key]['sCid'] = 0;
				$picList[$key]['sPidNo'] = $val['id'];
				$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
				$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
				$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
			}
		}
		$this->assign('jsonData', json_encode(array('arrPicList' => $picList, 'cid' => 0, 'isVip' => $this->isRightB)));
		$Arr['voList'] = $voList;
		$Arr['page'] = $p->showOne();
		$Arr['pageTop'] = $p->showTwo();
		$this->assign($Arr);
		$this->assign('backFolder', Cookie::get('_currentFolderUrl_'));
		$info = $this->modelF->field('filed_name')->find($fid);
		$this->assign('info', $info);
		$this->assign('fid', $fid);
		$this->display('Member/folder_detail');
	}

	public function folderDetailAction() {
		$Arr['type'] = $type = trim($_REQUEST['type']);
		$member_id = Cookie::get(C('USER_AUTH_KEY'));
		$dosubmit = intval($_REQUEST['dosubmit']);
		$fid = intval($_REQUEST['fid']);
		$goPage = '';
		if (!$this->isRightB) {
			$Arr['message'] = '对不起，请检查您是否已登陆或是否拥有相应的权限！';
		} else {
			switch ($type) {
				case 'add':
					$pic_small = trim($_REQUEST['pic_small']);
					$pic_big = trim($_REQUEST['pic_big']);
					if ($dosubmit) {
						if (empty($pic_small) || empty($pic_big)) {
							$Arr['message'] = '对不起，你不能收藏。';
						} else {
							$map['filed_id'] = $fid;
							$map['member_id'] = $member_id;
							$count = $this->modelL->where($map)->count();
							if ($count + 1 > 100) {
								$message = '剩余空间不足,请删除部分数据!';
								$this->assign('jumpUrl', 'javascript:self.parent.tb_remove();');
								$this->assign('waitSecond', 0);
								$this->error($message, false, true);
							} else {
								$map['small_picture_url'] = $pic_small;
								$map['big_picture_url'] = $pic_big;
								$row = $this->modelL->where($map)->find();
								if ($row) {
									$message = '此文件已经收藏过了!';
									$this->assign('jumpUrl', 'javascript:self.parent.tb_remove();');
									$this->error($message, false, true);
								} else {
									$map['collect_time'] = time();
									$row = $this->modelL->add($map);
									if ($row) {
										$message = '收藏成功!';
										$this->assign('jumpUrl', 'javascript:self.parent.tb_remove();');
										$this->success($message, false, true);
									} else {
										$message = '收藏成功,请稍候再试!';
										$this->assign('jumpUrl', 'javascript:self.parent.tb_remove();');
										$this->error($message, false, true);
									}
								}
							}
						}
					} else {
						$this->assign('pic_small', $pic_small);
						$this->assign('pic_big', $pic_big);
						$page = intval($_REQUEST['p']);
						$page = $page ? $page : 1;
						import("ORG.Util.Page");
						$map['member_id'] = $member_id;
						$count = $this->modelF->where($map)->count();
						if ($count == 0) {
							$cinfo = array();
							$cinfo['filed_name'] = '我的文件夹';
							$cinfo['filed_desc'] = '系统创建';
							$cinfo['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
							$cinfo['add_time'] = time();
							$this->modelF->add($cinfo);
						}
						$p = new Page($count, 8);
						$Arr['count'] = $count;
						$Arr['arrFile'] = $this->modelF->where($map)->field('id,filed_name')->order(array('id' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->select();
						$Arr['pageStr'] = $p->showUpDown();
					}
					break;
				case 'move':
					$ids = $this->getPicIds();
					if ($ids) {
						$map['member_id'] = $member_id;
						if ($dosubmit) {
							$count = $this->modelL->where(array_merge($map, array('filed_id' => $fid)))->count();
							if ($count + count($ids) > 100) {
								$message = '剩余空间不足,请删除部分数据!';
								$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
								$this->assign('waitSecond', 0);
								$this->error($message, false, true);
							} else {
								//取出目标文件夹中的图片
								$targetMap['filed_id'] = $fid;
								$targetMap['member_id'] = $member_id;
								$targetRes = $this->modelL->where($targetMap)->field('small_picture_url')->select();
								$targetArr = $this->getNewArr($targetRes);
								//循环对比 插入目标文件中（有重复的记录下来）
								//$map['id'] = array('in', $ids);
								$nowIds = explode(',', $ids);
								$i = $j = '';
								foreach ($nowIds as $k => $v) {
									$nowSmallMap['id'] = $v;
									$nowSmallPic = $this->modelL->where($nowSmallMap)->field('small_picture_url')->find();
									if (in_array($nowSmallPic['small_picture_url'], $targetArr)) {
										//$i .= $v.",";
									} else {
										$updataMap['id'] = $v;
										$updataMap['member_id'] = $member_id;
										$this->modelL->where($updataMap)->save(array('filed_id' => $fid)) ? ++$i : ++$j;
									}
								}
								if ($i > 0) {
									$message = '转存成功!';
									$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
									$this->assign('waitSecond', 0);
									$this->success($message, false, true);
								} else {
									if ($i == 0 && $j !== 0) {
										$message = '该图片在此文件夹内已存在!';
										$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
										$this->assign('waitSecond', 0);
										$this->error($message, false, true);
									} else {
										$message = '转存失败,请稍候再试!';
										$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
										$this->assign('waitSecond', 0);
										$this->error($message, false, true);
									}
								}
							}
						} else {
							$page = intval($_REQUEST['p']);
							$page = $page ? $page : 1;
							import("ORG.Util.Page");
							$count = $this->modelF->where($map)->field('id,filed_name')->order(array('id' => 'desc'))->count();
							$p = new Page($count, 8);
							$Arr['count'] = $count;
							$Arr['arrFile'] = $this->modelF->where($map)->field('id,filed_name')->order(array('id' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->select();
							$Arr['pageStr'] = $p->showUpDown();
						}
					} else {
						$message = '未选取文件,不能进行操作!';
						$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
						$this->assign('waitSecond', 0);
						$this->error($message, false, true);
					}
					break;
				case 'del':
					$ids = $this->getPicIds();
					if ($ids) {
						$map['member_id'] = $member_id;
						if ($dosubmit) {
							if ($fid)
								$map['filed_id'] = $fid;
							$map['id'] = array('in', $ids);
							$row = $this->modelL->where($map)->delete();
							if ($row) {
								$message = '删除成功!';
								$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
								$this->assign('waitSecond', 0);
								$this->success($message, false, true);
							} else {
								$message = '删除失败,请稍候再试!';
								$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
								$this->assign('waitSecond', 0);
								$this->error($message, false, true);
							}
						}
					} else {
						$message = '未选取文件,不能进行操作!';
						$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
						$this->assign('waitSecond', 0);
						$this->error($message, false, true);
					}
					break;
				case 'down':
					$ids = $this->getPicIds();
					if (!$this->checkIsTry) {
						$message = '试用账号无下载权限!';
						$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
						$this->assign('waitSecond', 0);
						$this->error($message, false, true);
					} else {
						if ($ids) {
							$map['member_id'] = $member_id;
							$system_time = time();
							$pc_name = Cookie::get('pc_name');
							$zip_id = $map['member_id'] . $pc_name . rand(100, 999) . $system_time;
							if ($fid) {
								$map['filed_id'] = $fid;
							}
							$map['id'] = array('in', $ids);
							$picArr = $this->modelL->field('filed_id,big_picture_url as pic_big')->where($map)->select();
							if ($picArr) {
								$modelDL = D('MemberFavoritesDownList');
								foreach ($picArr as $v) {
									$v['zip_id'] = $zip_id;
									$v['add_time'] = $system_time;
									$modelDL->add($v);
								}
								$modelDT = D('MemberFavoritesDownTeam');
								$tarr['member_id'] = $map['member_id'];
								$tarr['pc_name'] = $pc_name;
								$tarr['system_time'] = $system_time;
								$tarr['update_time'] = $system_time;
								$tarr['zip_id'] = $zip_id;
								$ins_id = $modelDT->add($tarr);
								if ($ins_id) {
									$row = $modelDT->where(array('id' => array('lt', $ins_id)))->count();
									$this->assign("posation", $row);
								}
								$code = "ins_id={$ins_id}&file_id={$file_id}&get_num=100";
								$d = urlencode(authcode($code, 'ENCODE'));
								$Arr['dUrl'] = "createFavoritesZip?d={$d}&jsoncallback=?";
								$Arr['picNum'] = sizeof(explode(',', $ids));
							}
							$goPage = 'TideSection/download';
						} else {
							$message = '未选取文件,不能进行操作!';
							$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
							$this->assign('waitSecond', 0);
							$this->error($message, false, true);
						}
					}
					break;
			}
		}
		if ($Arr['message'])
			$Arr['ref'] = $Arr['ref'] ? $Arr['ref'] : 'close';
		if (empty($goPage))
			$goPage = 'Member/folder_detail_action';
		$this->assign($Arr);
		$this->display($goPage);
	}

	private function getPicIds() {
		$fid = intval($_REQUEST['fid']);
		$this->assign('fid', $fid);
		$ids = trim($_COOKIE['picList']);
		//$ids = intval($_REQUEST['pid']);
		//$ids = '1,2';
		$idArr = explode(',', $ids);
		$tmpid = array();
		foreach ($idArr as $val) {
			$val = intval($val);
			if ($val) {
				$tmpid[] = $val;
			}
		}
		$ids = implode(',', $tmpid);
		return($ids ? $ids : false);
	}

	protected function getNewArr($arr) {
		if (empty($arr)) {
			return FALSE;
		}
		$newArr = array();
		foreach ($arr as $key => $val) {
			$newArr[$key] = $val['small_picture_url'];
		}
		return $newArr;
	}

}

?>
