<?php
class PantsPatternsAction extends PatternsAction {

    public function _initialize() {
        $this->sid = 2;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

 	public function folderList(){
        parent::folderList();
	}

	public function folderDetail() {
        parent::folderDetail();
	}

	public function themeList() {
        parent::themeList();
	}

	public function themeDetail($tid = '') {
        parent::themeDetail($tid);
	}

    public function pictureList(){
         parent::pictureList();
    }
	
	public function downloadzip() {
		parent::downloadzip();
	}
}