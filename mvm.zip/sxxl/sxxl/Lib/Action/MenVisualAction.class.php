<?php
class MenVisualAction extends VisualAction {

    public function _initialize() {
        $this->soid = 1;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

	public function themeDetail($tid = '') {
        $this->pListRows = 20;
        parent::themeDetail($tid);
	}
	
	public function downloadzip() {
		parent::downloadzip();
	}
}