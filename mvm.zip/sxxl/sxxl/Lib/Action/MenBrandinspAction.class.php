<?php

class MenBrandinspAction extends BrandinspAction {

	public function _initialize() {
		$this->soid = 1;
		parent::_initialize();
	}

	public function index() {
		parent::index();
	}

	public function themeDetail($tid = '') {
		parent::themeDetail($tid);
	}

	protected function getSpecialChildMenu() {
		$specialChildMenu = array(
			array('id' => 14, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 14)), 'picture' => '/Public/Images/fishion/m-brand/7-For-All-Mankind.jpg', 'name' => '7 For All Mankind'),
			array('id' => 17, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 17)), 'picture' => '/Public/Images/fishion/m-brand/Abercrombie-Fitch.jpg', 'name' => 'Abercrombie Fitch'),
			array('id' => 29, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 29)), 'picture' => '/Public/Images/fishion/m-brand/Alexander-McQueen.jpg', 'name' => 'Alexander McQueen'),
			array('id' => 11169, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 11169)), 'picture' => '/Public/Images/fishion/m-brand/Armani-Collezioni.jpg', 'name' => 'Armani Collezioni'),
			array('id' => 793, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 793)), 'picture' => '/Public/Images/fishion/m-brand/Armani-Exchange.jpg', 'name' => 'Armani Exchange'),
			array('id' => 4518, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 4518)), 'picture' => '/Public/Images/fishion/m-brand/BALLY.jpg', 'name' => 'BALLY'),
			array('id' => 1729, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 1729)), 'picture' => '/Public/Images/fishion/m-brand/Daks.jpg', 'name' => 'Daks'),
			array('id' => 195, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 195)), 'picture' => '/Public/Images/fishion/m-brand/Diesel.jpg', 'name' => 'Diesel'),
			array('id' => 229, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 229)), 'picture' => '/Public/Images/fishion/m-brand/Ermenegildo-Zegna.jpg', 'name' => 'Ermenegildo Zegna'),
			array('id' => 1029, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 1029)), 'picture' => '/Public/Images/fishion/m-brand/FENDI.jpg', 'name' => 'FENDI'),
			array('id' => 1253, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 1253)), 'picture' => '/Public/Images/fishion/m-brand/marc-jacobs.jpg', 'name' => 'marc jacobs'),
			array('id' => 443, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 443)), 'picture' => '/Public/Images/fishion/m-brand/Massimo-Dutti.jpg', 'name' => 'Massimo Dutti'),
			array('id' => 2007, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 2007)), 'picture' => '/Public/Images/fishion/m-brand/TNGT.jpg', 'name' => 'TNGT'),
			array('id' => 2010, 'url' => U("/" . MODULE_NAME . "/index", array('bid' => 2010)), 'picture' => '/Public/Images/fishion/m-brand/TOMMY-HILFIGER.jpg', 'name' => 'TOMMY HILFIGER'),
		);
		return $specialChildMenu;
	}

	public function downloadzip() {
		parent::downloadzip();
	}

}

