<?php
class PantsInvogueAction extends InvogueAction {

    public function _initialize() {
        $this->sid = 2;
        parent::_initialize();
    }

    public function index() {
        $this->themeList();
	}

    public function themeList(){
        if($this->param['bid'] || $this->param['brandStr'] || $this->param['seid'] || $this->param['ano']){
            $Arr['cmid'] = $this->cmid = 0;
            $Arr['aid'] = $aid = '';
        }else{
            $aid = $this->param['aid'];
            $Arr['aid'] = $aid = in_array($aid, array('gw', 'gl', 'hg')) ? $aid : (!$this->cmid ? 'gw' : '');
        }

        $Arr['specialChildMenus'] = $this->getSpecialChildMenu();

		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,area_no,season_id,pv_count,picture_count";
        $order = array('publish_time' => 'desc', $this->tableArr['subject_original'] . '.id' => 'desc');
		$this->relationArr = false;
        $this->tListRows = 12;
        //parent::themeDataList($field, $map, $order);
        parent::themeDataListBySphinx($field, $map, $order);
        $this->assign($Arr);
		$this->display('theme_list');
    }

	public function themeDetail($tid = '') {
        $this->pListRows = 20;
        parent::themeDetail($tid);
	}

    public function pictureList(){
        $specialChildMenus = $this->getSpecialChildMenu();
        $this->assign('specialChildMenus',$specialChildMenus);

        $this->pListRows = 20;
		$field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,publish_time,brand_id,area_no,season_id";
        $order = array('publish_time'=>'desc',$this->tableArr['picture_original'].'.id'=>'desc');
		//parent::pictureDataList($field, $map, $order);
        parent::pictureDataListBySphinx($field, $map, $order);
		$this->display('picture_list');
    }

    protected function getSpecialChildMenu() {
        $soid = parent::getSoid();
        $soidTmp = $soid > 2 ? 3 : $soid;
        $specialChildMenu['2'] = array(
            array('id'=>'128','name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'thirdMenu'=>
                array(
                    array('id'=>148,'name'=>'休闲裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>148))),
                    array('id'=>141,'name'=>'时装裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>141))),
                    #array('id'=>134,'name'=>'妇女裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>134))),
                    array('id'=>137,'name'=>'连体裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>137))),
                    array('id'=>139,'name'=>'热裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>139))),
					array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150))),
                    array('id'=>138,'name'=>'七分裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>138))),
                    array('id'=>151,'name'=>'中裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>151))),
                    array('id'=>146,'name'=>'细节','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>146))),
                )
            )
        );

        $specialChildMenu['1'] = array(
            array('id'=>'128','name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'thirdMenu'=>
                array(
                    array('id'=>148,'name'=>'休闲裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>148))),
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150))),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132))),
					array('id'=>144,'name'=>'西裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>144))),
                    array('id'=>146,'name'=>'细节','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>146))),
					#array('id'=>149,'name'=>'休闲长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>149))),
                    array('id'=>147,'name'=>'休闲短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>147))),
                )
            )
        );

        $specialChildMenu['3'] = array(
            array('id'=>'128','name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'thirdMenu'=>
                array(
                    array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>129))),
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150))),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132))),
                )
            )
        );

        return $specialChildMenu[$soidTmp];
    }

	public function downloadzip() {
		parent::downloadzip();
	}
}
