<?php

class MenCatwalkAction extends CatwalkAction {

    public function _initialize() {
        $this->soid = 1;
        parent::_initialize();
    }

    public function index() {
        $this->assign('style_menu_list',$this->getSpecialChildMenu());
        parent::index();
    }

    public function folderList() {
        $this->assign('style_menu_list',$this->getSpecialChildMenu());
        parent::folderList();
    }

    public function folderDetail() {
        parent::folderDetail();
    }

    /*
     * 秀场提练专用
     */

    public function themeList() {
        $this->assign('style_menu_list',$this->getSpecialChildMenu());
        $styleList = $this->getCatwalkStyleList();
        $this->assign('styleList',$styleList);
        parent::themeList();
    }

 	public function themeDetail($fid = '',$tid = '') {
        parent::themeDetail($fid,$tid);
	}

    public function pictureList(){
        $this->assign('style_menu_list',$this->getSpecialChildMenu());
        parent::pictureList();
    }

    protected function getSpecialChildMenu() {
        $soid = parent::getSoid();
        $stid = $this->param['stid'];
        $specialChildMenu = array(
            array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1,4,28,10)),
                'thirdMenu'=>
                array(
                    array('id'=>4,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>4)),'selected'=>$stid == 4),
                    array('id'=>28,'name'=>'长袖T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>28)),'selected'=>$stid == 28),
                    array('id'=>10,'name'=>'短袖T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>10)),'selected'=>$stid == 10),
                )
            ),
            array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>29)),'selected'=>in_array($stid,array(29)),
                'thirdMenu'=>
                array(
                 )
            ),
            array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66,93,71)),
                'thirdMenu'=>
                array(
                    array('id'=>93,'name'=>'长袖衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>93)),'selected'=>$stid == 93),
                    array('id'=>71,'name'=>'短袖衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>71)),'selected'=>$stid == 71),
                )
            ),
            array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95,96,120,105)),
                'thirdMenu'=>
                array(
                    array('id'=>96,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>96)),'selected'=>$stid == 96),
                    array('id'=>120,'name'=>'套衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>120)),'selected'=>$stid == 120),
                    array('id'=>105,'name'=>'开衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>105)),'selected'=>$stid == 105),
                )
            ),
			array('id'=>295,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>295)),'selected'=>in_array($stid,array(295)),
                'thirdMenu'=>
                array(
                )
            ),
			array('id'=>276,'name'=>'卫衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>276)),'selected'=>in_array($stid,array(276)),
                'thirdMenu'=>
                array(
                )
            ),
			array('id'=>288,'name'=>'风衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>288)),'selected'=>in_array($stid,array(288)),
                'thirdMenu'=>
                array(
                )
            ),
			array('id'=>285,'name'=>'大衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>285)),'selected'=>in_array($stid,array(285)),
                'thirdMenu'=>
                array(
                )
            ),
			array('id'=>264,'name'=>'棉衣\羽绒服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>264)),'selected'=>in_array($stid,array(264)),
                'thirdMenu'=>
                array(
                )
            ),
            array('id'=>242,'name'=>'皮草','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>242)),'selected'=>in_array($stid,array(242,249,244,246)),
                'thirdMenu'=>
                array(
                    array('id'=>249,'name'=>'全皮','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>249)),'selected'=>$stid == 249),
                    array('id'=>244,'name'=>'皮草','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>244)),'selected'=>$stid == 244),
                    array('id'=>246,'name'=>'皮毛一体','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>246)),'selected'=>$stid == 246),
                )
            ),
			array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'selected'=>in_array($stid,array(128,132,150,137,129,144)),
                'thirdMenu'=>
                array(
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132)),'selected'=>$stid == 132),
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150)),'selected'=>$stid == 150),
                    array('id'=>137,'name'=>'连体裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>137)),'selected'=>$stid == 137),
					array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>129)),'selected'=>$stid == 129),
					array('id'=>144,'name'=>'西裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>144)),'selected'=>$stid == 144),
                )
            ),
			array('id'=>152,'name'=>'运动装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152)),
                'thirdMenu'=>
                array(
                )
            ),
			array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'selected'=>in_array($stid,array(211,227,224,219)),
                'thirdMenu'=>
                array(
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227)),'selected'=>$stid == 227),
                    array('id'=>219,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>219)),'selected'=>$stid == 219),
                )
            ),
			array('id'=>300,'name'=>'西装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>300)),'selected'=>in_array($stid,array(300,301,302)),
                'thirdMenu'=>
                array(
                    array('id'=>301,'name'=>'套西','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>301)),'selected'=>$stid == 301),
                    array('id'=>302,'name'=>'单西','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>302)),'selected'=>$stid == 302),
                )
            ),
        );

        return $specialChildMenu;
    }

    //时装发布 - 秀场提练专用
    protected function getCatwalkStyleList() {
        $soid = parent::getSoid();
        $stid = $this->param['stid'];
        $seid = (int)$this->param['seid'];
        $ano = (int)$this->param['ano'];
        $styleList =array(
            array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>1)),'selected'=>$stid == 1),
            array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>29)),'selected'=>$stid == 29),
			array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>66)),'selected'=>$stid == 66),
            array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>95)),'selected'=>$stid == 95),
            array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>211)),'selected'=>$stid == 211),
			array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>128)),'selected'=>$stid == 128),
            array('id'=>242,'name'=>'皮草','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>242)),'selected'=>$stid == 242),
            array('id'=>284,'name'=>'风衣/大衣','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>284)),'selected'=>$stid == 284),
			array('id'=>310,'name'=>'套装','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>310)),'selected'=>$stid == 310),
            array('id'=>264,'name'=>'棉衣/羽绒','url'=>U('/'.MODULE_NAME."/themeList",array('soid'=>$soid,'seid'=>$seid,'ano'=>$ano,'stid'=>264)),'selected'=>$stid == 264),
        );
        return $styleList;
    }

	public function downloadzip() {
		parent::downloadzip();
	}
}
