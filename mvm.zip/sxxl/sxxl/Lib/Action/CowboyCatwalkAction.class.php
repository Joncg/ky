<?php
class CowboyCatwalkAction extends CatwalkAction {

    public function _initialize() {
        $this->sid = 1;
        parent::_initialize();
    }

	public function index() {
        $this->folderList();
	}

	public function folderList(){
        parent::folderList();
	}

	public function folderDetail() {
        parent::folderDetail();
	}

    /*
     * 秀场提练专用
     */
    public function themeList(){
        parent::themeList();

    }

 	public function themeDetail($fid = '',$tid = '') {
        parent::themeDetail($fid,$tid);
	}

    public function pictureList(){
        parent::pictureList();
    }
	public function downloadzip() {
		parent::downloadzip();
	}
}
