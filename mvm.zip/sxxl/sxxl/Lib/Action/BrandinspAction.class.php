<?php

class BrandinspAction extends TideSectionAction {

    public function _initialize() {
        $this->cid = 20;

	   if( MODULE_NAME == 'UnderwearBrandinsp' )
		   $this->cid = 100; //品牌画册 menu_id=100

        $this->cache = Cache::getInstance();
        parent::_initialize();
    }

    protected function index() {
        $this->childMenus = $this->getSpecialChildMenu();

		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,brand_id,season_id,area_no,pv_count";
		$order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->tListRows = 8;
		$this->themeDataList($field, $map, $order);
		$this->display('Brandinsp/index');
    }
    /**
     * 主题列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeDataList($field, $map, $order = array('publish_time'=>'desc','id'=>'desc')) {
        //时间筛选项
        $this->setDateSift();

       $cid = $this->cid;

        if ($cid)
            $map[$this->tableArr['subject_original'] . '.menu_id'] = $cid;
        if ($this->cmid)
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;

        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
			/*关联查询需要耗费600毫秒，故换成子查询模式：180毫秒
			if( $soid == 3 )
				$sql_sub_ext = ' sort_id >= 3 ';
			else
				$sql_sub_ext = ' sort_id = '.$soid;
			if( $cid )
				$sql_sub_ext .= " and menu_id={$cid} ";
			$sql_sub = " select subject_id from {$this->tableArr['ref_subject_sort_original']} where {$sql_sub_ext} ";
			$map['id'] = array('exp'," in( {$sql_sub} ) ");
            */
        }

        if ($this->sid == 1 || $this->sid == 4) {
            $map['fse.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_subject_column_original']} as fse on fse.subject_id = {$this->tableArr['subject_original']}.id";
        }

        $map['is_publish'] = 1;

        $date = $this->param['date'];
        if ($date) {
            if (!in_array($date, array(7, 30, 90))) {
                $date = 90;
                $this->assign('date', $date);
            }
            $dateTmp = strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - $date * 86400;
            $map['publish_time'] = array(array('egt', $dateTmp),array('elt',C('TODAY_LAST_TIME')));

            //以人气排序
            $order = array_merge(array('pv_count'=>'desc'),$order);
            unset($dateTmp);
        }else{
            $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        }

        $seid = $this->param['seid'];
        if ($seid)
            $map['season_id'] = $seid;

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }

            $this->assign('areaStr',$this->areas[$ano]['name']);
        }

        $bid = $this->param['bid'];
        $brandStr = $this->param['brandStr'];
        if (!$bid && $brandStr != '') {
            $bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
            $bid = intval($bid);
            if($bid){
                $map['brand_id'] = $bid;
                $this->assign('bid',$bid);
            }
        } elseif ($bid) {
            $map['brand_id'] = $bid;
            $brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
            $this->assign('brandStr', $brandStr);
        }

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Brandinsp::themeDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            //$count = $this->modelT->join($join)->where($map)->count();
            //$count = $this->modelT->where($map)->count();

            //echo $this->modelT->getlastsql();
            import("ORG.Util.DataCount");
            $count = DataCount::getCount($this->tableArr['subject'],$map,$join);
            if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->tListRows);
                $voList = $this->modelT->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelT->getLastSql();
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        if ($val['season_id'])
                            $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        if ($val['area_no'])
                            $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                        if ($val['brand_id'])
                            $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];

                        $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'soid'=>$soid,'tid' => $val['id']));
                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                        $voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                 }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    protected function themeInfo($tid) {
        $tid = intval($tid);

        if (!$tid)
            $this->error('参数错误！');

        $cid = $this->cid;
        if($cid)
            $map[$this->tableArr['subject_original'].'.menu_id'] = $cid;

        $map[$this->tableArr['subject_original'].'.id'] = $tid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        if ($this->soid) {
            $map['fs.sort_id'] = $this->soid == 3 ? array('egt',3) : $this->soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }

        if ($this->sid == 1 || $this->sid == 4) {
            $map['fse.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_subject_column_original']} as fse on fse.subject_id = {$this->tableArr['subject_original']}.id";
        }

        $field = $this->tableArr['subject_original'].'.id,title,publish_time,season_id,area_no,show_edit,brand_id';
		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Brandinsp::themeInfo::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $info = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if (!$info) {
            $info = $this->modelT->join($join)->relation($this->relationArr)->field($field)->where($map)->find();
            //echo $this->modelT->getLastSql()."</br>";exit;
            if(!$info){
                $this->error('参数错误！');
            }
            $info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
            $soid = intval($_GET['soid']);
            $soid = $soid ? $soid : $this->soid;
            if(!$soid)
                $soid = M($this->tableArr['ref_subject_sort'])->getField("sort_id","subject_id='{$tid}'");

            $info['sortStr'] = $this->sorts[$soid]['title'];
            $info['areaStr'] = $this->areas[$info['area_no']]['name'];
            $info['seasonStr'] = $this->seasons[$info['season_id']]['en_name'];
            $info['brandStr'] = $this->brands[$info['brand_id']]['name']; //品牌灵感需用到
            $info['brandUrl'] = U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'bid'=>$info['brand_id']));
            $info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']): '';
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $info,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $info);
        }
        //权限验证
        parent::withoutPermission('',$info);

        return $info;
    }

    /**
     * get theme picture list
     * @param $tid intval
     * @return array
     */
    protected function themePicture($tid) {
        $tid = intval($tid);
        $this->assign('tid', $tid);

        if (!$tid)
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url,page_no';
        $order = array('page_no' => 'asc');

        $cid = $this->cid;
        if ($cid)
            $map['menu_id'] = $cid;
        //if($this->cmid) $map['child_menu_id'] = $this->cmid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $tid;

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Brandinsp::themePicture::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
           $count = $this->modelP->where($map)->count();
           //echo $this->modelP->getLastSql();
           if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->pListRows);
                $voList = $this->modelP->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelP->getLastSql()."</br>";
                if ($voList) {
                    $picList = array();
                    foreach ($voList as $key => $val) {
                        $voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
                        $voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);

                        $picList[$key]['sTid'] = 0;
                        $picList[$key]['sPid'] = $val['id'];
                        $picList[$key]['sCid'] = $cid;
                        $picList[$key]['sPidNo'] = $val['id'];
                        $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                        $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                        $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                    }
                }
                $showOne = $p->showOne();
                //var_dump($picList);
                $Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
                //模板赋值显示
                $Arr['listArr'] = $voList;
                //分页显示
                $Arr['pageStr'] = $showOne;
                //主题下载处需要用到
                $Arr['picNum'] = $count;
           }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    protected function themeDetail($tid = '') {
        $this->assign('jumpUrl', 'javascript:window.close();');
        $this->relationArr = array('SubjectExtend');
        $tid = intval($tid);

        $tid = $tid ? $tid : intval($_GET['tid']);
        $themeInfo = $this->themeInfo($tid);
        //dump($themeInfo);
        if ($themeInfo['show_edit'] == 1){
            $this->getShowContent($themeInfo);
        }else{
            $this->themePicture($tid);
        }
        $this->updateThemePvCount($tid);
		$this->assign('nume',MODULE_NAME);
        $this->assign('info', $themeInfo);
        $this->display('Brandinsp/theme_detail');
    }

    protected function setCmid() {
        $this->cmid = intval($_GET['cmid']);
        $this->assign('cmid', $this->cmid);
    }

    protected function setCidSift() {
        $sMap['menu_id'] = $this->cid;
        $this->cmid ? $sMap['child_menu_id'] = $this->cmid : '';
        $soid = $this->getSoid();
        if($soid){
            $sMap['sort_id'] = $soid == 3 ? array('egt',3) : $soid;
        }

        //$this->sid ? $sMap['special_column_id'] = $this->sid : '';
        $fieldArr = array('season_id_list','area_no_list','brand_id_list');
        $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
        $this->areas = $siftArr['area_no_list'];
        $this->seasons = $siftArr['season_id_list'];
        $Arr['brands'] = $this->brands = $siftArr['brand_id_list'];
        if ($this->seasons) {
            $seasonsTmp = $this->seasons;
            uasort($seasonsTmp, "cmp");
            $Arr['seasons'] = $seasonsTmp;
            unset($seasonsTmp);
        }
        if ($this->areas) {
            $Arr['areaHtml'] = $this->getAreaOption($this->param['ano']);
            $Arr['areas'] = format_tree_area($this->areas);
        }

        $Arr['letters'] = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
        $this->assign($Arr);
    }

    //设置时间筛选列表
    protected function setDateSift() {
        //近似值，无需精确(全部的ID＝1只起标识作用)
        $dateArr = array(
            array('id' => 7, 'title' => '1周内'),
            array('id' => 30, 'title' => '1月内'),
            array('id' => 90, 'title' => '3月内'),
        );
        $this->assign('dateArr', $dateArr);
    }

    protected function setParam() {
        $this->param = array('cmid' => intval($this->cmid));

        //品牌画册下只有专栏中才允许传入性别参数
        $soid = $this->sid ? intval($_REQUEST['soid']) : $this->soid;
        if ($soid)
            $this->param = array_merge($this->param, array('soid' => $soid));

        $seid = intval($_REQUEST['seid']);
        if ($seid)
            $this->param = array_merge($this->param, array('seid' => $seid));

        $ano = intval($_REQUEST['ano']);
        if ($ano)
            $this->param = array_merge($this->param, array('ano' => $ano));

        $bid = intval($_REQUEST['bid']);
        if ($bid)
            $this->param = array_merge($this->param, array('bid' => $bid));

        $date = intval($_REQUEST['date']);
        if ($date)
            $this->param = array_merge($this->param, array('date' => $date));

        $brandStr = trim($_REQUEST['brandStr']);
        if ($brandStr)
            $this->param = array_merge($this->param, array('brandStr' => $brandStr));

        $act = trim($_REQUEST['act']);
        if ($act)
            $this->param = array_merge($this->param, array('act' => $act));

        $fid = intval($_REQUEST['fid']);
        if ($fid)
            $this->param = array_merge($this->param, array('fid' => $fid));

        $tid = intval($_REQUEST['tid']);
        if ($tid)
            $this->param = array_merge($this->param, array('tid' => $tid));
    }

    protected function getShowContent($themeInfo) {
        if (!$themeInfo['id'])
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url';

        $cid = $this->cid;
        if ($cid)
            $map['menu_id'] = $cid;

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $themeInfo['id'];

        $cache_key = md5('Brandinsp::getShowContent::'.$this->isRightS."::".$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $voList = $this->modelP->where($map)->field($field)->order(array('publish_time' => 'desc','id'=>'desc'))->findAll();
            $picList = array();
            $parse_arr = parse_content(stripslashes($themeInfo['content']));
            $detailhtml = $parse_arr['result'];
            if ($parse_arr['pic_arr']) {
                //$i = 0;
                foreach ($parse_arr['pic_arr'] as $key => $val) {
                    $picList[$key]['sTid'] = $themeInfo['id'];
                    $picList[$key]['sPid'] = 0;
                    $picList[$key]['sSex'] = $themeInfo['sort_id'];
                    $picList[$key]['sCid'] = $this->cid;
                    $picList[$key]['sPicNo'] = 0;
                    $picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
                    $picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
                    $picList[$key]['sSpic'] = $val['sSpic'];
                    $picList[$key]['sBpic'] = $val['sBpic'];
                    if ($voList) {
                        foreach ($voList as $ke => $va) {
                            if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
                                //echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
                                $picList[$key]['sPid'] = $va['id'];
                                $picList[$key]['sSex'] = $va['sort_id'];
                                $picList[$key]['sPicNo'] = $va['id'];
                            }
                        }
                    }
                }
            }
            $Arr['detailhtml'] = $detailhtml;
            $Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)); //放大图片
            $Arr['picNum'] = $count;//主题下载处需要用到
            $this->cache->set($cache_key, $Arr);
        }
        $this->assign($Arr);
    }

    /*
     * 根据各栏目需求获性别ID
     */
    protected function getSoid() {
        $soid = $this->param['soid'];
        if ($soid)
            $soid = in_array($soid, array(1, 2, 3, 4, 5, 6)) ? $soid : 2;
        else
            $soid = $this->sid ? 2 : $this->soid;
        $this->assign('soid', $soid);
        return $soid;
    }
}
