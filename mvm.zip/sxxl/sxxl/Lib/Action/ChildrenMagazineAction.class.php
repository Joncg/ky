<?php

class ChildrenMagazineAction extends MagazineAction {

	public function _initialize() {
		$this->soid = 3;
		parent::_initialize();
	}

	public function index() {
		parent::index();
	}

	public function themeDetail($tid = '') {
		parent::themeDetail($tid);
	}

	public function downloadzip() {
		parent::downloadzip();
	}

}