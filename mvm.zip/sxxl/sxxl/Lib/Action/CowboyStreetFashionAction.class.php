<?php
class CowboyStreetFashionAction extends StreetFashionAction {

    public function _initialize() {
        $this->sid = 1;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

    public function pictureList() {
        $field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,publish_time,area_no,season_id";
        $this->pListRows = 20;
		$order = array('publish_time'=>'desc',$this->tableArr['picture_original'].'.id'=>'desc');
        $this->pictureDataList($field, $map, $order);
        $this->display('picture_list');
    }

	public function themeDetail($tid = '') {
        $this->pListRows = 20;
        parent::themeDetail($tid);
	}


    /**
     * 图片列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function pictureDataList($field, $map, $order) {
        $map[$this->tableArr['picture_original'] . '.menu_id'] = $this->cid;
        if ($this->cmid)
            $map[$this->tableArr['picture_original'] . '.child_menu_id'] = $this->cmid;

        $soid = $this->getSoid();
        if ($soid ){
            $map['fs.sort_id'] = $soid == 3 ? array('egt', $soid) : $soid;
            $join[] = "{$this->tableArr['ref_picture_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_original']}.id";
		}

        //款式
       $stid = $this->param['stid'];
       if (!$stid && $this->sid && $this->sid != 2 && $this->sid != 5) {
            $map['fsc.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_picture_column_original']} as fsc on fsc.picture_id = {$this->tableArr['picture_original']}.id";
        }

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        if ($stid) {
            $join[] = "{$this->tableArr['ref_picture_style_original']} ps ON ps.picture_id={$this->tableArr['picture_original']}.id";
            $map['ps.style_id'] = $stid;
        }elseif($this->cid == 12){
            $join[] = "{$this->tableArr['ref_picture_style_original']} ps ON ps.picture_id={$this->tableArr['picture_original']}.id";
            $map['ps.style_id'] = $stid = 1;
		}

        //取得满足条件的记录数
        //$count = $this->modelP->join($join)->where($map)->count();
        //echo $this->modelP->getlastsql();
        import("ORG.Util.DataCount");
        $count = DataCount::getCount($this->tableArr['picture'],$map,$join);
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $this->pListRows);
            //分页查询数据
            $voList = $this->modelP->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $this->modelP->getlastsql();
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);//show_pic_power($val['small_picture_url'], $this->isRightS);
                    $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                    if ($val['season_id'])
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                    if ($val['area_no'])
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($stid) {
                        $voList[$key]['styleStr'] = M('AttributeStyle')->getField('name', array('id' => $stid));
                        $voList[$key]['styleUrl'] = U('/' . MODULE_NAME . '/pictureList', array('soid'=>$soid,'stid' => $stid));
                    } else {
                        $stidTmp = M($this->tableArr['ref_picture_style'])->getField('style_id', array('picture_id' => $val['id']));
                        $voList[$key]['styleStr'] = M('AttributeStyle')->getField('name', array('id' => $stidTmp));
                        $voList[$key]['styleUrl'] = U('/' . MODULE_NAME . '/pictureList', array('soid'=>$soid,'stid' => $stidTmp));
                    }

                    $picList[$key]['sTid'] = 0;
                    $picList[$key]['sPid'] = $val['id'];
                    $picList[$key]['sCid'] = $this->cid;
                    $picList[$key]['sPidNo'] = $val['id'];
                    $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                    $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                    $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                }
            }
            //dump($this->brands);
            $this->assign('jsonData', json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)));
            //模板赋值显示
            $this->assign('listArr', $voList);
            //分页显示
            $page = $p->showOne();
            $this->assign("pageStr", $page);
        }
    }
	public function downloadzip() {
		parent::downloadzip();
	}
}
