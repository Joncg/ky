<?php
class BookAction extends TideSectionAction {

    public function _initialize() {
        $this->cid = 26;
        $this->cache = Cache::getInstance();
        parent::_initialize();
    }

	protected function index() {
        $this->childMenus = $this->getSpecialChildMenu();

		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,area_no,season_id,book_id,pv_count";
		$order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->tListRows = 8;
		$this->themeDataList($field, $map, $order);
		$this->display('Book/index');
	}

    /**
     * 主题列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeDataList($field, $map, $order = array('publish_time'=>'desc','id'=>'desc')) {
        $cid = $this->cid;
        if ($cid)
            $map[$this->tableArr['subject_original'] . '.menu_id'] = $cid;
        if ($this->cmid)
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;

        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $seid = $this->param['seid'];
        if ($seid)
            $map['season_id'] = $seid;

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }

            $this->assign('areaStr',$this->areas[$ano]['name']);
        }

        $boid = $this->param['boid'];
        $bookStr = $this->param['bookStr'];
        if (empty($boid) && $bookStr != '') {
            $boid = M('AttributeBook')->getField('id', array('name' => $bookStr));
            $boid = intval($boid);
            if($boid){
              $map['book_id'] = $boid;
              $this->assign('boid',$boid);
            }
        } elseif ($boid) {
            $map['book_id'] = $boid;
            $bookStr = M('AttributeBook')->getField('name', array('id' => $boid));
            $this->assign('bookStr', $bookStr);
        }

        $stid = $this->param['stid'];
        if ($map['sst.style_id'] || $stid) {
            $join[] = "{$this->tableArr['ref_subject_style_original']} sst on sst.subject_id={$this->tableArr['subject_original']}.id";
            $map['sst.style_id'] ? '' : $map['sst.style_id'] = $stid;
        }

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Book::'.'themeDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            //$count = $this->modelT->join($join)->where($map)->count();
            //echo $this->modelT->getlastsql();
            import("ORG.Util.DataCount");
            $count = DataCount::getCount($this->tableArr['subject'],$map,$join);
            if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->tListRows);
                $voList = $this->modelT->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelT->getLastSql();
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        if ($val['book_id']){
                            $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                        }
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'soid'=>$soid,'tid' => $val['id']));
                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                        $voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                 }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    protected function themeInfo($tid) {
        $tid = intval($tid);

        if (!$tid)
            $this->error('参数错误！');

        $cid = $this->cid;
        if($cid)
            $map[$this->tableArr['subject_original'].'.menu_id'] = $cid;

        $map[$this->tableArr['subject_original'].'.id'] = $tid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }

        $field = $this->tableArr['subject_original'].'.id,title,publish_time,season_id,area_no,show_edit,book_id';

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Book::'.'themeInfo::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $info = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$info){
            $info = $this->modelT->join($join)->relation($this->relationArr)->field($field)->where($map)->find();
            //echo $this->modelT->getLastSql()."</br>";exit;
            if(!$info){
                $this->error('参数错误！');
            }
            $info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
            $soid = intval($_GET['soid']);
            $soid = $soid ? $soid : $this->soid;
            if(!$soid){
                $soid = M($this->tableArr['ref_subject_sort'])->getField("sort_id","subject_id='{$tid}'");
            }
            $info['sortStr'] = $this->sorts[$soid]['title'];
            $info['areaStr'] = $this->areas[$info['area_no']]['name'];
            $info['seasonStr'] = $this->seasons[$info['season_id']]['en_name'];
            $info['bookStr'] = $this->books[$info['book_id']]['name']; //时尚杂志需用到
            $info['bookUrl'] = U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'boid'=>$info['book_id']));
            $info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']): '';
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $info,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $info);
        }

        //权限验证
        $this->withoutPermission('',$info);

        return $info;
    }

    /**
     * get theme picture list
     * @param $tid intval
     * @return array
     */
    protected function themePicture($tid) {
        $tid = intval($tid);
        $this->assign('tid', $tid);

        if (!$tid)
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url,page_no';
        $order = array('page_no' => 'asc');

        $cid = $this->cid;
        if ($cid){
            $map['menu_id'] = $cid;
        }
        //if($this->cmid) $map['child_menu_id'] = $this->cmid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $tid;

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Book::themePicture::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
           $count = $this->modelP->where($map)->count();
           if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->pListRows);
                $voList = $this->modelP->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelP->getLastSql()."</br>";
                if ($voList) {
                    $picList = array();
                    foreach ($voList as $key => $val) {
                        $voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
                        $voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);

                        $picList[$key]['sTid'] = 0;
                        $picList[$key]['sPid'] = $val['id'];
                        $picList[$key]['sCid'] = $cid;
                        $picList[$key]['sPidNo'] = $val['id'];
                        $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                        $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                        $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                    }
                }
				//var_dump($picList);
				$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
				//模板赋值显示
				$Arr['listArr'] = $voList;
				//分页显示
				$Arr['pageStr'] = $p->showOne();
				//主题下载处需要用到
				$Arr['picNum'] = $count;
           }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    protected function themeDetail($tid = '') {
        $this->assign('jumpUrl', 'javascript:window.close();');
        $this->relationArr = array('SubjectExtend');
        $tid = intval($tid);

        $tid = $tid ? $tid : intval($_GET['tid']);
        $themeInfo = $this->themeInfo($tid);
        //dump($themeInfo);
        if ($themeInfo['show_edit'] == 1)
            $this->getShowContent($themeInfo);
        else
            $this->themePicture($tid);

        $this->updateThemePvCount($tid);
		$this->assign('nume',MODULE_NAME);
        $this->assign('info', $themeInfo);
        $this->display('Book/theme_detail');
    }

    protected function setCmid() {
        $this->cmid = intval($_GET['cmid']);
        $this->assign('cmid', $this->cmid);
    }

    protected function setCidSift() {
        $sMap['menu_id'] = $this->cid;
        $this->cmid ? $sMap['child_menu_id'] = $this->cmid : '0';
        $soid = $this->getSoid();
        if($soid){
            $sMap['sort_id'] = $soid == 3 ? array('egt',3) : $soid;
        }
        $fieldArr = array('season_id_list','area_no_list','book_id_list');
        $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
        $this->areas = $siftArr['area_no_list'];
        $this->seasons = $siftArr['season_id_list'];
        $this->books = $siftArr['book_id_list'];
        if ($this->seasons) {
            $seasonsTmp = $this->seasons;
            uasort($seasonsTmp, "cmp");
            $Arr['seasons'] = $seasonsTmp;
            unset($seasonsTmp);
        }
        if ($this->areas) {
            $Arr['areaHtml'] = $this->getAreaOption($this->param['ano']);
            $Arr['areas'] = format_tree_area($this->areas);
        }

        $Arr['letters'] = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
        $Arr['config'] = $config;
        $this->assign($Arr);
    }

    protected function setParam() {
        $this->param = array('cmid' => intval($this->cmid));

        $soid = $this->sid ? intval($_REQUEST['soid']) : $this->soid;
        if ($soid)
            $this->param = array_merge($this->param, array('soid' => $soid));

        $seid = intval($_REQUEST['seid']);
        if ($seid)
            $this->param = array_merge($this->param, array('seid' => $seid));

        $stid = intval($_REQUEST['stid']);
        if ($stid)
            $this->param = array_merge($this->param, array('stid' => $stid));

        $ano = intval($_REQUEST['ano']);
        if ($ano)
            $this->param = array_merge($this->param, array('ano' => $ano));

        $boid = intval($_REQUEST['boid']);
        if ($boid)
            $this->param = array_merge($this->param, array('boid' => $boid));

        $bookStr = trim($_REQUEST['bookStr']);
        if ($bookStr)
            $this->param = array_merge($this->param, array('bookStr' => $bookStr));

        $act = trim($_REQUEST['act']);
        if ($act)
            $this->param = array_merge($this->param, array('act' => $act));

        $tid = trim($_REQUEST['tid']);
        if ($tid)
            $this->param = array_merge($this->param, array('tid' => $tid));
    }

    protected function getShowContent($themeInfo) {
        if (!$themeInfo['id'])
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url';

        $cid = $this->cid;
        if ($cid)
            $map['menu_id'] = $cid;

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $themeInfo['id'];

        $cache_key = md5('Book::getShowContent::'.$this->isRightS."::".$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $voList = $this->modelP->where($map)->field($field)->order(array('publish_time' => 'desc','id'=>'desc'))->findAll();
            $picList = array();
            $parse_arr = parse_content(stripslashes($themeInfo['content']));
            $detailhtml = $parse_arr['result'];
            if ($parse_arr['pic_arr']) {
                //$i = 0;
                foreach ($parse_arr['pic_arr'] as $key => $val) {
                    $picList[$key]['sTid'] = $themeInfo['id'];
                    $picList[$key]['sPid'] = 0;
                    $picList[$key]['sSex'] = $themeInfo['sort_id'];
                    $picList[$key]['sCid'] = $this->cid;
                    $picList[$key]['sPicNo'] = 0;
                    $picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
                    $picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
                    $picList[$key]['sSpic'] = $val['sSpic'];
                    $picList[$key]['sBpic'] = $val['sBpic'];
                    if ($voList) {
                        foreach ($voList as $ke => $va) {
                            if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
                                //echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
                                $picList[$key]['sPid'] = $va['id'];
                                $picList[$key]['sSex'] = $va['sort_id'];
                                $picList[$key]['sPicNo'] = $va['id'];
                            }
                        }
                    }
                }
            }
            $Arr['detailhtml'] = $detailhtml;
            $Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)); //放大图片
            $Arr['picNum'] = $count;//主题下载处需要用到
            $this->cache->set($cache_key, $Arr);
        }
        $this->assign($Arr);
    }

    /*
     * 根据各栏目需求获性别ID
     */
    protected function getSoid() {
        $soid = $this->param['soid'];
        $soid = $this->sid ? ( $soid ? $soid : 2) : $this->soid;
        $this->assign('soid', $soid);
        return $soid;
    }

    protected function getSpecialChildMenu(){
        $soid = $this->getSoid();
        $stid = $this->param['stid'];
        $specialChildMenu['1'] = array(
            array('id'=>1,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>1)),'name'=>'T恤','selected'=>$stid == 1),
            array('id'=>29,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>29)),'name'=>'外套','selected'=>$stid == 29),
            array('id'=>66,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>66)),'name'=>'衬衫','selected'=>$stid == 66),
            array('id'=>95,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>95)),'name'=>'毛衫','selected'=>$stid == 95),
            array('id'=>211,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>211)),'name'=>'牛仔','selected'=>$stid == 211),
            array('id'=>128,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>128)),'name'=>'裤子','selected'=>$stid == 128),
            array('id'=>152,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>152)),'name'=>'运动','selected'=>$stid == 152),
            array('id'=>242,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>242)),'name'=>'皮草','selected'=>$stid == 242),
            array('id'=>448,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>448)),'name'=>'内衣','selected'=>$stid == 448),
        );

        $specialChildMenu['2'] = array(
            array('id'=>1,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>1)),'name'=>'T恤','selected'=>$stid == 1),
            array('id'=>29,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>29)),'name'=>'外套','selected'=>$stid == 29),
            array('id'=>267,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>267)),'name'=>'棉服','selected'=>$stid == 267),
            array('id'=>66,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>66)),'name'=>'衬衫','selected'=>$stid == 66),
            array('id'=>95,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>95)),'name'=>'毛衫','selected'=>$stid == 95),
            array('id'=>178,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>178)),'name'=>'裙子','selected'=>$stid == 178),
            array('id'=>211,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>211)),'name'=>'牛仔','selected'=>$stid == 211),
            array('id'=>128,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>128)),'name'=>'裤子','selected'=>$stid == 128),
            array('id'=>152,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>152)),'name'=>'运动','selected'=>$stid == 152),
            array('id'=>242,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>242)),'name'=>'皮草','selected'=>$stid == 242),
            array('id'=>448,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>448)),'name'=>'内衣','selected'=>$stid == 448),
            array('id'=>360,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>360)),'name'=>'礼服','selected'=>$stid == 360),
        );

        $specialChildMenu['3'] = array(
            array('id'=>1,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>1)),'name'=>'T恤','selected'=>$stid == 1),
            array('id'=>29,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>29)),'name'=>'外套','selected'=>$stid == 29),
            array('id'=>66,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>66)),'name'=>'衬衫','selected'=>$stid == 66),
            array('id'=>95,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>95)),'name'=>'毛衫','selected'=>$stid == 95),
            array('id'=>178,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>178)),'name'=>'裙子','selected'=>$stid == 178),
            array('id'=>211,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>211)),'name'=>'牛仔','selected'=>$stid == 211),
            array('id'=>128,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>128)),'name'=>'裤子','selected'=>$stid == 128),
            array('id'=>152,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'stid'=>152)),'name'=>'运动','selected'=>$stid == 152),
       );

        return $specialChildMenu[$soid];
    }
}
