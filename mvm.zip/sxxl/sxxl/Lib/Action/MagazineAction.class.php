<?php

class MagazineAction extends TideSectionAction {

    public function _initialize() {
        $this->cid = 19;
        $this->cache = Cache::getInstance();
        parent::_initialize();
		if(!Cookie::get(C('USER_AUTH_KEY'))){
			$this->redirect("/Public/login");
			exit();
		}elseif(!$this->checkIsTry() && !$this->isRightB){
			$this->display('TideSection/without_permission');
			exit();
		}
    }

	protected function index() {
		
        $Arr['specialChildMenus'] = $this->getSpecialChildMenu();
        $Arr['monthTab'] = $this->getMonth();
        $this->assign($Arr);

		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,area_no,season_id,book_id,pv_count";
		$order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->tListRows = 8;
		$this->themeDataList($field, $map, $order);
		$this->display('Magazine/index');
	}

    /**
     * 主题列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeDataList($field, $map, $order) {
        if ($this->cid)
            $map[$this->tableArr['subject_original'] . '.menu_id'] = $this->cid;
        if ($this->cmid)
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;

        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }

        //风格
        $faid = $this->param['faid'];
        if ($faid) {
            $join[] = "{$this->tableArr['ref_subject_fashion_original']} sf on sf.subject_id={$this->tableArr['subject_original']}.id";
            $map['sf.fashion_id'] = $faid;
        }

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $seid = $this->param['seid'];
        if ($seid)
            $map['season_id'] = $seid;

        //月份
        $moid = $this->param['moid'];
        if ($moid)
            $map['month'] = $moid;

        $ano = intval($_REQUEST['ano']);
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
            } elseif (substr($ano, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }

            $this->assign('areaStr',$this->areas[$ano]['name']);
        }

        $boid = $this->param['boid'];
        $bookStr = $this->param['bookStr'];
        if (empty($boid) && $bookStr != '') {
            $boid = M('AttributeBook')->getField('id', array('name' => $bookStr));
            $boid = intval($boid);
            if($boid){
              $map['book_id'] = $boid;
              $this->assign('boid',$boid);
            }
        } elseif ($boid) {
            $map['book_id'] = $boid;
            $bookStr = M('AttributeBook')->getField('name', array('id' => $boid));
            $this->assign('bookStr', $bookStr);
        }

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Magazine::'.'themeDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            //$count = $this->modelT->join($join)->where($map)->count();
            import("ORG.Util.DataCount");
            $count = DataCount::getCount($this->tableArr['subject'],$map,$join);
            if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->tListRows);
                $voList = $this->modelT->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelT->getLastSql();
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        if ($val['book_id']){
                            $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                        }
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                        $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'soid'=>$soid,'tid' => $val['id']));
                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                        $voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }


    protected function themeInfo($tid) {
        $tid = intval($tid);

        if (!$tid)
            $this->error('参数错误！');

        $map['menu_id'] = $this->cid == 12 && ACTION_NAME == 'themeDetail' ? 28 : $this->cid;
        $map['id'] = $tid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $field = 'id,title,publish_time,season_id,area_no,show_edit,book_id';

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Magazine::themeInfo::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.implode('::', $map));
        $info = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if ( !$info) {
            $info = $this->modelT->relation($this->relationArr)->field($field)->where($map)->find();
            //echo $this->modelT->getLastSql()."</br>";exit;
            $info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
            $soid = intval($_GET['soid']);
            $soid = $soid ? $soid : $this->soid;
            if(!$soid){
                $soid = M($this->tableArr['ref_subject_sort'])->getField("sort_id","subject_id='{$tid}'");
            }
            $info['sortStr'] = $this->sorts[$soid]['title'];
            $info['areaStr'] = $this->areas[$info['area_no']]['name'];
            $info['seasonStr'] = $this->seasons[$info['season_id']]['en_name'];
            $info['bookStr'] = $this->books[$info['book_id']]['name']; //时尚杂志需用到
            $info['bookUrl'] = U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'boid'=>$info['book_id']));
            $info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']): '';
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $info,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $info);
        }
        //权限验证
        parent::withoutPermission('',$info);

        return $info;
    }

    /**
     * get theme picture list
     * @param $tid intval
     * @return array
     */
    protected function themePicture($tid) {
        $tid = intval($tid);
        $this->assign('tid', $tid);

        if (!$tid)
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url,page_no';
        $order = array('page_no' => 'asc');

        if ($this->cid)
            $map['menu_id'] = $this->cid;
        //if($this->cmid) $map['child_menu_id'] = $this->cmid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $tid;

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Magazine::themePicture::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
           $count = $this->modelP->where($map)->count();
           if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->pListRows);
                $voList = $this->modelP->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelP->getLastSql()."</br>";
                if ($voList) {
                    $picList = array();
                    foreach ($voList as $key => $val) {
                        $voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
                        $voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);

                        $picList[$key]['sTid'] = 0;
                        $picList[$key]['sPid'] = $val['id'];
                        $picList[$key]['sCid'] = $cid;
                        $picList[$key]['sPidNo'] = $val['id'];
                        $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                        $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                        $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                    }
                }
				//var_dump($picList);
				$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
				//模板赋值显示
				$Arr['listArr'] = $voList;
				//分页显示
				$Arr['pageStr'] = $p->showOne();
				//主题下载处需要用到
				$Arr['picNum'] = $count;
           }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    protected function themeDetail($tid = '') {
        $this->assign('jumpUrl', 'javascript:window.close();');
        $this->relationArr = array('SubjectExtend');
        $tid = intval($tid);

        $tid = $tid ? $tid : intval($_GET['tid']);
        $themeInfo = $this->themeInfo($tid);
        //dump($themeInfo);
        if ($themeInfo['show_edit'] == 1)
            $this->getShowContent($themeInfo);
        else
            $this->themePicture($tid);

        $this->updateThemePvCount($tid);
		$this->assign('nume',MODULE_NAME);
        $this->assign('info', $themeInfo);
        $this->display('Magazine/theme_detail');
    }

    protected function setCmid() {
        $this->cmid = intval($_GET['cmid']);
        $this->assign('cmid', $this->cmid);
    }

    protected function getSoid() {
        $soid = $this->param['soid'];
        if ($soid)
            $soid = in_array($soid, array(1, 2, 3, 4, 5, 6)) ? $soid : 2;
        else
            $soid = $this->sid ? 2 : $this->soid;
        $this->assign('soid', $soid);
        return $soid;
    }

    protected function setCidSift() {
        $sMap['menu_id'] = $this->cid;
        $this->cmid ? $sMap['child_menu_id'] = $this->cmid : '';
        $soid = $this->getSoid();
        if($soid){
            $sMap['sort_id'] = $soid == 3 ? array('egt',3) : $soid;
        }
        $fieldArr = array('season_id_list','area_no_list','book_id_list');
        $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
        $this->areas = $siftArr['area_no_list'];
        $this->seasons = $siftArr['season_id_list'];
        $Arr['books'] = $this->books = $siftArr['book_id_list'];
        $Arr['fashions'] = $this->fashions = $siftArr['fashion_id_list'];

        if ($this->seasons) {
            $seasonsTmp = $this->seasons;
            uasort($seasonsTmp, "cmp");
            $Arr['seasons'] = $seasonsTmp;
            unset($seasonsTmp);
        }
        if ($this->areas) {
            $Arr['areaHtml'] = $this->getAreaOption($this->param['ano']);
            $Arr['areas'] = format_tree_area($this->areas);
        }

       $Arr['letters'] = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');

        $this->assign($Arr);
    }

    protected function getSpecialChildMenu(){
        $soid = $this->getSoid();
        $faid = $this->param['faid'];
        $ano = $this->param['ano'];
        $specialChildMenu[2] = array(
            array('id'=>26,'name'=>'纺织品趋势系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>26)),'selected'=>$faid == 26),
            array('id'=>25,'name'=>'成熟优雅系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>25)),'selected'=>$faid == 25),
            array('id'=>35,'name'=>'皮衣皮草系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>35)),'selected'=>$faid == 35),
            array('id'=>38,'name'=>'时尚杂志系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>38)),'selected'=>$faid == 38),
            array('id'=>39,'name'=>'时装走秀系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>39)),'selected'=>$faid == 39),
            array('id'=>46,'name'=>'针织毛衣系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>46)),'selected'=>$faid == 46),
            array('id'=>32,'name'=>'年轻时尚系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>32)),'selected'=>$faid == 32),
            array('id'=>40,'name'=>'斯文优雅系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>40)),'selected'=>$faid == 40),
            array('id'=>37,'name'=>'少女街头系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>37)),'selected'=>$faid == 37),
            array('id'=>41,'name'=>'田园淑女系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>41)),'selected'=>$faid == 41),
            array('id'=>31,'name'=>'内衣/泳装','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>31)),'selected'=>$faid == 31),
            array('id'=>28,'name'=>'婚纱系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>28)),'selected'=>$faid == 28),
            array('id'=>42,'name'=>'晚装系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>42)),'selected'=>$faid == 42),
            array('id'=>45,'name'=>'运动休闲装','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>45)),'selected'=>$faid == 45)
        );

        $specialChildMenu[1] = array(
            array('id'=>29,'name'=>'街头休闲系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>29)),'selected'=>$faid == 29),
            array('id'=>36,'name'=>'商务休闲系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>36)),'selected'=>$faid == 36),
            array('id'=>32,'name'=>'年轻时尚系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>32)),'selected'=>$faid == 32),
            array('id'=>39,'name'=>'时装走秀系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>39)),'selected'=>$faid == 39),
            array('id'=>45,'name'=>'运动休闲装','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>45)),'selected'=>$faid == 45),
            array('id'=>46,'name'=>'针织毛衣系列','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'faid'=>46)),'selected'=>$faid == 46),
        );

        $specialChildMenu[3] = array(
            //array('id'=>395008,'name'=>'新加坡','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>395008)),'selected'=>$ano == 395008),
            array('id'=>200960,'name'=>'法国','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>200960)),'selected'=>$ano == 200960),
            array('id'=>200704,'name'=>'德国','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>200704)),'selected'=>$ano == 200704),
            array('id'=>206080,'name'=>'英国','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>206080)),'selected'=>$ano == 206080),
            array('id'=>262400,'name'=>'日本','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>262400)),'selected'=>$ano == 262400),
            array('id'=>205824,'name'=>'意大利','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>205824)),'selected'=>$ano == 205824),
            array('id'=>205312,'name'=>'西班牙','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>205312)),'selected'=>$ano == 205312),
            array('id'=>393472,'name'=>'俄罗斯','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>393472)),'selected'=>$ano == 393472),
            array('id'=>459008,'name'=>'澳大利亚','url'=>U('/'.MODULE_NAME.'/index',array('soid'=>$soid,'ano'=>459008)),'selected'=>$ano == 459008)
        );

        return $specialChildMenu[$soid];
    }

    protected function getMonth(){
        $voList = array('1'=>'01月','2'=>'02月','3'=>'03月','4'=>'04月','5'=>'05月','6'=>'06月','7'=>'07月','8'=>'08月','9'=>'09月','10'=>'10月','10'=>'10月','11月','12月');
        return $voList;
    }

    protected function setParam() {
        $this->param = array('cmid' => intval($this->cmid));

        $act = trim($_REQUEST['act']);
        if ($act)
            $this->param = array_merge($this->param, array('act' => $act));

        $soid = intval($_REQUEST['soid']);
        if ($soid)
            $this->param = array_merge($this->param, array('soid' => $soid));

        $ano = intval($_REQUEST['ano']);
        if ($ano)
            $this->param = array_merge($this->param, array('ano' => $ano));

        $boid = intval($_REQUEST['boid']);
        if ($boid)
            $this->param = array_merge($this->param, array('boid' => $boid));

        $bookStr = trim($_REQUEST['bookStr']);
        if ($bookStr)
            $this->param = array_merge($this->param, array('bookStr' => $bookStr));

        $faid = intval($_REQUEST['faid']);
        if ($faid)
            $this->param = array_merge($this->param, array('faid' => $faid));

        $moid = intval($_REQUEST['moid']);
        if ($moid)
            $this->param = array_merge($this->param, array('moid' => $moid));

        $tid = intval($_REQUEST['tid']);
        if ($tid)
            $this->param = array_merge($this->param, array('tid' => $tid));


    }

    protected function getShowContent($themeInfo) {
        if (!$themeInfo['id'])
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url';

        $cid = $this->cid;
        if ($cid)
            $map['menu_id'] = $cid;

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $themeInfo['id'];

        $cache_key = md5('Magazine::getShowContent::'.$this->isRightS."::".$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $voList = $this->modelP->where($map)->field($field)->order(array('publish_time' => 'desc','id'=>'desc'))->findAll();
            $picList = array();
            $parse_arr = parse_content(stripslashes($themeInfo['content']));
            $detailhtml = $parse_arr['result'];
            if ($parse_arr['pic_arr']) {
                //$i = 0;
                foreach ($parse_arr['pic_arr'] as $key => $val) {
                    $picList[$key]['sTid'] = $themeInfo['id'];
                    $picList[$key]['sPid'] = 0;
                    $picList[$key]['sSex'] = $themeInfo['sort_id'];
                    $picList[$key]['sCid'] = $this->cid;
                    $picList[$key]['sPicNo'] = 0;
                    $picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
                    $picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
                    $picList[$key]['sSpic'] = $val['sSpic'];
                    $picList[$key]['sBpic'] = $val['sBpic'];
                    if ($voList) {
                        foreach ($voList as $ke => $va) {
                            if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
                                //echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
                                $picList[$key]['sPid'] = $va['id'];
                                $picList[$key]['sSex'] = $va['sort_id'];
                                $picList[$key]['sPicNo'] = $va['id'];
                            }
                        }
                    }
                }
            }
            $Arr['detailhtml'] = $detailhtml;
            $Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)); //放大图片
            $Arr['picNum'] = $count;//主题下载处需要用到
            $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }
}
