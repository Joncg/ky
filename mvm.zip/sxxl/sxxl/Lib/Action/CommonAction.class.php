<?php

class CommonAction extends Action {

	public $subSec;
	protected $loginInfo;
	protected $tableArr;
	protected $modelT;
	protected $modelP;
	protected $modelF;
	protected $isRightS = false;
	protected $isRightB = false;
	public $isPcRight = false; //PC授权与否,默认否
	protected $cache;
	protected $tideSectionArr;	  #潮流部门相关信息数据
	public $childrenSoids = array(3, 4, 5, 6); //当前童装所拥有的性别
	public $checkIsTry = false;

	//protected $cacheFileOption = array('temp'=>'../config/cache/','expire'=>'-1');

	function _initialize() {
		//更改配置文件的限制显示时间
		C('TODAY_LAST_TIME', mktime(23, 59, 59, date("m"), date("d"), date("Y")));

		$this->cache = Cache::getInstance();
		$no_buy_login = Cookie::get('no_buy_login');
		if (Cookie::get(C('USER_AUTH_KEY')) && empty($no_buy_login)) {
			Cookie::set('no_buy_login', 1);
			$Arr['loginInfo'] = R('Public', 'loginInfo');
			//$power = $Arr['loginInfo']['vipInfoArr'][1]['name'];
            $power = '';
			$UserName = Cookie::get('loginUser');
			$buy_encode = urlencode(base64_encode('user_name=' . $UserName . '&time=' . time() . '&vip_words=' . $power));
            //$url = "M2MzYldKQksrc1VCSTh0a3hJVEh4YjVGQmtCSGxwUmtlZUkrMVlNVjA2Wkd0bHhmeng2ZlQycU5BQkJyY3hqcEozQmEwczFuLzM1WEp0d0Z2M1Zqb29pelQwQTFkOXVKc2RWS2VEc0pGVFlQZ2c%3D";
           // echo authcode(base64_decode(urldecode($url)), 'DECODE', C('URL_SEND_ENCODE_KEY'));exit;
			$this->assign('is_buy_login', 1);
			$this->assign('buy_diexun', C('BUY_DIEXUN'));
			$this->assign('buy_encode', $buy_encode);
		}
		if (in_array(MODULE_NAME, C('REQUIRE_AUTH_IAKN'))) {
			R('Public', 'checkMember'); //检测PC是否授权
			// 用户权限检查
			$this->isRightS = $this->isRightB = rbac();
		} else {
			if (in_array(MODULE_NAME, C('REQUIRE_AUTH_LOGIN'))) {
				$rightArr['isLogin'] = R('Public', 'isLogin');
				$rightArr['isLogin'] ? '' : redirect(PHP_FILE . C('USER_AUTH_GATEWAY'));
				$rightArr['isPcRight'] = $this->isPcRight = R('Public', 'checkPc');
				//能到这一步说明已经登录
				if ($this->isPcRight && rbac()) {
					$Arr['isRightB'] = $Arr['isRightS'] = $this->isRightS = $this->isRightB = true;
				} elseif (intval($_GET['p']) < 4) {
					$Arr['isRightS'] = $this->isRightS = true;
					$Arr['isRightB'] = $this->isRightB = false;
				}
			} else {
                $cache_key = md5('getRight::'.Cookie::get(C('USER_AUTH_KEY')).'::'.Cookie::get('cpu_id').'::'.MODULE_NAME.'::'.ACTION_NAME);
                $rightArr = trim($_GET['cache']) == 'false' ? '' : $this->cache->get($cache_key);
                if(!$rightArr['isRightB']){
                    $rightArr = get_right();
                    $this->cache->set($cache_key,$rightArr);
                }
				$this->isRightS = $rightArr['isRightS'];
				$this->isRightB = $rightArr['isRightB'];
				$this->isPcRight = $rightArr['isPcRight'];
				//dump($rightArr);
			}
		}

		$this->tideSectionArr = C('TIDE_SECTION');
		$cidTmp = $this->cid == 12 && (ACTION_NAME == 'themeList' || ACTION_NAME == 'themeDetail') ? 28 : $this->cid;
		$this->tableArr = getCidModel($cidTmp);
		unset($cidTmp);

		if ($this->tableArr['folder'])
			$this->modelF = D($this->tableArr['folder']);
		if ($this->tableArr['subject'])
			$this->modelT = D($this->tableArr['subject']);
		if ($this->tableArr['picture'])
			$this->modelP = D($this->tableArr['picture']);

		$Arr['cid'] = $this->cid;
		$Arr['loginInfo'] = $this->loginInfo = R('Public', 'loginInfo');
		//$Arr['leftMenu'] =  $this->leftMenu();
		$Arr['specialColumn'] = $this->specialColumn();
		$Arr['subSec'] = $this->subSec = $this->subSec();
		if ($this->sid) {
			$Arr['subSecCowboy'] = $this->subSec(1);
			$Arr['subSecPants'] = $this->subSec(2);
			$Arr['subSecUnderwear'] = $this->subSec(4);
			$Arr['subSecWoolens'] = $this->subSec(5);
			$Arr['getsid'] = $this->sid;
		}
		$map['member_id'] = $id = Cookie::get(C('USER_AUTH_KEY'));
		$map['is_try'] = 1;
		$map['invalid_time'] = array('EGT', time());
		$map['role_id'] = array("GT",0);
		$trysearch = D("RefMemberRole")->where($map)->field('id')->find();
		//echo D("RefMemberRole")->getLastSql();
		//echo $this->isRightB;
		$this->checkIsTry = $trysearch ? false : true;
		$this->checkIsTry = (MODULE_NAME == 'Search' || MODULE_NAME =="Favorites" || MODULE_NAME == "Member") ? $this->checkIsTry : $this->checkIsTry();
		$Arr['istryrightkey'] = (($this->isRightB && !$this->checkIsTry) || (!$this->isRightB)) ? 1 : 0;
		$Arr['action_name'] = ACTION_NAME;
		$Arr['module_name'] = MODULE_NAME;
		$this->assign(array_merge($Arr, $rightArr));
	}

	protected function getPageInfo($params, $str = '') {
		extract($params);
		$title = '蝶讯服装网';
		$keywords = '蝶讯服装网';
		$description = '蝶讯服装网';
		$urlHere = '';
		$curMenu = $sortName = $speColName = '';
		$seowords = C('SEO_WOERDS');
		if (MODULE_NAME == 'Index') {
			$title = $seowords[0]['title'];
			$description = $seowords[0]['description'];
			$keywords = $seowords[0]['keywords'];
		}
		if ($this->soid && MODULE_NAME != 'Index') {
			$soidTmp = $this->soid > 2 ? 3 : $this->soid;
			$info = C('SORT');
			$info = $info[$soidTmp];
			$curMenu = $sortName = $info['name'];
			$sortTitle = $info['title'];
			$title = $seowords[$this->soid]['title'];
			$keywords = $seowords[$this->soid]['keywords'];
			$description = $seowords[$this->soid]['description'];
			$urlHere .= "<a href='" . U('/Sort/index', array('soid' => $this->soid)) . "' title='" . $sortTitle . "' class='special_blue'>" . $sortTitle . "</a>";
		} elseif ($this->sid) {
			$info = C('SPECIAL_COLUMN');
			$specialcolumnseo = C('SEO_SPECIALCOLUMN');
			$info = $info[$this->sid];
			$speColTitle = $info['title'];
			$speColName = $info['name'];
			$curMenu = 'SpecialColumn';
			$title = $specialcolumnseo[$this->sid]['title'];
			$keywords .= $specialcolumnseo[$this->sid]['keywords'];
			$description = $specialcolumnseo[$this->sid]['description'];
			$urlHere .= "<a href='" . U('/SpecialColumn/index', array('sid' => $this->sid)) . "' title='{$info['title']}' class='special_blue'>{$info['title']}</a>";
		}
		if ($this->cid) {
			$info = $this->tideSectionArr;
			$info = $info[$this->cid];
			if ($sortName || $speColName) {
				$title = $info['title'] . '_' . $title;
				$keywords .= ',' . $info['title'];
				$description = $info['title'] . ',' . $description;
				if ($this->cid == 100 && $this->sid == 4)
					$urlHere .= "&gt;<a href='" . U("/UnderwearBrandinsp/index") . "' title='品牌画册'>品牌画册</a>";
				else
					$urlHere .= "&gt;<a href='" . U("/" . $sortName . $speColName . $info['name'] . "/index") . "' title='{$info['title']}'>{$info['title']}</a>";
			} else {
				$title = $info['title'] . '_潮流部门_' . $title;
				$keywords .= ',潮流部门,' . $info['title'];
				$description = $info['title'] . ',潮流部门,' . $description;
				$urlHere .= "&gt;<a href='javascript:void(0);' class='special_blue'>潮流部门</a> &gt;<a href='" . U("/" . $sortName . $speColName . $info['name'] . "/index") . "' title='{$info['title']}'>{$info['title']}</a>";
			}
		}

		if ($cmid && $this->cid != 17) {
			$name = $this->menus[$cmid]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
			if (in_array($this->cid, array(11, 12, 13, 15)) || ($this->cid == 24 && in_array($cmid, array(65, 69)))) {
				$urlHere .= "&gt;<a href='" . U("/" . $sortName . $speColName . $info['name'] . "/folderList", array('cmid' => $cmid)) . "' title='{$name}'>{$name}</a>";
			} else if ($this->cid == 24 && in_array($cmid, array(66, 67, 68))) {
				$urlHere .= "&gt;<a href='" . U("/" . $sortName . $speColName . $info['name'] . "/themeList", array('cmid' => $cmid)) . "' title='{$name}'>{$name}</a>";
			} else if ($this->cid == 24 && $cmid == 70) {
				$urlHere .= "&gt;<a href='" . U("/" . $sortName . $speColName . $info['name'] . "/pictureList", array('cmid' => $cmid)) . "' title='{$name}'>{$name}</a>";
			} else {
				$urlHere .= "&gt;<a href='" . U("/" . $sortName . $speColName . $info['name'] . "/index", array('cmid' => $cmid)) . "' title='{$name}'>{$name}</a>";
			}
			//$urlHere .=  $this->cid == 22 || $this->cid == 25 ? "&nbsp;&gt;&nbsp;<a href='".U("/".$sortName.$speColName.$info['name']."/index",array('cmid'=>$cmid))."' title='{$name}'>{$name}</a>" : "&nbsp;&gt;&nbsp;{$name}" ;
		}/* elseif($this->cid == 17 && in_array($aid,array('gw','gl','hg'))){
		  if($aid == 'gw'){
		  $name = '国外';
		  }else if($aid == 'gl'){
		  $name = '国内';
		  }else if($aid == 'hg'){
		  if(strpos(MODULE_NAME,'Women') !== false){
		  $name = '韩国东大门';
		  }else if(strpos(MODULE_NAME,'Children') !== false){
		  $name = '韩国南大门';
		  }else{
		  $name = '韩版牛仔';
		  }
		  }

		  $title = $name . '_' . $title;
		  $keywords .= ',' . $name;
		  $description = $name . ',' . $description;
		  $urlHere .= "&gt;<a href='" . U("/" . $sortName . $speColName . $info['name'] . "/index", array('aid' => $aid)) . "' title='{$name}'>{$name}</a>";
		  } */

		//款式
		if ($stid) {
			$stylesTmp = F('styleList', '', C('DATA_CACHE_PATH'));
			$name = $stylesTmp[$stid]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
			unset($stylesTmp);
		}

		//季度
		if ($seid) {
			$name = $this->seasons[$seid]['en_name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//设计师
		if ($did) {
			$name = $this->designers[$did]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//区域
		if ($ano) {
			$name = $this->areas[$ano]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//风格
		if ($faid) {
			$name = $this->fashions[$faid]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//颜色
		if ($coid) {
			$name = $this->colors[$coid]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//细节
		if ($deid) {
			$name = $this->details[$deid]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//配饰
		if ($acid) {
			$name = $this->accs[$acid]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//关键词
		if ($kid) {
			$name = $this->keywords[$kid]['name'];
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		//页码
		$page = intval($_GET['p']);
		if ($page) {
			$name = "第{$page}页";
			$title = $name . '_' . $title;
			$keywords .= ',' . $name;
			$description = $name . ',' . $description;
		}

		$curMenu = empty($curMenu) && MODULE_NAME == 'Gallery' ? 'Gallery' : $curMenu;
		return array('title' => $title, 'keywords' => $keywords, 'description' => $description, 'urlHere' => $urlHere, 'curMenu' => $curMenu, 'speColTitle' => $speColTitle, 'speColName' => $speColName, 'sortTitle' => $sortTitle, 'sortName' => $sortName,);
	}

	/**
	 * 潮流部门
	 * return array
	 */
	protected function leftMenu() {
		$leftMenu['images'] = array('title' => '图片库', 'url' => '');
		$data = $this->tideSectionArr;
		foreach ($data as $key => $val) {
			$data[$key]['url'] = U('/' . $val['name'] . '/index');
		}
		$leftMenu['section'] = array('title' => '潮流部门', 'url' => 'javascript:void(0)', 'subSec' => $data);
		$leftMenu['specialColumn'] = array('title' => '专栏频道', 'url' => '');
		return $leftMenu;
	}

	/**
	 * 专栏菜单
	 * return array
	 */
	protected function specialColumn() {
		$data = C('SPECIAL_COLUMN');
		foreach ($data as $key => $val) {
			$data[$key]['url'] = U('/SpecialColumn/index', array('sid' => $val['id']));
		}
		return $data;
	}

	/**
	 * 潮流部门
	 * return array
	 */
	protected function subSec($sid = null) {
		$subSec = $this->tideSectionArr;
		if ($subSec) {
			foreach ($subSec as $key => $val) {
				if ($val['id'] == 28 || ($this->soid != 2 && $val['id'] == 14))
					continue;

				if ($this->soid) {
					if ($val['id'] == 29 || ($this->soid < 3 && $val['id'] == 30))
						continue;

					$soidTmp = $this->soid > 3 ? 3 : $this->soid;
					$info = C('SORT');
					$info = $info[$soidTmp];
					$sortName = $info['name'];
					$subSecTmp[$key] = $val;
					$subSecTmp[$key]['name'] = $sortName . $val['name'];
				} elseif ($this->sid || $sid) {
					$sid_selrct = $sid ? $sid : $this->sid;
					if ($sid_selrct == 1 && in_array($val['id'], array(13, 14, 16, 23, 25, 30)))
						continue;
					if ($sid_selrct == 2 && in_array($val['id'], array(11, 14, 23, 25, 29, 30)))
						continue;
					if ($sid_selrct == 3 && in_array($val['id'], array(12, 13, 21, 25, 29, 30)))
						continue;
					if ($sid_selrct == 4 && in_array($val['id'], array(13, 21, 25, 29, 30)))
						continue;
					if ($sid_selrct == 5 && in_array($val['id'], array(14, 23, 25, 29, 30)))
						continue;
					$info = C('SPECIAL_COLUMN');
					$info = $info[$sid_selrct];
					$speColName = $info['name'];
					$subSecTmp[$key] = $val;
					$subSecTmp[$key]['name'] = $speColName . $val['name'];
				}
				else {
					if ($val['id'] == 29 || $val['id'] == 30)
						continue;

					$subSecTmp[$key] = $val;
				}
			}
		}
		return $subSecTmp;
	}

	//通过不同策略统计筛选项
	protected function createAttributeSift($field = '*', $map = array()) {
		$list = explode(",", $field);
		$attrArr = array(
			array('field' => 'area_no_list', 'table' => 'AttributeArea'),
			array('field' => 'book_id_list', 'table' => 'AttributeBook'),
			array('field' => 'brand_id_list', 'table' => 'AttributeBrand'),
			array('field' => 'designer_id_list', 'table' => 'AttributeDesigner'),
			array('field' => 'season_id_list', 'table' => 'AttributeSeason'),
			array('field' => 'acc_id_list', 'table' => 'AttributeAcc'),
		);

		foreach ($list as $k => $v) {
			foreach ($attrArr as $ke => $va) {
				if ($v == $va['field']) {
					$f = $v == 'area_no_list' ? 'no' : 'id';
					$fieldname = substr($v, 0, strpos($v, '_')) . '_' . $f; //取得该统计的字段
					$sMap = array();
					$join = array();
					$table = $this->tableArr['folder'] ? $this->tableArr['folder'] : $this->tableArr['subject'];
					$ftable = $this->tableArr['folder_original'] ? $this->tableArr['folder_original'] : $this->tableArr['subject_original'];
					$stable = $this->tableArr['ref_folder_sort_original'] ? $this->tableArr['ref_folder_sort_original'] : $this->tableArr['ref_subject_sort_original'];
					$ctable = $this->tableArr['ref_folder_column_original'] ? $this->tableArr['ref_folder_column_original'] : $this->tableArr['ref_subject_column_original'];
					$tid = $this->tableArr['folder'] ? 'folder' : 'subject';
					if (in_array($map['menu_id'], array(20, 21, 23, 25, 26, 27, 28, 29)) or in_array($map['child_menu_id'], array(66, 67, 68))) {
						$table = $this->tableArr['subject'];
						$ftable = $this->tableArr['subject_original'];
						$stable = $this->tableArr['ref_subject_sort_original'];
						$ctable = $this->tableArr['ref_subject_column_original'];
						$tid = 'subject';
					}
					if (($this->cid == 22) and $this->sid != 4) {
						//图案栏目
						$table = $this->tableArr['picture'];
						$ftable = $this->tableArr['picture_original'];
						$stable = $this->tableArr['ref_picture_sort_original'];
						$ctable = $this->tableArr['ref_picture_column_original'];
						$tid = 'picture';
					}

					if ($map['special_column_id'] && !in_array($this->cid, array(15, 17, 22))) {
						if ($this->cid == 11) {
							if ($this->sid == 1) {
								$sMap[$this->tableArr['folder_original'] . '.child_menu_id'] = 39;
							} elseif ($this->sid == 4) {
								$sMap[$this->tableArr['folder_original'] . '.child_menu_id'] = 40;
							} elseif ($this->sid == 5) {

							} elseif ($this->sid == 2) {

							}
						} else {
							$join[] = "left join {$ctable} as sc on sc.{$tid}_id = {$ftable}.id";
							$sMap['sc.special_column_id'] = $map['special_column_id'];
						}
					}

					if ($map['special_column_id'] == 2 && in_array($this->cid, array(12, 17, 22))) {
						if ($this->cid == 12) {
							$s = $this->tableArr['ref_subject_style_original'];
							$ref_id = 'subject';
						} else {
							$s = $this->tableArr['ref_picture_style_original'];
							$ref_id = 'picture';
						}
						$join[] = "left join {$s} as sc on sc.{$ref_id}_id = {$ftable}.id";
						$sMap['sc.style_id'] = 128;
					}

					if ($map['menu_id']) {
						$sMap["{$ftable}.menu_id"] = $map['menu_id'];
					}
					if ($map['child_menu_id']) {
						$sMap["{$ftable}.child_menu_id"] = $map['child_menu_id'];
					}
					if ($v == 'acc_id_list') {
						$join[] = "left join {$this->tableArr['ref_subject_acc_original']} as sc on sc.{$tid}_id = {$ftable}.id";
					}
					if ($this->sid == 4 and $this->cid == 22) {
						$sMap["{$ftable}.menu_id"] = 10;
					}
					if ($this->cid == 27) {
						$join[] = "left join sxxl_ref_subject_menu sm on sm.subject_id = ${ftable}.id";
						$sMap['sm.child_menu_id'] = $map['child_menu_id'];
						unset($sMap["{$ftable}.menu_id"]);
						unset($sMap["{$ftable}.child_menu_id"]);
					}
					if (in_array($map['sort_id'], array(1, 2))) {
						$join[] = "left join {$stable} as fs on fs.{$tid}_id = {$ftable}.id";
						$sMap['fs.sort_id'] = $map['sort_id'];
					} elseif (!in_array($this->cid, array(15, 24, 25))) {
						$join[] = "left join {$stable} as fs on fs.{$tid}_id = {$ftable}.id";
						$sMap['fs.sort_id'] = array('egt', 3);
						//unset($map['sort_id']);
						//var_dump($map['sort_id']);
						//var_dump($map);
						$map['sort_id'] = 3;
					}

					$sMap['is_publish'] = 1;
					$row = M($table)->field($fieldname)->join($join)->where($sMap)->findAll();
					//$row = M($va['table'])->field($f)->findAll();
					//echo M($table)->getLastSql()."sdfadsf<br/>";
					$id_list = '';
					$tmp = array();
					foreach ($row as $t => $x) {
						if ($x[$fieldname])
							$tmp[$x[$fieldname]] = 1;
						//$id_list .=$x[$field].',';
					}
					foreach ($tmp as $t => $x) {
						$id_list .=$t . ',';
					}
					$data = array();
					$t = M('AttributeSift')->where($map)->find();
					//echo M('AttributeSift')->getLastSql()."~~~~~~~~~</br>";
					if (empty($t)) {
						//没有记录就新增
						$data = $map;
						$data[$v] = $id_list;
						M('AttributeSift')->data($data)->add();
						//echo M('AttributeSift')->getLastSql()."111111111</br>";
					} else {
						M('AttributeSift')->where($map)->setField($v, $id_list);
						//echo M('AttributeSift')->getLastSql()."22222222222</br>";
					}
				}
			}
		}
	}

	/**
	 * 获取各个栏目下的相应属性
	 * return array
	 */
	protected function getAttributeSift($field = '*', $map = array(), $isSingle = true) {
		//$this->createAttributeSift($field,$map);

		$attrArr = array(
			array('field' => 'area_no_list', 'table' => 'AttributeArea'),
			array('field' => 'book_id_list', 'table' => 'AttributeBook'),
			array('field' => 'brand_id_list', 'table' => 'AttributeBrand'),
			array('field' => 'designer_id_list', 'table' => 'AttributeDesigner'),
			array('field' => 'season_id_list', 'table' => 'AttributeSeason'),
			array('field' => 'acc_id_list', 'table' => 'AttributeAcc'),
		);
		$siftArr = M('AttributeSift')->where($map)->field($field)->findAll();
		//echo M('AttributeSift')->getLastSql()."</br>";
		//dump($siftArr);exit;
		if ($siftArr) {
			foreach ($siftArr as $key => $val) {
				foreach ($attrArr as $ke => $va) {
					$fieldTmp = $va['field'];
					if ($val[$fieldTmp])
						$$fieldTmp .= $val[$fieldTmp] . ',';
				}
			}
			foreach ($attrArr as $key => $val) {
				$fieldTmp = $val['field'];
				if (in_array($fieldTmp, array('area_no_list')))
					$fTmp = 'no';
				else
					$fTmp = 'id';

				$ex = substr($fieldTmp, 0, strpos($fieldTmp, '_'));
				$cruSift = F($ex . 'List', '', C('DATA_CACHE_PATH'));
				$attrIdString = substr($$fieldTmp, 0, -1);
				if ($attrIdString) {
					$attrIdArr = array_unique(explode(',', $attrIdString));
					foreach ($attrIdArr as $ke => $va) {
						if (empty($va) || $fTmp == 'no' && $va < 65536)
							continue;
						$name = $fieldTmp == 'season_id_list' ? 'en_name' : 'name';
						if ($fieldTmp == 'area_no_list') {
							if ($va) {
								$ano = dechex($va);
								if (substr($ano, -4, 4) !== '0000') {
									if (substr($ano, -2, 2) === '00') {
										//一级
										$anoTmp = hexdec(substr($ano, 0, -4) . "0000");
										$Arr[$fieldTmp][$anoTmp]['no'] = $anoTmp;
										$Arr[$fieldTmp][$anoTmp][$name] = $cruSift[$anoTmp][$name];
										$Arr[$fieldTmp][$anoTmp]['parent_no'] = $cruSift[$anoTmp]['parent_no'];
									} else {
										//一级
										$anoTmp = hexdec(substr($ano, 0, -4) . "0000");
										$Arr[$fieldTmp][$anoTmp]['no'] = $anoTmp;
										$Arr[$fieldTmp][$anoTmp][$name] = $cruSift[$anoTmp][$name];
										$Arr[$fieldTmp][$anoTmp]['parent_no'] = $cruSift[$anoTmp]['parent_no'];
										//二级
										$anoTmp = hexdec(substr($ano, 0, -2) . "00");
										$Arr[$fieldTmp][$anoTmp]['no'] = $anoTmp;
										$Arr[$fieldTmp][$anoTmp][$name] = $cruSift[$anoTmp][$name];
										$Arr[$fieldTmp][$anoTmp]['parent_no'] = $cruSift[$anoTmp]['parent_no'];
									}
								}
								$Arr[$fieldTmp][$va][$fTmp] = $va;
								$Arr[$fieldTmp][$va][$name] = $cruSift[$va][$name];
								$Arr[$fieldTmp][$va]['parent_no'] = $cruSift[$va]['parent_no'];
							}
						} else {
							$Arr[$fieldTmp][$va][$fTmp] = $va;
							$Arr[$fieldTmp][$va][$name] = $cruSift[$va][$name];
							$Arr[$fieldTmp][$va]['order_id'] = $cruSift[$va]['order_id'];
						}
					}
				}
			}
		}
		return $isSingle ? $Arr[$field] : $Arr;
	}

	/**
	 * 获取相应栏目的MORL链接
	 * @param int $cid
	 * return string
	 */
	protected function getMoreUrl($cid) {
		if (empty($cid))
			return fasle;
		return $cid == 28 ? U('/' . $this->subSec[12]['name'] . '/themeList') : U('/' . $this->subSec[$cid]['name'] . '/index');
	}

	/**
	 * 获取多条相应推荐数据
	 * @param int $cid
	 * @param int $position
	 * @param string $limit
	 * return array
	 */
	protected function getRecList($position, $limit = '10') {
		if (empty($position))
			return false;

		$position_id = M("sysRecommendPosition")->getField('id', array('name' => $position));
		$map['position_id'] = $position_id;
		$field = "id,picture_url,title,menu_id,is_folder,subject_id,position_id,`describe`,recommend_time";
		$dataList = M('SysRecommend')->where($map)->order(array('recommend_time' => 'desc'))->field($field)->limit($limit)->findAll();
		if (is_array($dataList)) {
			foreach ($dataList as $key => $val) {
				$dataList[$key]['title_pic'] = show_pic_path($val['picture_url']);

				if (in_array($position, array('A1', 'B1', 'C1', 'D1'))) {//时装发布物殊处理
					$tableArr = getCidModel(12);
					$hasType = M($tableArr['folder'])->getField('has_type', array('id' => $val['subject_id']));
					if ($hasType & 4)
						$dataList[$key]['url'] = U("/" . $this->subSec[$val['menu_id']]['name'] . "/folderDetail", array('fid' => $val['subject_id'], 'type' => 4));

					if ($hasType & 2)
						$dataList[$key]['url'] = $voList[$key]['url'] ? $voList[$key]['url'] : U("/" . $this->subSec[$val['menu_id']]['name'] . "/folderDetail", array('fid' => $val['subject_id'], 'type' => 2));

					if ($hasType & 1)
						$dataList[$key]['url'] = $voList[$key]['url'] ? $voList[$key]['url'] : U("/" . $this->subSec[$val['menu_id']]['name'] . "/folderDetail", array('fid' => $val['subject_id'], 'type' => 1));
				}
				else {
					$dataList[$key]['url'] = $val['is_folder'] ? U('/' . $this->subSec[$val['menu_id']]['name'] . '/folderDetail', array('fid' => $val['subject_id'])) : U('/' . $this->subSec[$val['menu_id']]['name'] . '/themeDetail', array('tid' => $val['subject_id']));
				}

				$dataList[$key]['publish_time'] = date('Y-m-d', $val['recommend_time']);
				if (in_array($val['menu_id'], array(17, 18)) && $this->soid) {
					$area_no = $val['is_folder'] ? $this->modelF->getField('area_no', array('id' => $val['subject_id'])) : $this->modelT->getField('area_no', array('id' => $val['subject_id']));
					$dataList[$key]['areaStr'] = M('AttributeArea')->where("id='{$area_no}'")->getField('name');
				}
				if ($this->sid) {
					$season_id = $val['is_folder'] ? $this->modelF->getField('season_id', array('id' => $val['subject_id'])) : $this->modelT->getField('season_id', array('id' => $val['subject_id']));
					$dataList[$key]['seasonStr'] = M('AttributeSeason')->where("id='{$val['season_id']}'")->getField('en_name');
				}
				$dataList[$key]['content'] = strip_tags($val['describe']);
			}
		}
		return $dataList;
	}

	/**
	 * 获取一条相应推荐数据
	 * @param int $cid
	 * @param int $position
	 * return array
	 */
	protected function getRecOne($position) {
		if (empty($position))
			return false;
		$position_id = M("sysRecommendPosition")->getField('id', array('name' => $position));
		$map['position_id'] = $position_id;
		$field = "id,picture_url,title,menu_id,is_folder,subject_id,position_id,`describe`,recommend_time";
		$dataList = D('SysRecommend')->where($map)->order(array('recommend_time' => 'desc'))->field($field)->find();
		//echo D('SysRecommend')->getLastSql()."</br>";
		if ($dataList) {
			$dataList['title_pic'] = show_pic_path($dataList['picture_url']);
			if ($dataList['menu_id'] == 24) {
				$child_menu_id = D('PatternSubject')->getField('child_menu_id', array('id' => $dataList['subject_id']));
				$dataList['url'] = $dataList['is_folder'] ? U('/' . $this->subSec[$dataList['menu_id']]['name'] . '/folderDetail', array('fid' => $dataList['subject_id'])) : U('/' . $this->subSec[$dataList['menu_id']]['name'] . '/themeDetail', array('cmid' => $child_menu_id, 'tid' => $dataList['subject_id']));
			} else {
				$dataList['url'] = $dataList['is_folder'] ? U('/' . $this->subSec[$dataList['menu_id']]['name'] . '/folderDetail', array('fid' => $dataList['subject_id'])) : U('/' . $this->subSec[$dataList['menu_id']]['name'] . '/themeDetail', array('tid' => $dataList['subject_id']));
			}
			$dataList['publish_time'] = date('Y-m-d', $dataList['recommend_time']);
			if (in_array($dataList['menu_id'], array(17, 18)) && $this->soid) {
				$area_no = $dataList['is_folder'] ? $this->modelF->getField('area_no', array('id' => $dataList['subject_id'])) : $this->modelT->getField('area_no', array('id' => $dataList['subject_id']));
				$dataList['areaStr'] = M('AttributeArea')->where("id='{$area_no}'")->getField('name');
			}
			if ($this->sid) {
				$season_id = $dataList['is_folder'] ? $this->modelF->getField('season_id', array('id' => $dataList['subject_id'])) : $this->modelT->getField('season_id', array('id' => $dataList['subject_id']));
				$dataList['seasonStr'] = M('AttributeSeason')->where("id='{$season_id}'")->getField('en_name');
			}
			$dataList['content'] = strip_tags($dataList['describe']);
		}
		return $dataList;
	}

	//款式
	protected function getStyleList($cid) {
		if (!$cid)
			return false;

		$stid = $this->param['stid'];
		$map['menu_id'] = $cid;

		$soid = $this->getSoid();
		if ($soid)
			$map['sort_id'] = $soid;

		$styles = M('RefMenuStyle')->where($map)->field('style_id')->findAll();
		//echo M('RefMenuStyle')->getLastSql();
		if (!is_array($styles))
			return false;

		$voList = array();
		$this->styles = F('styleList', '', C('DATA_CACHE_PATH'));
		//dump($this->styles);
		foreach ($styles as $key => $val) {
			if (!is_array($this->styles[$val['style_id']]) || $this->styles[$val['style_id']]['parent_id'] != 0)
				continue;

			$voList[$key]['id'] = $val['style_id'];
			$voList[$key]['name'] = $this->styles[$val['style_id']]['name'];

			if (in_array($cid, array(17, 22)) || (in_array($cid, array(12, 18)) && ACTION_NAME == 'pictureList'))
				$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/pictureList', array('stid' => $val['style_id']));
			elseif ($cid == 16 || ($cid == 26 && $this->sid)) {
				$soid = $this->getSoid();
				$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/index', array('soid' => $soid, 'stid' => $val['style_id']));
			}
			else
				$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/index', array('stid' => $val['style_id']));

			$voList[$key]['selected'] = $stid == $val['style_id'] ? true : false;
		}

		foreach ($voList as $key => $val) {
			foreach ($styles as $ke => $va) {
				if (!is_array($this->styles[$va['style_id']]) || $this->styles[$va['style_id']]['parent_id'] != $val['id'])
					continue;

				$voList[$key]['thirdMenu'][$ke]['name'] = $this->styles[$va['style_id']]['name'];

				if (in_array($cid, array(17, 22)) || (in_array($cid, array(12, 18)) && ACTION_NAME == 'pictureList'))
					$voList[$key]['thirdMenu'][$ke]['url'] = U('/' . $this->subSec[$cid]['name'] . '/pictureList', array('stid' => $va['style_id']));
				elseif ($cid == 16 || ($cid == 26 && $this->sid)) {
					$soid = $this->getSoid();
					$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/index', array('soid' => $soid, 'stid' => $val['style_id']));
				}
				else
					$voList[$key]['thirdMenu'][$ke]['url'] = U('/' . $this->subSec[$cid]['name'] . '/index', array('stid' => $va['style_id']));

				if ($stid == $va['style_id']) {
					$voList[$key]['thirdMenu'][$ke]['selected'] = true;
					$voList[$key]['selected'] = true;
				}
			}
		}

		unset($styles);
		return $voList;
	}

	//栏目
	protected function getSubMenuList($cid) {
		if (!$cid)
			return false;
		$menus = F('menuList', '', C('DATA_CACHE_PATH'));
		$voList = array();
		foreach ($menus as $key => $val) {
			if ($val['parent_id'] == $cid) {
				if ($cid == 11 && $this->sid == 4 && !in_array($val['id'], array(36, 37, 40)))
					continue;

				if ($cid == 12 && in_array($this->sid, array(1, 2, 4, 5)) && !in_array($val['id'], array(31, 33)))
					continue;
				if ($cid == 17 && !in_array($val['id'], array(54, 56))) {
					continue;
				}

				if ($cid == 27 && $this->getSoid() > 2 && $val['id'] == 89)
					continue;

				if ($cid == 24) {
					if ($val['id'] == 70)
						$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/pictureList', array('cmid' => $val['id']));
					elseif (in_array($val['id'], array(65, 69)))
						$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/folderList', array('cmid' => $val['id']));
					else
						$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/themeList', array('cmid' => $val['id']));
				}
				elseif ($cid == 20 || $cid == 25)
					$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/index', array('cmid' => $val['id'], 'soid' => intval($this->param['soid'])));
				elseif (in_array($cid, array(11, 12, 13, 15)) || ($cid == 18 && $val['id'] == 55)) {
					if ($cid == 11 && $this->soid == 3 && in_array($val['id'], array(38, 83)))
						continue;

					if ($cid == 12 && $this->soid == 1 && !in_array($val['id'], array(31, 34)))
						continue;

					$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/folderList', array('cmid' => $val['id'], 'soid' => intval($this->param['soid'])));
				}
				else
					$voList[$key]['url'] = U('/' . $this->subSec[$cid]['name'] . '/themeList', array('cmid' => $val['id'], 'soid' => intval($this->param['soid'])));

				$voList[$key]['selected'] = $this->cmid == $val['id'] ? true : false;
				$voList[$key]['id'] = $val['id'];
				$voList[$key]['name'] = $val['name'];
				$voList[$key]['name_en'] = $val['name_en'];
			}
		}
		return $voList;
	}

	/**
	 * @获取对应栏目中最新发布主题信息
	 * @param int $cid
	 * @param int $sort_id
	 * @param int $limit
	 * @param int $type 1:男女童 ， 2：专栏
	 * @return array $voList
	 */
	protected function getNewlist($cid = '17', $sort_special_id = '2', $limit = '4', $type = '1') {
		$tmpTableArr = getCidModel($cid);
		if ($tmpTableArr['subject']) {
			$subjectModel = D($tmpTableArr['subject']);
		}
		$map[$tmpTableArr['subject_original'] . '.menu_id'] = $map_sub['menu_id'] = $cid == 17 && $this->sid == 4 ? 101 : $cid;
		if ($type == 1) {//性别
			$tmpTypeModel = $tmpTableArr['ref_subject_sort_original'];
			$type_str = 'sort_id';
			//$map['rss.sort_id'] = $sort_special_id;
			//$sub_sql = "select subject_id from {$tmpTypeModel} where sort_id = '{$sort_special_id}' ";
			//$map['id'] = array('exp'," in($sub_sql) ");

			$map_sub['sort_id'] = $sort_special_id;
			$subList = M($tmpTableArr['ref_subject_sort'])->where($map_sub)->order(array("id" => 'desc'))->field('subject_id')->limit(40)->findAll();
			//echo M($tmpTableArr['ref_subject_sort'])->getLastSql();
            if ($subList) {
				$ids = array();
				foreach ($subList as $k => $v)
					$ids[] = $v['subject_id'];
				$map['id'] = array('exp', ' in(' . implode(',', $ids) . ') ');
			}
		} elseif ($type == 2) {//专栏
			$tmpTypeModel = $tmpTableArr['ref_subject_column_original'];
			$type_str = 'special_column_id';
			//$map['rss.special_column_id'] = $sort_special_id;
			//$sub_sql = "select subject_id from {$tmpTypeModel} where special_column_id = '{$sort_special_id}' ";
			//$map['id'] = array('exp'," in($sub_sql) ");

			$map_sub['special_column_id'] = $sort_special_id;
			$subList = M($tmpTableArr['ref_subject_column'])->where($map_sub)->order(array("id" => 'desc'))->field('subject_id')->limit(40)->findAll();
			//echo M($tmpTableArr['ref_subject_column'])->getLastSql().'<br/>';
			if ($subList) {
				$ids = array();
				foreach ($subList as $k => $v)
					$ids[] = $v['subject_id'];
				$map['id'] = array('exp', ' in(' . implode(',', $ids) . ') ');
			}
		}

		$map['is_publish'] = 1;
		$map['publish_time'] = array('elt', C('TODAY_LAST_TIME'));
		//$field = $tmpTableArr['subject_original'].".id,title,title_picture_url,".$tmpTableArr['subject_original'].".menu_id,".$tmpTableArr['subject_original'].".child_menu_id,area_no,season_id,publish_time,rss.".$type_str;
		$field = "id,title,title_picture_url,menu_id,child_menu_id,area_no,season_id,publish_time ";

		$join[] = $tmpTypeModel . ' rss ON rss.subject_id=' . $tmpTableArr['subject_original'] . '.id';

		//$voList = $subjectModel->where($map)->field($field)->join($join)->order(array('publish_time' => 'desc','id' => 'desc'))->limit($limit)->findAll();

		$listKey = md5(MODULE_NAME . ACTION_NAME . "::" . serialize($map) . '::' . $this->sid . '::' . $this->soid . "::getNewlist::" . $cid);
		if (!$voList = $this->cache->get($listKey)) {
			$voList = $subjectModel->where($map)->field($field)->order(array('publish_time' => 'desc', 'id' => 'desc'))->limit($limit)->findAll();
            //echo $subjectModel->getLastSql().'<br/>';
            $this->areas = F('areaList', '', C('DATA_CACHE_PATH'));
			foreach ($voList as $key => & $val) {
				$val[$type_str] = $sort_special_id; //还原缺失字段
				if ($val['area_no']) {
					$voList[$key]['area_str'] = $this->areas[$val['area_no']]['name'];
				}
				if ($val['title_picture_url']) {
					$voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
				}
				if ($type == 1) {
					$voList[$key]['url'] = U("/" . $this->subSec[$cid]['name'] . "/themeDetail", array('cmid' => $val['child_menu_id'], 'soid' => $val['sort_id'], 'tid' => $val['id']));
				} else {
					$voList[$key]['url'] = U("/" . $this->subSec[$cid]['name'] . "/themeDetail", array('cmid' => $val['child_menu_id'], 'sid' => $val['special_column_id'], 'tid' => $val['id']));
				}
				$voList[$key]['publish_time_str'] = date('Y-m-d', $val['publish_time']);
			}
			$this->cache->set($listKey, $voList);
		}
		return $voList;
	}

	/**
	 * @获取对应栏目中最新发布主题信息
	 * @param int $cid
	 * @param int $sort_id
	 * @param int $limit
	 * @param int $type 1:男女童 ， 2：专栏
	 * @return array $voList
	 */
	protected function getInvogueNewlistBySphinx($sort_special_id = '2', $limit = '4', $type = '1') {
		import('@.ORG.Search');
		$search = new Search();
		$search->setSortMode(SPH_SORT_EXTENDED, 'publish_time desc,id desc');
		$search->setPageSize(4);
		$search->setPage(1);

		$search->setFilterRange('publish_time', strtotime('1990-01-01 00:00:00'), C('TODAY_LAST_TIME'));

        $cid = $sort_special_id == 4 ? 101 : 17;
        $search->setFilter('menu_id', array($cid));
		if ($type == 1) {//性别
			if ($sort_special_id == 3)
				$search->setFilter('sort_id', $this->childrenSoids);
			else
				$search->setFilter('sort_id', array($sort_special_id));
		} elseif ($type == 2) {//专栏
            $search->setFilter('special_column_id', array($sort_special_id));
		}

		$listKey = md5(MODULE_NAME . '::getInvogueNewlistBySphinx::' . serialize($map) . '::' . $this->sid . '::' . $this->soid);
		$voList = '';//trim($_GET['cache']) == 'cache' ? '' : $this->cache->get($listKey);
        if (!$voList) {
			$rows = $search->query('','sxxl_invogue_subject');
			$count = intval($rows['total_found']); //下面做分页之用
            if($count > 0){
				$ids = array();
				foreach ($rows['matches'] as $k => $v){
					$ids[] = $v['id'];
                }

                $field = "id,title,title_picture_url,menu_id,child_menu_id,area_no,season_id,publish_time ";
				$voList = $this->getSubjectInfoByIds($cid,$ids, $field);

                $this->areas = F('areaList', '', C('DATA_CACHE_PATH'));
                foreach ($voList as $key => & $val) {
                    $val[$type_str] = $sort_special_id; //还原缺失字段
                    if ($val['area_no']) {
                        $voList[$key]['area_str'] = $this->areas[$val['area_no']]['name'];
                    }
                    if ($val['title_picture_url']) {
                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                    }
                    if ($type == 1) {
                        $voList[$key]['url'] = U("/" . $this->subSec[$cid]['name'] . "/themeDetail", array('cmid' => $val['child_menu_id'], 'soid' => $sort_special_id, 'tid' => $val['id']));
                    } else {
                        $voList[$key]['url'] = U("/" . $this->subSec[$cid]['name'] . "/themeDetail", array('cmid' => $val['child_menu_id'], 'sid' => $sort_special_id, 'tid' => $val['id']));
                    }
                    $voList[$key]['publish_time_str'] = date('Y-m-d', $val['publish_time']);
                }
            }

			$this->cache->set($listKey, $voList);
		}
		return $voList;
	}

    protected function getSubjectInfoByIds($cid = '17',$ids,$field){
        if(empty($field)){
            $field = 'id,title,title_picture_url,publish_time,area_no,season_id,pv_count,picture_count';
        }

		$tableArr = getCidModel($cid);
        $order = array('publish_time'=>'desc','id'=>'desc');
        if($this->param['date']){
            $order = array_merge(array('pv_count'=>'desc'),$order);
        }

		$row = M($tableArr['subject'])->where( 'id in('.implode(',',$ids).')' )->field($field)->order($order)->select();
        //echo $MODEL->getLastSql()."<br/>";
		return $row;
    }

	//是否试用
	public function checkIsTry() {

		if ($this->isRightB == false) {
			return false;
		}
		if ($this->loginInfo['vipInfoArr']['1']['id']
				&& $this->loginInfo['vipInfoArr']['1']['is_try'] != 1) {
			return true;
		}

		if (strpos(MODULE_NAME, 'Women') !== false) {
			if ($this->loginInfo['vipInfoArr']['2']['id']
					&& $this->loginInfo['vipInfoArr']['2']['is_try'] != 1) {
				return true;
			}
		} else if (strpos(MODULE_NAME, 'Men') !== false) {
			if ($this->loginInfo['vipInfoArr']['3']['id']
					&& $this->loginInfo['vipInfoArr']['3']['is_try'] != 1) {
				return true;
			}
		} else if (strpos(MODULE_NAME, 'Children') !== false) {
			if ($this->loginInfo['vipInfoArr']['4']['id']
					&& $this->loginInfo['vipInfoArr']['4']['is_try'] != 1) {
				return true;
			}
		} else if (strpos(MODULE_NAME, 'Cowboy') !== false) {//牛仔
			if ($this->loginInfo['vipInfoArr']['20']['id']
					&& $this->loginInfo['vipInfoArr']['20']['is_try'] != 1) {
				return true;
			}
		} else if (strpos(MODULE_NAME, 'Pants') !== false) {//裤子
			if ($this->loginInfo['vipInfoArr']['21']['id']
					&& $this->loginInfo['vipInfoArr']['21']['is_try'] != 1) {
				return true;
			}
		} else if (strpos(MODULE_NAME, 'Woolens') !== false) {//毛织
			if ($this->loginInfo['vipInfoArr']['23']['id']
					&& $this->loginInfo['vipInfoArr']['23']['is_try'] != 1) {
				return true;
			}
		} else if (strpos(MODULE_NAME, 'Underwear') !== false) {//内衣
			if ($this->loginInfo['vipInfoArr']['24']['id']
					&& $this->loginInfo['vipInfoArr']['24']['is_try'] != 1) {
				return true;
			}
		}

		return false;
	}
}
