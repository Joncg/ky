<?php
class MenFashionStyleAction extends FashionStyleAction {

    public function _initialize() {
        $this->soid = 1;
        parent::_initialize();
    }

    public function index() {
        parent::index();
    }

    public function getPictureListByAjax() {
        parent::getPictureListByAjax();
    }

    public function themeList() {
        parent::themeList();
    }

    public function themeDetail($tid = '') {
        parent::themeDetail($tid);
    }

    public function pictureList() {
        parent::pictureList();
    }

    public function brandSearch() {
        parent::brandSearch();
    }

    public function detail() {
        $this->styles = array(
                '1'=>array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>1)),'selected'=>($this->param['stid'] == 1 ? true : false)),
                '66'=>array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>66)),'selected'=>($this->param['stid'] == 66 ? true : false)),
                '95'=>array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>95)),'selected'=>($this->param['stid'] == 95 ? true : false)),
                '128'=>array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>128)),'selected'=>($this->param['stid'] == 128 ? true : false)),
                '284'=>array('id'=>284,'name'=>'大衣风衣','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>284)),'selected'=>($this->param['stid'] == 284 ? true : false)),
                '211'=>array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>211)),'selected'=>($this->param['stid'] == 211 ? true : false)),
                '29'=>array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>29)),'selected'=>($this->param['stid'] == 29 ? true : false)),
                '264'=>array('id'=>264,'name'=>'棉衣羽绒','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>264)),'selected'=>($this->param['stid'] == 264 ? true : false)),
                '276'=>array('id'=>276,'name'=>'卫衣','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>276)),'selected'=>($this->param['stid'] == 276 ? true : false)),
                '256'=>array('id'=>256,'name'=>'皮衣皮草','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>256)),'selected'=>($this->param['stid'] == 256 ? true : false)),
                '152'=>array('id'=>152,'name'=>'运动','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>152)),'selected'=>($this->param['stid'] == 152 ? true : false)),
                '320'=>array('id'=>320,'name'=>'情侣装','url'=>U('/'.MODULE_NAME.'/detail',array('stid'=>320)),'selected'=>($this->param['stid'] == 320 ? true : false)),
            );
        $this->assign('childMenus',$this->styles);
        parent::detail();
    }

    protected function getSpecialChildMenu() {
        $soid = parent::getSoid();
        $stid = $this->param['stid'];
        $specialChildMenu = array(
            array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1,24,4)),
                'thirdMenu'=>
                array(
                    array('id'=>24,'name'=>'图案T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>24)),'selected'=>$stid == 24),
                    array('id'=>4,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>4)),'selected'=>$stid == 4),
                )
            ),
            array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66,84,77)),
                'thirdMenu'=>
                array(
                    array('id'=>84,'name'=>'套头','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>84)),'selected'=>$stid == 84),
                    array('id'=>77,'name'=>'开襟','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>77)),'selected'=>$stid == 77),
                 )
            ),
            array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95,103,96,121)),
                'thirdMenu'=>
                array(
                    array('id'=>103,'name'=>'开襟','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>103)),'selected'=>$stid == 103),
                    array('id'=>96,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>96)),'selected'=>$stid == 96),
                    array('id'=>121,'name'=>'套头','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>121)),'selected'=>$stid == 121),
                )
            ),
            array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'selected'=>in_array($stid,array(128,150,132,137,131,140,129,143)),
                'thirdMenu'=>
                array(
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150)),'selected'=>$stid == 150),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132)),'selected'=>$stid == 132),
                    array('id'=>137,'name'=>'连体裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>137)),'selected'=>$stid == 137),
                    array('id'=>131,'name'=>'吊档裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>131)),'selected'=>$stid == 131),
                    array('id'=>140,'name'=>'商务裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>140)),'selected'=>$stid == 140),
                    array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>129)),'selected'=>$stid == 129),
                    array('id'=>143,'name'=>'五-七分裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>143)),'selected'=>$stid == 143),
                )
            ),
            array('id'=>284,'name'=>'大衣风衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>284)),'selected'=>in_array($stid,array(284,285,288)),
                'thirdMenu'=>
                array(
                    array('id'=>285,'name'=>'大衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>285)),'selected'=>$stid == 285),
                    array('id'=>288,'name'=>'风衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>288)),'selected'=>$stid == 288),
                )
            ),
            array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'selected'=>in_array($stid,array(211,232,227,234)),
                'thirdMenu'=>
                array(
                    array('id'=>232,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>232)),'selected'=>$stid == 232),
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227)),'selected'=>$stid == 227),
                    array('id'=>234,'name'=>'中裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>234)),'selected'=>$stid == 234),
                )
            ),
            array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>29)),'selected'=>in_array($stid,array(29,37,55,34,39)),
                'thirdMenu'=>
                array(
                    array('id'=>37,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>37)),'selected'=>$stid == 37),
                    array('id'=>55,'name'=>'西装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>55)),'selected'=>$stid == 55),
                    array('id'=>34,'name'=>'夹克','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>34)),'selected'=>$stid == 34),
                    array('id'=>39,'name'=>'尼克服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>39)),'selected'=>$stid == 39),
                 )
            ),
            array('id'=>264,'name'=>'棉衣羽绒','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>264)),'selected'=>in_array($stid,array(264,267,270,269)),
                'thirdMenu'=>
                array(
                    array('id'=>267,'name'=>'棉服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>267)),'selected'=>$stid == 267),
                    array('id'=>270,'name'=>'羽绒服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>270)),'selected'=>$stid == 270),
                    array('id'=>269,'name'=>'羽绒背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>269)),'selected'=>$stid == 269),
                )
            ),
            array('id'=>276,'name'=>'卫衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>276)),'selected'=>in_array($stid,array(276,282,277)),
                'thirdMenu'=>
                array(
                    array('id'=>282,'name'=>'套头','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>282)),'selected'=>$stid == 282),
                    array('id'=>277,'name'=>'开襟','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>277)),'selected'=>$stid == 277),
                )
            ),
            array('id'=>256,'name'=>'皮衣皮草','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>256)),'selected'=>in_array($stid,array(256,257,259,258,262)),
                'thirdMenu'=>
                array(
                    array('id'=>257,'name'=>'皮毛一体','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>257)),'selected'=>$stid == 257),
                    array('id'=>259,'name'=>'皮革','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>259)),'selected'=>$stid == 259),
                    array('id'=>258,'name'=>'皮草','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>258)),'selected'=>$stid == 258),
                    array('id'=>262,'name'=>'洗水皮','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>262)),'selected'=>$stid == 262),
                )
            ),
            array('id'=>152,'name'=>'运动','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152,168,153,172,155,164,177,170,167,160)),
                'thirdMenu'=>
                array(
                    array('id'=>168,'name'=>'运动T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>168)),'selected'=>$stid == 168),
                    array('id'=>153,'name'=>'POLO衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>153)),'selected'=>$stid == 153),
                    array('id'=>172,'name'=>'运动套装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>172)),'selected'=>$stid == 172),
                    array('id'=>155,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>155)),'selected'=>$stid == 155),
                    array('id'=>164,'name'=>'梭织外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>164)),'selected'=>$stid == 164),
                    array('id'=>177,'name'=>'针织外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>177)),'selected'=>$stid == 177),
                    array('id'=>170,'name'=>'运动裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>170)),'selected'=>$stid == 170),
                    array('id'=>167,'name'=>'羽绒棉服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>167)),'selected'=>$stid == 167),
                    array('id'=>160,'name'=>'户外','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>160)),'selected'=>$stid == 160),
                 )
            ),
            array('id'=>320,'name'=>'情侣装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>320)),'selected'=>$stid == 320)
        );

        return $specialChildMenu;
    }

	public function downloadzip() {
		parent::downloadzip();
	}
}
