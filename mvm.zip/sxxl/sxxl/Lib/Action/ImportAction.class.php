<?php
class ImportAction extends CommonAction{

    public function _initialize() {
        $this->in = M('SysArea');
        $this->province = M('ProvinceCode');
        $this->city = M('CityCode');
        $this->area = M('AreaCode');
    }

    public function index(){
        exit('别乱操作！');
        $voList = $this->province->findAll();
        echo $this->province->getLastSql()."<br/>";
        if($voList){
            foreach($voList as $key=>$val){
                $data = array();
                $data['parent_id'] = 0;
                $data['name'] = $val['name'];
                $this->in->add($data);
                $nPid = $this->in->getLastInsID();
                echo $this->in->getLastSql()."<br/>";
                if($nPid)
                   $this->city ($nPid,$val['id']);
            }
        }
        exit('OK');
    }

    public function city($nPid,$oPid){
        if(empty($nPid) || empty($oPid))
            return false;

        $voList = $this->city->where(array('province_id'=>$oPid))->findAll();
        echo $this->city->getLastSql()."<br/>";
        if($voList){
            foreach($voList as $key =>$val){
                $data = array();
                $data['parent_id'] = $nPid;
                $data['name'] = $val['name'];
                $this->in->add($data);
                echo $this->in->getLastSql()."<br/>";
                $nCid = $this->in->getLastInsID();
                if($nCid)
                   $this->area($nCid,$val['id']);
            }
        }
    }

    public function area($nCid,$oCid){
        if(empty($nCid) || empty($oCid))
            return false;

        $voList = $this->area->where(array('city_id'=>$oCid))->findAll();
        echo $this->area->getLastSql()."<br/>";
        if($voList){
            foreach($voList as $key =>$val){
                $data = array();
                $data['parent_id'] = $nCid;
                $data['name'] = $val['name'];
                $this->in->add($data);
                echo $this->in->getLastSql()."<br/>";
            }
        }
    }
}