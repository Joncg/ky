<?php
class ChildrenManuscriptTrendAction extends ManuscriptTrendAction {

    public function _initialize() {
        $this->soid = 3;
        parent::_initialize();
    }

	public function index() {
        $this->themeList();
	}

    public function themeList(){
        parent::themeList();
    }

	public function themeDetail($tid = '') {
        $this->pListRows = 20;
        parent::themeDetail($tid);
	}
	public function downloadzip() {
		parent::downloadzip();
	}
}
