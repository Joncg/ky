<?php
class PantsPopularsAction extends PopularsAction {

    public function _initialize() {
        $this->sid = 2;
        parent::_initialize();
    }

    public function index(){
        parent::index();
	}

	public function folderDetail() {
        $this->pListRows = 20;
        parent::folderDetail();
	}
	public function downloadzip() {
        parent::downloadzip();
    }
}
