<?php

class JobAction extends CommonAction {

	function _initialize() {
		parent::_initialize();
		$this->model = D('Member');
		$this->modelRes = D("ResumeInformation");
		$this->modelarea = D('AreaCode');
		$this->modelcity = D('CityCode');
		$this->modelprovince = D('ProvinceCode');
		$this->modelcorporatejobs = D("CorporateJobs");
		//if(empty(Cookie::get(C('USER_AUTH_KEY')))){
			//$this->redirect("Job/enterpriseManager");
		//}
	}

	function updatePersonalResume() {
		$data['title'] = '个人求职_我的简历';
		$this->userAuthorized();
		if (Cookie::get('is_personal') == 1) {
			$this->resumeData();
			$this->assign($data);
			$this->display("update_personal_resume");
		}
	}

//修改简历
	function updateResume() {
		$this->userAuthorized();
		if (Cookie::get('is_personal') == 1) {
			$_POST['birthday'] = ($_POST['birthday_year'] && $_POST['birthday_month'] &&  $_POST['birthday_day']) ? strtotime($_POST['birthday_year'] ."-". $_POST['birthday_month'] ."-". $_POST['birthday_day']) : "";
			$_POST['graduated_time'] = ($_POST['graduated_time_year'] && $_POST['graduated_time_month'] &&  $_POST['graduated_time_day']) ? strtotime($_POST['graduated_time_year'] ."-". $_POST['graduated_time_month'] ."-". $_POST['graduated_time_day']) : "";
			unset($_POST['birthday_year']);
			unset($_POST['birthday_month']);
			unset($_POST['birthday_day']);
			unset($_POST['graduated_time_year']);
			unset($_POST['graduated_time_month']);
			unset($_POST['graduated_time_day']);
			unset($_POST['job_name']);
			$uid = Cookie::get(C('USER_AUTH_KEY'));
			//$_POST['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
			$_POST['edit_time'] = time();
			$_POST['province'] = ($_POST['province'] !='省') ? $_POST['province'] : "";
			$_POST['city'] = ($_POST['city'] !='市') ? $_POST['city'] : "";
			$_POST['county'] = ($_POST['county'] !='县/区') ? $_POST['county'] : "";
			
			$_POST['work_place_province'] = ($_POST['work_place_province'] !='省') ? $_POST['work_place_province'] : "";
			$_POST['work_place_city'] = ($_POST['work_place_city'] !='市') ? $_POST['work_place_city'] : "";
			$_POST['work_place_county'] = ($_POST['work_place_county'] !='县/区') ? $_POST['work_place_county'] : "";
			if ($_POST && $uid) {
				if ($this->modelRes->data($_POST)->where("member_id = '{$uid}'")->save()) {
					$this->display('update_personal_resume_ok');
				};
			}else{
				$this->error("修改失败!");
			}
		}
	}

	function seeResume() {
		$data['title'] = '个人求职_查看简历';
		$this->userAuthorized();
		if (Cookie::get('is_personal') == 1) {
			$this->resumeData();
			$this->assign($data);
			$this->display("see_personal_resume");
		}
	}

	function resumeData($ids='') {
		$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
		$Arr['currentTagB'] = ACTION_NAME;
		$Arr['id'] = $id = $ids ? $ids : Cookie::get(C('USER_AUTH_KEY'));
		$this->jobData();
		if ($ids)
			$map['id'] = $ids;
		else
			$map['member_id'] = $id;
		$info = $this->modelRes->where($map)->find();
		if (!empty($info))
			$Arr = array_merge($Arr, $info);
		if (empty($Arr['province']))
			$Arr['province'] = 0;
		if (empty($Arr['city']))
			$Arr['city'] = 0;
		if (empty($Arr['county']))
			$Arr['county'] = 0;
		$Arr['provinceArr'] = M('ProvinceCode')->field('id,name')->findAll();
		foreach ($jobdata['JobType'] as $k => $v) {
			if ($jobdata['JobNameSon'][$k][$info['job_id']]) {
				$job = $jobdata['JobNameSon'][$k][$info['job_id']];
			}
		}

		$Arr['job_name'] = $job;
		$Arr['birthday'] = date("Y", time()) - date("Y", $info['birthday']);
		
		$Arr['birthday_year'] = $info['birthday'] ? date("Y",$info['birthday']) : "";
		$Arr['birthday_month'] = $info['birthday'] ? date("n",$info['birthday']) : "";
		$Arr['birthday_day'] = $info['birthday'] ? date("j",$info['birthday']) : "";
		
		$Arr['graduated_time_year'] = $info['graduated_time'] ? date("Y",$info['graduated_time']) : "";
		$Arr['graduated_time_month'] = $info['graduated_time'] ? date("n",$info['graduated_time']) : "";
		$Arr['graduated_time_day'] = $info['graduated_time'] ? date("j",$info['graduated_time']) : "";
		
		$Arr['province_reg'] = $this->getProvince('province', $info);
		$Arr['city_reg'] = $this->getProvince('city', $info);
		$Arr['area_reg'] = $this->getProvince('county', $info);
		$Arr['work_province_reg'] = $this->getProvince('work_place_province', $info);
		$Arr['work_city_reg'] = $this->getProvince('work_place_city', $info);
		$Arr['work_area_reg'] = $this->getProvince('work_place_county', $info);
		$Arr['graduated_time_reg'] = $info['graduated_time'] ? date("Y-m-d",$info['graduated_time']) : "";
		$Arr['language_reg'] = $jobdata['languages'][$info['language']];
		$Arr['experience_reg'] = $jobdata['work_experience'][$info['experience']];
		$Arr['education_reg'] = $jobdata['educations'][$info['education']];
		$Arr['edit_time'] = $info['edit_time'] ? date("Y-m-d", $info['edit_time']) : "无";
		$Arr['add_time'] = $info['add_time'] ? date("Y-m-d", $info['add_time']) : "无";
		//echo "<pre>";
		//print_r($Arr);
		$this->assign($Arr);
	}

	function getProvince($field, $info) {
		if (in_array($field, array('province', 'work_place_province')))
			$datas = $this->modelprovince->where(array('id' => $info[$field]))->field('name')->find();
		if (in_array($field, array('city', 'work_place_city')))
			$datas = $this->modelcity->where(array('id' => $info[$field]))->field('name')->find();
		if (in_array($field, array('county', 'work_place_county')))
			$datas = $this->modelarea->where(array('id' => $info[$field]))->field('name')->find();
		if ($datas)
			return $datas['name'];
	}

	//企业用户
	function recruitment() {
		$this->userAuthorized();
		$Arr['title'] = "企业招聘_发布职位";
		if (Cookie::get('is_personal') == 0) {
			$Arr['currentTagB'] = ACTION_NAME;
			$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
			$uid = Cookie::get(C('USER_AUTH_KEY'));
			$info = $this->model->field("company_name")->where("id = '{$uid}'")->find();
			$Arr['provinceArr'] = M('ProvinceCode')->field('id,name')->findAll();
			$Arr['jobdata'] = $jobdata;
			$Arr['company_name'] = $info['company_name'];
			if ($_POST) {
				unset($_POST['JobType']);
				$_POST['add_time'] = time();
				$_POST['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
				if ($this->modelcorporatejobs->add($_POST))
					$Arr['message'] = "发布成功!";
				else
					$Arr['message'] = "发布失败!";
				$this->assign($Arr);
				$this->display('recruitment_ok');
			}
			$this->assign($Arr);
			$this->display("recruitment");
		}
	}

	//管理职位列表
	function positionList() {
		$this->userAuthorized();
		$data['title'] = "企业招聘_管理职位";
		if (Cookie::get('is_personal') == 0) {
			$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
			if ($_REQUEST['job_class'])
				$map['job_class'] = $data['job_class'] = $_REQUEST['job_class'];
			if ($_REQUEST['job_name'])
				$map['job_name'] = $data['job_name'] = $_REQUEST['job_name'];
			if ($_REQUEST['add_time']) {
				$data['add_time'] = $_REQUEST['add_time'];
				$map['add_time'] = array('ELT', strtotime("" . $jobdata['public_time'][$_REQUEST['add_time']]['time'] . "  " . date('Y-m-d', strtotime("now")) . ""));
			}
			if ($_REQUEST['search']) {
				if($_REQUEST['search'] != '请输入职位或公司名称'){
					$where['job_name'] = array('like', "%{$_REQUEST['search']}%");
					$where['company_name'] = array('like', "%{$_REQUEST['search']}%"); 
					$where['_logic'] = 'or';
					$map['_complex'] = $where;
				}
			}
			$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
			$this->positionData($map);
			$this->assign($data);
			$this->display("management_position");
		}
	}

	//职位数据
	function positionData($map) {
		import("ORG.Util.Page");
		$count = $this->modelcorporatejobs->where($map)->count();
		$Arr['count'] = $count;
		//创建分页对象
		$p = new Page($count, 8);
		$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
		$Arr['jobdata'] = $jobdata;
		$Arr['currentTagB'] = ACTION_NAME;
		$voList = $this->modelcorporatejobs->field("id,job_name,work_place_province,work_place_city,work_place_county,hire_number,salary,add_time,time_out,company_name")
						->where($map)->order(array('add_time' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->findAll();
		//echo $this->modelcorporatejobs->getLastSql();
		foreach ($voList as $k => $v) {
			$voList[$k]['work_place_province'] = $this->getProvince('work_place_province', $v);
			$voList[$k]['work_place_city'] = $this->getProvince('work_place_city', $v);
			$voList[$k]['work_place_county'] = $this->getProvince('work_place_county', $v);
			$voList[$k]['add_time'] = date('Y-m-d', $v['add_time']);
			$voList[$k]['end_time'] =( $v['time_out'] == 7) ? "长期" : date('Y-m-d', strtotime("" . $jobdata['effective_duration'][$v['time_out']]['time'] . "  " . date('Y-m-d', $v['add_time']) . ""));
		}
		//echo "<pre>";
		//print_r($voList);
		$Arr['voList'] = $voList;
		$Arr['pageStr'] = $p->showOne();
		$this->assign($Arr);
	}

	//修改招聘信息
	function updatePosition() {
		$this->userAuthorized();
		if (Cookie::get('is_personal') == 0) {
			$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
			$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
			$map['id'] = intval($_REQUEST['id']);
			$info = $this->modelcorporatejobs->where($map)->find();
			if ($_POST) {
				unset($_POST['JobType']);
				$_POST['edit_time'] = time();
				if ($this->modelcorporatejobs->where($map)->save($_POST)) {
					$this->display("update_recruitment_ok");
				} else {
					$this->error('亲，您貌似没做任何改动哦!');
				}
			}
			if ($info) {
				$Arr = $info;
				$Arr['JobType'] = $jobdata['JobType'][$info['job_class']];
				$Arr['provinceArr'] = M('ProvinceCode')->field('id,name')->findAll();
				$Arr['jobdata'] = $jobdata;
				$this->assign($Arr);
				$this->display("update_recruitment");
			}
		}
	}

	//删除招聘信息
	function delPosition() {
		$this->userAuthorized();
		if (Cookie::get('is_personal') == 0) {
			$Arr['id'] = intval($_REQUEST['id']);
			if ($_REQUEST['dosubmit']) {
				if ($this->modelcorporatejobs->where("id='{$_REQUEST['id']}'")->delete()) {
					$message = '删除成功!';
					$this->assign('jumpUrl', 'javascript:self.parent.location.reload()');
					$this->assign('waitSecond', 0);
					$this->success($message, false, true);
				}
			}
			$this->assign($Arr);
			$this->display('del_position');
		}
	}

	//查看职位信息
	function seePosition() {
		$this->userAuthorized();
		//if (Cookie::get('is_personal') == 1) {
			$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
			//$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
			$map['id'] = intval($_REQUEST['id']);
			$info = $this->modelcorporatejobs->where($map)->find();
			if ($info) {
				$Arr = $info;
				$Arr['JobType'] = $jobdata['JobType'][$info['job_class']];
				$Arr['provinceArr'] = M('ProvinceCode')->field('id,name')->findAll();
				$Arr['jobdata'] = $jobdata;
				$Arr['work_place_province'] = $this->getProvince('work_place_province', $info);
				$Arr['work_place_city'] = $this->getProvince('work_place_city', $info);
				$Arr['work_place_county'] = $this->getProvince('work_place_county', $info);
				$Arr['edit_time'] = $info['edit_time'] ? date("Y-m-d", $info['edit_time']) : "无";
				$Arr['add_time'] = $info['add_time'] ? date("Y-m-d", $info['add_time']) : "无";
				$Arr['job_class'] = $jobdata['JobType'][$info['job_class']];
				$Arr['job_type'] = $jobdata['JobNature'][$info['job_type']];
				$Arr['sort_id'] = ($info['sort_id'] == 1) ? '男' : ($info['sort_id'] == 2 ? "女" : "不限");
				$Arr['age'] = $jobdata['Age'][$info['age']];
				$Arr['marry'] = $jobdata['Marital_status'][$info['marry']];
				$Arr['education'] = $jobdata['educations'][$info['education']];
				$Arr['cantonese'] = $jobdata['Cantonese'][$info['cantonese']];
				$Arr['language'] = $jobdata['languages'][$info['language']];
				$Arr['experience'] = $jobdata['work_experience'][$info['experience']];
				//echo "<pre>";
				//print_r($Arr);
				$this->assign($Arr);
				$this->display("see_position");
			}
		//}
	}

	//查看所有简历(企业)
	function seeJobResume() {
		$this->userAuthorized();
		$data['title'] = "企业招聘_求职简历";
		if (Cookie::get('is_personal') == 0) {
			$this->seeJobResumeData();
			$this->assign($data);
			$this->display("see_job_resume");
		}
	}

	//未登录个人求职
	function userJobWanted() {
		if (Cookie::get('is_personal') == "") {
			$this->seeJobResumeData();
			$data["is_personal"] = Cookie::get('is_personal'); //企业用户还是个人用户
			$this->display('user_job_wanted');
		}
	}

	//未登陆企业招聘
	function enterpriseManager() {
		$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
		if (Cookie::get('is_personal') == '') {
			$data['job_class'] = $job_class = $_REQUEST['job_class'];
			$data['job_name'] = $job_name = $_REQUEST['job_name'];
			$data['work_place_province'] = $work_place_province = $_REQUEST['work_place_province'];
			$data['add_time'] = $add_time = $_REQUEST['add_time'];
			$data['stype'] = $stype = $_REQUEST['stype'];
			$data['search'] = $search = $_REQUEST['search'];
			$data["is_personal"] = Cookie::get('is_personal'); //企业用户还是个人用户
			if ($job_class)
				$map['job_class'] = intval($job_class);
			if ($job_name)
				$map['job_name'] = $job_name;
			if ($work_place_province)
				$map['work_place_province'] = $work_place_province;
			if ($add_time){
				//$map['add_time'] = array('ELT', strtotime("" . $jobdata['public_time'][$add_time]['time'] . "  " . date('Y-m-d', strtotime("now")) . ""));
				$map['add_time'] = array(array('EGT', strtotime("" . $jobdata['public_time'][$add_time]['time'] . "  " . date('Y-m-d', strtotime("now")) . "")),array('ELT', strtotime("now")));
				}
			if ($search != "请输入职位或公司名称") {
				if ($stype == 1) {
					$map['job_name'] = array('like', "%{$search}%");
				} else {
					$map['company_name'] = array('like', "%{$search}%");
				}
			}
			$this->positionData($map);
			$data['provinceArr'] = M('ProvinceCode')->field('id,name')->findAll();
			$this->assign($data);
			$this->display('enterprise_manager');
		}
	}

	//查看求职简历
	function seeJobResumeData() {
		
		$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
		$Arr['jobdata'] = $jobdata;
		$Arr['job_id'] = $job_id = $_REQUEST['job_id'] ? $_REQUEST['job_id'] : "";
		$Arr['job_name'] = $job_name = $_REQUEST['job_name'] ? $_REQUEST['job_name'] : "";
		$Arr['education'] = $education = $_REQUEST['education'] ? $_REQUEST['education'] : "";
		$Arr['experience'] = $experience = $_REQUEST['experience'] ? $_REQUEST['experience'] : "";
		$Arr['name'] = $search = $_REQUEST['search'];
		//echo $experience;
		import("ORG.Util.Page");
		if ($job_id && !$job_name) {
			$typeson = $jobdata['JobNameSon'][$job_id];
			if ($typeson) {
				foreach ($typeson as $k => $v) {
					$jobsontype .= $k . ",";
				}
			}
			$map["job_id"] = array("in", "{$jobsontype}");
		}
		if ($job_name)
			$map["job_id"] = $job_name;
		if ($education)
			$map["education"] = $education;
		if ($experience)
			$map['experience'] = $experience;
		if ($search != '请输入查找姓名' && !empty($search))
			$map['name'] = $search;
		$map['is_publish'] = 1;
		$count = $this->modelRes->where($map)->count();
		$Arr['count'] = $count;
		//创建分页对象
		$p = new Page($count, 8);
		$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
		$Arr['jobdata'] = $jobdata;
		$Arr['currentTagB'] = ACTION_NAME;
		$voList = $this->modelRes->field("id,name,birthday,education,experience,salary,edit_time,job_id")
						->where($map)->order(array('add_time' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->findAll();
		foreach ($voList as $k => $v) {
			foreach ($jobdata['JobType'] as $key => $val) {
				if ($jobdata['JobNameSon'][$key][$v['job_id']]) {
					$job = $jobdata['JobNameSon'][$key][$v['job_id']];
				}
			}
			$voList[$k]['education'] = $jobdata['educations'][$v['education']];
			$voList[$k]['add_time'] = $v['add_time'] ? date('Y-m-d', $v['add_time']) : "无";
			$voList[$k]['edit_time'] = $v['edit_time'] ? date('Y-m-d', $v['edit_time']) : "无";
			$voList[$k]['birthday'] = date("Y", time()) - date("Y", $v['birthday']);
			$voList[$k]['job_id'] = $job;
		}
		$Arr['voList'] = $voList;
		$Arr['pageStr'] = $p->showOne();

		$this->assign($Arr);
		//$this->display("see_job_resume");
	}

	//查看个人简历
	function seeUserResume() {
		$this->userAuthorized();
		if (Cookie::get('is_personal') == '0') {
			$id = $_REQUEST['id'];
			$this->resumeData($id);
			$this->display("see_user_resume");
		}
	}

	function jobData() {
		$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
		$Arr['educations'] = $jobdata['educations']; //学历
		$Arr['languages'] = $jobdata['languages']; //外语
		$Arr['work_experience'] = $jobdata['work_experience']; //工作经验
		$Arr['JobType'] = $jobdata['JobType'];
		$Arr['JobNameSon'] = $jobdata['JobNameSon'];
		$this->assign($Arr);
	}

	//查看招聘信息
	function seeRecruitmentInformation() {
		$this->userAuthorized();
		if (Cookie::get('is_personal') == 1) {
			$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
			$data['job_class'] = $job_class = $_REQUEST['job_class'];
			$data['job_name'] = $job_name = $_REQUEST['job_name'];
			$data['work_place_province'] = $work_place_province = $_REQUEST['work_place_province'];
			$data['add_time'] = $add_time = $_REQUEST['add_time'];
			$data['stype'] = $stype = $_REQUEST['stype'];
			$data['search'] = $search = $_REQUEST['search'];
			$data['title'] = "个人求职_招聘信息";
			if ($job_class)
				$map['job_class'] = intval($job_class);
			if ($job_name)
				$map['job_name'] = $job_name;
			if ($work_place_province)
				$map['work_place_province'] = $work_place_province;
			if ($add_time){
				$map['add_time'] = array(array('EGT', strtotime("" . $jobdata['public_time'][$add_time]['time'] . "  " . date('Y-m-d', strtotime("now")) . "")),array('ELT', strtotime("now")));
				//$where['add_time'] = ;
				//$where['_logic'] = 'and';
				//$map['_complex'] = $where;
				
				//$map['add_time'] = array('EGT', strtotime("" . $jobdata['public_time'][$add_time]['time'] . "  " . date('Y-m-d', strtotime("now")) . ""));
				//$map['add_time'] = array('ELT', date('Y-m-d', strtotime("now")));
			}
			if ($search != "请输入职位或公司名称") {
				if ($stype == 1) {
					$map['job_name'] = array('like', "%{$search}%");
				} else {
					$map['company_name'] = array('like', "%{$search}%");
				}
			}
			//echo "<pre>";
			//	print_r($map);
			$this->positionData($map);
			$data['provinceArr'] = M('ProvinceCode')->field('id,name')->findAll();
			$this->assign($data);
			$this->display("see_recruitment");
		}
	}

	//登陆跳转
	function jobLogin() {
		if (Cookie::get('is_personal') == 1) {
			$this->redirect("Job/seeRecruitmentInformation");
		} else {
			$this->redirect("Job/seeJobResume");
		}
	}

	function ajaxJobSon() {
		$jobtype = $_REQUEST['job_class'] ? intval($_REQUEST['job_class']) : "";
		$type = $_REQUEST['type'] ? $_REQUEST['type'] : "";
		if ($jobtype) {
			$jobdata = F('jobdata', '', C('CACHE_PATH_FILE') . "indexdata/");
			$html = "<option value=0>请选择职位名称</option>";
			if ($type == 1) {
				$job_id = $_REQUEST['job_id'] ? $_REQUEST['job_id'] : "";
				foreach ($jobdata['JobNameSon'][$jobtype] as $k => $v) {
					$html .= '<option value= "' . $k . '" ' . ($job_id == $k ? selected : "") . '>' . $v . '</option>';
				}
			} else {
				$jobname = $_REQUEST['job_name'] ? $_REQUEST['job_name'] : "";
				foreach ($jobdata['JobNameSon'][$jobtype] as $k => $v) {
					$html .= '<option value= "' . $v . '" ' . ($jobname == $v ? selected : "") . '>' . $v . '</option>';
				}
			}
			echo $html;
		} else {
			echo "<option value=0>请选择职位名称</option>";
		}
	}
	
	
	//错误提示信息
	function jobMessage(){
		$Arr['message'] = $_REQUEST['message'];
		$this->assign($Arr);
		$this->display("message");
	}

	//权限判断
	function userAuthorized(){
		if(!Cookie::get(C('USER_AUTH_KEY'))){
			$this->redirect("Job/enterpriseManager");
		}
	}
}