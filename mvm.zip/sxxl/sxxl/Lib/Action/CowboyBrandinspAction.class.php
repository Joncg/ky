<?php

class CowboyBrandinspAction extends BrandinspAction {

	public function _initialize() {
		$this->sid = 1;
		parent::_initialize();
	}

	public function index() {
		parent::index();
	}

	public function themeDetail($tid = '') {
		parent::themeDetail($tid);
	}

	protected function getSpecialChildMenu() {
        $soid = $this->getSoid();
		$specialChildMenu = array(
			array('id' => 93, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 93)), 'picture' => '/Public/Images/fishion/cb-brand/Bershka.jpg', 'name' => 'Bershka'),
			array('id' => 195, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 195)), 'picture' => '/Public/Images/fishion/cb-brand/DIESEL.jpg', 'name' => 'DIESEL'),
			array('id' => 10924, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 10924)), 'picture' => '/Public/Images/fishion/cb-brand/Dolce&Gabbana.jpg', 'name' => 'Dolce&Gabbana'),
			array('id' => 7065, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 7065)), 'picture' => '/Public/Images/fishion/cb-brand/Dsquared2.jpg', 'name' => 'Dsquared2'),
			array('id' => 227, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 227)), 'picture' => '/Public/Images/fishion/cb-brand/Energie.jpg', 'name' => 'Energie'),
			array('id' => 241, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 241)), 'picture' => '/Public/Images/fishion/cb-brand/EVISU.jpg', 'name' => 'EVISU'),
			array('id' => 1049, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 1049)), 'picture' => '/Public/Images/fishion/cb-brand/G-star.jpg', 'name' => 'G-STAR RAW'),
			array('id' => 1079, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 1078)), 'picture' => '/Public/Images/fishion/cb-brand/GUESS.jpg', 'name' => 'GUESS'),
			array('id' => 399, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 399)), 'picture' => '/Public/Images/fishion/cb-brand/LEE.jpg', 'name' => 'LEE'),
			array('id' => 458, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 458)), 'picture' => '/Public/Images/fishion/cb-brand/Miss-sixty.jpg', 'name' => 'Miss sixty'),
			array('id' => 1379, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 1379)), 'picture' => '/Public/Images/fishion/cb-brand/Pepe-Jeans.jpg', 'name' => 'Pepe Jeans'),
			array('id' => 567, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 567)), 'picture' => '/Public/Images/fishion/cb-brand/Replay.jpg', 'name' => 'Replay'),
			array('id' => 10418, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 10418)), 'picture' => '/Public/Images/fishion/cb-brand/SALSA.jpg', 'name' => 'SALSA'),
			array('id' => 715, 'url' => U("/" . MODULE_NAME . "/index", array('soid'=>$soid,'bid' => 715)), 'picture' => '/Public/Images/fishion/cb-brand/Zara.jpg', 'name' => 'Zara'),
		);
		return $specialChildMenu;
	}

	public function downloadzip() {
		parent::downloadzip();
	}

}