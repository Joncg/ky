<?php

define('IS_TEST', FALSE);
/*
 * 新旧服装网跨域操作
 */

class ApiAction extends Action {

	protected $_model; //会员表
	protected $_model_authorized;  //会员电脑信息表
	protected $_model_role;
	protected $_model_ref_member_role;
	protected $_model_member_orders;
	protected $_model_log_login;
	protected $_model_area;
	protected $_model_city;
	protected $_model_province;
	protected $_model_feedback_reply;
	protected $_model_feedback;

	function _initialize() {
		$this->_model = D('Member');
		$this->_model_authorized = D('MemberAuthorized');
		$this->_model_role = M('role');
		$this->_model_area = M('AreaCode');
		$this->_model_city = M('CityCode');
		$this->_model_province = M('ProvinceCode');
		$this->_model_ref_member_role = M('RefMemberRole');
		$this->_model_member_authorized = M('MemberAuthorized');
		$this->_model_member_orders = M('MemberOrders');
		$this->_model_log_login = M('LogLogin');
		$this->_model_feedback_reply = M("FeedbackReply");
		$this->_model_feedback = M('Feedback');
	}

	/**
	 * 接收旧服装网新注册信息，并同步到新服装网相关会员表中
	 */
	public function register() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY'))); //post
		$json_msg = '';
		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}

			$province_id = intval($this->_model_province->getField('id', array('name' => array('like', $data['province'] . '%'))));
			$city_id = intval($this->_model_city->getField('id', array('name' => array('like', $data['city'] . '%'))));
			$county_id = intval($this->_model_area->getField('id', array('name' => array('like', $data['county'] . '%'))));

			$data_tmp = array();
			$data_tmp['uid'] = $data['ID'];
			$data_tmp['crm_staff'] = $data['crm_staff'];
			$data_tmp['name'] = $data['UserName'];
			$data_tmp['password'] = md5($data['PassWord']);
			$data_tmp['linkman_email'] = $data['Email'];
			$data_tmp['final_login_time'] = 0;
			$data_tmp['login_count'] = 0;
			$data_tmp['register_time'] = $data['nUpdateTime'];
			$data_tmp['status'] = 0; //待定
			$data_tmp['company_name'] = $data['Company'];
			$data_tmp['company_phone'] = $data['Tel'];
			$data_tmp['linkman_name'] = $data['RealName'];
			if ($data['mobile']) {
				$data_tmp['linkman_tel'] = $data['mobile'];
			} else {
				$data_tmp['linkman_tel'] = $data['moblie'];
			}
			//$data_tmp['linkman_tel'] = $data['mobile'];
			$data_tmp['linkman_position'] = $data['JobName'];
			$data_tmp['qq'] = $data['im_qq'];
			$data_tmp['province'] = $province_id;
			$data_tmp['city'] = $city_id;
			$data_tmp['county'] = $county_id;
			$data_tmp['address'] = $data['Address'];
			$data_tmp['postcode'] = $data['PostCode'];
			$data_tmp['product_type'] = '';
			//$data_tmp['notes'] = $data['memo'];
			$data_tmp['register_ip'] = $data['RegIP'];
			$data_tmp['appellation_id'] = intval($data['Sex']);
			if ($this->_model->add($data_tmp) === false) {
				$json_msg = json_encode(array('status' => '0', 'msg' => '同步注册会员失败：' . $this->_model->getDbError()));
			} else {
				$json_msg = json_encode(array('status' => '1', 'msg' => '同步注册会员成功。'));
			}
		} else {
			$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空'));
		}
		//$rightdata = authcode(json_encode($rightdata), 'ENCODE', C('SXXL_KEY'));
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model->getLastSql()) : exit($json_msg);
	}

	/**
	 * 修改会员资料
	 */
	public function editMemberInfo() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		//$data = unserialize(json_decode(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')), true));
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));

		$json_msg = '';
		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}

			$province_id = $data['province'] ? intval($this->_model_province->getField('id', array('name' => array('like', $data['province'] . '%')))) : "";
			$city_id = $data['city'] ? intval($this->_model_city->getField('id', array('name' => array('like', $data['city'] . '%')))) : "";
			$county_id = $data['county'] ? intval($this->_model_area->getField('id', array('name' => array('like', $data['county'] . '%')))) : "";

			if ($data['ID']) {
				$map = array();
				$map['name'] = $data['UserName'];
				$data_tmp = array();
				if ($data['crm_staff'])
					$data_tmp['crm_staff'] = $data['crm_staff'];

				if ($data['UserName'])
					$data_tmp['name'] = $data['UserName'];

				if ($data['PassWord'])
					$data_tmp['password'] = $data['PassWord'];

				if ($data['Email'])
					$data_tmp['linkman_email'] = $data['Email'];

				if ($data['nLoginTime'])
					$data_tmp['final_login_time'] = $data['nLoginTime'];

				if ($data['LoginLog'])
					$data_tmp['login_count'] = $data['LoginLog'];

				if ($data['nUpdateTime'])
					$data_tmp['register_time'] = $data['nUpdateTime'];

				//$data_tmp['status'] = 1;//待定
				if ($data['Company'])
					$data_tmp['company_name'] = $data['Company'];

				//if ($data['Tel'])
				$data_tmp['company_phone'] = $data['Tel'];

				if ($data['RealName'])
					$data_tmp['linkman_name'] = $data['RealName'];

				//if ($data['mobile'] || $data['moblie'])
				if ($data['mobile']) {
					$data_tmp['linkman_tel'] = $data['mobile'];
				} else {
					$data_tmp['linkman_tel'] = $data['moblie'];
				}
				//if ($data['JobName'])
				$data_tmp['linkman_position'] = $data['JobName'];

				//if ($data['im_qq'])
				$data_tmp['qq'] = $data['im_qq'];

				if ($province_id)
					$data_tmp['province'] = $province_id;

				if ($city_id)
					$data_tmp['city'] = $city_id;

				if ($county_id)
					$data_tmp['county'] = $county_id;

				if ($data['Address'])
					$data_tmp['address'] = $data['Address'];

				//if ($data['PostCode'])
				$data_tmp['postcode'] = $data['PostCode'];

				if ($data['product_type'])
					$data_tmp['product_type'] = '';

				//if ($data['memo'])
				//	$data_tmp['notes'] = $data['memo'];

				if ($data['RegIP'])
					$data_tmp['register_ip'] = $data['RegIP'];

				if ($data['Sex'])
					$data_tmp['appellation_id'] = intval($data['Sex']);

				if ($this->_model->where($map)->save($data_tmp) === false) {
					$json_msg = json_encode(array('status' => '0', 'msg' => '同步编辑会员信息失败：' . $this->_model->getDbError()));
				} else {
					$json_msg = json_encode(array('status' => '1', 'msg' => '同步编辑会员信息成功。'));
				}
			} else {
				$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空'));
			}
		} else {
			$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空'));
		}
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model->getLastSql()) : exit($json_msg);
	}

	/**
	 * 修改密码
	 */
	public function editPassword() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		//$data = unserialize(json_decode(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')), true));
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$json_msg = '';
		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}

			if ($data['name']) {
				$map = array();
				$map['name'] = $data['name'];

				if ($this->_model->where($map)->save(array('password' => $data['PassWord'])) === false) {
					$json_msg = json_encode(array('status' => '0', 'msg' => '同步修改密码失败：' . $this->_model->getDbError()));
				} else {
					$json_msg = json_encode(array('status' => '1', 'msg' => '同步修改密码成功。'));
				}
			} else {
				$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空。'));
			}
		} else {
			$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空。'));
		}
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model->getLastSql()) : exit($json_msg);
	}

	/**
	 * 修改会员权限(试用、正式的相关角色和过期时间)
	 */
	public function editMemberRight() {
		//参数应为一个二维数组，暂时这样
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		//$data = unserialize(authcode($data,'DECODE',C('SXXL_KEY')));
		$json_msg = '';
		$error_num = 0;
		if (!empty($data)) {
			//将GBK转为UTF8
			$data['ID'] = auto_charset($val['ID']);
			$member = $this->getNewMemberMessage(iconv('gbk', 'utf-8', $data['name']));
			$member_id = $member ? $member : '';

			if ($member_id) {
				//开启事务
				$this->_model_ref_member_role->startTrans();
				$map = array();
				$map['member_id'] = $maps['member_id'] = $member_id;
				$map['is_try'] = $data['is_try'];
				if ($this->_model_ref_member_role->where($map)->delete() !== false) {
					foreach ($data['vip_info'] as $key => $val) {
						$maps['role_id'] = auto_charset($val);
						$this->_model_ref_member_role->where($maps)->delete();
						$data_tmp = array();
						$data_tmp['member_id'] = $member_id;
						$data_tmp['role_id'] = auto_charset($val);
						$data_tmp['invalid_time'] = auto_charset($data['nValidTime'][$val]);
						$data_tmp['is_try'] = auto_charset($data['is_try']);
						if ($this->_model_ref_member_role->add($data_tmp) === false) {
							++$error_num;
						}
					}
				} else {
					++$error_num;
				}
				if ($error_num > 0) {
					//事务回滚
					$this->_model_ref_member_role->rollback();
					$json_msg = json_encode(array('status' => '0', 'msg' => '同步修改权限失败。'));
				} else {
					//提交事务
					$this->_model_ref_member_role->commit();
					$json_msg = json_encode(array('status' => '1', 'msg' => '同步修改权限成功。'));
				}
			} else {
				$json_msg = json_encode(array('status' => '0', 'msg' => '同步修改权限失败。'));
			}
		} else {
			$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空。'));
		}
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model_ref_member_role->getLastSql()) : exit($json_msg);
	}

	/**
	 * 获取新网站前台角色给旧服装网
	 */
	public function getRole() {
		$data = $this->_model_role->select();
		IS_TEST ? dump($data) : exit(authcode(json_encode($data), 'decode', C('SXXL_KEY')));
	}

	/**
	 * 修改订单相关信息（订单状态）
	 */
	public function editOrder() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		//$data = unserialize(json_decode(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')), true));
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$json_msg = '';
		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}

			$data_tmp = array();
			$data_tmp['status'] = $data['status'];
			if ($this->_model_member_orders->where(array('vip_number' => $data['vip_number']))->save($data_tmp) === false) {
				$json_msg = json_encode(array('status' => '0', 'msg' => '同步修改订单信息失败：' . $this->_model_member_orders->getDbError()));
			} else {
				$json_msg = json_encode(array('status' => '1', 'msg' => '同步修改订单信息成功。'));
			}
		} else {
			$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空。'));
		}
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model_member_orders->getLastSql()) : exit($json_msg);
	}

	/**
	 * 修改电脑授权等信息
	 */
	public function editAuthorized() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		//$data = unserialize(json_decode(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')), true));
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$json_msg = '';

		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}

			//$member_id = $data['ID'] ? $this->_model->getField('id',array('uid'=>$data['ID'])) : '';
			if ($data['UserName']) {
				$data_tmp = array();
				$member = $this->getNewMemberMessage($data['UserName']);
				$member_id = $member ? $member : '';
				$map['cpu_id'] = $data['cpu_info'] ? $data['cpu_info'] : "";
				$map['mac_id'] = $data['net_info'] ? $data['net_info'] : "";
				//$map['computer_name'] = $data['pc_name'] ? $data['pc_name'] : "";
				$map['login_type'] = $data['login_type'] ? $data['login_type'] : "";
				$map['member_id'] = $member_id;
				//$data_tmp['id'] = $data['ID'];
				//$data_tmp['member_id'] = $this->_model->getField('id', array('uid' => $member_id));
				//$data_tmp['login_type'] = '';
				//$data_tmp['computer_name'] = $data['pc_name'];
				//$data_tmp['mac_id'] = $data['net_info'];
				//$data_tmp['storage_id'] = $data['hd_info'];
				//$data_tmp['cpu_id'] = $data['cpu_info'];
				$data_tmp['status'] = $data['StatusLog']; //待定
				$data_tmp['cpu_status'] = $data['cpu_check'];
				$data_tmp['storage_status'] = $data['hd_check'];
				$data_tmp['mac_status'] = $data['net_check'];
				//$data_tmp['add_time'] = strtotime($data['update_time']) ? strtotime($data['update_time']) : '';
				if ($this->_model_member_authorized->where($map)->save($data_tmp) === false) {
					$json_msg = json_encode(array('status' => '0', 'msg' => '同步修改电脑授权失败：' . $this->_model_member_authorized->getDbError()));
				} else {
					$json_msg = json_encode(array('status' => '1', 'msg' => '同步修改电脑授权成功。'));
				}
			} else {
				$json_msg = json_encode(array('status' => '0', 'msg' => '同步修改电脑授权失败。'));
			}
		} else {
			$json_msg = json_encode(array('status' => '0', 'msg' => '参数不能为空。'));
		}
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model_member_authorized->getLastSql()) : exit($json_msg);
	}

	/**
	 * 删除电脑授权信息
	 */
	public function deleteAuthorized() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		//$data = unserialize(json_decode(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')), true));
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$json_msg = '';
		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}
			$map = array();
			//$map['id'] = $data['ID'];
			$member = $this->getNewMemberMessage($data['UserName']);
			$member_id = $member ? $member : '';
			$map['cpu_id'] = $data['cpu_info'] ? $data['cpu_info'] : "";
			$map['mac_id'] = $data['net_info'] ? $data['net_info'] : "";
			$map['computer_name'] = $data['pc_name'] ? $data['pc_name'] : "";
			$map['member_id'] = $member_id;
			if ($this->_model_member_authorized->where($map)->delete() === false) {
				$json_msg = json_encode(array('status' => '0', 'msg' => '同步删除电脑授权失败：' . $this->_model_member_authorized->getDbError()));
			} else {
				$json_msg = json_encode(array('status' => '1', 'msg' => '同步删除电脑授权成功。'));
			}
		}
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model_member_authorized->getLastSql()) : exit($json_msg);
	}

	//获取用户新网站相关权限
	function getUserNewRight() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$map['member_id'] = $this->getNewMemberMessage($data['UserName']);
		$map['is_try'] = $data['is_try'];
		$rightdata = $this->_model_ref_member_role->where($map)->select();
		$rightdata = authcode(json_encode($rightdata), 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($rightdata, $this->_model_ref_member_role->getLastSql()) : exit($rightdata);
	}

	//获取用户信息
	function getNewMemberMessage($name) {
		$datainfouid = $this->_model->getField('id', array('name' => $name));
		if ($datainfouid)
			return $datainfouid;
	}

	//获取用户ID
	function getNewMemberMemberId() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$name = $data['name'];
		$datainfouid = $this->_model->getField('id', array('name' => $name));
		if ($datainfouid)
			IS_TEST ? $this->isTest($datainfouid, $this->_model->getLastSql()) : exit($datainfouid);
	}

	//获取用户信息
	function getNewMember() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$name = $data['name'];
		$map['name'] = $name;
		$datamessage = $this->_model->where($map)->find();
		if ($datamessage)
			IS_TEST ? $this->isTest($datamessage, $this->_model->getLastSql()) : exit(json_encode($datamessage));
	}

	//获取用户权限
	function getNewMemberRole() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$member_id = $this->getNewMemberMessage($data['uname']);
		$map['member_id'] = $member_id;
		$map['is_try'] = 0;
		$datas = $this->_model_ref_member_role->where($map)->select();
		if ($datas) {
			$json_msg = json_encode(array('status' => '0', 'data' => $datas));
			$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
			IS_TEST ? $this->isTest($json_msg, $this->_model_ref_member_role->getLastSql()) : exit($json_msg);
			//echo $json_msg;
		}
	}

	//获取已调整过的用户
	function getUserAdjustment() {
		$datas = $this->_model_ref_member_role->field('name')->join("sxxl_member ON sxxl_member.id = sxxl_ref_member_role.member_id ")->select();
		if ($datas) {
			$datas = authcode(json_encode($datas), 'ENCODE', C('SXXL_KEY'));
			IS_TEST ? $this->isTest($datas, $this->_model_ref_member_role->getLastSql()) : exit($datas);
		}
	}

	//修改更进人员
	function UpdataNewCrmStaff() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$map['name'] = $data['UserName'];
		$data_tmp['crm_staff'] = $data['crm_staff'];
		if ($this->_model->where($map)->save($data_tmp) === false) {
			$json_msg = json_encode(array('status' => '0', 'msg' => '同步修改更进人员失败：' . $this->_model_member_authorized->getDbError()));
		} else {
			$json_msg = json_encode(array('status' => '1', 'msg' => '同步修改更进人员成功。'));
		}
		$json_msg = authcode($json_msg, 'ENCODE', C('SXXL_KEY'));
		IS_TEST ? $this->isTest($json_msg, $this->_model->getLastSql()) : exit($json_msg);
	}

	//从老网站登录向新网站日志表中写登录日志
	function pcLoingLog() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		$logdata['member_id'] = $data['member_id'] ? $data['member_id'] : "undefined";
		$logdata['login_time'] = $data['login_time'] ? $data['login_time'] : "undefined";
		$logdata['computer_name'] = $data['computer_name'] ? $data['computer_name'] : "undefined";
		$logdata['cpu_id'] = $data['cpu_id'] ? $data['cpu_id'] : "undefined";
		$logdata['storage_id'] = $data['storage_id'] ? $data['storage_id'] : "undefined";
		$logdata['mac_id'] = $data['mac_id'] ? $data['mac_id'] : "undefined";
		$logdata['login_ip'] = $data['login_ip'] ? $data['login_ip'] : "undefined";
		$logdata['computer_type'] = $data['computer_type'] ? $data['computer_type'] : "";
		$logdata['client_version'] = $data['client_version'] ? $data['client_version'] : "";
		$logdata['login_type'] = $data['login_type'] ? $data['login_type'] : "";
		$log = $this->_model_log_login->add($logdata);
		if ($log) {
			$json_msg = json_encode(array('status' => '1', 'msg' => '登录日志写入成功!'));
		} else {
			$json_mag = json_encode(array('status' => '0', 'msg' => '登录日志写入失败!'));
		}
		IS_TEST ? $this->isTest($json_msg, $this->_model_log_login->getLastSql()) : exit($json_msg);
	}

	//软件登录插入授权表
	function pcRight() {
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}
		}
		$map = array();
		$map['member_id'] = $datapc['member_id'] = $this->getNewMemberMessage($data['UserName']);
		$map['cpu_id'] = $data['cpu_info'] ? $data['cpu_info'] : "";
		$map['mac_id'] = $data['net_info'] ? $data['net_info'] : "";
		//$map['storage_id'] = $data['storage_id'] ? $data['storage_id'] : "";
		if (!$this->_model_member_authorized->where($map)->find()) {
			$datapc['computer_name'] = $data['computer_name'];
			$datapc['mac_id'] = $data['net_info'];
			$datapc['storage_id'] = $data['storage_id'];
			$datapc['cpu_id'] = $data['cpu_info'];
			$datapc['add_time'] = time();
			$this->_model_member_authorized->add($datapc);
		}
	}

	function FeedbackReply(){
		$data = $_POST['data'] ? $_POST['data'] : (IS_TEST ? $_GET['data'] : '');
		$data = unserialize(authcode(urldecode($data), 'DECODE', C('SXXL_KEY')));
		if (!empty($data)) {
			foreach ($data as $key => $val) {
				//将GBK转为UTF8
				$data[$key] = auto_charset($val);
			}
		}
		$fdata['feedback_id'] = $data['feedback_id'] ? $data['feedback_id'] : ""; //feedback_id,title,content,add_time,add_user_id
		$fdata['title'] = '回复内容';
		$fdata['content'] = $data['content'] ? trim($data['content']) : "";
		$fdata['add_time'] = time();
		$fdata['add_user_id'] = $data['add_user_id'] ? trim($data['add_user_id']) : "";
		if($this->_model_feedback_reply->add($fdata)){
			$map['id'] = $fdata['feedback_id'];
			$rdata['reply_id'] = $this->_model_feedback_reply->getLastInsID();
			$this->_model_feedback->where($map)->save($rdata);
		}
	}
	
	
	//调试模式
	function isTest($data, $sql) {
		dump(json_decode($data)) . "<br>";
		echo $sql;
	}

	/**
	 * 保存会员注册信息
	 */
	public function member_add() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$data = authcode($data, $operation = 'DECODE', C('CRM_KEY'));
			$_POST = unserialize($data);

			if ($_POST) {
				if (!($info = $this->_model->create($_POST))) {
					$this->error($this->_model->getError());
				} else {
					if ($this->_model->add()) {
						echo json_encode("1");
					} else {
						echo json_encode("0");
					}
				}
			}
		}
	}

	/**
	 * 修改会员信息
	 */
	public function member_edit() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$data = authcode($data, $operation = 'DECODE', C('CRM_KEY'));
			$pinfo = unserialize($data);
			if ($pinfo['id']) {
				if (!$this->_model->create($pinfo)) {
					echo json_encode(array('status' => "0"));
				} else {
					if ($this->_model->save()) {
						echo json_encode(array('status' => "1"));
					} else {
						echo json_encode(array('status' => "0"));
					}
				}
			}
		}
	}

	/**
	 * 修改跟进人
	 */
	public function member_edituid() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$data = authcode($data, $operation = 'DECODE', C('CRM_KEY'));
			$_POST = unserialize($data);
			$memberList = $this->_model->where(array('uid' => $_POST['uid']))->field('id')->find();
			if ($memberList['id']) {
				$_POST['id'] = $memberList['id'];
				if (!$this->_model->create($_POST)) {
					echo json_encode(array('status' => "2"));
				} else {
					if ($this->_model->save()) {
						echo json_encode(array('status' => "1"));
					} else {
						echo json_encode(array('status' => "0"));
					}
				}
			}
		}
	}

	/**
	 * 获取电脑授权记录记录
	 */
	public function member_authorized() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$data = authcode($data, $operation = 'DECODE', C('CRM_KEY'));
			$pinfo = unserialize($data);

			$memberList = $this->_model->where(array('name' => $pinfo))->field('id')->find();

			$web_authorizedList = $this->_model_authorized->where(array('member_id' => $memberList['id'], 'login_type' => "0"))->findall();
			$soft_authorizedList = $this->_model_authorized->where(array('member_id' => $memberList['id'], 'login_type' => "1"))->findall();
			$data = array();
			if ($soft_authorizedList) {
				foreach ($soft_authorizedList as $key => $val) {
					$data['softpcinfo'][$key]['ID'] = $val['id'];
					$data['softpcinfo'][$key]['cpu_info'] = $val['cpu_id'];
					$data['softpcinfo'][$key]['pc_name'] = $val['computer_name'];
					$data['softpcinfo'][$key]['hd_info'] = $val['storage_id'];
					$data['softpcinfo'][$key]['net_info'] = $val['mac_id'];
					$data['softpcinfo'][$key]['cpu_info'] = $val['cpu_id'];
					$data['softpcinfo'][$key]['update_time'] = date("Y-m-d", $val['add_time']);
					$data['softpcinfo'][$key]['cpu_check'] = $val['cpu_status'];
					$data['softpcinfo'][$key]['hd_check'] = $val['storage_status'];
					$data['softpcinfo'][$key]['net_check'] = $val['mac_status'];
					$data['softpcinfo'][$key]['StatusLog'] = $val['status'];
				}
			}
			if ($web_authorizedList) {
				foreach ($web_authorizedList as $key => $val) {
					$data['webpcinfo'][$key]['ID'] = $val['id'];
					$data['webpcinfo'][$key]['cpu_info'] = $val['cpu_id'];
					$data['webpcinfo'][$key]['pc_name'] = $val['computer_name'];
					$data['webpcinfo'][$key]['hd_info'] = $val['storage_id'];
					$data['webpcinfo'][$key]['net_info'] = $val['mac_id'];
					$data['webpcinfo'][$key]['cpu_info'] = $val['cpu_id'];
					$data['webpcinfo'][$key]['update_time'] = date("Y-m-d", $val['add_time']);
					$data['webpcinfo'][$key]['cpu_check'] = $val['cpu_status'];
					$data['webpcinfo'][$key]['hd_check'] = $val['storage_status'];
					$data['webpcinfo'][$key]['net_check'] = $val['mac_status'];
					$data['webpcinfo'][$key]['StatusLog'] = $val['status'];
				}
			}
			echo json_encode($data);
		}
	}

	/**
	 * 电脑授权
	 */
	function editPcInfo() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$data = authcode($data, $operation = 'DECODE', C('CRM_KEY'));
			$pinfo = unserialize($data);
			if (!$this->_model_authorized->create($pinfo)) {
				echo json_encode(array('status' => "0"));
			} else {
				if ($this->_model_authorized->save()) {
					echo json_encode(array('status' => "1"));
				} else {
					echo json_encode(array('status' => "0"));
				}
			}
		}
	}

	/**
	 * 会员登录记录
	 */
	function getMemberLoginLog() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$data = authcode($data, $operation = 'DECODE', C('CRM_KEY'));
			$pinfo = unserialize($data);
			$memberList = $this->_model->where(array('name' => $pinfo))->field('id')->find();
			$memberLogList = $this->_model_log_login->where(array('member_id' => $memberList['id']))->order(array('id' => 'desc'))->findall();
			if ($memberLogList) {
				foreach ($memberLogList as $key => $val) {
					$memberLog[$key]['ID'] = $val['id'];
					$memberLog[$key]['pc_name'] = $val['computer_name'];
					$memberLog[$key]['pc_type'] = $val['computer_type'];
					$memberLog[$key]['cpu_info'] = $val['cpu_id'];
					$memberLog[$key]['hd_info'] = $val['storage_id'];
					$memberLog[$key]['net_info'] = $val['mac_id'];
					$memberLog[$key]['pc_id'] = $val['login_ip'];
					$memberLog[$key]['LoginIP'] = $val['login_ip'];
					$memberLog[$key]['UpDateTime'] = $val['login_time'];
				}echo json_encode($memberLog);
			}
		}
	}

	/**
	 * 获取权限列表
	 */
	function roles() {
		if ($_GET) {
			$powersTry = $this->_model_role->field('id,name,price')->findAll();
			if ($powersTry)
				echo json_encode($powersTry);
		}
	}

	/**
	 * 获取会员权限信息
	 */
	function roleinfo() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$data = authcode($data, $operation = 'DECODE', C('CRM_KEY'));
			$pinfo = unserialize($data);
			$sql = "SELECT id as power_id,name,price FROM `sxxl_role` WHERE id IN ({$pinfo})";
			$info = $this->_model_role->query($sql);
		} echo json_encode($info);
	}

	/**
	 * 缓存会员类型
	 */
	function getVipTypes() {
		$data = $this->_model_role->field('id,name')->where(array('status' => "1"))->findAll();
		if ($data) {
			foreach ($data as $key => $val) {
				$datas[$val["id"]] = $val["name"];
			}
		}
		if (!$data)
			echo json_encode(array('status' => "0"));
		echo json_encode($datas);
	}

	/**
	 * 读取会员信息uid,id
	 */
	function memberInfo() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$pinfo = unserialize(authcode($data, $operation = 'DECODE', C('CRM_KEY')));
			$memberinfo = $this->_model->field('id,uid,name,linkman_email,company_name,company_phone,linkman_name,linkman_tel,linkman_position,qq,province,address,postcode,product_type,notes,appellation_id,register_time')->where(array('name' => $pinfo))->find();
			if ($memberinfo['province']) {
				$datas = $this->_model_province->where(array('id' => $memberinfo['province']))->field('name')->find();
				$memberinfo['province'] = $datas['name'];
			}
			if ($_POST['city']) {
				$datas = $this->_model_city->where(array('id' => $memberinfo['city']))->field('name')->find();
				$memberinfo['city'] = $datas['name'];
			}
			if ($memberinfo['area']) {
				$datas = $this->_model_area->where(array('id' => $memberinfo['area']))->field('name')->find();
				$memberinfo['area'] = $datas['name'];
			}
		}
		echo json_encode($memberinfo);
	}

	/**
	 * 读取会员购买的权限类型
	 */
	function getMemberViptypes() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$pinfo = unserialize(authcode($data, $operation = 'DECODE', C('CRM_KEY')));
			$role_info = $this->_model_ref_member_role->field('id,role_id,invalid_time')->where($pinfo)->findall();
			$datas = array();
			if ($role_info) {
				foreach ($role_info as $key => $val) {
					//		$datas['id'][$key] =$val['role_id'];
					//		$datas['role_id'][$val['role_id']] = date("Y-m-d",$val["invalid_time"]);
					$datas[$key]['id'] = $val['id'];
					$datas[$key]['role_id'] = $val['role_id'];
					$datas[$key]['invalid_time'] = date("Y-m-d", $val["invalid_time"]);
				}
				echo json_encode($datas);
			}
		}
	}

	/**
	 * 权限插入
	 */
	function role_insert() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$pinfo = unserialize(authcode($data, $operation = 'DECODE', C('CRM_KEY')));
			if ($this->_model_ref_member_role->create($pinfo)) {
				if ($this->_model_ref_member_role->add())
					echo json_encode(array('status' => "1"));
				else
					echo json_encode(array('status' => "0"));
			}
		}
	}

	/**
	 * 权限修改
	 */
	function role_edit() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$pinfo = unserialize(authcode($data, $operation = 'DECODE', C('CRM_KEY')));
			if ($data = $this->_model_ref_member_role->create($pinfo)) {
				if ($this->_model_ref_member_role->save())
					echo json_encode(array('status' => "1"));
			}else {
				echo json_encode(array('status' => "0"));
			}
		}
	}

	/**
	 * 权限删除
	 */
	function role_delete() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$pinfo = unserialize(authcode($data, $operation = 'DECODE', C('CRM_KEY')));
			$this->_model_ref_member_role->delete(array('id' => $pinfo));
		}
	}

	/*
	 *
	 */

	function upSxxlMember() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$pinfo = unserialize(authcode($data, $operation = 'DECODE', C('CRM_KEY')));
			if ($this->_model->create($pinfo)) {
				if ($this->_model->save())
					echo json_encode(array('status' => "1"));
			}else {
				echo json_encode(array('status' => "0"));
			}
		}
	}

	/**
	 * 修改订单
	 */
	function upOrder() {
		if ($_GET) {
			$data = $_GET["data"] ? $_GET["data"] : "";
			$pinfo = unserialize(authcode($data, $operation = 'DECODE', C('CRM_KEY')));
			if ($this->_model_member_orders->create($pinfo)) {
				if ($this->_model_member_orders->save('', array('where' => "vip_number=" . $pinfo['vip_number'])))
					echo json_encode(array('status' => "1"));
			}else {
				echo json_encode(array('status' => "0"));
			}
		}
	}

}