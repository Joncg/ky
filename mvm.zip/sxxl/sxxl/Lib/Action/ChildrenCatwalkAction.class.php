<?php
class ChildrenCatwalkAction extends CatwalkAction {

    public function _initialize() {
        $this->soid = 3;
        parent::_initialize();
    }

	public function index() {
        $this->folderList();
	}

	public function folderList(){
        parent::folderList();
	}

	public function folderDetail() {
        parent::folderDetail();
	}

 	public function themeDetail($fid = '',$tid = '') {
        parent::themeDetail($fid,$tid);
	}

	public function downloadzip() {
        parent::downloadzip();
    }
}
