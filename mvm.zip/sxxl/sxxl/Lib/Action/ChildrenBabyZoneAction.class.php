<?php
class ChildrenBabyZoneAction extends TideSectionAction {

    public function _initialize() {
        $this->cid = 30;
        $this->soid = 3;
        parent::_initialize();
    }

	public function index() {
        $this->patternAnalysis();
	}

    //图案分析
    public function patternAnalysis(){
        $cid = 24;
        $this->tableArr = getCidModel($cid);

        $map["{$this->tableArr['subject_original']}.menu_id"] = $cid;
        $map["{$this->tableArr['subject_original']}.child_menu_id"] = 66;

        $title = trim($_POST['title']);
        if($title !== '') $map['title'] = array("like","%{$title}%");
        $this->assign('keyword',$title);

        $field = "{$this->tableArr['subject_original']}.id,{$this->tableArr['subject_original']}.menu_id,title,title_picture_url,publish_time,season_id,designer_id";
		$order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = array('SubjectExtend');
        $this->tListRows = 12;
		$this->themeDataList($field, $map, $order);
        $this->display('pattern_analysis');
    }

    public function invogue(){
        $cid = 17;
        $this->tableArr = getCidModel($cid);
        $map["{$this->tableArr['subject_original']}.menu_id"] = $cid;
        $field = "{$this->tableArr['subject_original']}.id,{$this->tableArr['subject_original']}.menu_id,title,title_picture_url,publish_time,season_id,area_no,pv_count";
		$order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = array('SubjectExtend');
        $this->tListRows = 12;
		$this->themeDataList($field, $map, $order);
        $this->display('invogue');
    }

    public function fashionStyle(){
        $styleTab = array(
            array('id'=>351,'name'=>'裙子','url'=>U('/'.MODULE_NAME.'/fashionStyle',array_merge($this->param,array('stid'=>351))),'selected'=>($this->param['stid'] == 351 ? true : false)),
            array('id'=>352,'name'=>'上装','url'=>U('/'.MODULE_NAME.'/fashionStyle',array('bid'=>intval($this->param['bid']),'seid'=>intval($this->param['seid']),'stid'=>352)),'selected'=>($this->param['stid'] == 352 ? true : false)),
            array('id'=>354,'name'=>'下装','url'=>U('/'.MODULE_NAME.'/fashionStyle',array('bid'=>intval($this->param['bid']),'seid'=>intval($this->param['seid']),'stid'=>354)),'selected'=>($this->param['stid'] == 354 ? true : false)),
            array('id'=>348,'name'=>'连体装','url'=>U('/'.MODULE_NAME.'/fashionStyle',array('bid'=>intval($this->param['bid']),'seid'=>intval($this->param['seid']),'stid'=>348)),'selected'=>($this->param['stid'] == 348 ? true : false)),
            array('id'=>349,'name'=>'内衣','url'=>U('/'.MODULE_NAME.'/fashionStyle',array('bid'=>intval($this->param['bid']),'seid'=>intval($this->param['seid']),'stid'=>349)),'selected'=>($this->param['stid'] == 349 ? true : false)),
            array('id'=>350,'name'=>'配饰','url'=>U('/'.MODULE_NAME.'/fashionStyle',array('seid'=>intval($this->param['seid']),'stid'=>350)),'selected'=>($this->param['stid'] == 350 ? true : false)),
            array('id'=>353,'name'=>'套装','url'=>U('/'.MODULE_NAME.'/fashionStyle',array('seid'=>intval($this->param['seid']),'stid'=>353)),'selected'=>($this->param['stid'] == 353 ? true : false)),
        );
        $this->assign('styleTab',$styleTab);

        $cid = 22;
        $this->tableArr = getCidModel($cid);
        $map[$this->tableArr['picture_original'].'.menu_id'] = $cid;
        $field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,area_no,brand_id,season_id,publish_time";
		$order = array('publish_time'=>'desc',$this->tableArr['picture_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->pListRows = 16;
		$this->pictureDataListBySphinx();//$this->pictureDataList($field, $map, $order,$cid);
        $this->display('fashion_style');
    }

    public function book(){
        $this->tListRows = 9;

        $title = trim($_POST['title']);
        if($title !== '') {
            $map['title'] = array("like","%{$title}%");
            $this->assign("keyword", $title);
        }

		$seid = $this->param['seid'];
		if ($seid)
            $map['season_id'] = $seid;

		$boid = $this->param['boid'];
		if ($boid)
            $map['book_id'] = $boid;

		$ano = $this->param['ano'];
		if ($ano){
            $anoTmp = dechex($ano);
            if(substr($anoTmp,-4,4) === '0000')
                $map['area_no'] = array(array('egt',$ano),array('lt',$ano+65536));
            elseif(substr($anoTmp,-2,2) === '00')
                $map['area_no'] = array(array('egt',$ano),array('lt',$ano+256));
            else
                $map['area_no'] = $ano;
        }

        $model = M('vBaby');
        $count = $model->where($map)->count();
   		//echo $model->getlastsql();
		import("ORG.Util.DataCount");
        $count = DataCount::getCount('vBaby',$map,$join);
		if ($count > 0) {
			import("ORG.Util.Page");
			$p = new Page($count, $this->tListRows);
            $field = "id,title,menu_id,title_picture_url,publish_time,season_id,book_id,pv_count";
            $voList = $model->where($map)->field($field)->order(array('publish_time'=>'desc','id'=>'desc'))->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo M()->getLastSql();
            if ($voList) {
				foreach ($voList as $key => $val) {
					$voList[$key]['bookStr'] = M('AttributeBook')->getField('name',array('id'=>intval($val['book_id'])));
                    if($val['content']) $voList[$key]['content'] = strip_tags ($val['content']);
					$voList[$key]['url'] = U("/".MODULE_NAME."/themeDetail",array('cid'=>$val['menu_id'],'tid'=>$val['id']));
					$voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
					$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
					$voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
				}
			}
			//dump($voList);
			//模板赋值显示
			$this->assign('listArr', $voList);
			//分页显示
			$page = $p->showOne();
			$this->assign("pageStr", $page);
		}

        $this->display('book');
    }

	public function themeDetail() {
        $this->assign('jumpUrl','javascript:window.close();');

        $cid = intval($_GET['cid']);
        $tid = intval($_GET['tid']);
		if (!$tid || !$cid)
           $this->error('参数错误！');

        $this->relationArr = array('SubjectExtend');

        if($cid == 17)
            $goPage = MODULE_NAME.'/theme_detail_17';
        elseif($cid == 24)
            $goPage = MODULE_NAME.'/theme_detail_24';
        elseif(in_array($cid,array(19,26,27)))
            $goPage = MODULE_NAME.'/theme_detail_19';
        else
            $this->error('请不要恶意操作。');

        $tid = $tid ? $tid : intval($_GET['tid']);
		$themeInfo = $this->themeInfo($cid,$tid);
        //dump($themeInfo);
        if($themeInfo['show_edit'] == 1)
            $this->getShowContent($cid,$themeInfo);
        else
            $this->themePicture($cid,$tid);

        $this->assign('info', $themeInfo);
		$this->display($goPage);
	}

    protected function getShowContent($cid,$themeInfo) {
        if (!$cid || !$themeInfo['id'])
            $this->error('参数错误！');

        $this->tableArr = getCidModel($cid);
        $model = M($this->tableArr['picture']);

        $field = "{$this->tableArr['picture_original']}.id,small_picture_url,big_picture_url";
        $map["{$this->tableArr['picture_original']}.menu_id"] = $cid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $themeInfo['id'];
        $Arr['picNum'] = $count = $model->where($map)->count();
        //echo $this->modelP->getLastSql();
        if ($count > 0) {
            import("ORG.Util.Page");
            $voList = $model->where($map)->field($field)->order(array('publish_time' => 'desc',$this->tableArr['picture_original'].'.id'=>'desc'))->findAll();
        }
        $picList = array();
        $parse_arr = parse_content($themeInfo['content']);
        $Arr['detailhtml'] = $parse_arr['result'];

        if ($parse_arr['pic_arr']) {
            //$i = 0;
            foreach ($parse_arr['pic_arr'] as $key => $val) {
                $picList[$key]['sTid'] = $themeInfo['id'];
                $picList[$key]['sPid'] = 0;
                $picList[$key]['sSex'] = $themeInfo['sort_id'];
                $picList[$key]['sCid'] = $this->cid;
                $picList[$key]['sPicNo'] = 0;
                $picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
                $picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
                $picList[$key]['sSpic'] = $val['sSpic'];
                $picList[$key]['sBpic'] = $val['sBpic'];
                if ($voList) {
                    foreach ($voList as $ke => $va) {
                        if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
                            //echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
                            $picList[$key]['sPid'] = $va['id'];
                            $picList[$key]['sSex'] = $va['sort_id'];
                            $picList[$key]['sPicNo'] = $va['id'];
                        }
                    }
                }
            }
        }

        $Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)); //放大图片
        $this->assign($Arr);
    }

 	protected function themeInfo($cid,$tid) {
		if (!$tid || !$cid)
           $this->error('参数错误！');

        $this->tableArr = getCidModel($cid);
        $model = D($this->tableArr['subject']);
		$map[$this->tableArr['subject_original'].'.menu_id'] = $cid;
		$map[$this->tableArr['subject_original'].'.id'] = $tid;
		$map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['fs.sort_id'] = array('egt',3);
        $join = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";

        $field = $this->tableArr['subject_original'].'.id,'.$this->tableArr['subject_original'].'.menu_id,title,publish_time,season_id,area_no,show_edit,brand_id,book_id';
		$info = $model->join($join)->relation($this->relationArr)->field($field)->where($map)->find();
        //echo $model->getLastSql()."<br/>";exit;
        if(!$info){
           $this->error('参数错误！');
        }
		$info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
        $info['sortStr'] = '婴童';//M('AttributeSort')->getField('name',array('id'=>$info['sort_id']));
        $info['areaStr'] = M('AttributeArea')->getField('name',array('no'=>$info['area_no']));
        $info['seasonStr'] = M('AttributeSeason')->getField('en_name',array('id'=>$info['season_id']));
        $info['bookStr'] = M('AttributeBook')->getField('name',array('id'=>$info['book_id']));
        $info['bookUrl'] = U('/ChildrenBabyZone/book',array('soid'=>3,'boid'=>$info['book_id']));
        $info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']): '';

        //权限验证
        $this->withoutPermission('',$info);

		return $info;
	}

	/**
	 * get theme picture list
	 * @param $tid intval
	 * @return array
	 */
	protected function themePicture($cid,$tid) {
		$tid = intval($tid);
		$this->assign('tid', $tid);

		if (!$tid)
           $this->error('参数错误！');

        $this->tableArr = getCidModel($cid);
        $model = M($this->tableArr['picture']);
        $order = in_array($cid,array(19,26,27)) ? array('page_no'=>'asc') : array('publish_time'=>'desc','id'=>'desc');
        $field = 'id,small_picture_url,big_picture_url,page_no';
		$map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
		$map['subject_id'] = $tid;
		$count = $model->where($map)->count();
        //echo $this->modelP->getLastSql();
		if ($count > 0) {
			import("ORG.Util.Page");
			$p = new Page($count, $this->pListRows);
			$voList = $model->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $this->modelP->getLastSql()."</br>";
            if ($voList) {
				$picList = array();
				foreach ($voList as $key => $val) {
					$voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
                    $voList[$key]['publish_time'] = date('Y-m-d',$val['publish_time']);

					$picList[$key]['sTid'] = 0;
					$picList[$key]['sPid'] = $val['id'];
					$picList[$key]['sCid'] = $this->cid;
					$picList[$key]['sPidNo'] = $val['id'];
					$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
					$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
					$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
				}
			}
			//var_dump($picList);
			$this->assign('jsonData', json_encode(array('arrPicList'=>$picList,'cid'=>$this->cid, 'isVip' => $this->isRightB)));
			//模板赋值显示
			$this->assign('listArr', $voList);
			//分页显示
			$this->assign('pageStr', $p->showOne());
            //主题下载处需要用到
            $this->assign('picNum',$count);
		}
	}

	/**
	 * 主题列表分页
	 * @param type $field
	 * @param type $map
	 * @param type $sortBy
	 * @param type $asc
	 * @return type
	 */
	protected function themeDataList($field, $map, $order) {
        $this->setDateSift();

        $model = D($this->tableArr['subject']);

        $map['is_publish'] = 1;

        $map['fs.sort_id'] = ACTION_NAME == 'patternAnalysis' || ACTION_NAME == 'index' ? array('egt',3) : 6;
        $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";

        $date = $this->param['date'];
        if($date){
            if(!in_array($date,array(7,30,90))){
                $date = 90;
                $this->assign('date',$date);
            }
            $dateTmp = strtotime(date("Y-m-d",$_SERVER['REQUEST_TIME'])." 23:59:59")-$date*86400;
            $map['publish_time'] = array(array('egt',$dateTmp),array('elt',C('TODAY_LAST_TIME')));

            $order = array_merge(array('pv_count'=>'desc'),$order);
            unset($dateTmp);
        }else{
            $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        }

		$seid = $this->param['seid'];
		if ($seid)
            $map['season_id'] = $seid;

		$ano = $this->param['ano'];
		if ($ano){
            $anoTmp = dechex($ano);
            if(substr($anoTmp,-4,4) === '0000'){
                $map['area_no'] = array(array('egt',$ano),array('lt',$ano + 65536));
            }
            elseif(substr($anoTmp,-2,2) === '00'){
                $map['area_no'] = array(array('egt',$ano),array('lt',$ano + 256));
            }
            else{
                $map['area_no'] = $ano;
            }
        }

        $bid = $this->param['bid'];
        $brandStr = $this->param['brandStr'];
        if(empty($bid) && $brandStr != ''){
            $bid = M('AttributeBrand')->getField('id',array('name'=>$brandStr));
            $bid = intval($bid);
            $bid ? $map['brand_id'] = $bid : '';
        }elseif($bid){
            $map['brand_id'] = $bid;
            $brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
            $this->assign('brandStr', $brandStr);
        }

 		//$count = $model->join($join)->where($map)->count();
		//echo $model->getlastsql();
		import("ORG.Util.DataCount");
        $count = DataCount::getCount($this->tableArr['subject'],$map,$join);
		if ($count > 0) {
			import("ORG.Util.Page");
			$p = new Page($count, $this->tListRows);
			$voList = $model->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $model->getLastSql();
            if ($voList) {
				foreach ($voList as $key => $val) {
					$voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
					$voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
					if ($val['season_id']) $voList[$key]['seasonStr'] = M('AttributeSeason')->getField('en_name',array('id'=>$val['season_id']));
					if ($val['area_no']) $voList[$key]['areaStr'] = M('AttributeArea')->getField('name',array('no'=>$val['area_no']));
					if ($val['brand_id']) $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
					if ($val['designer_id']) $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
					if ($val['book_id']) $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    if($val['content']) $voList[$key]['content'] = strip_tags ($val['content']);
					$voList[$key]['url'] = U("/".MODULE_NAME."/themeDetail",array('cid'=>$val['menu_id'],'tid'=>$val['id']));
					$voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
					$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
					//$voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
				}
			}
			//dump($voList);
			//模板赋值显示
			$this->assign('listArr', $voList);
			//分页显示
			$page = $p->showOne();
			$this->assign("pageStr", $page);
		}
	}

	/**
	 * 图片列表分页
	 * @param type $field
	 * @param type $map
	 * @param type $sortBy
	 * @param type $asc
	 * @return type
	 */
	protected function pictureDataList($field, $map, $order,$cid = null) {
        $model = D($this->tableArr['picture']);

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $map['fs.sort_id'] = 6;
        $join[] = "{$this->tableArr['ref_picture_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_original']}.id";

		$season_id = intval($_REQUEST['seid']);
		if ($season_id) $map['season_id'] = $season_id;

   		$detail_id = intval($_REQUEST['deid']);
		if ($detail_id) $map['detail_id'] = $detail_id;

		$area_no = intval($_REQUEST['ano']);
		if ($area_no){
            $ano = dechex($area_no);
            if(substr($ano,-4,4) === '0000'){
                $map['area_no'] = array(array('egt',$area_no),array('elt',$area_no + 65536));
            }
            elseif(substr($ano,-2,2) === '00'){
                $map['area_no'] = array(array('egt',$area_no),array('elt',$area_no + 256));
            }
            else{
                $map['area_no'] = $area_no;
            }
        }

        $deid = intval($_REQUEST['did']);
        $designerStr = trim($_REQUEST['designerStr']);
        if(empty($deid) && $designerStr != ''){
            $deid = M('AttributeDesigner')->getField('id',array('name'=>$designerStr));
            $deid = intval($deid);
            $deid ? $map['designer_id'] = $deid : '';
        }elseif($deid){
            $map['designer_id'] = $deid;
        }

        $bid = intval($_REQUEST['bid']);
        $brandStr = trim($_REQUEST['brandStr']);
        if(empty($bid) && $brandStr != ''){
            $bid = M('AttributeBrand')->getField('id',array('name'=>$brandStr));
            $bid = intval($bid);
            $bid ? $map['brand_id'] = $bid : '';
        }elseif($bid){
            $map['brand_id'] = $bid;
        }

        $boid = intval($_REQUEST['boid']);
        $bookStr = trim($_REQUEST['bookStr']);
        if(empty($boid) && $bookStr != ''){
            $boid = M('AttributeBook')->getField('id',array('name'=>$bookStr));
            $boid = intval($boid);
            $boid ? $map['book_id'] = $boid : '';
        }elseif($boid){
            $map['boid'] = $boid;
        }

        $stid = intval($_REQUEST['stid']);
		if ($stid) {
			$join[] = "{$this->tableArr['ref_picture_style_original']} ps ON ps.picture_id={$this->tableArr['picture_original']}.id";
            $map['ps.style_id'] = $stid;
		}

		$coid = intval($_REQUEST['coid']);
		if ($coid) {
			$join[] = "{$this->tableArr['ref_picture_color_original']} pc ON pc.picture_id={$this->tableArr['picture_original']}.id";
			$map['pc.color_id'] = $coid;
		}

        //风格
		$faid = intval($_REQUEST['faid']);
		if ($faid) {
			$join[] = "{$this->tableArr['ref_picture_fashion_original']} pf ON pf.picture_id={$this->tableArr['picture_original']}.id";
			$map['pf.fashion_id'] = $faid;
		}

        //配饰
		$acid = intval($_REQUEST['acid']);
		if ($acid) {
			$join[] = "{$this->tableArr['ref_picture_acc_original']} sa ON sa.picture_id={$this->tableArr['picture_original']}.id";
			$map['sa.acc_id'] = $acid;
		}

		//取得满足条件的记录数
		//$count = $model->join($join)->where($map)->count();
		//echo $model->getlastsql();
        import("ORG.Util.DataCount");
        $count = DataCount::getCount($this->tableArr['picture'],$map,$join);
		if ($count > 0) {
			import("ORG.Util.Page");
			//创建分页对象
			$p = new Page($count, $this->pListRows);
			//分页查询数据
			$voList = $model->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $model->getlastsql();
			if ($voList) {
				foreach ($voList as $key => $val) {
					$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);//show_pic_power($val['small_picture_url'], $this->isRightS);
					$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                    if ($val['brand_id']) $voList[$key]['brandStr'] = M('AttributeBrand')->getField('name',array('id'=>$val['brand_id']));
                    if ($val['area_no']) $voList[$key]['areaStr'] = M('AttributeArea')->getField('name',array('no'=>$val['area_no']));
					if ($val['season_id']) $voList[$key]['seasonStr'] = M('AttributeSeason')->getField('en_name',array('id'=>$val['season_id']));
					$picList[$key]['sTid'] = 0;
					$picList[$key]['sPid'] = $val['id'];
					$picList[$key]['sCid'] = $cid;
					$picList[$key]['sPidNo'] = $val['id'];
					$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
					$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
					$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
				}
			}
            //dump($voList);
			$this->assign('jsonData', json_encode(array('arrPicList'=>$picList,'cid'=>$cid, 'isVip' => $this->isRightB)));
			//模板赋值显示
			$this->assign('listArr', $voList);
			//分页显示
			$page = $p->showOne();
			$this->assign("pageStr", $page);
		}
	}

    /**
     * 500页后shpinx图片列表分页
     */
    protected function pictureDataListBySphinx() {
        $cid = 22;
 		import ('@.ORG.Search');
		$search = new Search();
        $search->setSortMode(SPH_SORT_EXTENDED,'publish_time desc,picture_id desc');
		$pageSize = 20;
		$page = intval($_GET['p']) < 1 ? 1 : intval($_GET['p']);
		$search->setPageSize($pageSize);
		$search->setPage($page);

        $map = array();//作缓存key值之用
        $map['menu_id'] = $cid;
        $search->setFilter('menu_id',array($cid));

        if ($this->cmid){
            $map['child_menu_id'] = $this->cmid;
            $search->setFilter('child_menu_id',array($this->cmid));
        }

        $search->setFilterRange('publish_time',strtotime('1990-01-01 00:00:00'),C('TODAY_LAST_TIME'));

		$search->setFilter('sort_id',array(6));

        $seid = $this->param['seid'];
        if ($seid){
            $map['season_id'] = $seid;
            $search->setFilter('season_id',array($seid));
        }

        $deid = $this->param['deid'];
        if ($deid){
            $map['detail_id'] = $deid;
            $search->setFilter('detail_id',array($deid));
        }

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('elt', $ano + 65535));
                $search->setFilterRange('area_no',$ano,$ano + 65535);
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('elt', $ano + 256));
                $search->setFilterRange('area_no',$ano,$ano + 256);
            } else {
                $map['area_no'] = $ano;
                $search->setFilter('area_no',array($ano));
            }
        }

        $bid = $this->param['bid'];
        $brandStr = $this->param['brandStr'];
        if (empty($bid) && $brandStr != '') {
            $bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
            $bid = intval($bid);
            $bid ? $search->setFilter('brand_id',array($bid)) : '';
            $map['brand_id'] = $bid;
        } elseif ($bid) {
            $map['brand_id'] = $bid;
            $search->setFilter('brand_id',array($bid));
            $brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
            $this->assign('brandStr', $brandStr);
        }

		//款式
        $stid = $this->param['stid'];
        $stid = $stid ? $stid : ($this->sid == 2 ? 128 : 0);
        if ($stid){
            $map['style_id'] = $stid;
            $search->setFilter('style_id',array($stid));
        }

        $coid = $this->param['coid'];
        if ($coid){
            $map['color_id'] = $coid;
            $search->setFilter('color_id',array($coid));
        }

        $maid = $this->param['maid'];
        if ($maid){
            $map['material_id'] = $maid;
            $search->setFilter('material_id',array($maid));
        }

        //风格
        $faid = $this->param['faid'];
        if ($faid){
            $map['fashion_id'] = $faid;
            $search->setFilter('fashion_id',array($faid));
        }
        //配饰
        $acid = $this->param['acid'];
        if ($acid){
            $map['acc_id'] = $acid;
            $search->setFilter('acc_id',array($acid));
        }

        //关键词
        $kid = $this->param['kid'];
        if ($kid){
            $map['keyword_id'] = $kid;
            $search->setFilter('keyword_id',array($kid));
        }

        $cache_key = md5("ChildrenBabyZone::pictureDataListBySphinx::".$this->isRightS."::".$this->isRightB.'::6::'.$this->sid."::".$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $rows = $search->query();
            $count = intval($rows['total_found']);//下面做分页之用
            $Arr['listArr'] = array();
            $picList = array();
            $Arr['total'] = intval($rows['total_found']);
            $Arr['runTime'] = $rows['time'];

            if ($count > 0) {
                import("ORG.Util.Page");
                $p = new Page($count, $pageSize);
                foreach ($_REQUEST as $key => $val) {
                    if (!is_array($val)) {
                        $p->parameter .= "$key=" . urlencode($val) . "&";
                    }
                }

				$field = 'picture_id,small_picture_url,big_picture_url,menu_id,publish_time,season_id,brand_id,area_no';
				$ids = array();
				foreach ($rows['matches'] as $k => $v)
					$ids[] = $v['id'];

                $voList = $search->getPicInfoByIds($ids,$field);
                if($voList){
                    foreach ($voList as $key =>$val) {
                        $voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);
                        $voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);
                        if ($val['brand_id']) $voList[$key]['brandStr'] = M('AttributeBrand')->getField('name',array('id'=>$val['brand_id']));
                        if ($val['area_no']) $voList[$key]['areaStr'] = M('AttributeArea')->getField('name',array('no'=>$val['area_no']));
                        if ($val['season_id']) $voList[$key]['seasonStr'] = M('AttributeSeason')->getField('en_name',array('id'=>$val['season_id']));

                        $picList[$key]['sTid'] = 0;
                        $picList[$key]['sPid'] = $val['picture_id'];
                        $picList[$key]['sCid'] = $val['menu_id'];
                        $picList[$key]['sPidNo'] = $val['picture_id'];
                        $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                        $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                        $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                    }

                    $Arr['listArr'] = $voList;
                    $Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
                    $Arr['pageStr'] = $p->showOne();
                }
             }
             $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
		}

        $this->assign($Arr);
    }

    protected function setCidSift() {
        $Arr = $config = array();
        $sMap['sort_id'] = 6;

        if(ACTION_NAME == 'invogue' || $this->param['act'] == 'invogue'){
            $sMap['menu_id'] = 17;
            $fieldArr = array('season_id_list','area_no_list','brand_id_list'); //季度
            $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
            $Arr['areas'] = $this->areas = $siftArr['area_no_list'];
            $this->seasons = $siftArr['season_id_list'];
            $Arr['brands'] = $this->brands = $siftArr['brand_id_list'];
            $Arr['letters'] = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
        }
        elseif(ACTION_NAME == 'fashionStyle'){
            $sMap['menu_id'] = 22;
            $fieldArr = array('season_id_list'); //季度
            $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
            $this->seasons = $siftArr['season_id_list'];
        }
        elseif(ACTION_NAME == 'book'){
            $sMap['menu_id'] = array('in','19,26,24');
            $fieldArr = array('season_id_list','area_no_list'); //季度
            $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
            $Arr['areas'] = $this->areas = $siftArr['area_no_list'];
            $this->seasons = $siftArr['season_id_list'];
        }

        if ($this->seasons) {
            $seasonsTmp = $this->seasons;
            uasort($seasonsTmp, "cmp");
            $Arr['seasons'] = $seasonsTmp;
            unset($seasonsTmp);
        }
        if ($this->areas) {
            $Arr['areaHtml'] = $this->getAreaOption($_REQUEST['ano']);
        }

        $this->assign($Arr);
    }

    protected function setCmid(){

    }

    protected function getSoid(){

    }

    protected function setParam() {
        $this->param = array('cmid' => intval($this->cmid));

        $seid = intval($_REQUEST['seid']);
        if ($seid)
            $this->param = array_merge($this->param, array('seid' => $seid));

        $stid = intval($_REQUEST['stid']);
        if ($stid)
            $this->param = array_merge($this->param, array('stid' => $stid));

        $ano = intval($_REQUEST['ano']);
        if ($ano)
            $this->param = array_merge($this->param, array('ano' => $ano));

        $bid = intval($_REQUEST['bid']);
        if ($bid)
            $this->param = array_merge($this->param, array('bid' => $bid));

        $boid = intval($_REQUEST['boid']);
        if ($boid)
            $this->param = array_merge($this->param, array('boid' => $boid));

        $brandStr = trim($_REQUEST['brandStr']);
        if ($brandStr)
            $this->param = array_merge($this->param, array('brandStr' => $brandStr));

        $date = intval($_REQUEST['date']);
        if ($date)
            $this->param = array_merge($this->param, array('date' => $date));

        $act = trim($_REQUEST['act']);
        if ($act)
            $this->param = array_merge($this->param, array('act' => $act));
    }

    public function getPicFt() {
        $pid = intval($_REQUEST['pid']);
        $limit = intval($_REQUEST['i']);
        $limit = empty($limit) ? 0 : $limit;

        if ($pid < 1)
            exit('failure');

        $field = 'big_picture_url,small_picture_url';
        $orgPic = M('StylePicture')->field($field)->where("id='{$pid}' and is_publish=1")->find();
        $orgSmallSrc = show_pic_power($orgPic["small_picture_url"], $this->isRightS);
        $orgBigSrc = show_pic_power($orgPic["big_picture_url"], $this->isRightB);
        $data = "<li id='ft0' onclick='viewPic.imgFtChoose(0)' class='fta current'><img onclick='viewPic.loadPicFt(\"{$orgBigSrc}\")' alt='' src='{$orgSmallSrc}' title='' /></li>";

        $arrPicList = M('StylePictureSubsidiary')->field($field)->where("picture_id='{$pid}' and is_publish=1")->findAll();
        if ($arrPicList) {
            $i = 1;
            foreach ($arrPicList as $key => $val) {
                $smallSrc = show_pic_power($val["small_picture_url"], $this->isRightS);
                $bigSrc = show_pic_power($val["big_picture_url"], $this->isRightB);
                $data .= "<li id='ft{$i}' onclick='viewPic.imgFtChoose($i)' class='fta'><img onclick='viewPic.loadPicFt(\"{$bigSrc}\")' alt='' src='{$smallSrc}' title='' /></li>";
                ++$i;
            }
        }

        exit($arrPicList ? $data : '');
    }

	public function downloadzip() {
        parent::downloadzip();
    }
}
