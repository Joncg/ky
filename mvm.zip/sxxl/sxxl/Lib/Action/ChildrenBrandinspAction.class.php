<?php
class ChildrenBrandinspAction extends BrandinspAction {

    public function _initialize() {
        $this->soid = 3;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

	public function themeDetail($tid = '') {
        parent::themeDetail($tid);
	}

    protected function getSpecialChildMenu(){
        $specialChildMenu = array(
            array('id'=>10992,'url'=>U("/".MODULE_NAME."/index",array('bid'=>10992)),'picture'=>'/Public/Images/fishion/c-brand/allo&lugh.jpg','name'=>'allo&lugh'),
            array('id'=>3608,'url'=>U("/".MODULE_NAME."/index",array('bid'=>3608)),'picture'=>'/Public/Images/fishion/c-brand/Benetton.jpg','name'=>'Benetton'),
            array('id'=>466,'url'=>U("/".MODULE_NAME."/index",array('bid'=>466)),'picture'=>'/Public/Images/fishion/c-brand/BITZ.jpg','name'=>'monnalisa'),
            array('id'=>118,'url'=>U("/".MODULE_NAME."/index",array('bid'=>118)),'picture'=>'/Public/Images/fishion/c-brand/burberry.jpg','name'=>'burberry'),
            array('id'=>3446,'url'=>U("/".MODULE_NAME."/index",array('bid'=>3446)),'picture'=>'/Public/Images/fishion/c-brand/catimini.jpg','name'=>'catimini'),
            array('id'=>279,'url'=>U("/".MODULE_NAME."/index",array('bid'=>279)),'picture'=>'/Public/Images/fishion/c-brand/celden.jpg','name'=>'Gap'),
            array('id'=>195,'url'=>U("/".MODULE_NAME."/index",array('bid'=>195)),'picture'=>'/Public/Images/fishion/c-brand/DIESEL.jpg','name'=>'DIESEL'),
            array('id'=>1078,'url'=>U("/".MODULE_NAME."/index",array('bid'=>1078)),'picture'=>'/Public/Images/fishion/c-brand/GUESS.jpg','name'=>'GUESS'),
            array('id'=>3394,'url'=>U("/".MODULE_NAME."/index",array('bid'=>3394)),'picture'=>'/Public/Images/fishion/c-brand/John-Galliano.jpg','name'=>'John Galliano'),
            array('id'=>331,'url'=>U("/".MODULE_NAME."/index",array('bid'=>331)),'picture'=>'/Public/Images/fishion/c-brand/OHOO.jpg','name'=>'IKKS'),
            array('id'=>7914,'url'=>U("/".MODULE_NAME."/index",array('bid'=>7914)),'picture'=>'/Public/Images/fishion/c-brand/oshkosh.jpg','name'=>'oshkosh'),
            array('id'=>7268,'url'=>U("/".MODULE_NAME."/index",array('bid'=>7268)),'picture'=>'/Public/Images/fishion/c-brand/twin-kids.jpg','name'=>'twin kids'),
            array('id'=>6218,'url'=>U("/".MODULE_NAME."/index",array('bid'=>6218)),'picture'=>'/Public/Images/fishion/c-brand/walton.jpg','name'=>'Nicholas & Bears'),
            array('id'=>715,'url'=>U("/".MODULE_NAME."/index",array('bid'=>715)),'picture'=>'/Public/Images/fishion/c-brand/zara.jpg','name'=>'zara'),
        );
        return $specialChildMenu;
    }

	public function downloadzip() {
        parent::downloadzip();
    }
}

