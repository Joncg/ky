<?php

class IndexAction extends CommonAction {

	protected $soid = 2; //女装

	public function index() {
        //header("Content-type:text/html;charset=utf-8");
        //exit('蝶讯新服装网10-08号上线！敬请期待！');
        $cache = trim($_REQUEST['cache']);
		if ($cache != 'false' && is_cache_time_valid('indexdata')) {
			$Arr = F('indexdata', '', C('CACHE_PATH_FILE') . "indexdata/");
		} else {
			//流行趋势
			$Arr['trendList'] = parent::getRecList('A3', 4);
			$Arr['trendMoreUrl'] = parent::getMoreUrl(11);
			//时装发布
			$Arr['catwalkList'] = parent::getRecList('A1', 7);
			$Arr['catwalkTab'] = parent::getSubMenuList(12);
			$Arr['catwalkMoreUrl'] = parent::getMoreUrl(12);
			$Arr['catwalkSift'] = parent::getAttributeSift('season_id_list,area_no_list', "menu_id = 12 and child_menu_id = 31", false);
			if ($Arr['catwalkSift']['season_id_list']) {
				usort($Arr['catwalkSift']['season_id_list'], "cmp");
			}
			if ($Arr['catwalkSift']['area_no_list']) {
				$Arr['catwalkSift']['areaHtml'] = $this->getAreaOption($Arr['catwalkSift']['area_no_list'], '');
				unset($Arr['catwalkSift']['area_no_list']);
			}
			$Arr['catwalkSift']['sorts'] = C('SORT');
			//T台趋势
			$Arr['tshapeList'] = parent::getRecList('A4', 4);
			$Arr['tshapeMoreUrl'] = parent::getMoreUrl(13);
			//时尚杂志
			$Arr['magazineList'] = parent::getRecOne('A5');
			//企划方案
			$Arr['layoutPlanList'] = parent::getRecList('A6', 10);
			$Arr['layoutPlanMoreUrl'] = parent::getMoreUrl(14);
			//正在流行
			$Arr['invogueRecommendOne'] = parent::getRecList('A2', 1);
			$Arr['invogueList'] = parent::getInvogueNewlistBySphinx(2, 4);
			$Arr['invogueMoreUrl'] = parent::getMoreUrl(17);
			//流行分析
			$Arr['popularsList'] = parent::getRecList('A7', 4);
			//图案
			$Arr['patternsList'] = parent::getRecOne('A8');
			$Arr['patternsTab'] = $this->patternsTab();
			//招聘信息
			$Arr['jobList'] = $this->getJobList();
			F('indexdata', $Arr, C('CACHE_PATH_FILE') . "indexdata/");
		}
		//数据统计
		$timestr = date("Y.m.d");
		$weekarray = array('日', '一', '二', '三', '四', '五', '六');
		$weekstr = "星期" . $weekarray[date("w")];
		$this->assign('timestr', $timestr);
		$this->assign('weekstr', $weekstr);

		$Arr = array_merge($Arr, parent::getPageInfo());
		$this->assign($Arr);
		$this->display();
	}

	public function picNum() {
		$cache_path = C('CACHE_PATH_FILE') . "indexdata/";
		$inside_arr = F('inside_arr', '', $cache_path);
		if (empty($inside_arr)) {
			$inside_arr['min'] = rand(12000, 20000); //初始今日更新数量(事实上是昨天更新的数量)
			$inside_arr['max'] = 24185916; //初始总数
			F('inside_arr', $inside_arr, $cache_path); //初次生成缓存文件
		}
		//如果为星期天，则今日更新数为0，总数不跳动
		//if (date('w') == 0) {
		//	$inside_arr['min'] = 0;
		//} else {
			$last_modified = filemtime($cache_path . 'inside_arr.php'); //获取文件最后更新时间
			$last_update = date("Y-m-d", $last_modified); //输出最后更新时间UNIX时间戳
			if ($last_update != date('Y-m-d')) {
				if ($inside_arr['max'] > 0) {
					$inside_arr['max'] = $inside_arr['max'] ? ($inside_arr['max'] + $inside_arr['min']) : 24185916;
					$inside_arr['min'] = (date('w') == 0) ? rand(3500, 4500) : rand(12000, 20000);
					F('inside_arr', $inside_arr, $cache_path);
				}
			}
		//}

		$add_new = str_split(str_pad(strval($inside_arr['min']), 5, '0', STR_PAD_LEFT));
		//dump($add_new);exit();
		$total = str_split(str_pad(strval($inside_arr['max']), 8, '0', STR_PAD_LEFT));
		$new_html = '';
		foreach ($add_new as $key => $value) {
			$new_html .= "<b>" . $value . "</b>";
		}
		$total_html = '';
		foreach ($total as $k => $v) {
			if ($k >= 5) {
				$total_html .= "<b class='special'>" . $v . "</b>";
			} else {
				$total_html .= "<b>" . $v . "</b>";
			}
		}
		//var_dump($total_html);
		$rArr = array('totalCount' => $total_html, 'todayCount' => $new_html);

		$this->ajaxReturn($rArr, '获取最新图片数量成功！', 1);
	}

	public function oldSxxlPicNum() {
		$cache_path = C('CACHE_PATH_FILE') . "indexdata/";
		$inside_arr = F('inside_arr', '', $cache_path);
		exit(json_encode($inside_arr));
	}

	protected function patternsTab() {
		$cid = 24;
		$list = array();
		$patternInfoArr = array('65' => 'TrendsImage', '66' => 'AnalsyeImage', '67' => 'BooksImage', '68' => 'InspirationImage', '69' => 'PrintsImage', '70' => 'DatabaseImage');
		$patternList = parent::getSubMenuList($cid);
		if ($patternList) {
			foreach ($patternList as $key => $val) {
				$list[$key] = $val;
				$list[$key]['class'] = $patternInfoArr[$val['id']];
			}
		}
		return $list;
	}

	protected function getAreaOption($areas, $sid = 0) {
		import('@.ORG.Tree');
		$tree = new Tree($areas);
		$tree->set('gid', 'no');
		$tree->set('parent_id', 'parent_no');
		$phtml = "<option value='\$no' \$selected>\$spacer\$name</option>";
		$areaHtml = $tree->getTree(0, $phtml, $sid);
		return $areaHtml;
	}

	protected function getJobList() {

		$voList = unserialize(getCurlDate('newwww.php?act=job_show', ''));
		//echo "<pre>";
		//print_r($voList);
		return $voList;
	}
}
