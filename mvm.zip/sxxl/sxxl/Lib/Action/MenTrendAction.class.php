<?php

class MenTrendAction extends TrendAction {

	public function _initialize() {
		$this->soid = 1;
		parent::_initialize();
	}

	public function index() {
		$this->childMenus = $this->getSubMenuList($this->cid);
		parent::index();
	}

	public function folderList() {
		$this->childMenus = $this->getSubMenuList($this->cid);
		parent::folderList();
	}

	public function folderDetail() {
		$this->pListRows = 20;
		parent::folderDetail();
	}

	public function downloadzip() {
		parent::downloadzip();
	}

}
