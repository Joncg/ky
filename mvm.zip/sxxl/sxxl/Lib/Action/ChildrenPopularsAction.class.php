<?php

class ChildrenPopularsAction extends PopularsAction {

	public function _initialize() {
		$this->soid = 3;
		parent::_initialize();
	}

	public function index() {
		parent::index();
	}

	public function folderDetail() {
		$this->pListRows = 20;
		parent::folderDetail();
	}

	public function downloadzip() {
		parent::downloadzip();
	}

}
