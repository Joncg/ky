<?php

class OtherAction extends CommonAction {

	function _initialize() {
		parent::_initialize();
		//品牌中英文表，展会日程表特殊处理
		if (MODULE_NAME == 'Other') {
			$curMenu = 'Other';
			if (ACTION_NAME == 'brandList')
				$curMenu = 'brandList';
			elseif (ACTION_NAME == 'exhibitionSchedule')
				$curMenu = 'exhibitionSchedule';
		}
		$this->assign('curMenu', $curMenu);
		$this->cache = Cache::getInstance();
	}

	public function service() {
		$Arr['title'] = '客户中心_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'service';
		$this->assign($Arr);
		$this->display('service');
	}

	public function payType() {
		$Arr['title'] = '付款方式_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'payType';
		$this->assign($Arr);
		$this->display('pay_type');
	}

	public function serviceItem() {
		$Arr['title'] = '服务条款_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'serviceItem';
		$this->assign($Arr);
		$this->display('service_item');
	}
    
    /**
	 * 广告服务
	 */
	public function offer() {
		$Arr['title'] = '广告服务_我的蝶讯';
		$Arr['currentTagB'] = 'offer';
		$this->assign($Arr);
		$this->display();
	}
    
    /**
	 * 新版网站上线广告第二版
	 */
	public function newsxxl() {
		$Arr['title'] = '2012蝶讯网专题页_蝶讯服装网';
		$this->assign($Arr);
		$this->display();
	}

	public function priProclaim() {
		$Arr['title'] = '隐私声明_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'priProclaim';
		$this->assign($Arr);
		$this->display('pri_proclaim');
	}

	public function codexProclaim() {
		$Arr['title'] = '法律声明_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'codexProclaim';
		$this->assign($Arr);
		$this->display('codex_proclaim');
	}

	public function orderVip() {
		$Arr['title'] = '收费一览_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'orderVip';

		$cache = $_GET['cache'] ? $_GET['cache'] : false;
		$cKey = 'roleList';

		//权限列表
		$vipList = $cache == true ? $this->cache->get($cKey) : '';
		if (empty($vipList)) {
			$map['status'] = 1;
			$vipList = M('Role')->where($map)->field('id,name,dsc,price,status')->limit(24)->findAll();
			//echo M('Role')->getLastSql();
			if ($vipList) {
				$vipListTmp = array();
				foreach ($vipList as $key => $val) {
					$vipListTmp[$val['id']] = $val;
				}
				$vipList = $vipListTmp;
				$this->cache->set($cKey, $vipList);
			}
		}
		$Arr['vipList'] = $vipList;

		$this->assign($Arr);
		$this->display('order_vip');
	}

	public function signDemo() {
		$Arr['title'] = '注册演示_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'signDemo';
		$this->assign($Arr);
		$this->display('sign_demo');
	}

	public function landingDemo() {
		$Arr['title'] = '登陆演示_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'landingDemo';
		$this->assign($Arr);
		$this->display('landing_demo');
	}

	public function downClient() {
		$Arr['title'] = '终端下载_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'downClient';
		$this->assign($Arr);
		$this->display('down_client');
	}

	public function question() {
		$Arr['title'] = '常见问题_客户服务_蝶讯服装网';
		$Arr['currentTagB'] = 'question';
		$this->assign($Arr);
		$this->display('question');
	}

	public function exhibitionSchedule() {
		$Arr['title'] = '全球发布会展会日程表_蝶讯服装网';
		$data = getCurlDate('newwww.php?act=show_zh', '');
		$page = $_GET['p'] ? $_GET['p'] : "1";
		$indexinpage = 10;
		$newarr = array_slice($data, ($page - 1) * $indexinpage, $indexinpage);
        $now = time();
        foreach ($newarr as $key => $value) {
            $start_str_time = $this->getDataStr($value['start_time'],true);
            $end_str_time = $this->getDataStr($value['end_time']);
            if ( $end_str_time < $now ) {
                $newarr[$key]['status'] = '';//已结束
            }
            if ( $start_str_time > $now ) {
                $newarr[$key]['status'] = 'soon';//未开始
            }
            if ( $start_str_time < $now && $end_str_time > $now ) {
                $newarr[$key]['status'] = 'bein';//正在进行
            }
            $newarr[$key]['is_show'] = strlen($value['remark']) > 400 ? 1 : 0;
        }
		$count = count($data);
		import("ORG.Util.Page");
		$p = new Page($count, '10');
		$Arr['pageStr'] = $p->showOne();
		$Arr['currentTagB'] = 'exhibitionSchedule';
		$Arr['voList'] = $newarr;
		$this->assign($Arr);
		$this->display('exhibition_schedule');
	}

    protected function getDataStr($time,$is_b = false){
        if ( empty($time) ) {
            return false;
        }
        $timeArr = explode('-', $time);
        $newTimeSre = '';
        if ( $is_b ){
            $newTimeSre = mktime(0, 0, 0, $timeArr['1'], $timeArr['2'], $timeArr['0']);
        } else {
            $newTimeSre = mktime(23, 59, 59, $timeArr['1'], $timeArr['2'], $timeArr['0']);
        }
        return $newTimeSre;
    }

    public function brandList() {
		$Arr['title'] = '中英文品牌对照表_蝶讯服装网';
		$Arr['currentTagB'] = 'brandList';

		$k = trim($_GET['k']);
		$Arr['k'] = $k = empty($k) ? 'all' : $k;
		$url = C('CRM_HTTP') . "newwww.php?act=brand_list&k=";
		$param = $k;
		$key = C('SXXL_KEY');
		$Arr['voList'] = get_json_data($url, $param, $key);
		$this->assign($Arr);
		$this->display('brand_list');
	}

	public function transferProblem() {
		$Arr['title'] = '蝶讯服装网2012新版上线通知_蝶讯服装网';
		$this->assign($Arr);
		$this->display('Public:transfer_problem');
	}

	//建议反馈
	public function Suggestion() {
		//$datas['contact'] = $dataf['content'] = iconv('gbk', "utf-8", $_REQUEST['contact']);
		$datas['contact'] = $dataf['content'] = htmlentities($_REQUEST['contact'],ENT_QUOTES,"utf-8");
		$datas['post_url'] = $_SERVER['HTTP_REFERER'];
		$datas['loginUser'] = Cookie::get('loginUser');
		$datas['add_ip'] = $_SERVER['REMOTE_ADDR'];
		$map['member_id'] = $dataf['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
		$map['invalid_time'] = array("egt", time());
		$data = D('RefMemberRole')->where($map)->select();
		if ($data) {
			foreach ($data as $k => $v) {
				$vipstr .= $v['role_id'] . ",";
			}
		}
		$datas['viptype'] = rtrim($vipstr, ',');
		if (!$datas['contact']) {
			echo "0";
		} else {
			$dataf['add_time'] = time();
			D('Feedback')->add($dataf);
			$datas['insert_id'] = D('Feedback')->getLastInsID();
			if (getCurlDate('newwww.php?act=suggestion', $datas)) {
				echo "1";
			} else {
				echo "0";
			}
		}
	}

	/**
	 * 帮助中心
	 */
	public function helpCenter() {
		$Arr['title'] = '帮助中心_我的蝶讯';
		$Arr['currentTagA'] = 'MemberCenter';
		$Arr['currentTagB'] = 'helpCenter';
		$this->assign($Arr);
		$this->display('help_center');
	}
}
?>
