<?php
class CowboyBookAction extends BookAction {

    public function _initialize() {
        $this->sid = 1;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

	public function themeDetail($tid = '') {
        parent::themeDetail($tid);
	}
	
	public function downloadzip() {
		parent::downloadzip();
	}
}
