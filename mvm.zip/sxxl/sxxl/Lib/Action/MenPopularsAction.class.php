<?php

class MenPopularsAction extends PopularsAction {

	public function _initialize() {
		$this->soid = 1;
		parent::_initialize();
	}

	public function index() {
		parent::index();
	}

	public function folderDetail() {
		$this->pListRows = 20;
		parent::folderDetail();
	}

	public function downloadzip() {
		parent::downloadzip();
	}

}
