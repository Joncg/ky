<?php
class ChildrenStreetFashionAction extends StreetFashionAction {

    public function _initialize() {
        $this->soid = 3;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

	public function themeDetail($tid = '') {
        $this->pListRows = 20;
        parent::themeDetail($tid);
	}
	
	public function downloadzip() {
        parent::downloadzip();
    }
}