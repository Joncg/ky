<?php

class InvogueAction extends TideSectionAction {

    public function _initialize() {
        $this->cid = 17;
        $this->cache = Cache::getInstance();
        parent::_initialize();
    }

    /**
     * 主题列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeDataList($field, $map, $order, $join = array()) {
        //时间筛选项
        $this->setDateSift();

        if($this->sid == 4)
            $cid = 101; //内衣.正在流行 menu_id=101
        else
            $cid = $this->cid;

        if ($cid)
            $map[$this->tableArr['subject_original'] . '.menu_id'] = $cid;

        $aid = $this->param['aid'];
        if($this->sid == 1){
             if ($aid === 'gw') {
                $map['area_no'] = array(array('lt', 397568), array('egt', 397824), 'or');
                $join[] = "{$this->tableArr['ref_subject_style_original']} sa on sa.subject_id={$this->tableArr['subject_original']}.id";
                $map['sa.style_id'] = 211;
            } elseif ($aid === 'gl') {
                $this->cmid = 57;
                $join[] = "{$this->tableArr['ref_subject_style_original']} sa on sa.subject_id={$this->tableArr['subject_original']}.id";
                $map['sa.style_id'] = 211;
            } elseif ($aid === 'hg') {
                $this->cmid = 55;
            }
        }elseif(!$this->sid){
            if ($aid === 'gw'){
                $map['area_no'] = array(array('lt', 397568), array('egt', 397824), 'or');
            }elseif ($aid === 'gl'){
                $this->cmid = 57;
            }elseif ($aid === 'hg'){//韩国东大门
                if($this->soid == 2){//女
                    $this->cmid = 59;
                }elseif($this->soid == 3){//童
                    $this->cmid = 60;
                }
            }
        }

        //除牛仔专栏之外其它栏目不显示韩版牛仔的数据
        if ($this->cmid && $this->cmid != 55 || ($this->cmid && $this->sid == 1)){
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;
        }else{
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = array('neq',55);
        }

        //时尚杂志特殊处理
        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] =  $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }

        if(empty($map['sa.style_id']) && $this->sid == 2){
            if($this->cmid != 55){
                //正在流行裤子专栏，主题数据展示裤子(128)
                $join[] = "{$this->tableArr['ref_subject_style_original']} sa on sa.subject_id={$this->tableArr['subject_original']}.id";
                $map['sa.style_id'] = 128;
            }
        }

       if (($this->sid == 1 && $this->param['aid'] != 'hg') || $this->sid == 5) {
            $map['fsc.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
        }

        $map['is_publish'] = 1;

        $date = $this->param['date'];
        if ($date) {
            if (!in_array($date, array(7, 30, 90))) {
                $date = 90;
                $this->assign('date', $date);
            }
            $dateTmp = strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - $date * 86400;
            $map['publish_time'] = array(array('egt', $dateTmp),array('elt',C('TODAY_LAST_TIME')));

            //以人气排序
            $order = array_merge(array('pv_count'=>'desc'),$order);
            unset($dateTmp);
        }else{
            $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        }

        $seid = $this->param['seid'];
        if ($seid)
            $map['season_id'] = $seid;

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }
            $this->assign('areaStr', $this->areas[$ano]['name']);
        }

        $bid = $this->param['bid'];
        $brandStr = $this->param['brandStr'];
        if (!$bid && $brandStr != '') {
            $bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
            $bid = intval($bid);
            if($bid){
                $map['brand_id'] = $bid;
                $this->assign('bid',$bid);
            }
        } elseif ($bid) {
            $map['brand_id'] = $bid;
            $brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
            $this->assign('brandStr', $brandStr);
        }

        $stid = $this->param['stid'];
        if ($map['sst.style_id'] || $stid) {
            $join[] = "{$this->tableArr['ref_subject_style_original']} sst on sst.subject_id={$this->tableArr['subject_original']}.id";
            $map['sst.style_id'] ? '' : $map['sst.style_id'] = $stid;
        }

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Invogue::'.'themeDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->sid . '::' . $this->soid . '::' .$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            import("ORG.Util.DataCount");
			$count = DataCount::getCount($this->tableArr['subject'], $map, $join);
            //$count = $this->modelT->join($join)->where($map)->count();
            if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->tListRows);
                $voList = $this->modelT->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
				//echo $this->modelT->getLastSql();
				//dump($voList);exit;
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        if ($val['season_id'])
                            $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        if ($val['area_no'])
                            $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];

                        if($this->sid == 1 && $this->param['aid']){//为了便于牛仔专主题详情页权限验证，添加参数aid
                            $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'aid'=>$this->param['aid'],'soid'=>$soid,'tid' => $val['id']));
                        }else{
                            $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'soid'=>$soid,'tid' => $val['id']));
                        }

                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                        $voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    /**
     * 主题列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeDataListBySphinx($field, $map, $order, $join = array()) {
		import('@.ORG.Search');
		$search = new Search();
		$search->setSortMode(SPH_SORT_EXTENDED, 'publish_time desc,id desc');
		$pageSize = $this->tListRows;
		$page = intval($_GET['p']) < 1 ? 1 : intval($_GET['p']);
		$search->setPageSize($pageSize);
		$search->setPage($page);

        //时间筛选项
        $this->setDateSift();

        if($this->sid == 4)
            $cid = 101; //内衣.正在流行 menu_id=101
        else
            $cid = $this->cid;

        $aid = $this->param['aid'];
        if($this->sid == 1){
             if ($aid === 'gw') {
                $map['area_no'] = array(array('lt', 397568), array('egt', 397824), 'or');
                $search->setFilterRange('area_no', 397569, 397823,true);
                $map['sst.style_id'] = 211;
                $search->setFilter('style_id', array(211));
            } elseif ($aid === 'gl') {
                $this->cmid = 57;
                $map['sst.style_id'] = 211;
                $search->setFilter('style_id', array(211));
            } elseif ($aid === 'hg') {
                $this->cmid = 55;
            }
        }elseif(!$this->sid){
            if ($aid === 'gw'){
                $map['area_no'] = array(array('lt', 397568), array('egt', 397824), 'or');
                $search->setFilterRange('area_no', 397569, 397823,true);
            }elseif ($aid === 'gl'){
                $this->cmid = 57;
            }elseif ($aid === 'hg'){//韩国东大门
                if($this->soid == 2){//女
                    $this->cmid = 59;
                }elseif($this->soid == 3){//童
                    $this->cmid = 60;
                }
            }
        }

        if ($cid){
            $map[$this->tableArr['subject_original'] . '.menu_id'] = $cid;
            $search->setFilter('menu_id', array($cid));
        }

        //除牛仔专栏之外其它栏目不显示韩版牛仔的数据
        if ($this->cmid && $this->cmid != 55 || ($this->cmid && $this->sid == 1)){
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;
            $search->setFilter('child_menu_id', array($this->cmid));
        }else {
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = array('neq',55);
            $search->setFilter('child_menu_id', array(55),true);
        }

        //时尚杂志特殊处理
        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] =  $soid == 3 ? array('egt',3) : $soid;
			if ($soid == 3)
				$search->setFilter('sort_id', $this->childrenSoids);
			else
				$search->setFilter('sort_id', array($soid));
        }

        if(empty($map['sa.style_id']) && $this->sid == 2){
            if($this->cmid != 55){
                //正在流行裤子专栏，主题数据展示裤子(128)
                $map['sa.style_id'] = 128;
                $search->setFilter('style_id', array(128));
            }
        }

       if (($this->sid == 1 && $this->param['aid'] != 'hg') || $this->sid == 5) {
            $map['fsc.special_column_id'] = $this->sid;
            $search->setFilter('special_column_id', array($this->sid));
        }

        $date = $this->param['date'];
        if ($date) {
            if (!in_array($date, array(7, 30, 90))) {
                $date = 90;
                $this->assign('date', $date);
            }
            $dateTmp = strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - $date * 86400;
            $map['publish_time'] = array(array('egt', $dateTmp),array('elt',C('TODAY_LAST_TIME')));
            $search->setFilterRange('publish_time', $dateTmp, C('TODAY_LAST_TIME'));

            //以人气排序
            $search->setSortMode(SPH_SORT_EXTENDED, 'pv_count desc,publish_time desc,id desc');
            unset($dateTmp);
        }else{
            $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
            $search->setFilterRange('publish_time',strtotime('2004-01-01'),C('TODAY_LAST_TIME'));
        }

        $seid = $this->param['seid'];
        if ($seid){
            $map['season_id'] = $seid;
            $search->setFilter('season_id', array($seid));
        }

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
                $search->setFilterRange('area_no', $ano, $ano + 65535);
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
                $search->setFilterRange('area_no', $ano, $ano + 255);
            } else {
                $map['area_no'] = $ano;
                $search->setFilter('area_no', array($ano));
            }
            $this->assign('areaStr', $this->areas[$ano]['name']);
        }

        $bid = $this->param['bid'];
        $brandStr = $this->param['brandStr'];
        if (!$bid && $brandStr != '') {
            $bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
            $bid = intval($bid);
            if($bid){
                $search->setFilter('brand_id', array($bid));
                $this->assign('bid',$bid);
            }
        } elseif ($bid) {
            $map['brand_id'] = $bid;
            $search->setFilter('brand_id', array($bid));
            $brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
            $this->assign('brandStr', $brandStr);
        }

        $stid = $this->param['stid'];
        if ($map['sst.style_id'] || $stid) {
            if(!$map['sst.style_id']){
                $map['sst.style_id'] = $stid;
                $search->setFilter('style_id', array($stid));
            }
        }

        $cache_key = md5('Invogue::'.'themeDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->sid . '::' . $this->soid . '::' .$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
			$rows = $search->query('','sxxl_invogue_subject');
//            echo '<pre>';
//            print_r($search);
			$count = intval($rows['total_found']); //下面做分页之用
            if($count > 0){
				import("ORG.Util.Page");
				$p = new Page($count, $pageSize);
				$ids = array();
				foreach ($rows['matches'] as $k => $v)
					$ids[] = $v['id'];

                $voList = $this->getSubjectInfoByIds($ids,$field);
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        if ($val['season_id'])
                            $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        if ($val['area_no'])
                            $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];

                        if($this->sid == 1 && $this->param['aid']){//为了便于牛仔专主题详情页权限验证，添加参数aid
                            $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'aid'=>$this->param['aid'],'soid'=>$soid,'tid' => $val['id']));
                        }else{
                            $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'soid'=>$soid,'tid' => $val['id']));
                        }

                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                        $voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    protected function themeInfo($tid) {
        $tid = intval($tid);

        if (!$tid){
            $this->error('参数错误！');
        }
        $cid = $this->sid == 4 ? 101 : $this->cid;
        if($cid)
            $map[$this->tableArr['subject_original'].'.menu_id'] = $cid;

        $map[$this->tableArr['subject_original'].'.id'] = $tid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        //为验证权限额外加的筛选条件
        $aid = $this->param['aid'];
        if($this->sid == 1){
             if ($aid === 'gw') {
                $map['area_no'] = array(array('lt', 397568), array('egt', 397824), 'or');
                $join[] = "{$this->tableArr['ref_subject_style_original']} sa on sa.subject_id={$this->tableArr['subject_original']}.id";
                $map['sa.style_id'] = 211;
            } elseif ($aid === 'gl') {
                $this->cmid = 57;
                $join[] = "{$this->tableArr['ref_subject_style_original']} sa on sa.subject_id={$this->tableArr['subject_original']}.id";
                $map['sa.style_id'] = 211;
            } elseif ($aid === 'hg') {
                $this->cmid = 55;
            }
        }elseif(!$this->sid){
            if ($aid === 'gw'){
                $map['area_no'] = array(array('lt', 397568), array('egt', 397824), 'or');
            }elseif ($aid === 'gl'){
                $this->cmid = 57;
            }elseif ($aid === 'hg'){//韩国东大门
                if($this->soid == 2){//女
                    $this->cmid = 59;
                }elseif($this->soid == 3){//童
                    $this->cmid = 60;
                }
            }
        }

        //这个性别为栏目固定的，不能手动输入，加性别筛选条件是为了权限判断
        if ($this->soid) {
            $map['fs.sort_id'] = $this->soid == 3 ? array('egt',3) : $this->soid;
            $join[] = "left join {$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }

        //这个专栏为栏目固定的，不能手动输入，加性别筛选条件是为了权限判断
       if (($this->sid == 1 && $aid != 'hg') || $this->sid == 5) {
            $map['fsc.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
        }else if($this->sid == 2){
            if($this->cmid != 55){
                //正在流行裤子专栏，主题数据展示裤子(128)
                $join[] = "{$this->tableArr['ref_subject_style_original']} sa on sa.subject_id={$this->tableArr['subject_original']}.id";
                $map['sa.style_id'] = 128;
            }
        }

        if($this->cmid && $this->cmid != 55 || ($this->cmid && $this->sid == 1) ){
            $map[$this->tableArr['subject_original'].'.child_menu_id'] = $this->cmid;
        }else{
            $map[$this->tableArr['subject_original'].'.child_menu_id'] = array('neq',55);
        }

        $field = $this->tableArr['subject_original'].'.id,title,publish_time,season_id,area_no,show_edit,book_id';

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Invogue::'.'themeInfo::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->sid . '::' . $this->soid . '::' .$page.'::'.serialize($map));
        $info = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if (!$info) {
            $info = $this->modelT->join($join)->relation($this->relationArr)->field($field)->where($map)->find();
            if(!$info){
                $this->error('参数错误！');
            }
            //echo $this->modelT->getLastSql()."</br>";exit;
            $info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
            $soid = intval($_GET['soid']);
            $soid = $soid ? $soid : $this->soid;
            if(!$soid){
                $soid = M($this->tableArr['ref_subject_sort'])->getField("sort_id","subject_id='{$tid}'");
            }
            $info['sortStr'] = $this->sorts[$soid]['title'];
            $info['areaStr'] = $this->areas[$info['area_no']]['name'];
            $info['seasonStr'] = $this->seasons[$info['season_id']]['en_name'];
            $info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']): '';

            $this->cache->set($cache_key, $info);
        }

        //权限验证
        parent::withoutPermission('',$info);

        return $info;
    }

    /**
     * get theme picture list
     * @param $tid intval
     * @return array
     */
    protected function themePicture($tid) {
        $tid = intval($tid);
        $this->assign('tid', $tid);

        if (!$tid)
            $this->error('参数错误！');

        $order = array('publish_time' => 'desc','id'=>'desc');
        $field = 'id,small_picture_url,big_picture_url,brand_id,publish_time';

        $cid = 0;//10;
        if ($cid)
            $map['menu_id'] = $cid;
        //if($this->cmid) $map['child_menu_id'] = $this->cmid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $tid;

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Invogue::'.'themeInfo::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->sid . '::' . $this->soid . '::' .$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $count = $this->modelP->where($map)->count();
            if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->pListRows);
                $voList = $this->modelP->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelP->getLastSql()."</br>";
                if ($voList) {
                    $picList = array();
                    foreach ($voList as $key => $val) {
                        $voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
                        $voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);
                        $voList[$key]['brandStr'] = M('AttributeBrand')->getField('name',array('id'=>$val['brand_id']));

                        $picList[$key]['sTid'] = 0;
                        $picList[$key]['sPid'] = $val['id'];
                        $picList[$key]['sCid'] = $cid;
                        $picList[$key]['sPidNo'] = $val['id'];
                        $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                        $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                        $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                    }
                }
                //var_dump($picList);
                $Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
                //模板赋值显示
                $Arr['listArr'] = $voList;
                //分页显示
                $Arr['pageStr'] = $p->showOne();
                //主题下载处需要用到
                $Arr['picNum'] = $count;
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }
        $this->assign($Arr);
    }

    /**
     * 图片列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function pictureDataList($field, $map, $order) {
        //时间筛选项
        $this->setDateSift();

        if($this->sid == 4)
            $cid = 101; //内衣.正在流行 menu_id=101
        else
            $cid = $this->cid;

        if ($cid)
            $map[$this->tableArr['picture_original'] . '.menu_id'] = $cid;

        //除牛仔专栏之外其它栏目不显示韩版牛仔的数据
        if ($this->cmid && $this->cmid != 55 || ($this->cmid && $this->sid == 1)){
            $map[$this->tableArr['picture_original'] . '.child_menu_id'] = $this->cmid;
        }else if($this->sid != 1 && $this->sid != 4){
            $map[$this->tableArr['picture_original'] . '.child_menu_id'] = array('neq',55);
        }

        $soid = $this->getSoid();
        if ($soid ){
            $map['fs.sort_id'] =  $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_picture_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_original']}.id";
		}

        if($this->sid == 4){
            //风格
            $faid = $this->param['faid'];
            if ($faid) {
                $join[] = "{$this->tableArr['ref_picture_fashion_original']} pf on pf.picture_id={$this->tableArr['picture_original']}.id";
                $map['pf.fashion_id'] = $faid;
            }

            //面料
            $maid = $this->param['maid'];
            if ($maid) {
                $join[] = "{$this->tableArr['ref_picture_material_original']} pa on pa.picture_id={$this->tableArr['picture_original']}.id";
                $map['pa.material_id'] = $maid;
            }
        }else if (($this->sid == 1 && $this->param['aid'] != 'hg') || $this->sid == 5) {
            $map['fsc.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_picture_column_original']} as fsc on fsc.picture_id = {$this->tableArr['picture_original']}.id";
        }

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $date = $this->param['date'];
        if ($date) {
            if (!in_array($date, array(7, 30, 90))) {
                $date = 90;
                $this->assign('date', $date);
            }
            $dateTmp = strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - $date * 86400;
            $map['publish_time'] = array(array('egt', $dateTmp),array('elt',C('TODAY_LAST_TIME')));

            //以人气排序
            $order = array_merge(array('pv_count'=>'desc'),$order);
            unset($dateTmp);
        }else{
            $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        }

        //款式
        $stid = intval($_REQUEST['stid']);
        if ($stid) {
            $join[] = "{$this->tableArr['ref_picture_style_original']} ps ON ps.picture_id={$this->tableArr['picture_original']}.id";
            $map['ps.style_id'] = $stid;
        }

        $bid = $this->param['bid'];
        $brandStr = $this->param['brandStr'];
        if (!$bid && $brandStr != '') {
            $bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
            $bid = intval($bid);
            if($bid){
                $map['brand_id'] = $bid;
                $this->assign('bid',$bid);
            }
        } elseif ($bid) {
            $map['brand_id'] = $bid;
            $brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
            $this->assign('brandStr', $brandStr);
        }

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }
            $this->assign('areaStr', $this->areas[$ano]['name']);
        }

        $seid = $this->param['seid'];
        if ( $seid ) {
            $map['season_id'] = $seid;
        }

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Invogue::'.'pictureDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->sid . '::' . $this->soid .'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            //取得满足条件的记录数
            //$count = $this->modelP->join($join)->where($map)->count();
            //echo $this->modelP->getlastsql();
            import("ORG.Util.DataCount");
            $count = DataCount::getCount($this->tableArr['picture'],$map,$join);
            if($count > 0){
				import("ORG.Util.Page");
				//创建分页对象
                $p = new Page($count, $this->pListRows);
                $voList = $this->modelP->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelP->getlastsql();
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        $voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);//show_pic_power($val['small_picture_url'], $this->isRightS);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                        if ($val['season_id'])
                            $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        if ($val['area_no'])
                            $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                        if ($val['brand_id'])
                            $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];

                        $picList[$key]['sTid'] = 0;
                        $picList[$key]['sPid'] = $val['id'];
                        $picList[$key]['sCid'] = $cid;
                        $picList[$key]['sPidNo'] = $val['id'];
                        $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                        $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                        $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                    }
                    $Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
                    //模板赋值显示
                    $Arr['listArr'] = $voList;
                    //分页显示
                    $Arr['pageStr'] = $p->showOne();
                }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }


	//参数
	protected function pictureDataListBySphinx($field, $map, $order) {
        $sort_mode = 'publish_time desc,picture_id desc';
        //时间筛选项
        $this->setDateSift();

        if($this->sid == 4)
            $cid = 101; //内衣.正在流行 menu_id=101
        else
            $cid = $this->cid;

        $soid = $this->getSoid();

        if($this->sid == 4){
            //风格
            $faid = $this->param['faid'];
            //面料
            $maid = $this->param['maid'];
        }else if (($this->sid == 1 && $this->param['aid'] != 'hg') || $this->sid == 5) {
            $sid = $this->sid;
        }

        //款式
        $stid = $this->param['stid'];

        $bid = $this->param['bid'];
        $brandStr = $this->param['brandStr'];
        if (!$bid && $brandStr != '') {
            $bid = M('AttributeBrand')->getField('id', array('name' => $brandStr));
            $bid = intval($bid);
            if($bid){
                $this->assign('bid',$bid);
            }
        } elseif ($bid) {
            $brandStr = M('AttributeBrand')->getField('name', array('id' => $bid));
            $this->assign('brandStr', $brandStr);
        }

        $ano = $this->param['ano'];
        $seid = $this->param['seid'];


		$page = intval($_REQUEST['p']) < 1 ? 1 : intval($_REQUEST['p']);
		$param_str = implode("", $this->param);

		// 引入 sphinx  add 2012-08-31
		import ('@.ORG.Search');
		$search = new Search();
        $search->setSortMode(SPH_SORT_EXTENDED,'publish_time desc,picture_id desc');
		//栏目ID
		$search->setFilter('menu_id',array($cid));

        //除牛仔专栏之外其它栏目不显示韩版牛仔的数据
        if ($this->cmid && $this->cmid != 55 || ($this->cmid && $this->sid == 1)){
            $search->setFilter('child_menu_id',array($this->cmid));
        }else if($this->sid != 1 && $this->sid != 4){
            $search->setFilter('child_menu_id',array(55),true);
        }

		if( $soid ) { //性别
			if( $soid == 3 )
				$search->setFilter('sort_id',$this->childrenSoids);
			else
				$search->setFilter('sort_id',array($soid));
		}

        $date = $this->param['date'];
        if ($date) {
            if (!in_array($date, array(7, 30, 90))) {
                $date = 90;
                $this->assign('date', $date);
            }
            $dateTmp = strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - $date * 86400;
            $search->setFilterRange('publish_time',$dateTmp,C('TODAY_LAST_TIME'));

            //以人气排序
            $sort_mode = 'pv_count desc,publish_time desc,picture_id desc';
            unset($dateTmp);
        }else{
            $search->setFilterRange('publish_time',strtotime('1990-01-01 00:00:01'),C('TODAY_LAST_TIME'));
        }

        if($sid)//专栏
            $search->setFilter('column_id',array($sid));
		if( $faid ) //风格
			$search->setFilter('fashion_id',array($faid));
		if( $stid ) //款式
			$search->setFilter('style_id',array($stid));
		if( $maid ) //面料
			$search->setFilter('material_id',array($maid));
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $search->setFilterRange('area_no',$ano,$ano + 65536);
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $search->setFilterRange('area_no',$ano,$ano + 256);
            } else {
                $search->setFilter('area_no',array($ano));
            }
            $this->assign('areaStr', $this->areas[$ano]['name']);
        }
		if( $seid ) //季度
			$search->setFilter('season_id',array($seid));
		if( $bid ) //品牌
			$search->setFilter('brand_id',array($bid));

        $search->setFilterRange('publish_time',strtotime('1990-01-01 00:00:00'),C('TODAY_LAST_TIME'));

		// 处理 $map 相关条件 (例如WomenInvogueAction.php)
		if( isset($map) && is_array($map) ) {
			foreach($map as $k=>$v) {
				$karr = explode('.',$k);
				if( is_array($v) && $v[0]=='neq' ) {
					$search->setFilter( $karr[1], array($v[1]), true);
				}
			}
		}

		$search->setPageSize( $this->pListRows );
		$search->setPage($page);
		$rows = $search->query();
		$count  = (int)$rows['total_found'];

        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $this->pListRows);
            //分页查询数据
            $ids = array();
            $voList = array();
            if( isset($rows['matches']) )
                foreach($rows['matches'] as $v)
                    $ids[] = $v['id'];

            $field = 'picture_id, big_picture_url,small_picture_url,publish_time,brand_id,area_no,season_id ';
            $voList = $search->getPicInfoByIds($ids,$field);
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);//show_pic_power($val['small_picture_url'], $this->isRightS);
                    $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                    if ($val['season_id'])
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                    if ($val['area_no'])
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($val['brand_id'])
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];

                    $picList[$key]['sTid'] = 0;
                    $picList[$key]['sPid'] = $val['picture_id'];
                    $picList[$key]['sCid'] = $cid;
                    $picList[$key]['sPidNo'] = $val['picture_id'];
                    $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                    $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                    $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                }
            }
            //dump($this->brands);
            $this->assign('jsonData', json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB)));
            //模板赋值显示
            $this->assign('listArr', $voList);
            //分页显示
            $pageStr = $p->showOne();
            $this->assign("pageStr", $pageStr);
        }
    }

    protected function themeDetail($tid = '') {
        $this->assign('jumpUrl', 'javascript:window.close();');
        $this->relationArr = array('SubjectExtend');
        $tid = intval($tid);

        $goPage = $tid ? MODULE_NAME . '/folder_detail' :  MODULE_NAME . '/theme_detail';

        $tid = $tid ? $tid : intval($_GET['tid']);
        $themeInfo = $this->themeInfo($tid);
        //dump($themeInfo);
        if ($themeInfo['show_edit'] == 1){
            $this->getShowContent($themeInfo);
        }else{
            $this->themePicture($tid);
        }
        $this->updateThemePvCount($tid);

        $this->assign('info', $themeInfo);
        $this->display($goPage);
    }

    protected function setCmid() {
        $this->cmid = intval($_GET['cmid']);
        $this->assign('cmid', $this->cmid);
    }

    protected function setCidSift() {
            $sMap['menu_id'] = $this->sid == 4 ? 101 : $this->cid;
            $this->cmid ? $sMap['child_menu_id'] = $this->cmid : '';
            $soid = $this->getSoid();
            if($soid){
                $sMap['sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            }

            $this->sid && $this->sid != 2 && $this->sid != 4 && ($this->sid == 1 && $this->param['aid'] != 'hg') ? $sMap['special_column_id'] = $this->sid : '';
            $fieldArr = array('season_id_list','area_no_list','brand_id_list');
            $cache_key = md5('Invogue::'.'setcidsift::'. $this->sid . serialize($this->param) .'::'.serialize($sMap));
            $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
            if(!$Arr) {
                $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
                $this->areas = $siftArr['area_no_list'];
                $this->seasons = $siftArr['season_id_list'];
                $Arr['brands'] = $this->brands = $siftArr['brand_id_list'];
                if ($this->seasons) {
                    $seasonsTmp = $this->seasons;
                    uasort($seasonsTmp, "cmp");
                    $Arr['seasons'] = $seasonsTmp;
                    unset($seasonsTmp);
                }
                if ($this->areas) {
                    $Arr['areaHtml'] = $this->getAreaOption($this->param['ano']);
                    $Arr['areas'] = format_tree_area($this->areas);
                }

                $Arr['letters'] = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
                $this->cache->set($cache_key, $Arr);
            }
            $this->assign($Arr);
    }

    //设置时间筛选列表
    protected function setDateSift() {
        //近似值，无需精确(全部的ID＝1只起标识作用)
        $dateArr = array(
            array('id' => 7, 'title' => '1周内'),
            array('id' => 30, 'title' => '1月内'),
            array('id' => 90, 'title' => '3月内'),
        );
        $this->assign('dateArr', $dateArr);
    }

    protected function setParam() {
        $this->param = array('cmid' => intval($this->cmid));

        $soid = intval($_REQUEST['soid']);
        $soid = $this->sid ? $soid : ($this->soid == 3 && $soid > 2 ? $soid : $this->soid);
        if ($soid)
            $this->param = array_merge($this->param, array('soid' => $soid));

        $seid = intval($_REQUEST['seid']);
        if ($seid)
            $this->param = array_merge($this->param, array('seid' => $seid));

        $stid = intval($_REQUEST['stid']);
        if ($stid)
            $this->param = array_merge($this->param, array('stid' => $stid));

        $ano = intval($_REQUEST['ano']);
        if ($ano)
            $this->param = array_merge($this->param, array('ano' => $ano));

        $bid = intval($_REQUEST['bid']);
        if ($bid)
            $this->param = array_merge($this->param, array('bid' => $bid));

        $faid = intval($_REQUEST['faid']);
        if ($faid)
            $this->param = array_merge($this->param, array('faid' => $faid));

        $maid = intval($_REQUEST['maid']);
        if ($maid)
            $this->param = array_merge($this->param, array('maid' => $maid));

        $date = intval($_REQUEST['date']);
        if ($date)
            $this->param = array_merge($this->param, array('date' => $date));

        $brandStr = trim($_REQUEST['brandStr']);
        if ($brandStr)
            $this->param = array_merge($this->param, array('brandStr' => $brandStr));

        $aid = trim($_REQUEST['aid']);//区域标识，正在流行专有
        if ($aid)
            $this->param = array_merge($this->param, array('aid' => $aid));

        $act = trim($_REQUEST['act']);
        if ($act)
            $this->param = array_merge($this->param, array('act' => $act));

        $tid = trim($_REQUEST['tid']);
        if ($tid)
            $this->param = array_merge($this->param, array('tid' => $tid));

    }

    protected function getShowContent($themeInfo) {
        if (!$themeInfo['id'])
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url';
        $cid = 0;//10;
        if ($cid)
            $map['menu_id'] = $cid;

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $themeInfo['id'];

        $cache_key = md5('Invogue::'.'getShowContent::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->sid . '::' . $this->soid .'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $count = $this->modelP->where($map)->count();
            if($count > 0){
                $voList = $this->modelP->where($map)->field($field)->order(array('publish_time' => 'desc','id'=>'desc'))->findAll();
                $picList = array();
                $parse_arr = parse_content(stripslashes($themeInfo['content']));
                $detailhtml = $parse_arr['result'];
                if ($parse_arr['pic_arr']) {
                    //$i = 0;
                    foreach ($parse_arr['pic_arr'] as $key => $val) {
                        $picList[$key]['sTid'] = $themeInfo['id'];
                        $picList[$key]['sPid'] = 0;
                        $picList[$key]['sSex'] = $themeInfo['sort_id'];
                        $picList[$key]['sCid'] = $this->cid;
                        $picList[$key]['sPicNo'] = 0;
                        $picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
                        $picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
                        $picList[$key]['sSpic'] = $val['sSpic'];
                        $picList[$key]['sBpic'] = $val['sBpic'];
                        if ($voList) {
                            foreach ($voList as $ke => $va) {
                                if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
                                    //echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
                                    $picList[$key]['sPid'] = $va['id'];
                                    $picList[$key]['sSex'] = $va['sort_id'];
                                    $picList[$key]['sPicNo'] = $va['id'];
                                }
                            }
                        }
                    }
                }
            }
            $Arr['detailhtml'] = $detailhtml;
            $Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)); //放大图片
            $Arr['picNum'] = $count;//主题下载处需要用到
            $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    /*
     * 根据各栏目需求获性别ID
     */
    protected function getSoid() {
        $soid = $this->param['soid'];
        if ($soid){
            $soid = $this->soid == 3 && !in_array($soid, array(3,4, 5, 6)) ? 3 : (in_array($soid, array(1, 2, 3, 4, 5, 6)) ? $soid : 2);
        }else{
            $soid = $this->sid ? 2 : $this->soid;
        }
        $this->assign('soid', $soid);
        return $soid;
    }

    protected function getSubjectInfoByIds($ids,$field){
        if(empty($field)){
            $field = 'id,title,title_picture_url,publish_time,area_no,season_id,pv_count,picture_count';
        }

        $order = array('publish_time'=>'desc','id'=>'desc');
        if($this->param['date']){
            $order = array_merge(array('pv_count'=>'desc'),$order);
        }

		$row = $this->modelT->where( 'id in('.implode(',',$ids).')' )->field($field)->order($order)->select();
        //echo $MODEL->getLastSql()."<br/>";
		return $row;
    }
}