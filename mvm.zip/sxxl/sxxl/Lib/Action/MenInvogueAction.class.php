<?php

class MenInvogueAction extends InvogueAction {

	public function _initialize() {
		$this->soid = 1;
		parent::_initialize();
	}

	public function index() {
		$this->themeList();
	}

	public function themeList() {
		if ($this->param['bid'] || $this->param['brandStr'] || $this->param['seid'] || $this->param['ano']) {
			$Arr['cmid'] = $this->cmid = 0;
			$Arr['aid'] = $aid = '';
		} else {
			$aid = $this->param['aid'];
			$Arr['aid'] = $aid = in_array($aid, array('gw', 'gl', 'hg')) ? $aid : (!$this->cmid ? '' : '');
		}

		$this->childMenus = $this->getSubMenuList($this->cid);
		$Arr['specialChildMenus'] = $this->getSpecialChildMenu();

		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,area_no,season_id,pv_count,picture_count";
		$order = array('publish_time' => 'desc', $this->tableArr['subject_original'] . '.id' => 'desc');
		$this->relationArr = false;
		$this->tListRows = 12;
        //parent::themeDataList($field, $map, $order);
        parent::themeDataListBySphinx($field, $map, $order);
		$this->assign($Arr);
		$this->display('theme_list');
	}

	public function themeDetail($tid = '') {
		parent::themeDetail($tid);
	}

	public function pictureList() {
        $this->childMenus = $this->getSubMenuList($this->cid);
		$specialChildMenus = $this->getSpecialChildMenu();
		$this->assign('specialChildMenus', $specialChildMenus);

		$this->pListRows = 20;
		$field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,publish_time,brand_id,area_no,season_id";
		$order = array('publish_time' => 'desc', $this->tableArr['picture_original'] . '.id' => 'desc');
		//parent::pictureDataList($field, $map, $order);
		parent::pictureDataListBySphinx($field, $map, $order);
		$this->display('picture_list');
	}

    protected function getSpecialChildMenu() {
        return array('children_menu_list'=>$this->getThemeLeftMenu(),'style_menu_list'=>$this->getPictureLeftMenu());
    }

    protected function getSpecialChildMenuBak() {
        if (ACTION_NAME == 'pictureList')
            $specialChildMenu = $this->getPictureLeftMenu();
        else
            $specialChildMenu = $this->getThemeLeftMenu();

        return $specialChildMenu;
    }

	protected function getThemeLeftMenu() {
		$specialChildMenu = array(
			array('id' => 'gw', 'name' => '国外', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw')), 'thirdMenu' =>
				array(
					array('id' => 1, 'name' => 'T恤', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 1))),
					array('id' => 66, 'name' => '衬衫', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 66))),
					array('id' => 29, 'name' => '外套', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 29))),
					array('id' => 95, 'name' => '毛衫', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 95))),
					array('id' => 284, 'name' => '风衣', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 284))),
					array('id' => 264, 'name' => '棉衣/羽绒服', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 264))),
					array('id' => 256, 'name' => '皮衣皮草', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 256))),
					array('id' => 128, 'name' => '裤子', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 128))),
					array('id' => 211, 'name' => '牛仔', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 211))),
					array('id' => 152, 'name' => '运动', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'stid' => 152))),
				)
			),
			array('id' => 'gl', 'name' => '国内', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl')), 'thirdMenu' =>
				array(
					array('id' => 1, 'name' => 'T恤', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 1))),
					array('id' => 66, 'name' => '衬衫', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 66))),
					array('id' => 29, 'name' => '外套', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 29))),
					array('id' => 95, 'name' => '毛衫', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 95))),
					array('id' => 284, 'name' => '风衣', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 284))),
					array('id' => 264, 'name' => '棉衣/羽绒服', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 264))),
					array('id' => 256, 'name' => '皮衣皮草', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 256))),
					array('id' => 128, 'name' => '裤子', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 128))),
					array('id' => 211, 'name' => '牛仔', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 211))),
					array('id' => 152, 'name' => '运动', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'stid' => 152))),
				//array('id'=>'','name'=>'精选品牌','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>0)))
				)
			), /*
				  array('id' => 'hg', 'name' => '韩国东大门', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg')), 'thirdMenu' =>
				  array(
				  array('id' => 1, 'name' => 'T恤', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 1))),
				  array('id' => 66, 'name' => '衬衫', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 66))),
				  array('id' => 29, 'name' => '外套', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 29))),
				  array('id' => 95, 'name' => '毛衫', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 95))),
				  array('id' => 284, 'name' => '风衣', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 284))),
				  array('id' => 264, 'name' => '棉衣/羽绒服', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 264))),
				  array('id' => 256, 'name' => '皮衣皮草', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 256))),
				  array('id' => 128, 'name' => '裤子', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 128))),
				  array('id' => 211, 'name' => '牛仔', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 211))),
				  array('id' => 152, 'name' => '运动', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 152))),
				  array('id' => 276, 'name' => '卫衣', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' => 276))),
				  #array('id' => 358, 'name' => '婚纱礼服', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'stid' =>358)))
				  )
				  ) */
		);

		return $specialChildMenu;
	}

	protected function getPictureLeftMenu() {
		$stid = $this->param['stid'];
		$soid = $this->getSoid();
		$specialChildMenu = array(
			array('id' => 1, 'name' => 'T恤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 1)), 'selected' => in_array($stid, array(1, 18, 14, 25, 3, 23)),
				'thirdMenu' =>
				array(
					array('id' => 18, 'name' => '商务T', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 18)), 'selected' => $stid == 18),
					array('id' => 14, 'name' => '靓仔T', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 14)), 'selected' => $stid == 14),
					array('id' => 25, 'name' => '休闲T', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 25)), 'selected' => $stid == 25),
					array('id' => 3, 'name' => 'Polo衫', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 3)), 'selected' => $stid == 3),
					array('id' => 23, 'name' => '图案T', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 23)), 'selected' => $stid == 23),
				)
			),
			array('id' => 29, 'name' => '外套', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 29)), 'selected' => in_array($stid, array(29, 45, 35, 65, 58, 52, 39)),
				'thirdMenu' =>
				array(
					array('id' => 45, 'name' => '商务夹克', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 45)), 'selected' => $stid == 45 ? 1 : 0),
					array('id' => 35, 'name' => '靓仔夹克', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 35)), 'selected' => $stid == 35 ? 1 : 0),
					array('id' => 65, 'name' => '正装单西', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 65)), 'selected' => $stid == 65 ? 1 : 0),
					array('id' => 58, 'name' => '休闲便西', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 58)), 'selected' => $stid == 58 ? 1 : 0),
					array('id' => 52, 'name' => '套装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 52)), 'selected' => $stid == 52),
					array('id' => 39, 'name' => '尼克服', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 39)), 'selected' => $stid == 39),
				)
			),
			array('id' => 295, 'name' => '马甲', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 295)), 'selected' => in_array($stid, array(295, 297, 298)),
				'thirdMenu' =>
				array(
					array('id' => 297, 'name' => '靓仔休闲装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 297)), 'selected' => $stid == 297),
					array('id' => 298, 'name' => '商务装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 298)), 'selected' => $stid == 298 ? 1 : 0),
				)
			),
			array('id' => 276, 'name' => '卫衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 276)), 'selected' => in_array($stid, array(276, 278, 282)),
				'thirdMenu' =>
				array(
					array('id' => 278, 'name' => '开襟', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 278)), 'selected' => $stid == 278),
					array('id' => 282, 'name' => '套头', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 282)), 'selected' => $stid == 282),
				)
			),
			array('id' => 264, 'name' => '棉衣/羽绒服', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 264)), 'selected' => in_array($stid, array(264, 266, 265, 268)),
				'thirdMenu' =>
				array(
					array('id' => 266, 'name' => '棉/羽绒背心', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 266)), 'selected' => $stid == 266),
					array('id' => 265, 'name' => '靓仔棉/羽绒', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 265)), 'selected' => $stid == 265),
					array('id' => 268, 'name' => '商务棉/羽绒', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 268)), 'selected' => $stid == 268),
				)
			),
			array('id' => 252, 'name' => '皮衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 252)), 'selected' => in_array($stid, array(252, 253, 255)),
				'thirdMenu' =>
				array(
					array('id' => 253, 'name' => '靓仔皮衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 253)), 'selected' => $stid == 253),
					array('id' => 255, 'name' => '商务皮衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 255)), 'selected' => $stid == 255),
				)
			),
			array('id' => 288, 'name' => '风衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 288)), 'selected' => in_array($stid, array(288, 290, 292)),
				'thirdMenu' =>
				array(
					array('id' => 290, 'name' => '靓仔休闲装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 290)), 'selected' => $stid == 290),
					array('id' => 292, 'name' => '商务装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 292)), 'selected' => $stid == 292),
				)
			),
			array('id' => 285, 'name' => '大衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 285)), 'selected' => in_array($stid, array(285, 294, 291)),
				'thirdMenu' =>
				array(
					array('id' => 294, 'name' => '休闲大衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 294)), 'selected' => $stid == 294),
					array('id' => 291, 'name' => '商务大衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 291)), 'selected' => $stid == 291),
				)
			),
			array('id' => 66, 'name' => '衬衫', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 66)), 'selected' => in_array($stid, array(66, 79, 81, 72, 90)),
				'thirdMenu' =>
				array(
					array('id' => 79, 'name' => '靓仔休闲衫', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 79)), 'selected' => $stid == 79),
					array('id' => 81, 'name' => '商务衬衫', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 81)), 'selected' => $stid == 81),
					array('id' => 72, 'name' => '格子衬衫', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 72)), 'selected' => $stid == 72),
					array('id' => 90, 'name' => '印花衬衫', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 90)), 'selected' => $stid == 90),
				)
			),
			array('id' => 128, 'name' => '裤子', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 128)), 'selected' => in_array($stid, array(128, 150, 132, 144, 146)),
				'thirdMenu' =>
				array(
					array('id' => 150, 'name' => '休闲长裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 150)), 'selected' => $stid == 150),
					array('id' => 132, 'name' => '休闲短裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 132)), 'selected' => $stid == 132),
					array('id' => 144, 'name' => '西裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 144)), 'selected' => $stid == 144),
					array('id' => 146, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 146)), 'selected' => $stid == 146),
				)
			),
			array('id' => 95, 'name' => '毛衫', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 95)), 'selected' => in_array($stid, array(95, 106, 116, 110, 119, 101)),
				'thirdMenu' =>
				array(
					array('id' => 106, 'name' => '靓仔休闲装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 106)), 'selected' => $stid == 106),
					array('id' => 116, 'name' => '商务装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 116)), 'selected' => $stid == 116),
					array('id' => 110, 'name' => '毛织背心', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 110)), 'selected' => $stid == 110),
					array('id' => 119, 'name' => '数码印花', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 119)), 'selected' => $stid == 119),
					array('id' => 101, 'name' => '吊染', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 101)), 'selected' => $stid == 101),
				)
			),
			array('id' => 152, 'name' => '运动', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 152)), 'selected' => in_array($stid, array(152, 154, 177, 164, 161, 162)),
				'thirdMenu' =>
				array(
					array('id' => 154, 'name' => 'T恤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 154)), 'selected' => $stid == 154),
					array('id' => 177, 'name' => '针织外套', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 177)), 'selected' => $stid == 177),
					array('id' => 164, 'name' => '梭织外套', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 164)), 'selected' => $stid == 164),
					array('id' => 161, 'name' => '裤子', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 161)), 'selected' => $stid == 161),
					array('id' => 162, 'name' => '棉袄', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 162)), 'selected' => $stid == 162),
				)
			),
			array('id' => 211, 'name' => '牛仔', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 211)), 'selected' => in_array($stid, array(211, 227, 232, 231)),
				'thirdMenu' =>
				array(
					array('id' => 227, 'name' => '上装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 227)), 'selected' => $stid == 227),
					array('id' => 232, 'name' => '裤子', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 232)), 'selected' => $stid == 232),
					array('id' => 231, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('soid' => $soid, 'stid' => 231)), 'selected' => $stid == 231),
				)
			),
		);

		return $specialChildMenu;
	}

	public function downloadzip() {
		parent::downloadzip();
	}

}
