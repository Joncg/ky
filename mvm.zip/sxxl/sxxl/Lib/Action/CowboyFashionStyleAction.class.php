<?php
class CowboyFashionStyleAction extends FashionStyleAction {

    public function _initialize() {
        $this->sid = 1;
        parent::_initialize();
    }

    public function index(){
        $this->pictureList();
    }

    public function pictureList(){
        parent::pictureList();
    }


    public function brandSearch() {
        parent::brandSearch();
    }

    protected function getSpecialChildMenu() {
        $soid = parent::getSoid();
        $specialChildMenu['2'] = array(
            array('id'=>'211','name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'thirdMenu'=>
                array(
                    array('id'=>232,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>232))),
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227))),
                    array('id'=>224,'name'=>'裙子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>224))),
                    array('id'=>213,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>213))),
                    array('id'=>229,'name'=>'五分-九分裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>229))),
                    #array('id'=>231,'name'=>'细节','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>231))),
                )
            )
        );

        $specialChildMenu['1'] = array(
            array('id'=>'211','name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'thirdMenu'=>
                array(
                    array('id'=>232,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>232))),
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227))),
                    array('id'=>234,'name'=>'中裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>234))),
                    #array('id'=>231,'name'=>'细节','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>231))),
                )
            )
        );

        $specialChildMenu['3'] = array(
			array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'selected'=>in_array($stid,array(211,232,227,224,214)),
                'thirdMenu'=>
                array(
                    array('id'=>232,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>232)),'selected'=>$stid == 232),
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227)),'selected'=>$stid == 227),
                    array('id'=>224,'name'=>'裙子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>224)),'selected'=>$stid == 224),
                    array('id'=>214,'name'=>'短裤—七分裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>214)),'selected'=>$stid == 214),
                )
            ),
			);

        return $specialChildMenu[$soid];
    }

	public function downloadzip() {
		parent::downloadzip();
	}
}
