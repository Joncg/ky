<?php

class CowboyInvogueAction extends InvogueAction {

    public function _initialize() {
        $this->sid = 1;
        parent::_initialize();
    }

    public function index() {
        $this->themeList();
    }

    public function themeList() {
        if($this->param['bid'] || $this->param['brandStr'] || $this->param['seid'] || $this->param['ano']){
            $Arr['cmid'] = $this->cmid = 0;
            $Arr['aid'] = $aid = '';
        }else{
            $aid = $this->param['aid'];
            $Arr['aid'] = $aid = in_array($aid, array('gw', 'gl', 'hg')) ? $aid : (!$this->cmid ? '' : '');
        }

        $Arr['specialChildMenus'] = $this->getSpecialChildMenu();

        $field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,area_no,season_id,pv_count,picture_count";
        $order = array('publish_time' => 'desc', $this->tableArr['subject_original'] . '.id' => 'desc');
        $this->relationArr = false;
        $this->tListRows = 12;
        //parent::themeDataList($field, $map, $order);
        parent::themeDataListBySphinx($field, $map, $order);
        $this->assign($Arr);
        $this->display('theme_list');
    }

    public function themeDetail($tid = '') {
        parent::themeDetail($tid);
    }

    public function pictureList() {
        $Arr['specialChildMenus'] = $this->getSpecialChildMenu();
        $aid = trim($_GET['aid']);
        $Arr['aid'] = $aid = in_array($aid, array('gw', 'gl', 'hg')) ? $aid : 'gw';
        if($this->param['bid'] || $this->param['brandStr'] || $this->param['seid'] || $this->param['ano']){
            $Arr['cmid'] = $this->cmid = 0;
            $Arr['aid'] = $aid = '';
        }else{
            $aid = $this->param['aid'];
            $Arr['aid'] = $aid = in_array($aid, array('gw', 'gl', 'hg')) ? $aid : (!$this->cmid ? '' : '');
        }
        if ($aid === 'gw') {//397568(中国编号),397824 = 397568+256
            //$this->cmid = 58;
            $map['area_no'] = array(array('lt', 397568), array('egt', 397824), 'or');
        } elseif ($aid === 'gl') {
            $this->cmid = 57;
            //$map['area_no'] = array(array('egt',397568),array('lt',397824));
        } elseif ($aid === 'hg') {
            $this->cmid = 55;
            //$map['area_no'] = array(array('egt',397568),array('lt',397824));
        }

        $this->pListRows = 20;
        $field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,publish_time,brand_id,area_no,season_id";
        $order = array('publish_time'=>'desc',$this->tableArr['picture_original'].'.id'=>'desc');
        //parent::pictureDataList($field, $map, $order);
        parent::pictureDataListBySphinx($field, $map, $order);
        $this->assign($Arr);
        $this->display('picture_list');
    }

    protected function getSpecialChildMenu() {
        $soid = parent::getSoid();
        $specialChildMenu['2'] = array(
            array('id' => 'gw', 'name' => '国外', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 227, 'name' => '上装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 227))),
                    array('id' => 224, 'name' => '裙子', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 224))),
                    array('id' => 213, 'name' => '短裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 213))),
                    array('id' => 223, 'name' => '七分裙', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 223))),
                    array('id' => 232, 'name' => '长裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 232))),
                    array('id' => 231, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 231))),
                )
            ),
            array('id' => 'gl', 'name' => '国内', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 227, 'name' => '上装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 227))),
                    array('id' => 224, 'name' => '裙子', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 224))),
                    array('id' => 213, 'name' => '短裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 213))),
                    array('id' => 223, 'name' => '七分裙', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 223))),
                    array('id' => 232, 'name' => '长裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 232))),
                    array('id' => 231, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 231))),
                    array('id' => 215, 'name' => '妇女裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 215))),
                )
            ),
            array('id' => 'hg', 'name' => '韩版牛仔', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 236, 'name' => '弹力牛仔', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 236))),
                    array('id' => 237, 'name' => '铅笔裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 237))),
                    array('id' => 238, 'name' => '普洗', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 238))),
                    array('id' => 213, 'name' => '短裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 213))),
                    array('id' => 239, 'name' => '短裙', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 239))),
                    array('id' => 240, 'name' => '5分裤—9分裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 240))),
                    array('id' => 215, 'name' => '妇女裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 215))),
                    array('id' => 241, 'name' => '撞面料', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 241))),
                )
            )
        );

        $specialChildMenu['1'] = array(
            array('id' => 'gw', 'name' => '国外', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 227, 'name' => '上装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 227))),
                    array('id' => 231, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 231))),
                    array('id' => 232, 'name' => '长裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 232))),
                )
            ),
            array('id' => 'gl', 'name' => '国内', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 227, 'name' => '上装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 227))),
                    array('id' => 231, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 231))),
                    array('id' => 232, 'name' => '长裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 232))),
                    array('id' => 225, 'name' => '商务裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gl', 'soid' => $soid, 'stid' => 225))),
                )
            ),
            array('id' => 'hg', 'name' => '韩版牛仔', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'hg', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 218, 'name' => '简洁版', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 218))),
                    array('id' => 228, 'name' => '特色版', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 228))),
                    array('id' => 225, 'name' => '商务裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 225))),
                    array('id' => 241, 'name' => '撞面料', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'hg', 'soid' => $soid, 'stid' => 241))),
                )
            )
        );

        $specialChildMenu['3'] = array(
            array('id' => 'gw', 'name' => '国外', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gw', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 227, 'name' => '上装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 227))),
                    array('id' => 221, 'name' => '裙子', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 221))),
                    array('id' => 213, 'name' => '短裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 213))),
                    array('id' => 232, 'name' => '长裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 232))),
                    array('id' => 231, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 231))),
                    array('id' => 226, 'name' => '上衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 226)))
                )
            ),
            array('id' => 'gl', 'name' => '国内', 'url' => U('/' . MODULE_NAME . "/themeList", array('aid' => 'gl', 'soid' => $soid)), 'thirdMenu' =>
                array(
                    array('id' => 227, 'name' => '上装', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 227))),
                    array('id' => 221, 'name' => '裙子', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 221))),
                    array('id' => 213, 'name' => '短裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 213))),
                    array('id' => 232, 'name' => '长裤', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 232))),
                    array('id' => 231, 'name' => '细节', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 231))),
                    array('id' => 226, 'name' => '上衣', 'url' => U('/' . MODULE_NAME . "/pictureList", array('aid' => 'gw', 'soid' => $soid, 'stid' => 226)))
                )
            )
        );

        return $specialChildMenu[$soid];
    }


	public function downloadzip() {
		parent::downloadzip();
	}

}
