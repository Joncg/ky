<?php

//定时计划任务
//每日更新统计数据
//每小时更新整站数据
//每小时更新新增加的图片数
class CountAction extends Action {

	//更新整站的统计数据（需要时执行）
	public function index() {
		//列新整站数据
		import("ORG.Util.DataCount");
		DataCount::updateAll();
	}
	//更新所有图片的数据（每15分钟执行一次 num+new）
	public function updatePic() {
		//列新整站数据
		import("ORG.Util.DataCount");
		DataCount::updatePic();
	}
	//清空每日更新图片数量（每天执行一次）
	public function cleanNewPic() {
		//列新整站数据
		import("ORG.Util.DataCount");
		DataCount::cleanNewPic();
	}
}
?>