<?php
class PantsFashionStyleAction extends FashionStyleAction {

    public function _initialize() {
        $this->sid = 2;
        parent::_initialize();
    }

    public function index(){
        $this->pictureList();
    }

    public function pictureList(){
        parent::pictureList();
    }

    public function brandSearch() {
        parent::brandSearch();
    }

    protected function getSpecialChildMenu() {
        $soid = parent::getSoid();
        $specialChildMenu['2'] = array(
            array('id'=>'128','name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'thirdMenu'=>
                array(
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150))),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132))),
                    array('id'=>151,'name'=>'中裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>151))),
                    array('id'=>137,'name'=>'连体裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>137))),
                    array('id'=>131,'name'=>'吊档裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>131))),
                    array('id'=>134,'name'=>'妇女裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>134))),
                )
            )
        );

        $specialChildMenu['1'] = array(
            array('id'=>'128','name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'thirdMenu'=>
                array(
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150))),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132))),
                    array('id'=>137,'name'=>'连体裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>137))),
                    array('id'=>131,'name'=>'吊档裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>131))),
                    array('id'=>140,'name'=>'商务裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>140))),
                    array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>129))),
                    array('id'=>143,'name'=>'五-七分裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>143))),
                )
            )
        );

        $specialChildMenu['3'] = array(
            array('id'=>'128','name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'thirdMenu'=>
                array(
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150))),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132))),
                    array('id'=>151,'name'=>'中裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>151))),
                    array('id'=>137,'name'=>'连体裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>137))),
                    array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>129))),
                    array('id'=>130,'name'=>'打底裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>130))),
                )
            )
        );

        return $specialChildMenu[$soid];
    }
}
