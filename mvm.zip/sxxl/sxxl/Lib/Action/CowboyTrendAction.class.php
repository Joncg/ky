<?php
class CowboyTrendAction extends TrendAction {

    public function _initialize() {
        $this->sid = 1;
        parent::_initialize();
    }

   public function index() {
       $this->folderList();
	}

	public function folderList(){
        parent::folderList();
	}

	public function folderDetail() {
        $this->pListRows = 20;
        parent::folderDetail();
	}
	public function downloadzip() {
		parent::downloadzip();
	}
}
