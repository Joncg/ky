<?php
class GalleryAction extends CommonAction{
    protected $pListRows = 20;
    protected $relationArr;
    protected $table;
    protected $modelP;
    protected $tideSection;
    protected $sort;
    protected $season;
    protected $style;
    protected $area;
    protected $param;
    protected $cid;         #栏目ID
    protected $ano;         #区域ID
    protected $soid;        #类别ID
    protected $sid;         #季度ID
    protected $stno;        #款式NO
    protected $bid;         #品片ID
    protected $did;         #设计师ID
    protected $boid;        #书名ID
    protected $coid;        #颜色ID
	protected $pic_num;   #各栏目图片数量数组

    public function _initialize() {
        parent::_initialize();
        $this->table = 'Picture';
        $this->modelP = D($this->table);
        $Arr['cid'] = $this->cid = intval($_GET['cid']);
        $Arr['ano'] = $this->ano = intval($_GET['ano']);
        $Arr['soid'] = $this->soid = intval($_GET['soid']);
        $Arr['sid'] = $this->sid = intval($_GET['sid']);
        $Arr['stno'] = $this->stno = intval($_GET['stno']);
        $Arr['bid'] = $this->bid = intval($_GET['bid']);
        $Arr['did'] = $this->did = intval($_GET['did']);
        $Arr['boid'] = $this->boid = intval($_GET['boid']);
        $Arr['coid'] = $this->coid = intval($_GET['coid']);
        $this->param = array('cid'=>$this->cid,'ano'=>$this->ano,'soid'=>$this->soid,'sid'=>$this->sid,'stno'=>$this->stno,'bid'=>$this->bid,'did'=>$this->did,'boid'=>$this->boid,'coid'=>$this->coid);
        $this->assign($Arr);
        $this->redirect('/Index/index');
    }

    public function index() {
        $Arr = array();
        //潮流部门
        $this->tideSection = C('TIDE_SECTION');

        if(!$this->cid && $this->tideSection){
            foreach($this->tideSection as $key =>$val){
                $tideSection[$key] = $val;
                $tideSection[$key]['url'] = U('/Gallery/index',array_merge($this->param,array('cid'=>$val['cid'])));
				//将统计数据缓存
				if(S($key)){
					$tideSection[$key]['pic_num'] = S($key);
				}
				else{
					$tideSection[$key]['pic_num'] = $this->modelP->where("menu_id='{$val['cid']}' and is_delete=0 and is_publish=1")->count();
					S($key,$tideSection[$key]['pic_num']);
				}
            }
            $Arr['tideSection'] = $tideSection;
        }
        //类别
        $this->sort = C('SORT');
        if(!$this->soid && $this->sort){
            foreach($this->sort as $key =>$val){
                $sort[$key] = $val;
                $sort[$key]['url'] = U('/Gallery/index',array_merge($this->param,array('soid'=>$val['soid'])));
            }
            $Arr['sort'] = $sort;
        }
        //季度
        $this->season = $this->cache->get('seasonList');
        if(!$this->sid && $this->season){
            foreach($this->season as $key =>$val){
               $season[$key] = $val;
               $season[$key]['url'] = U('/Gallery/index',array_merge($this->param,array('sid'=>$val['id'])));
            }
            $Arr['season'] = $season;
        }
        //款式
        $this->style = $this->cache->get('styleList');
        if($this->style){
            foreach($this->style as $key =>$val){
               if($val['parent_no'] == $this->stno){
                   $style[$key] = $val;
                   $style[$key]['url'] = U('/Gallery/index',array_merge($this->param,array('stno'=>$val['no'])));
               }
            }
            $Arr['style'] = $style;
        }
        //区域
        $this->area = $this->cache->get('areaList');
        if($this->area){
            foreach($this->area as $key =>$val){
                if($val['parent_no'] == $this->ano){
                    $area[$key] = $val;
                    $area[$key]['url'] = U('/Gallery/index',array_merge($this->param,array('ano'=>$val['no'])));
                }
            }
            $Arr['area'] = $area;
        }
        //颜色
        $this->color = $this->cache->get('colorList');
        if(!$this->coid && $this->color){
            foreach($this->color as $key =>$val){
               $color[$key] = $val;
               $color[$key]['url'] = U('/Gallery/index',array_merge($this->param,array('coid'=>$val['id'])));
               $title_pic = $this->color[$val['id']]['url'];//M('AttributeColor')->getField('url',array('id'=>$val['id']));
               $color[$key]['title_pic'] = 'http://img9.f.sxxl.com/'.$title_pic;
           }
           $Arr['color'] = $color;
        }
        //品牌、设计师、书名弹出层字母索引
        $Arr['letters'] = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','qt');
        $Arr['chioceStr'] = $this->getChioceStr();
        $Arr['title'] = '图片库_蝶讯网';

		//默认查前三个月的数据
		$map['publish_time'] = array('egt',1321902527 );
		$field = 'id,big_picture_url,small_picture_url,area_no,season_id,publish_time';
		$this->picList($field,'',array('publish_time'=>'desc'));
        $Arr = array_merge($Arr,parent::getPageInfo());
        $this->assign($Arr);
        $this->display();
    }

	/**
	 * 图片列表分页
	 * @param type $field
	 * @param type $map
	 * @param type $order
	 * @return type
	 */
	protected function picList($field, $map = array(), $order = array('publish_time'=>'desc')) {
		$map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
		$map['is_delete'] = 0;
        //潮流部门
        if ($this->cid)$map['menu_id'] = $this->cid;
        //季度
		if ($this->sid) $map['season_id'] = $this->sid;
        //区域
		if ($this->ano){
            $ano = dechex($this->ano);
            if(substr($ano,-4,4) === '0000'){
                $map['area_no'] = array(array('egt',$this->ano),array('lt',$this->ano+65536));
            }
            elseif(substr($ano,-2,2) === '00'){
                $map['area_no'] = array(array('egt',$this->ano),array('lt',$this->ano+256));
            }
            else{
                $map['area_no'] = $this->ano;
            }
        }
        //设计师
		if ($this->did) $map['designer_id'] = $this->did;
        //品牌
		if ($this->bid) $map['brand_id'] = $this->bid;
        //书名
		if ($this->boid) $map['book_id'] = $this->boid;
        //款式
		if ($this->stno) {
			$join[] = 'sxxl_ref_picture_style ps ON ps.picture_id=sxxl_picture.id';
            $map['ps.style_no'] = $this->stno;
		}
        //颜色
		if ($this->coid) {
			$join[] = 'sxxl_ref_picture_color pc ON pc.picture_id=sxxl_picture.id';
			$map['pc.color_id'] = $this->coid;
		}
		if ($this->soid) $map['sort_id'] = $this->soid;

 		//if ($map['ssc.special_column_id']) $join[] = 'sxxl_ref_picture_special_column ssc on ssc.picture_id=sxxl_picture.id';
		import("ORG.Util.DataCount");
        $count = DataCount::getCount($this->table,$map,$join);
		if ($count > 0) {
			import("ORG.Util.Page");
			$p = new Page($count, $this->pListRows);
			$voList = $this->modelP->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $this->modelT->getlastsql();
			/*分页跳转的时候保证查询条件
			foreach ($_REQUEST as $key => $val) {
				if (!is_array($val)) {
					$p->parameter .= "$key=" . urlencode($val) . "&";
				}
			}*/
			if ($voList) {
				foreach ($voList as $key => $val) {
					$voList[$key]['is_new'] = date('Y-m-d', $v['publish_time']) == date('Y-m-d') ? 1 : 0;
					$voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
					$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                    //$aid = M('AttributeArea')->getField('id',array('no'=>$val['area_no']));
                    $voList[$key]['areaStr'] = $this->area[$val['area_no']]['name'];
                    $voList[$key]['seasonStr'] = $this->season[$val['season_id']]['en_name'];

                    $picList[$key]['stno'] = 0;
					$picList[$key]['stno'] = 0;
					$picList[$key]['sPid'] = $val['id'];
					$picList[$key]['sCid'] = $cid;
					$picList[$key]['sPidNo'] = $val['id'];
					$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
					$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
					$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
				}
			}
            //var_dump($voList);
			$this->assign('jsonData', json_encode(array('arrPicList'=>$picList,'cid'=>$cid,'isVip'=>$rightArr["vipType"])));
			//模板赋值显示
			$this->assign('listArr', $voList);
			//分页显示
			$page = $p->showOne();
            $this->assign('count',$count);
			$this->assign("pageStr", $page);
		}
	}

    protected function getChioceStr(){
        $chioceStr = '';
        if($this->cid){//栏目
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('cid'=>0)));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$this->tideSection[$this->cid]['title'].'</a></span>';
        }
         if($this->soid){//类别
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('soid'=>0)));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$this->sort[$this->soid]['title'].'</a></span>';
        }
        if($this->sid){//季度
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('sid'=>0)));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$this->season[$this->sid]['en_name'].'</a></span>';
        }
        if($this->stno){//款式
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('stno'=>0)));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$this->style[$this->stno]['name'].'</a></span>';
        }
        if($this->ano){//区域
            //$aid = M('AttributeArea')->getField('id',array('no'=>$this->ano));
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('ano'=>0)));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$this->area[$this->ano]['name'].'</a></span>';
        }
        if($this->bid){//品牌
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('bid'=>0)));
            $nameTmp = M('AttributeBrand')->getField('name',array('id'=>$this->bid));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$nameTmp.'</a></span>';
        }
        if($this->coid){//颜色
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('coid'=>0)));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$this->color[$this->coid]['name'].'</a></span>';
        }
        if($this->did){//设计师
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('did'=>0)));
            $nameTmp = M('AttributeDesigner')->getField('name',array('id'=>$this->did));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$nameTmp.'</a></span>';
        }
         if($this->boid){//书名
            $urlTmp = U('/Gallery/index',array_merge($this->param,array('boid'=>0)));
            $nameTmp = M('AttributeBook')->getField('name',array('id'=>$this->boid));
            $chioceStr .= '<span><a href="'.$urlTmp.'">'.$nameTmp.'</a></span>';
        }
        return $chioceStr;
    }

    //品牌、设计师、书名弹出层数据
    public function getSiftAjax(){
        $type = $_GET['tp'];
        $sType = $_GET['st'];
        $letter = $_GET['lt'];
        if(empty($letter) || !in_array($sType,array('brand','designer','book'))) return false;
        $param = array(
                       'cid'=>intval($_GET['cid']),'aid'=>intval($_GET['aid']),'soid'=>intval($_GET['soid']),
                       'sid'=>intval($_GET['sid']),'stno'=>intval($_GET['stno']),'bid'=>intval($_GET['bid']),
                       'did'=>intval($_GET['did']),'boid'=>intval($_GET['boid']),'coid'=>intval($_GET['coid'])
                    );
        $cKey = $sType."List";
        $voList = $this->cache->get($cKey);
        header("Content-Type:text/html; charset=utf-8");
        echo $type == 'id' ? $this->getSiftAjaxById($sType,$letter,$param,$voList) : $this->getSiftAjaxByText($sType,$letter,$param,$voList);
     }

      //品牌、设计师、书名弹出层数据
    public function getSiftAjaxById($sType,$letter,$param,$voList){
        $html = '';
        if($voList){
            foreach ($voList as $key => $val) {
                if($sType == 'brand')
                    $urlTmp = U('/Gallery/index',array_merge($param,array('bid'=>$val['id'])));
                elseif($sType == 'designer')
                    $urlTmp = U('/Gallery/index',array_merge($param,array('did'=>$val['id'])));
                elseif($sType == 'book')
                    $urlTmp = U('/Gallery/index',array_merge($param,array('boid'=>$val['id'])));

                $word = strtoupper(substr($val['name'],0,1));
                if (preg_match('/^[a-zA-Z]+$/',$word)) {
                    $voListTmp[$word][$key]["id"] =$val['id'];
                    $voListTmp[$word][$key]["name"] = $val["name"];
                    $voListTmp[$word][$key]["url"] = $urlTmp;
                }
                else {
                    $voListQt[$key]["id"] =$val['id'];
                    $voListQt[$key]["name"] = $val["name"];
                    $voListQt[$key]["url"] = $urlTmp;
                }
            }
            $voList = $voListTmp;
            if(is_array($voListQt)) $voList['qt'] = $voListQt;
            if($voList[$letter]){
               $html .= '<h4 class="singleLetter" id="'.$sType.'_'.$letter.'">'.($letter == 'qt' ? '其它' : $letter).'</h4>';
               $html .= '<p class="singleCentont" id="singleCentont_'.$sType.'_'.$letter.'">';
               foreach($voList[$letter] as $key =>$val){
                  $html .= '<a href="'.$val['url'].'">'.$val['name'].'</a>';
               }
               $html .= '</p>';
            }
         }
         return $html;
     }

     //品牌、设计师、书名弹出层数据
     public function getSiftAjaxByText($sType,$letter,$param,$voList){
        $length = strlen($letter);
        $html = '';
        if($voList){
            foreach ($voList as $key => $val) {
                if($sType == 'brand')
                    $urlTmp = U('/Gallery/index',array_merge($param,array('bid'=>$val['id'])));
                elseif($sType == 'designer')
                    $urlTmp =U('/Gallery/index',array_merge($param,array('did'=>$val['id'])));
                elseif($sType == 'book')
                    $urlTmp = U('/Gallery/index',array_merge($param,array('boid'=>$val['id'])));

                $word = strtoupper(substr($val['name'],0,$length));
                if ($word != strtoupper($letter)) continue;
                $voListTmp[$key]["id"] =$val['id'];
                $voListTmp[$key]["name"] = $val["name"];
                $voListTmp[$key]["url"] = $urlTmp;
            }
            $voList = $voListTmp;
            $html .= '<h4 class="singleLetter">'.$letter.'</h4>';
            $html .= '<p class="singleCentont">';
            if($voList){
               foreach($voList as $key =>$val){
                  $html .= '<a href="'.$val['url'].'">'.$val['name'].'</a>';
               }
            }
            else{
                $html .= '暂时没有相关数据!';
            }
            $html .= '</p>';
         }
         return $html;
     }
 }
?>
