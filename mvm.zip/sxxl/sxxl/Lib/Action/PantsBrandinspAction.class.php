<?php
class PantsBrandinspAction extends BrandinspAction {

    public function _initialize() {
        $this->sid = 2;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

	public function themeDetail($tid = '') {
        parent::themeDetail($tid);
	}

    protected function getSpecialChildMenu(){
        $soid = $this->getSoid();
        $specialChildMenu = array(
            array('id'=>11169,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>11169)),'picture'=>'/Public/Images/fishion/w-brand/Armani-Collezioni.jpg','name'=>'Armani Collezioni'),
            array('id'=>3656,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>3656)),'picture'=>'/Public/Images/fishion/w-brand/Balenciaga.jpg','name'=>'BALENCIAGA'),
            array('id'=>1694,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>1694)),'picture'=>'/Public/Images/fishion/w-brand/burberry-bluelabel.jpg','name'=>'BURBERRY'),
            array('id'=>894,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>894)),'picture'=>'/Public/Images/fishion/w-brand/CELINE.jpg','name'=>'CELINE'),
            array('id'=>140,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>140)),'picture'=>'/Public/Images/fishion/w-brand/CHANEL.jpg','name'=>'CHANEL'),
            array('id'=>147,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>147)),'picture'=>'/Public/Images/fishion/w-brand/Chloe.jpg','name'=>'Chloe'),
            array('id'=>972,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>972)),'picture'=>'/Public/Images/fishion/w-brand/Dior.jpg','name'=>'Dior'),
            array('id'=>198,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>198)),'picture'=>'/Public/Images/fishion/w-brand/DKNY.jpg','name'=>'DKNY'),
            array('id'=>10924,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>10924)),'picture'=>'/Public/Images/fishion/w-brand/Dolce-Gabbana.jpg','name'=>'Dolce-Gabbana'),
            array('id'=>7065,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>7065)),'picture'=>'/Public/Images/fishion/w-brand/DSQUARED2.jpg','name'=>'DSQUARED2'),
            array('id'=>1029,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>1029)),'picture'=>'/Public/Images/fishion/w-brand/FENDI-.jpg','name'=>'FENDI'),
            array('id'=>2843,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>2843)),'picture'=>'/Public/Images/fishion/w-brand/GIVENCHY.jpg','name'=>'GIVENCHY'),
            array('id'=>298,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>298)),'picture'=>'/Public/Images/fishion/w-brand/gucci.jpg','name'=>'gucci'),
            array('id'=>318,'url'=>U("/".MODULE_NAME."/index",array('soid'=>$soid,'bid'=>318)),'picture'=>'/Public/Images/fishion/w-brand/hugo-boss.jpg','name'=>'hugo-boss'),
        );
        return $specialChildMenu;
    }

	public function downloadzip() {
		parent::downloadzip();
	}
}

