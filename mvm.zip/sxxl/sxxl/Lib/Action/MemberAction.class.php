<?php

class MemberAction extends CommonAction {

	protected $model;
	protected $modelFb;

	function _initialize() {
		parent::_initialize();
		$this->model = D('Member');
		$this->modelFb = D('Feedback');
		$this->modelarea = D('AreaCode');
		$this->modelcity = D('CityCode');
		$this->modelprovince = D('ProvinceCode');
	}

	public function recentlyViewed() {
		$Arr['title'] = '最近浏览_我的蝶讯';
		$Arr['currentTagA'] = 'MemberCenter';
		$Arr['currentTagB'] = 'recentlyViewed';
		$model = M('LogBrowse');
		import("ORG.Util.Page");
		$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
		$count = $model->where($map)->count();
		//创建分页对象
		$p = new Page($count, 8);
		$voList = $model->where($map)->field('id,member_id,big_picture_url,small_picture_url,position_name,browse_time')->order(array('id' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->findAll();
		if ($voList) {
			foreach ($voList as $key => $val) {
				$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);
				$voList[$key]['browse_time'] = $val['browse_time'] ? date('Y-m-d', $val['browse_time']) : '';
				$picList[$key]['sTid'] = 0;
				$picList[$key]['sTid'] = 0;
				$picList[$key]['sPid'] = $val['id'];
				$picList[$key]['sCid'] = 0;
				$picList[$key]['sPidNo'] = $val['id'];
				$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
				$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
				$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
			}
		}
		$Arr['voList'] = $voList;
		$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => 0, 'isVip' => $this->isRightB));
		$Arr['pageStr'] = $p->showOne();
		$this->assign($Arr);
		$this->display('recently_viewed');
	}

	public function updatePassword() {
		$Arr['title'] = '修改密码_帐户管理';
        $Arr['currentTagB'] = 'memberPassword';
		$id = Cookie::get(C('USER_AUTH_KEY'));
		$this->assign('id', $id);
        $this->assign($Arr);
		$this->display('update_password');
	}

	public function checkOldPassword() {
		$map['id'] = Cookie::get(C('USER_AUTH_KEY'));
		$map['password'] = md5(trim($_GET['oldpassword']));
		echo $this->model->where($map)->count();
	}

	public function updateMemberInfo() {
		$Arr['title'] = '帐户信息_帐户管理';
        $Arr['currentTagB'] = 'memberInfo';
		$Arr['id'] = $id = Cookie::get(C('USER_AUTH_KEY'));
		$info = $this->model->where("id='{$id}'")->find();
		if (!empty($info))
			$Arr = array_merge($Arr, $info);
		if (empty($Arr['province']))
			$Arr['province'] = 0;
		if (empty($Arr['city']))
			$Arr['city'] = 0;
		if (empty($Arr['county']))
			$Arr['county'] = 0;
		$Arr['provinceArr'] = M('ProvinceCode')->field('id,name')->findAll();
		//echo $info['is_personal'];
		$this->assign($Arr);
		if($info['is_personal']){
			$this->display('Job/update_member_info');
		}else{
			$this->display('update_member_info');
		}
		
	}

	/**
	 * 会员信息修改
	 */
	public function saveMemberInfo() {
		if ($_POST['id']) {
			if (!$this->model->create()) {
				$this->ajaxReturn('', $this->model->getError(), 0);
			} else {
				$data = $this->model->save();
				if ($data >= 0) {
					$pub = A('public');
					//修改老服装网的会员信息
					if ($_POST['province']) {
						$datas = $this->modelprovince->where(array('id' => $_POST['province']))->field('name')->find();
						$_POST['province'] = $datas['name'];
					}
					if ($_POST['city']) {
						$datas = $this->modelcity->where(array('id' => $_POST['city']))->field('name')->find();
						$_POST['city'] = $datas['name'];
					}
					if ($_POST['area']) {
						$datas = $this->modelarea->where(array('id' => $_POST['area']))->field('name')->find();
						$_POST['area'] = $datas['name'];
					}
					$info = $_POST;
					$infos = getCurlDate('newwww.php?act=save', $info);
					$this->ajaxReturn($data, '修改成功!', 1);
				} else {
					$this->ajaxReturn($data, '修改失败!', 0);
				}
			}
		}
		else
			$this->ajaxReturn($data, '修改失败!', 0);
	}

	/**
	 * 更新密码
	 */
	public function saveUpdatePassword() {
		//Cookie::get('loginUser');
		if ($_POST['id']) {
			$map['password'] = md5(trim($_POST['oldpassword']));
			$map['id'] = Cookie::get(C('USER_AUTH_KEY'));
			$count = $this->model->where($map)->count();
			if ($count == 0)
				$this->ajaxReturn($data, '当前密码错误!', 0);
			else {
				$nPassword = trim($_POST['password']);
				if (strlen($nPassword) > 5 && $this->model->where($map)->data(array('password' => md5($nPassword)))->save() !== false) {
					//修改老服装网密码
					$info = $_POST;
					$info['name'] = Cookie::get('loginUser');
					$infos = getCurlDate('newwww.php?act=savepwd', $info);
					$this->ajaxReturn($data, '密码修改成功!', 1);
				}
				else
					$this->ajaxReturn($data, '密码修改失败!', 0);
			}
		}
		else
			$this->ajaxReturn($data, '密码修改失败!', 0);
	}

	/**
	 * 建议反馈
	 */
	public function feedback() {
		$act = trim($_POST['act']);
		if ($act == 'add') {
			if (!$this->modelFb->create()) {
				$this->ajaxReturn('', $this->modelFb->getError(), 0);
			} else {
				$data = $this->modelFb->add();
				$suggestion['insert_id'] = $this->modelFb->getLastInsID();
				if ($data >= 0) {
					$suggestion['contact'] = $_REQUEST['content'] ? $_REQUEST['content'] : "";
					$suggestion['title'] = $_REQUEST['title'] ? $_REQUEST['title'] : "";
					$suggestion['post_url'] = $_SERVER['HTTP_REFERER'];
					$suggestion['loginUser'] = Cookie::get('loginUser');
					$suggestion['add_ip'] = $_SERVER['REMOTE_ADDR'];
					$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
					$map['invalid_time'] = array("egt", time());
					$data = D('RefMemberRole')->where($map)->select();
					if ($data) {
						foreach ($data as $k => $v) {
							$vipstr .= $v['role_id'] . ",";
						}
					}
					$suggestion['viptype'] = rtrim($vipstr, ',');
					getCurlDate('newwww.php?act=suggestion', $suggestion);
					$this->ajaxReturn($data, '提交成功!', 1);
				} else {
					$this->ajaxReturn($data, '提交失败!', 0);
				}
			}
		} elseif ($act == 'del') {
			$idArr = $_POST['ids'];
			if (count($idArr) == 0)
				$this->error('您没有选中任何数据!');
			$errorNum = 0;
			foreach ($idArr as $key => $val){
				$dated['is_publish'] = '-1';
				//$this->modelFb->where("id='{$val}'")->save($datedel);
				//$this->modelFb->where("id='{$val}'")->delete() ? '' : $errorNum++;
				$this->modelFb->where("id='{$val}'")->save($dated) ? '' : $errorNum++;
				//$datedel['id'] = $val;
				//getCurlDate('newwww.php?act=delsuggestion', $datedel);
			}
			if ($errorNum == 0)

				$this->ajaxReturn($data, '删除成功!', 1);
			else
				$this->ajaxReturn($data, '删除发生错误，请重试!', 0);
		}

		$Arr['title'] = '建议反馈_我的蝶讯';
		$Arr['currentTagA'] = 'MemberCenter';
		$Arr['currentTagB'] = 'feedback';
		import("ORG.Util.Page");
		$map['member_id'] = Cookie::get(C('USER_AUTH_KEY'));
		$map['is_publish'] = array('neq','-1');
		$count = $this->modelFb->where($map)->count();
		//创建分页对象
		$p = new Page($count, 8);
		$field = 'id,member_id,type_id,title,content,reply_id,add_time';
		$Arr['voList'] = $this->modelFb->where($map)->field($field)->order(array('id' => 'desc'))->limit($p->firstRow . ',' . $p->listRows)->findAll();
		$Arr['pageStr'] = $p->showFour();
		$this->assign($Arr);
		$this->display();
	}

	/**
	 * 反馈回复内容
	 */
	public function replyContent() {
		$id = intval($_GET['id']);
		if (empty($id))
			$content = '非法操作!';
		$content = M('FeedbackReply')->getField('content', array('id' => $id));
		$content = $content ? $content : '回复已删除或已过期!';
		$html = '<div class="ContentLayerWindows">';
		$html .= '<div class="innereply">' . $content . '</div>';
		$html .= '</div>';
		echo $html;
	}

	public function feedbackForm() {
		$this->display('feedback_form');
	}

}