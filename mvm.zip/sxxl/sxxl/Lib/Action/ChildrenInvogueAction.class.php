<?php
class ChildrenInvogueAction extends InvogueAction {

    public function _initialize() {
        $this->soid = 3;
        parent::_initialize();
    }

    public function index() {
        $this->themeList();
	}

    public function themeList(){
        if($this->param['bid'] || $this->param['brandStr'] || $this->param['seid'] || $this->param['ano']){
            $Arr['cmid'] = $this->cmid = 0;
            $Arr['aid'] = $aid = '';
        }else{
            $aid = $this->param['aid'];
            $Arr['aid'] = $aid = in_array($aid, array('gw', 'gl', 'hg')) ? $aid : (!$this->cmid ? '' : '');
        }

        $this->childMenus = $this->getSubMenuList($this->cid);
        $Arr['specialChildMenus'] = $this->getSpecialChildMenu();

		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,publish_time,area_no,season_id,pv_count,picture_count";
		$order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->tListRows = 12;
        parent::themeDataList($field, $map, $order);
        //parent::themeDataListBySphinx($field, $map, $order);
        $this->assign($Arr);
		$this->display('theme_list');
    }

	public function themeDetail($tid = '') {
        parent::themeDetail($tid);
	}

    public function pictureList(){
        $this->childMenus = $this->getSubMenuList($this->cid);
        $specialChildMenus = $this->getSpecialChildMenu();
        $this->assign('specialChildMenus',$specialChildMenus);
        $this->pListRows = 20;

		$field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,publish_time,brand_id,area_no,season_id";
        $order = array('publish_time'=>'desc',$this->tableArr['picture_original'].'.id'=>'desc');
		parent::pictureDataList($field, $map, $order);
		//parent::pictureDataListBySphinx($field, $map, $order);
		$this->display('picture_list');
    }

    protected function getSpecialChildMenu() {
        return array('children_menu_list'=>$this->getThemeLeftMenu(),'style_menu_list'=>$this->getPictureLeftMenu());
    }

    protected function getSpecialChildMenuBak() {
        if (ACTION_NAME == 'pictureList')
            $specialChildMenu = $this->getPictureLeftMenu();
        else
            $specialChildMenu = $this->getThemeLeftMenu();

        return $specialChildMenu;
    }

    protected function getThemeLeftMenu() {
        $specialChildMenu = array(
            array('id'=>'gw','name'=>'国外','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw')),'thirdMenu'=>
                array(
                    array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>1))),
                    array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>66))),
                    array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>29))),
                    array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>95))),
                    array('id'=>284,'name'=>'风衣','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>284))),
                    array('id'=>264,'name'=>'棉衣/羽绒服','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>264))),
                    array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>128))),
                    array('id' =>202,'name' =>'半裙','url'=> U('/' . MODULE_NAME . "/themeList",array('aid' => 'gw','stid' =>202))),
                    array('id' =>189,'name' =>'连衣裙','url'=> U('/' . MODULE_NAME . "/themeList",array('aid' => 'gw','stid' =>189))),
                    array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>211))),
                    array('id'=>152,'name'=>'运动','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gw','stid'=>152))),
                )
            ),
            array('id'=>'gl','name'=>'国内','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl')),'thirdMenu'=>
                array(
                    array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>1))),
                    array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>66))),
                    array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>29))),
                    array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>95))),
                    array('id'=>284,'name'=>'风衣','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>284))),
                    array('id'=>264,'name'=>'棉衣/羽绒服','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>264))),
                    array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>128))),
                    array('id' =>202,'name' =>'半裙','url'=> U('/' . MODULE_NAME . "/themeList",array('aid' => 'gw','stid' =>202))),
                    array('id' =>189,'name' =>'连衣裙','url'=> U('/' . MODULE_NAME . "/themeList",array('aid' => 'gw','stid' =>189))),
                    array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>211))),
                    array('id'=>152,'name'=>'运动','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>152))),
                    //array('id'=>'','name'=>'精选品牌','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'gl','stid'=>0)))
                )
            ),
            array('id'=>'hg','name'=>'韩国南大门','url'=>U('/'.MODULE_NAME."/themeList",array('aid'=>'hg')),
            )
        );

        return $specialChildMenu;
    }

    protected function getPictureLeftMenu() {
        $soid = parent::getSoid();
        $stid = $this->param['stid'];
        $specialChildMenu = array(
            array('id'=>1,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>1)),'selected'=>in_array($stid,array(1,23,22,17,4,3,13)),
                'thirdMenu'=>
                array(
                    array('id'=>23,'name'=>'图案T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>23)),'selected'=>$stid == 23),
                    array('id'=>22,'name'=>'贴布','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>22)),'selected'=>$stid == 22),
                    array('id'=>17,'name'=>'其它','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>17)),'selected'=>$stid == 17),
                    array('id'=>4,'name'=>'背心','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>4)),'selected'=>$stid == 4),
                    array('id'=>3,'name'=>'POLO','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>3)),'selected'=>$stid == 3),
                    array('id'=>13,'name'=>'款式T','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>13)),'selected'=>$stid == 13),
                )
            ),
            array('id'=>29,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>29)),'selected'=>in_array($stid,array(29,59,57)),
                'thirdMenu'=>
                array(
                    array('id'=>59,'name'=>'休闲夹克','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>59)),'selected'=>$stid == 59),
                    array('id'=>57,'name'=>'小西装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>57)),'selected'=>$stid == 57),
                )
            ),
            array('id'=>295,'name'=>'马甲','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>295)),'selected'=>($stid == 295)),
            array('id'=>310,'name'=>'套装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>310)),'selected'=>($stid == 310)),
            array('id'=>276,'name'=>'卫衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>276)),'selected'=>in_array($stid,array(276,278,281)),
                'thirdMenu'=>
                array(
                    array('id'=>278,'name'=>'开衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>278)),'selected'=>$stid == 278),
                    array('id'=>281,'name'=>'套衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>281)),'selected'=>$stid == 281),
                )
            ),
            array('id'=>271,'name'=>'棉袄','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>271)),'selected'=>in_array($stid,array(271,273,274)),
                'thirdMenu'=>
                array(
                    array('id'=>273,'name'=>'棉服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>273)),'selected'=>$stid == 273),
                    array('id'=>274,'name'=>'羽绒服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>274)),'selected'=>$stid == 274),
                )
            ),
            array('id'=>242,'name'=>'皮草','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>242)),'selected'=>in_array($stid,array(242,239,242)),
                'thirdMenu'=>
                array(
                    array('id'=>245,'name'=>'皮革','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>245)),'selected'=>$stid == 245),
                    array('id'=>248,'name'=>'裘皮','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>248)),'selected'=>$stid == 248),
                )
            ),
            array('id'=>288,'name'=>'风衣','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>288)),'selected'=>$stid == 288),
            array('id'=>95,'name'=>'毛衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>95)),'selected'=>in_array($stid,array(95,120,105,111,125)),
                'thirdMenu'=>
                array(
                    array('id'=>120,'name'=>'套衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>120)),'selected'=>$stid == 120),
                    array('id'=>105,'name'=>'开衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>105)),'selected'=>$stid == 105),
                    array('id'=>111,'name'=>'毛织裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>111)),'selected'=>$stid == 111),
                    array('id'=>125,'name'=>'小披肩','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>125)),'selected'=>$stid == 125),
                )
            ),
            array('id'=>66,'name'=>'衬衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>66)),'selected'=>in_array($stid,array(66,70,92,94,78)),
                'thirdMenu'=>
                array(
                    array('id'=>70,'name'=>'短袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>70)),'selected'=>$stid == 70),
                    array('id'=>92,'name'=>'长袖','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>92)),'selected'=>$stid == 92),
                    array('id'=>94,'name'=>'罩衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>94)),'selected'=>$stid == 94),
                    array('id'=>78,'name'=>'开衫','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>78)),'selected'=>$stid == 78),
                )
            ),
            array('id'=>128,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>128)),'selected'=>in_array($stid,array(128,129,150,132)),
                'thirdMenu'=>
                array(
                    array('id'=>129,'name'=>'背带裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>129)),'selected'=>$stid == 129),
                    array('id'=>150,'name'=>'长裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>150)),'selected'=>$stid == 150),
                    array('id'=>132,'name'=>'短裤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>132)),'selected'=>$stid == 132),
                )
            ),
            array('id'=>152,'name'=>'运动','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>152)),'selected'=>in_array($stid,array(152,154,177,161,164,162,163)),
                'thirdMenu'=>
                array(
                    array('id'=>154,'name'=>'T恤','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>154)),'selected'=>$stid == 154),
                    array('id'=>166,'name'=>'外套','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>166)),'selected'=>$stid == 177),
                    array('id'=>161,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>161)),'selected'=>$stid == 161),
                    array('id'=>165,'name'=>'套装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>165)),'selected'=>$stid == 164),
                    array('id'=>162,'name'=>'棉袄','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>162)),'selected'=>$stid == 162),
                    array('id'=>163,'name'=>'裙子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>163)),'selected'=>$stid == 163),
                 )
            ),
            array('id'=>211,'name'=>'牛仔','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>211)),'selected'=>in_array($stid,array(211,227,219,224,231)),
                'thirdMenu'=>
                array(
                    array('id'=>227,'name'=>'上装','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>227)),'selected'=>$stid == 227),
                    array('id'=>219,'name'=>'裤子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>219)),'selected'=>$stid == 219),
                    array('id'=>224,'name'=>'裙子','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>224)),'selected'=>$stid == 224),
                    array('id'=>231,'name'=>'细节','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>231)),'selected'=>$stid == 231),
                )
            ),
            array('id'=>189,'name'=>'连衣裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>189)),'selected'=>$stid == 189),
            array('id'=>360,'name'=>'礼服','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>360)),'selected'=>$stid == 360),
            array('id'=>202,'name'=>'半裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>202)),'selected'=>in_array($stid,array(202,205,203)),
                'thirdMenu'=>
                array(
                    array('id'=>205,'name'=>'短裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>205)),'selected'=>$stid == 205),
                    array('id'=>203,'name'=>'背带裙','url'=>U('/'.MODULE_NAME."/pictureList",array('soid'=>$soid,'stid'=>203)),'selected'=>$stid == 203),
                )
            ),
        );

        return $specialChildMenu;
    }

	public function downloadzip() {
        parent::downloadzip();
    }
}
