<?php

class CatwalkAction extends TideSectionAction {

    public function _initialize() {
        $this->cid = 12;
        $this->cache = Cache::getInstance();
        $this->baseUrl = U('themeList', $this->param);
        parent::_initialize();
    }

	protected function index() {
        $this->childMenus = parent::getSubMenuList($this->cid);

        $map = array();
        $field = "{$this->tableArr['folder_original']}.id,title,title_picture_url,publish_time,season_id,designer_id,pv_count,area_no,has_type,has_desc";
		$order = array('publish_time'=>'desc',$this->tableArr['folder_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->fListRows = 8;
		//$this->folderDataList($field, $map, $order);
        $this->folderDataListBySphinx($field, $map);

        //判断是否为筛选页
        $did = $this->param['did'];
        $designerStr = $this->param['designerStr'];
        $goPage = $did || $designerStr ? 'index_search_list' : 'index';
		$this->display($goPage);
	}

	protected function folderList(){
        $this->childMenus = parent::getSubMenuList($this->cid);

		$field = "{$this->tableArr['folder_original']}.id,title,title_picture_url,publish_time,season_id,designer_id,area_no,pv_count,has_type,has_desc";

        $order = array('publish_time'=>'desc',$this->tableArr['folder_original'].'.id'=>'desc');
		$this->relationArr = false;
        $this->fListRows = 8;
		//$this->folderDataList($field, $map, $order);
        $this->folderDataListBySphinx($field, $map);
		$this->display('folder_list');
	}

	protected function folderDetail() {
 		$fid = intval($_GET['fid']);
		if (empty($fid))
            $this->error('参数错误！');

        $type = intval($_GET["type"]);//细节:1,及时版:2,清晰版:4,主题介绍：5（有别于前面几个数字就行）
        if (!in_array($type,array(1,2,4,5))){
            $folder_info_tmp = $this->modelF->where(array('id'=>$fid))->field('has_type,has_desc')->find();
            if ($folder_info_tmp['has_desc']){
                $type = 5;
            }

            if ($folder_info_tmp['has_type'] & 4){
                $type = 4;
            }

            if ($folder_info_tmp['has_type'] & 2){
                $type = 2;
            }

            if ($folder_info_tmp['has_type'] & 1){
                $type = 1;
            }
        }

        if(!$type){
            $this->error('非法操作！');
        }

        if($type == 1)
            $map['catwalk_type'] = 1;
        elseif($type == 2)
            $map['catwalk_type'] = 2;
        elseif($type == 4)
            $map['catwalk_type'] = 4;

        $field = 'id,title,publish_time,catwalk_type';
        $order = array('publish_time'=>'asc','id'=>'asc');

        $this->updateFolderPvCount($fid);
        $Arr['fid'] = $map['folder_id'] = $fid;

        $themeList = $this->folderThemeList($field, $map, $order);

        $Arr['themeList'] = $themeList;
        //$Arr['themeList'][0]['designerStr'] =  M('AttributeDesigner')->getField('name',array('id'=>$themeList[0]['designer_id']));
        $Arr['tid'] = $tid = $themeList['0']['id'];

        $Arr['lableList'] = '';
        $this->relationArr = array('FolderExtend');
        $Arr['folderInfo'] = $folderInfo = $this->modelF->relation($this->relationArr)->where(array('id'=>$fid))->field('id,title,has_type')->find();

        $soid = $this->getSoid();
        if($folderInfo['has_type']&1) {//细节
           $Arr['type_url_1'] =  U("/".MODULE_NAME."/folderDetail",array('cmid'=>$this->cmid,'soid'=>$soid,'fid'=>$fid,'type'=>1));
        }
        if($folderInfo['has_type']&2){//及时
            $Arr['type_url_2'] =  U("/".MODULE_NAME."/folderDetail",array('cmid'=>$this->cmid,'soid'=>$soid,'fid'=>$fid,'type'=>2));
        }
        if($folderInfo['has_type']&4){//清晰
            $Arr['type_url_4'] =  U("/".MODULE_NAME."/folderDetail",array('cmid'=>$this->cmid,'soid'=>$soid,'fid'=>$fid,'type'=>4));
        }

    	$this->assign($Arr);
		$this->themeDetail($fid,$tid);
	}

    /*
     * 秀场提练专用
     */
    protected function themeList(){
        $this->childMenus = parent::getSubMenuList($this->cid);

		$field = "{$this->tableArr['subject_original']}.id,title,title_picture_url,area_no,season_id,publish_time,area_no,pv_count";
        $order = array('publish_time'=>'desc',$this->tableArr['subject_original'].'.id'=>'desc');
		$this->relationArr = array('Style');
        $this->tListRows = 8;
		$this->themeDataList($field, $map, $order);
		$this->display('theme_list');

    }

    protected function pictureList(){
        $this->childMenus = parent::getSubMenuList($this->cid);
        $this->pListRows = 20;
		$field = "{$this->tableArr['picture_original']}.id,big_picture_url,small_picture_url,publish_time,designer_id,area_no,season_id";
		$order = array('publish_time'=>'desc',$this->tableArr['picture_original'].'.id'=>'desc');
        //$this->pictureDataList($field, $map, $order);
		$this->pictureDataListBySphinx($field, $map, $order);
		$this->display('picture_list');
    }

    /**
     * 主题列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeDataList($field, $map, $order) {
        if($this->cid == 12 && ACTION_NAME == 'themeList')//秀场提练特殊处理
            $cid = 28;

        if ($cid)
            $map[$this->tableArr['subject_original'] . '.menu_id'] = $cid; //秀场提练特殊处理

        if ($this->cmid)
            $map[$this->tableArr['subject_original'] . '.child_menu_id'] = $this->cmid;

        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }
        if ($this->sid && $this->sid != 5) {
            $map['fsc.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
        }

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $seid = $this->param['seid'];
        if ($seid)
            $map['season_id'] = $seid;

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }
        }

        $stid = $this->param['stid'];
        if ($map['sst.style_id'] || $stid) {
            $join[] = "{$this->tableArr['ref_subject_style_original']} sst on sst.subject_id={$this->tableArr['subject_original']}.id";
            $map['sst.style_id'] ? '' : $map['sst.style_id'] = $stid;
        }

        $page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Catwalk::themeDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            import("ORG.Util.DataCount");
			$count = DataCount::getCount($this->tableArr['subject'], $map, $join);
            //$count = $this->modelT->join($join)->where($map)->count();
            if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->tListRows);
                $voList = $this->modelT->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelT->getLastSql();
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        $voList[$key]['url'] = U("/" . MODULE_NAME . "/themeDetail", array('cmid' => $this->cmid,'soid'=>$soid,'tid' => $val['id']));
                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
                        $voList[$key]['is_new'] = $voList[$key]['publish_time'] == date('Y-m-d') ? 1 : 0;
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    protected function themeInfo($fid,$tid) {
        $tid = intval($tid);
        $cid = ACTION_NAME == 'themeDetail' ? 28 : $this->cid;
        if (!$tid || ($cid == 12 && !$fid)){
            $this->error('参数错误！');
        }

        $map[$this->tableArr['subject_original'].'.menu_id'] = $cid;
        $map[$this->tableArr['subject_original'].'.id'] = $tid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        if ($this->soid) {
            $map['fs.sort_id'] = $this->soid == 3 ? array('egt',3) : $this->soid;
            $join[] = "{$this->tableArr['ref_subject_sort_original']} as fs on fs.subject_id = {$this->tableArr['subject_original']}.id";
        }

        if($cid == 12){
            if ($this->sid ) {
                $map['fsc.special_column_id'] = $this->sid;
                $join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
            }
        }else{
            if ($this->sid && $this->sid != 5) {
                $map['fsc.special_column_id'] = $this->sid;
                $join[] = "{$this->tableArr['ref_subject_column_original']} as fsc on fsc.subject_id = {$this->tableArr['subject_original']}.id";
            }
        }

        $field = $this->tableArr['subject_original'].'.id,title,publish_time,season_id,area_no,show_edit,book_id,designer_id';

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Magazine::themeInfo::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.implode('::', $map));
        $info = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if (!$info) {
            $info = $this->modelT->join($join)->relation($this->relationArr)->field($field)->where($map)->find();
            //echo $this->modelT->getLastSql()."</br>";exit;
            if(!$info){
                $this->error('参数错误！');
            }

            $info['publish_time'] = $info['publish_time'] ? date('Y-m-d', $info['publish_time']) : '';
            $soid = intval($_GET['soid']);
            $soid = $soid ? $soid : $this->soid;
            if(!$soid){
                $soid = M($this->tableArr['ref_subject_sort'])->getField("sort_id","subject_id='{$tid}'");
            }
            $info['sortStr'] = $this->sorts[$soid]['title'];
            $info['areaStr'] = $this->areas[$info['area_no']]['name'];
            $info['seasonStr'] = $this->seasons[$info['season_id']]['en_name'];
            $info['bookStr'] = $this->books[$info['book_id']]['name'];
            $info['designerStr'] = $this->designers[$info['designer_id']]['name'];
            $info['zipfile_url'] = $this->isRightB && $info['zipfile_url'] ? $this->getDownloadUrl($info['zipfile_url']): '';
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $info,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $info);
        }

        //权限验证
        $this->withoutPermission('',$info);

        return $info;
    }

    /**
     * get theme picture list
     * @param $tid intval
     * @return array
     */
    protected function themePicture($tid) {
        $tid = intval($tid);
        $this->assign('tid', $tid);

        if (!$tid)
            $this->error('参数错误！');

        $cid = ACTION_NAME == 'themeDetail' ? 28 : $this->cid;
        if ($cid == 28) {
            $field = 'id,small_picture_url,big_picture_url,page_no';
            $order = array('page_no' => 'asc');
        }
        else{
            $field = 'id,small_picture_url,big_picture_url';
            $order = array('page_no' => 'asc','publish_time' => 'desc');
        }

        $map['menu_id'] = $cid;
        //if($this->cmid) $map['child_menu_id'] = $this->cmid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $tid;

		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Catwalk::themePicture::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
           $count = $this->modelP->where($map)->count();
           if($count > 0){
                import("ORG.Util.Page");
                $p = new Page($count, $this->pListRows);
                $voList = $this->modelP->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //echo $this->modelP->getLastSql()."</br>";
                if ($voList) {
                    $picList = array();
                    foreach ($voList as $key => $val) {
                        $voList[$key]['pic_small'] = show_pic_power($val['small_picture_url'], $this->isRightS);
                        $voList[$key]['publish_time'] = date('Y-m-d', $val['publish_time']);

                        $picList[$key]['sTid'] = 0;
                        $picList[$key]['sPid'] = $val['id'];
                        $picList[$key]['sCid'] = $cid;
                        $picList[$key]['sPidNo'] = $val['id'];
                        $picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
                        $picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
                        $picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
                    }
                }
				//var_dump($picList);
				$Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
				//模板赋值显示
				$Arr['listArr'] = $voList;
				//分页显示
				$Arr['pageStr'] = $p->showOne();
				//主题下载处需要用到
				$Arr['picNum'] = $count;
           }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    /**
     * 图片列表分页
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function pictureDataList($field, $map, $order) {
        if ($this->cid)
            $map[$this->tableArr['picture_original'] . '.menu_id'] = $this->cid;
        if ($this->cmid)
            $map[$this->tableArr['picture_original'] . '.child_menu_id'] = $this->cmid;

        $soid = $this->getSoid();
        if ($soid){
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_picture_sort_original']} as fs on fs.picture_id = {$this->tableArr['picture_original']}.id";
		}
        if ($this->sid){
			if($this->sid == 2){//时装发布 裤子专栏
				//默认展示什么数据？？

			}elseif($this->sid != 5){
				$map['fsc.special_column_id'] = $this->sid;
				$join[] = "{$this->tableArr['ref_picture_column_original']} as fsc on fsc.picture_id = {$this->tableArr['picture_original']}.id";
			}
		}

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $did = $this->param['did'];
        $designerStr = $this->param['designerStr'];
        if (empty($did) && $designerStr != '') {
            $did = M('AttributeDesigner')->getField('id', array('name' => $designerStr));
            $did = intval($did);
            $did ? $map['designer_id'] = $did : '';
        } elseif ($did) {
            $map['designer_id'] = $did;
        }

		//款式
        $stid = $this->param['stid'];
        if ($stid) {
            $join[] = "{$this->tableArr['ref_picture_style_original']} ps ON ps.picture_id={$this->tableArr['picture_original']}.id";
            $map['ps.style_id'] = $stid ? $stid : 1;
		}

        $page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Catwalk::pictureDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            //取得满足条件的记录数
            //$count = $this->modelP->join($join)->where($map)->count();
            //echo $this->modelP->getlastsql();
            import("ORG.Util.DataCount");
            $count = DataCount::getCount($this->tableArr['picture'],$map,$join);
            if($count > 0){
                import("ORG.Util.Page");
                //创建分页对象
                $p = new Page($count, $this->pListRows);
				//分页查询数据
				$voList = $this->modelP->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
				//echo $this->modelP->getlastsql();

				if ($voList) {
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);//show_pic_power($val['small_picture_url'], $this->isRightS);
						$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
						if ($val['season_id'])
							$voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
						if ($val['area_no'])
							$voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
						if ($val['designer_id'])
							$voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];

						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['id'];
						$picList[$key]['sCid'] = $cid;
						$picList[$key]['sPidNo'] = $val['id'];
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}

                    $Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
                    //模板赋值显示
                    $Arr['listArr'] = $voList;
                    //分页显示
                    $Arr['pageStr'] = $p->showOne();
				}
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }
        $this->assign($Arr);
    }


	protected function pictureDataListBySphinx($field, $map, $order) {
        if ($this->cid)
            $map[$this->tableArr['picture_original'] . '.menu_id'] = $this->cid;
        if ($this->cmid)
            $map[$this->tableArr['picture_original'] . '.child_menu_id'] = $this->cmid;

        if ($this->sid){
			if($this->sid == 2){//时装发布 裤子专栏
				//默认展示什么数据？？

			}elseif($this->sid != 5){
				$map['fsc.special_column_id'] = $this->sid;
			}
		}

        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $did = $this->param['did'];
        $designerStr = $this->param['designerStr'];
        if (empty($did) && $designerStr != '') {
            $did = M('AttributeDesigner')->getField('id', array('name' => $designerStr));
            $did = intval($did);
            $did ? $map['designer_id'] = $did : '';
        } elseif ($did) {
            $map['designer_id'] = $did;
        }

		//款式
        $stid = $this->param['stid'];
        if ($stid) {
            $map['ps.style_id'] = $stid ? $stid : 1;
		}
		// 引入 sphinx  add 2012-08-31
		import ('@.ORG.Search');
		$search = new Search();
		$search->setSortMode(SPH_SORT_EXTENDED,'publish_time desc,picture_id desc');
		// picture_id desc 排序没法做，没有定义字段

		if( $this->cid ) //栏目ID
			$search->setFilter('menu_id',array($this->cid));
		if( $this->cmid ) //子栏目ID
			$search->setFilter('child_menu_id',array($this->cmid));

        $soid = $this->getSoid();
        if ($soid){
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
		}
		if( $soid ) { //性别
			if( $soid == 3 ){
                $map['fs.sort_id'] = array('egt',3);
                $search->setFilter('sort_id',$this->childrenSoids);
            }else{
                $map['fs.sort_id'] = $soid;
				$search->setFilter('sort_id',array($soid));
            }
		}
		if( $stid ) //款式
			$search->setFilter('style_id',array($stid));
		if( $did ) //设计师
			$search->setFilter('designer_id',array($did));

        $search->setFilterRange('publish_time',strtotime('1990-01-01 00:00:00'),C('TODAY_LAST_TIME'));
		$page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Catwalk::pictureDataListBySphinx::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $search->setPageSize( $this->pListRows );
            $search->setPage($page);
            $rows = $search->query();
            $count  = (int)$rows['total_found'];

            if ($count > 0) {
                import("ORG.Util.Page");
                //创建分页对象
                $p = new Page($count, $this->pListRows);
				$ids = array();
				$voList = array();
				$field = 'picture_id,big_picture_url,small_picture_url,publish_time,designer_id,area_no,season_id';

				foreach($rows['matches'] as $v)
					$ids[] = $v['id'];

				$voList = $search->getPicInfoByIds($ids,$field);
				if ($voList) {
					foreach ($voList as $key => $val) {
						$voList[$key]['pic_small'] = show_pic_path($val['small_picture_url']);//show_pic_power($val['small_picture_url'], $this->isRightS);
						$voList[$key]['publish_time'] = $val['publish_time'] ? date('Y-m-d', $val['publish_time']) : '';
						if ($val['season_id'])
							$voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
						if ($val['area_no'])
							$voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
						if ($val['designer_id'])
							$voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];

						$picList[$key]['sTid'] = 0;
						$picList[$key]['sPid'] = $val['picture_id'];
						$picList[$key]['sCid'] = $cid;
						$picList[$key]['sPidNo'] = $val['picture_id'];
						$picList[$key]['sBigSrc'] = show_pic_power($val['big_picture_url'], $this->isRightB);
						$picList[$key]['sSpic'] = $this->isRightS ? str_replace('../', '', $val['small_picture_url']) : '';
						$picList[$key]['sBpic'] = $this->isRightB ? str_replace('../', '', $val['big_picture_url']) : '';
					}

                    $Arr['jsonData'] = json_encode(array('arrPicList' => $picList, 'cid' => $cid, 'isVip' => $this->isRightB));
                    //模板赋值显示
                    $Arr['listArr'] = $voList;
                    //分页显示
                    $Arr['pageStr'] = $p->showOne();
				}
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    /**
     * 文件夹列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function folderDataList($field, $map, $order = array('publish_time'=>'desc','id'=>'desc')) {
        //时间筛选项
        $this->setDateSift();

        $type = intval($_GET["type"]);
        $type = $type ? $type : 10;//细节:1,及时版:2,清晰版:4,主题介绍：5（有别于前面几个数字就行）
        if($type == 1)
            $map['has_type'] = array('exp','&1');//1;
        elseif($type == 4)
            $map['has_type'] = array('exp','&4');//4;
        elseif($type == 5)
            $map['has_desc'] = 1;

        if ($this->cid)
            $map[$this->tableArr['folder_original'] . '.menu_id'] = $this->cid;
        if ($this->cmid)
            $map[$this->tableArr['folder_original'] . '.child_menu_id'] = $this->cmid;

        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join[] = "{$this->tableArr['ref_folder_sort_original']} as fs on fs.folder_id = {$this->tableArr['folder_original']}.id";
        }

        if ($this->sid ) {
            $map['fsc.special_column_id'] = $this->sid;
            $join[] = "{$this->tableArr['ref_folder_column_original']} as fsc on fsc.folder_id = {$this->tableArr['folder_original']}.id";
        }

        $date = $this->param['date'];
        if ($date) {
            if (!in_array($date, array(7, 30, 90))) {
                $date = 90;
                $this->assign('date', $date);
            }
            $dateTmp = strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - $date * 86400;
            $map['publish_time'] = array(array('egt', $dateTmp),array('elt',C('TODAY_LAST_TIME')));

            //以人气排序
            $order = array_merge(array('pv_count'=>'desc'),$order);
            unset($dateTmp);
        }else{
			$map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
		}

        $map['is_publish'] = 1;

        $seid = $this->param['seid'];
        if ($seid)
            $map['season_id'] = $seid;

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('elt', $ano + 65536));
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('elt', $ano + 256));
            } else {
                $map['area_no'] = $ano;
            }

            $this->assign('areaStr',$this->areas[$ano]['name']);
        }

        $did = $this->param['did'];
        $designerStr = trim($_REQUEST['designerStr']);
        if (!$did && $designerStr != '') {
            $did = M('AttributeDesigner')->getField('id', array('name' => $designerStr));
            $did = intval($did);
            if($did){
                $map['designer_id'] = $did;
                $this->assign('did',$did);
            }
        } elseif ($did) {
            $map['designer_id'] = $did;
            $designerStr = M('AttributeDesigner')->getField('name', array('id' => $did));
            $this->assign('designerStr',$designerStr);
        }

        $page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Catwalk::folderDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid."::".$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            import("ORG.Util.DataCount");
			$count = DataCount::getCount($this->tableArr['folder'], $map, $join);
            //$count = $this->modelF->join($join)->where($map)->count();
            if($count > 0){
                import("ORG.Util.Page");
                //创建分页对象
                $p = new Page($count, $this->fListRows);
                //分页查询数据
                $voList = $this->modelF->relation($this->relationArr)->join($join)->where($map)->field($field)->order($order)->limit($p->firstRow . ',' . $p->listRows)->findAll();
                //dump($voList);
                //echo $this->modelT->getlastsql();
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        if ($val['season_id']){
                            $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        }
                        if ($val['area_no']){
                            $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                        }
                        if ($val['designer_id']){
                            $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                        }
                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y/m/d', $val['publish_time']) : '';
                        if ($val['has_type'] & 4){
                            $voList[$key]['url'] = $voList[$key]['type_url_4'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 4));
                        }

                        if ($val['has_type'] & 2){
                            $voList[$key]['type_url_2'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 2));
                            $voList[$key]['url'] = $voList[$key]['url'] ? $voList[$key]['url'] : $voList[$key]['type_url_2'];
                        }

                        if ($val['has_type'] & 1){
                            $voList[$key]['type_url_1'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 1));
                            $voList[$key]['url'] = $voList[$key]['url'] ? $voList[$key]['url'] : $voList[$key]['type_url_1'];
                        }

                        if ($val['has_desc'] == 1){
                            $voList[$key]['type_url_5'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 5));
                        }
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }
        //dump($voList);
        //模板赋值显示
        $this->assign($Arr);
    }

    /**
     * 文件夹列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function folderDataListBySphinx($field, $map) {
		import('@.ORG.Search');
		$search = new Search();
		$search->setSortMode(SPH_SORT_EXTENDED, 'publish_time desc,id desc');
		$pageSize = $this->fListRows;
		$page = intval($_GET['p']) < 1 ? 1 : intval($_GET['p']);
		$search->setPageSize($pageSize);
		$search->setPage($page);

        //时间筛选项
        $this->setDateSift();

        $type = intval($_GET["type"]);
        $type = $type ? $type : 10;//细节:1,及时版:2,清晰版:4,主题介绍：5（有别于前面几个数字就行）
        if($type == 1){
            $map['has_type'] = array('exp','&1');//1;
            $search->setFilter('has_type', array(1,3,5,7));
        }elseif($type == 4){
            $map['has_type'] = array('exp','&4');//4;
            $search->setFilter('has_type', array(4,5,6,7));
        }elseif($type == 5){
            $map['has_desc'] = 1;
            $search->setFilter('has_desc', array(1));
        }

        $this->assign('type',$type);

        if ($this->cid){
            $map[$this->tableArr['folder_original'] . '.menu_id'] = $this->cid;
            $search->setFilter('menu_id', array($this->cid));
        }if ($this->cmid){
            $map[$this->tableArr['folder_original'] . '.child_menu_id'] = $this->cmid;
            $search->setFilter('child_menu_id', array($this->cmid));
        }

        $soid = $this->getSoid();
        if ($soid) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
			if ($soid == 3){
				$search->setFilter('sort_id', $this->childrenSoids);
            }else{
				$search->setFilter('sort_id', array($soid));
            }
        }

        if ($this->sid ) {
            $map['fsc.special_column_id'] = $this->sid;
            $search->setFilter('special_column_id', array($this->sid));
        }

        $date = $this->param['date'];
        if ($date) {
            if (!in_array($date, array(7, 30, 90))) {
                $date = 90;
                $this->assign('date', $date);
            }
            $dateTmp = strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - $date * 86400;
            $map['publish_time'] = array(array('egt', $dateTmp),array('elt',C('TODAY_LAST_TIME')));
            $search->setFilterRange('publish_time', $dateTmp, C('TODAY_LAST_TIME'));

            //以人气排序
            $search->setSortMode(SPH_SORT_EXTENDED, 'pv_count desc,publish_time desc,id desc');
            unset($dateTmp);
        }else{
            $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
            $search->setFilterRange('publish_time',strtotime('2004-01-01'),C('TODAY_LAST_TIME'));
        }


        $seid = $this->param['seid'];
        if ($seid){
            $map['season_id'] = $seid;
            $search->setFilter('season_id', array($seid));
        }

        $ano = $this->param['ano'];
        if ($ano) {
            $anoTmp = dechex($ano);
            if (substr($anoTmp, -4, 4) === '0000') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 65536));
                $search->setFilterRange('area_no', $ano, $ano + 65535);
            } elseif (substr($anoTmp, -2, 2) === '00') {
                $map['area_no'] = array(array('egt', $ano), array('lt', $ano + 256));
                $search->setFilterRange('area_no', $ano, $ano + 255);
            } else {
                $map['area_no'] = $ano;
                $search->setFilter('area_no', array($ano));
            }
            $this->assign('areaStr', $this->areas[$ano]['name']);
        }

        $did = $this->param['did'];
        $designerStr = trim($_REQUEST['designerStr']);
        if (!$did && $designerStr != '') {
            $did = M('AttributeDesigner')->getField('id', array('name' => $designerStr));
            $did = intval($did);
            if($did){
                $map['designer_id'] = $did;
                $search->setFilter('designer_id', array($did));
                $this->assign('did',$did);
            }
        } elseif ($did) {
            $map['designer_id'] = $did;
            $search->setFilter('designer_id', array($did));
            $designerStr = M('AttributeDesigner')->getField('name', array('id' => $did));
            $this->assign('designerStr',$designerStr);
        }

        $page = intval($_REQUEST['p']);
        $page = $page ? $page : 1;
        $cache_key = md5('Catwalk::folderDataList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid."::".$page.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
			$rows = $search->query('','sxxl_catwalk_folder');
			$count = intval($rows['total_found']); //下面做分页之用
            if($count > 0){
                import("ORG.Util.Page");
                //创建分页对象
                $p = new Page($count, $pageSize);
				$ids = array();
				foreach ($rows['matches'] as $k => $v)
					$ids[] = $v['id'];

                $voList = $this->getFolderInfoByIds($ids,$field);
                if ($voList) {
                    foreach ($voList as $key => $val) {
                        if ($val['season_id']){
                            $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['en_name'];
                        }
                        if ($val['area_no']){
                            $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                        }
                        if ($val['designer_id']){
                            $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                        }
                        $voList[$key]['title_pic'] = show_pic_path($val['title_picture_url']);
                        $voList[$key]['publish_time'] = $val['publish_time'] ? date('Y/m/d', $val['publish_time']) : '';
                        if ($val['has_type'] & 4){
                            $voList[$key]['url'] = $voList[$key]['type_url_4'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 4));
                        }

                        if ($val['has_type'] & 2){
                            $voList[$key]['type_url_2'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 2));
                            $voList[$key]['url'] = $voList[$key]['url'] ? $voList[$key]['url'] : $voList[$key]['type_url_2'];
                        }

                        if ($val['has_type'] & 1){
                            $voList[$key]['type_url_1'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 1));
                            $voList[$key]['url'] = $voList[$key]['url'] ? $voList[$key]['url'] : $voList[$key]['type_url_1'];
                        }

                        if ($val['has_desc'] == 1){
                            $voList[$key]['type_url_5'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['id'], 'type' => 5));
                        }
                    }
                    $Arr['listArr'] = $voList;
                    $Arr['pageStr'] = $p->showOne();
                }
            }
            $page > C('DATA_CACHE_P') ? $this->cache->set($cache_key, $Arr,C('CACHE_TIME_LONG')) : $this->cache->set($cache_key, $Arr);
        }
        //dump($voList);
        //模板赋值显示
        $this->assign($Arr);
    }

    /**
     * 子主题列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return array
     */
    protected function folderThemeList($field, $map, $order = array('publish_time'=>'desc','id'=>'desc')) {
        if ($this->cid)
            $map['menu_id'] = $this->cid;
        //if ($this->cmid)
            //$map['child_menu_id'] = $this->cmid;
        $soid = $this->getSoid();
        //如果有文件夹ID，就不断判断子主题的栏目及其他属性了
        if ($soid && empty($map['folder_id'])) {
            $map['fs.sort_id'] = $soid == 3 ? array('egt',3) : $soid;
            $join = "left join {$this->tableArr['ref_subject_sort']} as fs on fs.folder_id = {$this->tableArr['folder_original']}.id";
        }
        //有父文件夹，就不管其他的了。
        if ($this->sid && empty($map['folder_id']))
            $map['special_column_id'] = $this->sid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));

        $cache_key = md5('Catwalk::folderThemeList::'.$this->isRightS.'::'.$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.serialize($map));
        $voList = trim($_REQUEST['cache']) == false ? '' : $this->cache->get($cache_key);
		if (!$voList) {
			$voList = $this->modelT->where($map)->join($join)->field($field)->order($order)->findAll();
			//echo $this->modelT->getLastSql()."</br>";exit;
			if (is_array($voList)) {
				$time = strtotime('-7 day');
				foreach ($voList as $key => $val) {
					$voList[$key]['href'] = U("/" . MODULE_NAME . "/folderDetail", array('cmid' => $this->cmid,'soid'=>$soid,'fid' => $val['folder_id'], 'tid' => $val['id']));
					$voList[$key]['isNew'] = $val['publish_time'] > $time ? 1 : 0;
				}
			}
			$this->cache->set($cache_key, $voList);
		}
        return $voList;
    }

    /**
     * 文件夹标签列表
     * @param type $map
     * @return array
     */
    protected function lableList($map) {
        $field = 'id,lable';
        $voList = M('ShareFolderLable')->where($map)->order(array('order_id' => 'desc'))->field($field)->findAll();
        //echo M('ShareFolderLable')->getLastSql();exit;
        return $voList;
    }

    protected function themeDetail($fid = '',$tid = '') {
        $this->assign('jumpUrl', 'javascript:window.close();');
        $this->relationArr = array('SubjectExtend');
        $tid = intval($tid);

        $goPage = $tid ? MODULE_NAME . '/folder_detail' : MODULE_NAME . '/theme_detail';

        $tid = $tid ? $tid : intval($_GET['tid']);
        $themeInfo = $this->themeInfo($fid,$tid);
        //dump($themeInfo);
        if ($themeInfo['show_edit'] == 1){
            $this->getShowContent($themeInfo);
        }else{
            $this->themePicture($tid);
        }
        $this->updateThemePvCount($tid);

        $this->assign('info', $themeInfo);
        $this->display($goPage);
    }

    protected function setCmid() {
        $this->cmid = intval($_GET['cmid']);
        $this->assign('cmid', $this->cmid);
    }

    protected function setCidSift() {
        $sMap['menu_id'] = ACTION_NAME != 'themeList' && ACTION_NAME != 'themeDetail' ? $this->cid : 28;
        $this->cmid ? $sMap['child_menu_id'] = $this->cmid : '';
        $soid = $this->getSoid();
        if($soid){
            $sMap['sort_id'] = $soid == 3 ? array('egt',3) : $soid;
        }

        $this->sid && $this->sid != 2 && $this->sid != 5 ? $sMap['special_column_id'] = $this->sid : '';

        $fieldArr = array();
        $fieldArr[] = 'season_id_list'; //季度
        $fieldArr[] = 'area_no_list'; //区域
        #$fieldArr[] = 'style_id_list'; //款式
        $fieldArr[] = 'designer_id_list'; //设计师
        $cache_key = md5('FashionStyle::'.'setcidsift::'. $this->sid . serialize($fieldArr) .'::'.serialize($sMap));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr) {
            $siftArr = parent::getAttributeSift(implode(',', $fieldArr), $sMap, false);
            $this->areas = $siftArr['area_no_list'];
            $this->seasons = $siftArr['season_id_list'];
            $Arr['designers'] = $this->designers = $siftArr['designer_id_list'];
            $Arr['styles'] = $this->styles = $siftArr['style_no_list'];

            if ($this->seasons) {
                $seasonsTmp = $this->seasons;
                uasort($seasonsTmp, "cmp");
                $Arr['seasons'] = $seasonsTmp;
                unset($seasonsTmp);
            }
            if ($this->areas) {
                $Arr['areaHtml'] = $this->getAreaOption($this->param['ano']);
                $Arr['areas'] = format_tree_area($this->areas);
            }

            $Arr['letters'] = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
            $this->cache->set($cache_key, $Arr);
        }
        $this->assign($Arr);
        unset($Arr);
    }

    protected function getShowContent($themeInfo) {
        if (!$themeInfo['id'])
            $this->error('参数错误！');

        $field = 'id,small_picture_url,big_picture_url';
        if ($this->cid)
            $map['menu_id'] = $this->cid;
        $map['is_publish'] = 1;
        $map['publish_time'] = array('elt',C('TODAY_LAST_TIME'));
        $map['subject_id'] = $themeInfo['id'];

        $cache_key = md5('Catwalk::getShowContent::'.$this->isRightS."::".$this->isRightB.'::'.$this->soid.'::'.$this->sid.'::'.serialize($map));
        $Arr = trim($_REQUEST['cache']) == 'false' ? '' : $this->cache->get($cache_key);
        if(!$Arr){
            $count = $this->modelP->where($map)->count();;
            if($count > 0){
                $voList = $this->modelP->where($map)->field($field)->order(array('publish_time' => 'desc','id'=>'desc'))->findAll();
                $picList = array();
                $parse_arr = parse_content(stripslashes($themeInfo['content']));
                $detailhtml = $parse_arr['result'];
                if ($parse_arr['pic_arr']) {
                    //$i = 0;
                    foreach ($parse_arr['pic_arr'] as $key => $val) {
                        $picList[$key]['sTid'] = $themeInfo['id'];
                        $picList[$key]['sPid'] = 0;
                        $picList[$key]['sSex'] = $themeInfo['sort_id'];
                        $picList[$key]['sCid'] = $this->cid;
                        $picList[$key]['sPicNo'] = 0;
                        $picList[$key]['sSmallSrc'] = show_pic_path($val['sSpic']);
                        $picList[$key]['sBigSrc'] = show_pic_path($val['sBpic']);
                        $picList[$key]['sSpic'] = $val['sSpic'];
                        $picList[$key]['sBpic'] = $val['sBpic'];
                        if ($voList) {
                            foreach ($voList as $ke => $va) {
                                if (stristr($va['small_picture_url'], $val['sSpic']) != false) {
                                    //echo $va['small_picture_url']."======".$va['id']."========".$val['sSpic']."</br>";
                                    $picList[$key]['sPid'] = $va['id'];
                                    $picList[$key]['sSex'] = $va['sort_id'];
                                    $picList[$key]['sPicNo'] = $va['id'];
                                }
                            }
                        }
                    }
                }
            }
            $Arr['detailhtml'] = $detailhtml;
            $Arr["jsonData"] = json_encode(array('arrPicList' => $picList, 'cid' => $this->cid, 'isVip' => $this->isRightB)); //放大图片
            $Arr['picNum'] = $count;//主题下载处需要用到
            $this->cache->set($cache_key, $Arr);
        }

        $this->assign($Arr);
    }

    /*
     * 根据各栏目需求获性别ID
     */
    protected function getSoid() {
        $soid = $this->param['soid'];
        if ($soid)
            $soid = in_array($soid, array(1, 2, 3, 4, 5, 6)) ? $soid : 2;
        else
            $soid = $this->sid ? 2 : $this->soid;

        $this->assign('soid', $soid);
        return $soid;
    }

    protected function setParam() {
        $this->param = array('cmid' => intval($this->cmid));

        if($this->cid == 12){
            $type = intval($_REQUEST['type']);
            if ($type)
                $this->param = array_merge($this->param, array('type' => $type));
        }

        //时装发布下只有专栏中才允许传入性别参数
        $soid = $this->sid ? intval($_REQUEST['soid']) : $this->soid;
        if ($soid)
            $this->param = array_merge($this->param, array('soid' => $soid));

        $seid = intval($_REQUEST['seid']);
        if ($seid)
            $this->param = array_merge($this->param, array('seid' => $seid));

        $stid = intval($_REQUEST['stid']);
        $stid = $stid ? $stid : ($this->sid == 2 ? 128 : 0);
        if ($stid)
            $this->param = array_merge($this->param, array('stid' => $stid));

        $did = intval($_REQUEST['did']);
        if ($did)
            $this->param = array_merge($this->param, array('did' => $did));

        $ano = intval($_REQUEST['ano']);
        if ($ano)
            $this->param = array_merge($this->param, array('ano' => $ano));

        $date = intval($_REQUEST['date']);
        if ($date)
            $this->param = array_merge($this->param, array('date' => $date));

        $tid = intval($_REQUEST['tid']);
        if ($tid)
            $this->param = array_merge($this->param, array('tid' => $tid));

        $fid = intval($_REQUEST['fid']);
        if ($fid)
            $this->param = array_merge($this->param, array('fid' => $fid));

        $designerStr = trim($_REQUEST['designerStr']);
        if ($designerStr)
            $this->param = array_merge($this->param, array('designerStr' => $designerStr));

        $act = trim($_REQUEST['act']);
        if ($act)
            $this->param = array_merge($this->param, array('act' => $act));
    }

    protected function getFolderInfoByIds($ids,$field){
        if(empty($field)){
            $field = 'id,title,title_picture_url,publish_time,area_no,season_id,pv_count,picture_count';
        }

        $order = array('publish_time'=>'desc','id'=>'desc');
        if($this->param['date']){
            $order = array_merge(array('pv_count'=>'desc'),$order);
        }

		$row = $this->modelF->where( 'id in('.implode(',',$ids).')' )->field($field)->order($order)->select();
        //echo $MODEL->getLastSql()."<br/>";
		return $row;
    }
}

