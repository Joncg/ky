<?php
class CowboyShowStuffAction extends ShowStuffAction {

    public function _initialize() {
       $this->sid = 1;//展会材料需展示全部数据
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

	public function folderList(){
        parent::folderList();
	}

	public function folderDetail() {
        parent::folderDetail();
	}

	public function themeDetail($tid = '') {
        $this->pListRows = 20;
        parent::themeDetail($tid);
	}
}