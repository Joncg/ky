<?php
class MenMagazineAction extends MagazineAction {

    public function _initialize() {
        $this->soid = 1;
        parent::_initialize();
    }

	public function index() {
        parent::index();
	}

	public function themeDetail($tid = '') {
        parent::themeDetail($tid);
	}
	public function downloadzip() {
		parent::downloadzip();
	}
}
