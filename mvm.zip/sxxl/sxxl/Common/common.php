<?php

// +----------------------------------------------------+
// | sxxl common.php |
// +----------------------------------------------------+
// | Copyright (c) 20010-2011 sxxl
// | Email xieweijun@diexun.com
// | Web http://www.sxxl.com
// +----------------------------------------------------+
// | 蝶讯服务网项目　前台公共函数
// +----------------------------------------------------+

/**
 * 用户是否拥有权限
 * return bool
 */
function get_right() {
    $Arr = array();
    if (C('USER_AUTH_ON')) {
        import('@.ORG.Power');
        $Arr['isLogin'] = R('Public', 'isLogin');
        $Arr['isPcRight'] = $Arr['isLogin'] && R('Public', 'checkPc');
        $Arr['RBAC'] = $Arr['isLogin'] ? Power::AccessDecision() : '';
        if ($Arr['isPcRight'] && $Arr['isLogin'] && $Arr['RBAC']) {
            $Arr['isRightB'] = $Arr['isRightS'] = true;
        } elseif (intval($_GET['p']) < 4) {
            $Arr['isRightS'] = true;
            $Arr['isRightB'] = false;
        }
    }
    return $Arr;
}

/**
 * 用户是否拥有权限
 * @param string $src 图片相对路径
 * @param int $isPower 权限标识
 * return string
 */
function show_pic_power($src, $isRight) {
    $path = '';
    if ($src && $isRight) {
        $path = show_pic_path($src);
    } else {
        $path = '/Public/Images/novip.jpg';
    }
    return $path;
}

function rbac() {
    if (C('USER_AUTH_ON')) {
        import('@.ORG.Power');
        if (!Power::AccessDecision()) {
            return false;
        } else {
            return true;
        }
    }
    return false;
}

/**
 * 给编辑器内容加上新的图片放大效果与功能
 * @param string $content
 * @return string
 */
function parse_content($content) {
    $arr = array();
    $content = str_replace('bsrc>', 'bsrc="" />', $content);
    $content = str_replace('分隔符.gif"', '分隔符.gif" bsrc=""', $content);
    $content = str_replace('border=0>', 'border=0 bsrc="">', $content);
    $bsrc_pattern = ' alt=\"\" height=\"[0-9]{1,3}\" width=\"[0-9]{1,3}\"';
    $content = ereg_replace($bsrc_pattern, '', $content);
    /* $pattern = "%<[img|IMG].*?[^b]src=\"([^\"]*?)\".*?bsrc=\"([^\"]*?)\".*?>%s"; */
    //preg_match_all($pattern, $content, $matches);
    //if (empty($matches[0])) {
    /* ------把2010年的目录路径替换------- */
    $a_content = '/\<[a|A] (.*)\>(.*)\<\/[a|A]\>/';
    preg_match_all($a_content, $content, $a_arr);
    for ($i = 0; $i < count($a_arr[0]); $i++) {
        if (stristr($matches[1][$key], '.rar') !== false || stristr($matches[1][$key], '.zip') !== false) {
            $str = str_replace('http://www.sxxl.cn/', '', $down_url[1]); //得到数据库存的路径
        }
        $down_url = explode('"', $a_arr[0][$i]);  //得到路径
        $str = str_replace('http://img0.f.sxxl.com/', '', $down_url[1]); //得到数据库存的路径
        $url = show_pic_path($str);   //找到路径
        $url = str_replace($down_url[1], $url, $a_arr[0][$i]); //替换新的路径
        $content = str_replace($a_arr[0][$i], $url, $content); //替换新的路径
    }
    $pattern = "%<[img|IMG].*?[^b]src=\"([^\"]*?)\".*?>%s";
    preg_match_all($pattern, $content, $matches);
    //}
    //print_r($matches);
    $target = array();
    $pic_arr = array();
    $i = 0;
    if (isset($matches[0])) {
        foreach ($matches[0] as $key => $val) {
            if (stristr($matches[1][$key], '分隔符') == false) {
                $pattern = "/height=(\"|)([0-9]{3})(\"|)|width=(\"|)([0-9]{3})(\"|)/s";
                preg_match_all($pattern, $val, $size);
                //dump($size);
                $target[$key]["height"] = $size[2][0] ? $size[2][0] : $size[2][1]; //$size[1][0] ? $size[1][0] : $size[1][1];
                $target[$key]["width"] = $size[5][0] ? $size[5][0] : $size[5][1]; //$size[2][0] ? $size[2][0] : $size[2][1];
                /* $val = str_replace('<IMG style="BORDER-BOTTOM-COLOR: #000000; FILTER: ; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000; BORDER-LEFT-COLOR: #000000" border=0 alt="" src="http://www.sxxl.cn/Files/images/download_rar.jpg">', '', $val);
                  $pic_pattern = "%<[img|IMG].*?>%s";
                  preg_match_all($pic_pattern, $val, $pic_new_arr);
                  if(!empty($pic_new_arr[0][0])){
                  $target[$key]["html"] = $pic_new_arr[0][0];
                  }else{
                  $target[$key]["html"] = $val;
                  } */
                $target[$key]["html"] = $val;
                if (stristr($matches[1][$key], 'download_rar.jpg') === false) {  //防止有下载包的图标影响放大浏览
                    //新添加数组
                    $new_big_pic_arr = explode('bsrc="', $matches[0][$key]); //获取大图片
                    $new_big_pic_arr = str_replace('">', '', $new_big_pic_arr[1]);
                    $new_big_pic_arr = str_replace('" />', '', $new_big_pic_arr);
                    $pic_arr[$i]['sBigSrc'] = $matches[1][$key] ? show_pic_path(replace_path($new_big_pic_arr)) : '';
                    $pic_arr[$i]['sSpic'] = $matches[1][$key] ? replace_path($matches[1][$key]) : '';
                    $pic_arr[$i]['sBpic'] = replace_path($new_big_pic_arr);
                    $i++;
                }
                //target[$key]["html"] = $new_pic_arr[1] != '' ? $new_pic_arr[1] : $new_pic_arr[0];
                $target[$key]["src"] = $matches[1][$key] ? show_pic_path(replace_path($matches[1][$key])) : '';
                $target[$key]["bsrc"] = $matches[1][$key] ? show_pic_path(replace_path($matches[1][$key])) : '';
            }
        }
    }
    //echo "<pre>";
    //print_r($pic_arr);//exit;
    unset($i);
    $arr['pic_arr'] = $pic_arr;
    $result = $content;
    $i = 0;
    if ($target) {
        foreach ($target as $key => $val) {
            if ($val["html"]) {
                $width = $val["width"] ? " width=\"{$val["width"]}\"" : '';
                $height = $val["height"] ? " height=\"{$val["height"]}\"" : '';
                //$onclick = $val["bsrc"] ? " onclick=\"onclickpic('{$val["bsrc"]}','','{$val["src"]}')\" style=\"cursor: pointer;\"" : '';
                if (stristr($val["src"], 'download_rar.jpg') === false) {  //防止有下载包的图标影响放大浏览
                    $onclick = $val["bsrc"] ? " onclick=\"viewPic.setPic(" . $i . ")\" style=\"cursor: pointer;\"" : '';
                    $i++;
                }
                $replace = $val["src"] ? "img src=\"{$val["src"]}\" {$width} {$height} alt='' {$onclick} /" : 'i></i';
                $result = preg_replace($val["html"], $replace, $result);
            }
        }
    }
    //print_r($result);
    $result = str_replace('http://www.sxxl.com', 'http://img1.f.sxxl.com', $result);
    $result = str_replace('hz.sxxl.com', 'img1.f.sxxl.com', $result);
    //$result = preg_replace("/<a[^>]*>/i", "", $result);
    //$result = preg_replace("/<\/a>/i", "", $result);
    //dump($result);
    $result = preg_replace('/<A.+ewebeditor.+target=_blank>(.*)<\/A>/', '$1', $result);
    //dump($result);
    unset($matches, $target, $content, $replace);
    $arr['result'] = $result;
    return $arr;
}

/**
 * 替换路径
 * @param string $path
 * @return string
 */
function replace_path($path) {
    $path = str_replace('http://www.sxxl.com/App/sxxlAdmin/eWeb/', '', $path);
    $path = str_replace('http://www.sxxl.com/', '', $path);
    $path = str_replace('http://www.sxxl.cn/App/sxxlAdmin/eWeb/', '', $path);
    $path = str_replace('http://www.sxxl.cn/', '', $path);
    $path = str_replace('http://images.sxxl.dx/', '', $path);
    $path = str_replace('../', '', $path);
    return $path;
}

/*
 * 跨域链接到crm转字符串
 *
 */

function getDateCrm($info, $url, $key="C('CRM_KEY'))") {
    $info = serialize($info);
    $info = authcode($info, $operation = 'ENCODE', C('CRM_KEY'));
    $info = urlencode($info);
    $file = fopen(C('CRM_HTTP') . $url . $info, 'rb');
//	return C('CRM_HTTP').$url.$info;
    $data = unserialize(fgets($file));
    fclose($file);
    return $data;
}

function get_json_data($url, $param, $key) {
    $param = serialize($param);
    $param = authcode($param, 'ENCODE', $key);
    $param = urlencode($param);
    $file = fopen($url . $param, 'rb');
    //echo $url.$param;
    $data = unserialize(fgets($file));
    fclose($file);
    return $data;
}

function get_job_name($JobType) {
    if ($JobType == '1101')
        $_JobType = "服装设计师";
    if ($JobType == '1102')
        $_JobType = "首席设计师";
    if ($JobType == '1103')
        $_JobType = "设计师";
    if ($JobType == '1104')
        $_JobType = "服装设计助理";
    if ($JobType == '1105')
        $_JobType = "女装设计师";
    if ($JobType == '1106')
        $_JobType = "男装设计师";
    if ($JobType == '1107')
        $_JobType = "童装设计师";
    if ($JobType == '1108')
        $_JobType = "内衣设计师";
    if ($JobType == '1109')
        $_JobType = "平面设计师";
    if ($JobType == '1110')
        $_JobType = "面料设计师";
    if ($JobType == '1111')
        $_JobType = "服装陈列师";
    if ($JobType == '1112')
        $_JobType = "服装设计总监";
    if ($JobType == '1113')
        $_JobType = "其它";

    if ($JobType == '1201')
        $_JobType = "服装生产/管理类";
    if ($JobType == '1202')
        $_JobType = "高级管理";
    if ($JobType == '1203')
        $_JobType = "生产厂长（主管）";
    if ($JobType == '1204')
        $_JobType = "厂长助理";
    if ($JobType == '1205')
        $_JobType = "板房/样板";
    if ($JobType == '1206')
        $_JobType = "品质管理";
    if ($JobType == '1207')
        $_JobType = "采购/物料控制/物流";
    if ($JobType == '1208')
        $_JobType = "车间主管";
    if ($JobType == '1209')
        $_JobType = "裁床主管";
    if ($JobType == '1210')
        $_JobType = "尾部主管";
    if ($JobType == '1211')
        $_JobType = "制版师";
    if ($JobType == '1212')
        $_JobType = "纸样师";
    if ($JobType == '1213')
        $_JobType = "样衣工";
    if ($JobType == '1214')
        $_JobType = "指导工";
    if ($JobType == '1215')
        $_JobType = "工艺员";
    if ($JobType == '1216')
        $_JobType = "染整技术人员";
    if ($JobType == '1217')
        $_JobType = "针织裁缝技术人员";
    if ($JobType == '1218')
        $_JobType = "车位工（机工）/辅工 印染技工";
    if ($JobType == '1219')
        $_JobType = "仓库/储备/理货员";
    if ($JobType == '1220')
        $_JobType = "跟单员";
    if ($JobType == '1221')
        $_JobType = "物控主管";

    if ($JobType == '1301')
        $_JobType = "服装销售/贸易类";
    if ($JobType == '1302')
        $_JobType = "市场总监";
    if ($JobType == '1303')
        $_JobType = "销售经理";
    if ($JobType == '1304')
        $_JobType = "市场专员";
    if ($JobType == '1305')
        $_JobType = "市场督导";
    if ($JobType == '1306')
        $_JobType = "销售业务员";
    if ($JobType == '1307')
        $_JobType = "销售助理";
    if ($JobType == '1308')
        $_JobType = "区域经理";
    if ($JobType == '1309')
        $_JobType = "贸易/进出口";
    if ($JobType == '1310')
        $_JobType = "加盟/项目招商";
    if ($JobType == '1311')
        $_JobType = "导购专员";
    if ($JobType == '1312')
        $_JobType = "时装秀";
    if ($JobType == '1313')
        $_JobType = "专卖店店长";
    if ($JobType == '1314')
        $_JobType = "接单员";
    if ($JobType == '1315')
        $_JobType = "其它";

    if ($JobType == '1401')
        $_JobType = "行政管理类";
    if ($JobType == '1402')
        $_JobType = "行政/人力资源/培训";
    if ($JobType == '1403')
        $_JobType = "接待/礼仪/客服";
    if ($JobType == '1404')
        $_JobType = "财务/审(统)计";
    if ($JobType == '1405')
        $_JobType = "计算机(IT)类";
    if ($JobType == '1406')
        $_JobType = "保卫/后勤";
    if ($JobType == '1407')
        $_JobType = "司机/物流(运输/物流)";
    if ($JobType == '1408')
        $_JobType = "实习生";
    if ($JobType == '1409')
        $_JobType = "行政经理";
    if ($JobType == '1410')
        $_JobType = "其它";
    return $_JobType;
}

/**
 * 判断缓存是否有效
 * @param type $filename
 * @return type
 */
function is_cache_time_valid($filename) {
    $filepath = C('CACHE_PATH_FILE') . "indexdata/{$filename}.php";
    if (file_exists($filepath) && ( filemtime($filepath) + C('CACHE_TIME_SHORT') > time() )) {
        return TRUE;
    } else {
        return FALSE;
    }
}

/**
 * 适用于季度按顺序排序
 */
function cmp($a, $b) {
    return $a['order_id'] < $b['order_id'];
}

/**
 * 适用于弹出层的品牌，设计师，书籍
 */
function cmp_for_bbd($a, $b) {
    return strcasecmp($a['name'], $b['name']);
}

function sub_str($str, $length = 0, $append = true,$charset = 'utf-8') {
    $str = trim($str);
    $strlength = strlen($str);
    if ($length == 0 || $length >= $strlength) {//截取长度等于0或大于等于本字符串的长度，返回字符串本身
        return $str;
    } elseif ($length < 0) {//如果截取长度为负数
        $length = $strlength + $length; //那么截取长度就等于字符串长度减去截取长度
        if ($length < 0) {
            $length = $strlength; //如果截取长度的绝对值大于字符串本身长度，则截取长度取字符串本身的长度1
        }
    }

    if (function_exists('mb_substr')) {
        $newstr = mb_substr($str, 0, $length, $charset);
    } elseif (function_exists('iconv_substr')) {
        $newstr = iconv_substr($str, 0, $length, $charset);
    } else {
        $newstr = trim_right(substr($str, 0, $length));
        $newstr = substr($str, 0, $length);
    }

    if ($append && $str != $newstr) {
        $newstr .= '...';
    }

    return $newstr;
}

/**
 * 返回分级区域数组
 * @param type $areas
 * @return array
 */
function format_tree_area($areas){
    $areas_tmp = array();
    if($areas){
        foreach($areas as $key=>$val){
            if($val['parent_no'] == 0){
                $areas_tmp[$key] = $val;
                foreach($areas as $ke=>$va){
                    if($va['parent_no'] == $val['no']){
                        $areas_tmp[$key]['sub_areas'][$ke] = $va;
                        foreach($areas as $k=>$v){
                            if($v['parent_no'] == $va['no']){
                                $areas_tmp[$key]['sub_areas'][$ke]['sub_areas'][$k] = $v;
                            }
                        }
                    }
                }
            }
        }
    }
    return $areas_tmp;
}