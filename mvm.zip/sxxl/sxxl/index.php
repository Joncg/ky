<?php 
 //
 // +----------------------------------------------------+
 // | sxxl index.php |
 // +----------------------------------------------------+
 // | Copyright (c) 20010-2011 weizp |
 // | Email weizp@diexun.com |
 // | Web http://www.sxxl.com |
 // +----------------------------------------------------+
 // | ��Ѷ��������Ŀ������ļ� |
 // +----------------------------------------------------+
 //

  define('THINK_PATH','../ThinkPHP');
  define('NO_CACHE_RUNTIME',True);
  define('STRIP_RUNTIME_SPACE',false);
  define('APP_NAME','sxxl');
  define('APP_PATH','.');

  require(THINK_PATH."/ThinkPHP.php");
  App::run();
  
?>