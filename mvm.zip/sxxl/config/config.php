<?php
$config = array(
	'URL_MODEL' => 2, // 如果你的环境不支持PATHINFO 请设置为3
	'DB_TYPE' => 'mysql',
	'DB_HOST' => '192.168.2.8',
	'DB_PORT' => '3306',
	'DB_USER' => 'qjl_sxxl',
	'DB_PWD' => '<qjl_sxxl_3298210>',
	//'DB_USER' => 'diexun',
	//'DB_PWD' => 'newsxxl88',
	'DB_NAME' => 'sxxl',
	'DB_PREFIX' => 'sxxl_',
	//'DB_DEPLOY_TYPE'=>1,
	//'DB_RW_SEPARATE'=>true,
	'APP_DEBUG'=> true,
	'TMPL_CACHE_ON'=>false,
	'URL_ROUTE_ON'=>true,
	'URL_HTML_SUFFIX'=>'.shtml',
	'TAGLIB_BEGIN'=>'{{',
	'TAGLIB_END'=>'}}',
	'TMPL_L_DELIM'=>'{{',
	'TMPL_R_DELIM'=>'}}',
	'DATA_CACHE_PATH' => '../config/cache/system/', //系统缓存
    'CACHE_PATH_FILE' => '../config/cache/',   //各栏目首页缓存
    'CACHE_TIME_LONG' => 20,                     //缓存长时间 （用于分页）
    'CACHE_TIME_SHORT' => 10,                    //缓存段时间 （用于各栏目首页）
    'DATA_CACHE_TYPE'=>'Memcache', // 数据缓存方式 内存
	//'MEMCACHE_HOST'   => '192.168.1.22',
	//'MEMCACHE_PORT'   => 11211,
	'MEMCACHE_HOST'   => '192.168.2.13',
	'MEMCACHE_PORT'   => 12000,
    'DATA_CACHE_TIME'=>  10,   // 数据缓存有效期 720000 秒     （用于分页）
    'DATA_CACHE_P'=>  3,      //长短缓存时间选择标准
	//'DATA_CACHE_PERSISTENT' =>false,
    'DB_FIELDS_CACHE' =>true,
    'COOKIE_EXPIRE' => 0, // COOKIE时间
);
//$this->cache = Cache::getInstance();
//$cKey = md5(MODULE_NAME.ACTION_NAME.$this->cid.$soid.$ano.$this->isRightB);
////$this->cache->set($cKey, "1111111",20);
////$this->cache->set($cKey, "1111111");
//if ($this->cache->get($cKey)) {
//    echo $this->cache->get($cKey);
//} else {
//    echo "错误";
//}
//exit();


?>