<?php
 //
 // +----------------------------------------------------+
 // | phpDocumentor |
 // +----------------------------------------------------+
 // | Copyright (c) 2011-2011 weizp |
 // | Email weizp@diexun.com |
 // | Web http://www.sxxl.com |
 // +----------------------------------------------------+
 // | This source file is subject to PHP License |
 // +----------------------------------------------------+
 //

// 定义ThinkPHP框架路径
define('THINK_PATH', '../ThinkPHP');
define('NO_CACHE_RUNTIME',True);
define('STRIP_RUNTIME_SPACE',false);

define('App_NAME', 'admin');
define('APP_PATH','.');
// 加载框架入口文件
require(THINK_PATH."/ThinkPHP.php");
//实例化一个网站应用实例
App::run();
?>