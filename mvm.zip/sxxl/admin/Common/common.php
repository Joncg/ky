<?php
//公共函数
function toDate($time, $format = 'Y-m-d H:i:s') {
	if (empty ( $time )) {
		return '';
	}
	$format = str_replace ( '#', ':', $format );
	return date ($format, $time );
}

function getStatus($status, $imageShow = true) {
	switch ($status) {
		case 0 :
			$showText = '禁用';
			$showImg = '<img src="' . WEB_PUBLIC_PATH . '/Images/locked.gif" width="20" height="20" border="0" alt="禁用">';
			break;
		case 2 :
			$showText = '待审';
			$showImg = '<img src="' . WEB_PUBLIC_PATH . '/Images/prected.gif" width="20" height="20" border="0" alt="待审">';
			break;
		case - 1 :
			$showText = '删除';
			$showImg = '<img src="' . WEB_PUBLIC_PATH . '/Images/del.gif" width="20" height="20" border="0" alt="删除">';
			break;
		case 1 :
		default :
			$showText = '正常';
			$showImg = '<img src="' . WEB_PUBLIC_PATH . '/Images/ok.gif" width="20" height="20" border="0" alt="正常">';

	}
	return ($imageShow === true) ?  $showImg  : $showText;

}

function getAdminColor($name) {
	if ($name == '管理员') {
		$r = "<span>{$name}</span>";
	}
	else {
		$r = "<span style='color:red;'>{$name}</span>";
	}
	return $r;
}

function IP($ip = '', $file = 'UTFWry.dat') {
	$_ip = array ();
	if (isset ( $_ip [$ip] )) {
		return $_ip [$ip];
	} else {
		import ( "ORG.Net.IpLocation" );
		$iplocation = new IpLocation ( $file );
		$location = $iplocation->getlocation ( $ip );
		$_ip [$ip] = $location ['country'] . $location ['area'];
	}
	return $_ip [$ip];
}

/**
 * 创建目录树
 * @param string $folder 目录
 * @param int $mode 创建模式
 * @return bool
 */
function makeDir($folder, $mode = 0777) {
	if (is_dir($folder) || @mkdir($folder, $mode)) return true;
	if (!makeDir(dirname($folder), $mode)) return false;
	return @mkdir($folder, $mode);
}

/**
 * 获取上传文件的路径
 * @return string
 */
function getFilePath() {
	$path = C('IMG_TOP') . '/' . date('md') . '/' . date('dH') . '/';
	return $path;
}

/**
 * 获取上传文件名
 * @return string
 */
function getFileName() {
	list($usec) = explode(' ', microtime());
	$usec = substr($usec, 2, 5);
	$file_name = md5(time()) . $usec;
	return $file_name;
}

function _upload() {
	$allowExts = array('jpg', 'jpeg', 'zip');
	$savePath = getFilePath();
	$savePathTmp = C('IMG_ROOT') . $savePath;
	//dump($savePath);exit ();
	//makeDir($savePathTmp);
	import("ORG.Net.UploadFile");
	$upload = new UploadFile();
	$upload->allowExts = $allowExts;
	$upload->savePath = str_replace('//', '/', $savePathTmp);
	$upload->saveRule = getFileName;
	if ($upload->upload()) {
		$info = $upload->getUploadFileInfo();
		return $info;
	}
}

function getTree($arr,$id){
    if(empty ($arr) or empty ($id))
        return ;
    $ids = '';
    foreach ($arr as $key => $val){
        if($val['parent_id'] == $id){
            $ids .= $val['id'].',';
            $ids .= getTree($arr,$val['id']);
        }
    }
    return $ids;
}

function get_type($status) {
	switch ($status) {
		case 1 :
			$showText = '上装';
			break;
		case 2 :
			$showText = '下装';
			break;
		case 3 :
			$showText = '内衣';
			break;
		case 0 :
		default :
			$showText = '其他';
	}
	return $showText;
}
/**
 * 得到两个数组的乘积
 * @param type $array1
 * @param type $array2
 * @return type
 */
function get_muster( $array1, $array2 ) {
    if ( isset($array1) && !empty ($array1) ) {
        $muster_str = "";
        foreach ($array1 as $key => $val) {
            if ( isset($array2) && !empty ($array2) ) {
                foreach ($array2 as $k => $v) {
                    $muster_str .= $val.'+'.$v.",";
                }
            } else {
                $muster_str .= $val."+00,";
            }
        }
        return substr($muster_str,0,-1);
    } else {
        return ;
    }
}

/**
 * 从栏目str中得到栏目arr
 * @param type $menu_str
 * @return type
 */
function get_decomposition($menu_str){
    if( isset($menu_str) && !empty($menu_str) ){
        $menu_arr = array();
        if ( strpos($menu_str,',') ) {
            $menu_array = explode(',', $menu_str);
            foreach ($menu_array as $key => $val) {
                $menu_arr[$key] = substr($val, 1);
            }
        } else {
            $menu_arr[0] = substr($menu_str, 1);
        }
        return array_unique($menu_arr);
    } else {
        return ;
    }
}

/**
 * 得到相对应的cid的fashions
 * @param type $array
 * @param type $cid
 * @return type
 */
function get_cid_fashions ($array, $cid){
    if (empty ($array) || empty ($cid)){
        return ;
    }
    $cid_arr = array();
    if (isset ($array) && !empty ($array)){
        foreach ($array as $key => $val) {
            if (strpos($val['sort_menu'], '+'.$cid) ){
                $cid_arr[$key] = $val;
            }
        }
    }
    return $cid_arr;
}