<?php
class AttributeFashionModel extends AttributeModel{
	protected $_validate = array(
		array('chs','require','风格名称必须填写。',0,'',3),
		array('order_id','require','序号必须填写。',0,'',3),
	);

	protected $_auto = array(
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);

	protected $_map = array(
		'chs'=>'name',
		'order'=>'order_id',
		'pid'=>'parent_id',
	);
    
    protected $_link = array(
		'style' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleFashion',
			'foreign_key' => 'fashion_id',
			'mapping_name' => 'style',
			'mapping_fields' => 'style_id,sort_id',
		),
	);
}
?>
