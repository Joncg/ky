<?php
// 用户模型
class SysUserModel extends CommonModel {
	public $_validate	=	array(
		array('account','/^[a-z]\w{3,}$/i','帐号格式错误'),
		array('password','require','密码必须'),
		array('real_name','require','昵称必须'),
		array('repassword','require','确认密码必须'),
		array('repassword','password','确认密码不一致',self::EXISTS_VAILIDATE,'confirm'),
		array('account','','帐号已经存在',self::EXISTS_VAILIDATE,'unique',self::MODEL_INSERT),
	);

	public $_auto = array(
		array('password','pwdHash',self::MODEL_BOTH,'callback'),
	);

	protected $_link = array(
		'roles' => array(
			'mapping_type' => MANY_TO_MANY,
			'class_name' => 'SysRole',
			'foreign_key' => 'user_id',
			'relation_foreign_key'=>'role_id',
			'relation_table' => 'sxxl_sys_role_user',
		),
	);

	protected function pwdHash() {
		if(isset($_POST['password'])) {
			return pwdHash($_POST['password']);
		}else{
			return false;
		}
	}
}
?>