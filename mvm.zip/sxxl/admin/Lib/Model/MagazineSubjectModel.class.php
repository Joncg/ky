<?php
// 主题模型
class MagazineSubjectModel extends CommonModel {
	protected $_validate = array(
		array('title','require','标题必须',1),
		array('menu_id','require','栏目必须',1),
		array('season_id','require','季度必须'),
		array('designer_id','require','设计师必须'),
		array('brand_id','require','品牌必须'),
		array('book_id','require','书名必须'),
		array('area_id','require','地区必须'),
	);

	protected $_auto = array(			 
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);

	protected $_link = array(
		'extend' => array(
			'mapping_type' => HAS_ONE,
			'class_name' => 'MagazineSubjectExtend',
			'foreign_key' => 'subject_id',
			'as_fields' => 'content,lable,pv_count',
		),
		'acc' => array(
			'mapping_type' => HAS_ONE ,
			'class_name' => 'RefMagazineSubjectAcc',
			'foreign_key' => 'subject_id',
			'mapping_name' => 'acc',
			'mapping_fields' => 'acc_id',
			'as_fields' => 'acc_id',
		),
        'sort_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefMagazineSubjectSort',
			'foreign_key' => 'subject_id',
			'mapping_name' => 'sort_id',
			'mapping_fields' => 'sort_id',
		),
        'special_column_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefMagazineSubjectSpecialColumn',
			'foreign_key' => 'subject_id',
			'mapping_name' => 'special_column_id',
			'mapping_fields' => 'special_column_id',
		),
        'fashion_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefMagazineSubjectFashion',
			'foreign_key' => 'subject_id',
			'mapping_name' => 'fashion_id',
			'mapping_fields' => 'fashion_id',
		),
		'SysUser' => array(
			'mapping_type'=>BELONGS_TO,
			'class_name'=>'SysUser',
			'foreign_key'=>'add_user_id',
			'mapping_fields'=>'real_name',
			'as_fields'=>'real_name:add_user_name'
		),
        'zipfile_url' => array(
			'mapping_type' => HAS_ONE ,
			'class_name' => 'MagazineSubjectExtend',
			'foreign_key' => 'subject_id',
			'mapping_name' => 'zipfile_url',
			'mapping_fields' => 'zipfile_url',
		),
		'Menu' => array(
			'mapping_type'=>BELONGS_TO,
			'class_name'=>'Menu',
			'foreign_key'=>'menu_id',
			'mapping_fields'=>'name',
			'as_fields'=>'name:menu_name'
		),
	);
}
