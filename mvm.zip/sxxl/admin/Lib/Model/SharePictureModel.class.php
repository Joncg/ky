<?php
// 图片模型
class SharePictureModel extends CommonModel {
	protected $_validate = array(
		array('title','require','标题必须',1),
		array('menu_id','require','栏目必须',1),
		array('season_id','require','季度必须'),
		array('designer_id','require','设计师必须'),
		array('brand_id','require','品牌必须'),
		array('book_id','require','书名必须'),
		array('area_id','require','地区必须'),
	);

	protected $_auto = array(
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);

	protected $_link = array(
		'description' => array(
			'mapping_type' => HAS_ONE,
			'class_name' => 'RefPictureExtend',
			'foreign_key' => 'picture_id',
			'as_fields' => 'description',
		),
		'extend' => array(
			'mapping_type' => HAS_ONE,
			'class_name' => 'SharePictureExtend',
			'foreign_key' => 'picture_id',
			'as_fields' => 'lable,zip_jrp,zip_ai,zip_cdr,zip_psd',
		),
		'acc' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureAcc',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'acc',
			'mapping_fields' => 'acc_id',
		),
		'color' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureColor',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'color',
			'mapping_fields' => 'color_id',
		),
		'fashion' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureFashion',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'fashion',
			'mapping_fields' => 'fashion_id',
		),
		'material' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureMaterial',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'material',
			'mapping_fields' => 'material_id',
		),
		'pattern' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePicturePattern',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'pattern',
			'mapping_fields' => 'pattern_no',
		),
		'style' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureStyle',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'style',
			'mapping_fields' => 'style_id',
		),
        'sort_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureSort',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'sort_id',
			'mapping_fields' => 'sort_id',
		),
		'special_column_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureSpecialColumn',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'special_column_id',
			'mapping_fields' => 'special_column_id',
		),
		'keyword' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefSharePictureKeyword',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'keyword',
			'mapping_fields' => 'keyword_id',
		),
        'child_menu_ids' => array(
			'mapping_type'=>HAS_MANY,
			'class_name'=>'RefPictureMenu',
			'foreign_key'=>'picture_id',
			'mapping_name' => 'child_menu_ids',
			'mapping_fields' => 'child_menu_id',
		),
		'SysUser' => array(
			'mapping_type'=>BELONGS_TO,
			'class_name'=>'SysUser',
			'foreign_key'=>'add_user_id',
			'mapping_fields'=>'real_name',
			'as_fields'=>'real_name:add_user_name'
		),
	);
}
