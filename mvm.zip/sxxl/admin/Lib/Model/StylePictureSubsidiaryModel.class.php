<?php
// 图片模型
class StylePictureSubsidiaryModel extends CommonModel {
	protected $_validate = array(
		array('title','require','标题必须',1),
		array('menu_id','require','栏目必须',1),
		array('season_id','require','季度必须'),
		array('designer_id','require','设计师必须'),
		array('brand_id','require','品牌必须'),
		array('book_id','require','书名必须'),
		array('area_id','require','地区必须'),
	);

	protected $_auto = array(
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);

	protected $_link = array(
		'detail_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleSubsidiaryDetail',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'detail_id',
			'mapping_fields' => 'detail_id',
		),
		'color' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleSubsidiaryColor',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'color',
			'mapping_fields' => 'color_id',
		),
		'fashion' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleSubsidiaryFashion',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'fashion',
			'mapping_fields' => 'fashion_id',
		),
		'sort_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleSubsidiarySort',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'sort_id',
			'mapping_fields' => 'sort_id',
		),
		'style' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleSubsidiaryStyle',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'style',
			'mapping_fields' => 'style_id',
		),
        'special_column_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleSubsidiarySpecialColumn',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'special_column_id',
			'mapping_fields' => 'special_column_id',
		),
		'keyword' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleSubsidiaryKeyword',
			'foreign_key' => 'picture_id',
			'mapping_name' => 'keyword',
			'mapping_fields' => 'keyword_id',
		),
		'SysUser' => array(
			'mapping_type'=>BELONGS_TO,
			'class_name'=>'SysUser',
			'foreign_key'=>'add_user_id',
			'mapping_fields'=>'real_name',
			'as_fields'=>'real_name:add_user_name'
		),
	);
}
