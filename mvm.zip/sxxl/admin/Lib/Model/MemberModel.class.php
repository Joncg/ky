<?php
// 会员模型
class MemberModel extends CommonModel {
	public $_validate	=	array(
		array('name','/^[a-z]\w{3,}$/i','帐号格式错误'),
		array('password','require','密码必须填写'),
		array('real_name','require','昵称必须填写'),
		array('repassword','require','确认密码必须填写'),
		array('repassword','password','确认密码不一致',self::EXISTS_VAILIDATE,'confirm'),
		array('name','','帐号已经存在',self::EXISTS_VAILIDATE,'unique',self::MODEL_INSERT),
	);

	public $_auto = array(
		array('password','pwdHash',self::MODEL_BOTH,'callback'),
	);

	protected $_link = array(
		'roles' => array(
			'mapping_type' => MANY_TO_MANY,
			'class_name' => 'Role',
			'foreign_key' => 'member_id',
			'relation_foreign_key'=>'role_id',
			'relation_table' => 'sxxl_ref_member_role',
		),
	);

	protected function pwdHash() {
		if(isset($_POST['password'])) {
			return pwdHash($_POST['password']);
		}else{
			return false;
		}
	}
}
?>