<?php
class CommonModel extends RelationModel {

	// 获取当前用户的ID
	public function getUserId() {
        $user_auth = Cookie::get(C('USER_AUTH_KEY'));
		return isset($user_auth) ? $user_auth : 0;
	}
}
?>