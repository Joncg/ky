<?php

class SearchActKeywrodModel extends AttributeModel {

//	protected $_auto = array(			 
//		array('add_user_id','getUser',3,'callback'),
//		//array('add_time','time',3,'function'),
//	);

}

?>
