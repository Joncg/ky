<?php
class AttributePatternTypeModel extends AttributeModel{
	protected $_validate = array(
		array('chs','require','图案名称必须填写。',0,'',3),
		array('order_id','require','序号必须填写。',0,'',3),
        array('pno','require','系统发生错误！',0,'',3),
        array('no','require','编号必须填写。',0,'',3),
	);

	protected $_auto = array(
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
        array('parent_id', 'getPno', 3, 'callback'),
	);

	protected $_map = array(
		'chs'=>'name',
		'order'=>'order_id',
		'pno' => 'parent_id',
	);

    protected function getPno(){
        $no = $_POST['no'];
        if(empty($no)) return false;
        if(substr($no,2,4) == 0){
           $pno = 0x000000;
        }
        elseif(substr($no,4,2) == 0){
           $pno = hexdec(substr($no,0,2)."0000");
        }else{
           $pno = hexdec(substr($no,0,4)."00");
        }           
        return $pno;
    }    
}
?>
