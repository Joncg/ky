<?php
class AttributeModel extends RelationModel{
	protected $_link = array(
			'SysUser' => array(
			'mapping_type'=>BELONGS_TO,
			'class_name'=>'SysUser',
			'foreign_key'=>'add_user_id',
			'mapping_fields'=>'real_name',
			'as_fields'=>'real_name:add_user_name'
		)
	);

	protected function getUser(){
		return Cookie::get(C('USER_AUTH_KEY'));
	}		
}
?>
