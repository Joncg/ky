<?php
class MenuModel extends AttributeModel{
	protected $_validate = array(
		array('chs','require','栏目名称必须填写。',0,'',3),
		array('chs_en','require','栏目名称必须填写。',0,'',3),
		array('order_id','require','序号必须填写。',0,'',3),	   
	);

	protected $_auto = array(			 
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);

	protected $_map = array(
		'chs'=>'name',
		'chs_en'=>'name_en',
		'order'=>'order_id',
		'pid'=>'parent_id',
		'attrs_subject'=>'attr_selected_subject',
		'attrs_picture'=>'attr_selected_picture'
	);		
}
?>
