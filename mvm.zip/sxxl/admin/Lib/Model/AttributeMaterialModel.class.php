<?php
class AttributeMaterialModel extends AttributeModel{
	protected $_validate = array(
		array('chs','require','面/辅料名称必须填写。',0,'',3),  
	);

	protected $_auto = array(			 
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);

	protected $_map = array(
		'chs'=>'name',
		'pid'=>'parent_id',
	);		
    protected $_link = array(
		'sort_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleMaterial',
			'foreign_key' => 'material_id',
			'mapping_name' => 'sort_id',
			'mapping_fields' => 'style_id,sort_id',
		),
	);
}
?>
