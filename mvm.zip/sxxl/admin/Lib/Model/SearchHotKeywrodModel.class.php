<?php

class SearchAssKeywrodModel extends AttributeModel {



}

?>
