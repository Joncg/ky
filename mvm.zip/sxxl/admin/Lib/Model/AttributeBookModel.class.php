<?php

class AttributeBookModel extends AttributeModel {

	protected $_validate = array(
		array('chs', 'require', '书名必须填写。', 0, '', 3),
		array('name','','书名已经存在',self::EXISTS_VAILIDATE,'unique',self::MODEL_INSERT),
	);
	protected $_map = array(
		'chs' => 'name',
	);
	protected $_auto = array(
		array('add_user_id', 'getUser', 3, 'callback'),
		array('add_time', 'time', 3, 'function'),
	);

}

?>
