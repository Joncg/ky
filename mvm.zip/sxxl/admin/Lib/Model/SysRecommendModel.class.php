<?php
class SysRecommendModel extends RelationModel{
	protected $_link = array(
			'Menu' => array(
				'mapping_type'=>BELONGS_TO,
				'class_name'=>'Menu',
				'foreign_key'=>'menu_id',
				'mapping_fields'=>'name',
				'as_fields'=>'name:menu_name'
			)
	);

	protected function getUser(){
		return Cookie::get(C('USER_AUTH_KEY'));
	}		
}
?>
