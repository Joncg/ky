<?php
// 关键词模型
class AttributeKeywordModel extends AttributeModel {

	protected $_validate = array(
		array('chs','require','关键词必须填写。',0,'',3),
		array('chs', 'checkNode', '关键词已经存在', 0, 'callback'),
	);

	protected $_auto = array(
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);

	protected $_map = array(
		'chs'=>'name',
		'pid'=>'parent_id',
	);
    
    protected $_link = array(
		'sort_id' => array(
			'mapping_type' => HAS_MANY ,
			'class_name' => 'RefStyleKeyword',
			'foreign_key' => 'keyword_id',
			'mapping_name' => 'sort_id',
			'mapping_fields' => 'style_id,sort_id',
		),
	);

	public function checkNode() {
		$map['name'] = $_POST['name'];
		if (!empty($_POST['id'])) {
			$map['id'] = array('neq', $_POST['id']);
		}
		$result = $this->where($map)->field('id')->find();
		if ($result) {
			return false;
		} else {
			return true;
		}
	}
}
?>