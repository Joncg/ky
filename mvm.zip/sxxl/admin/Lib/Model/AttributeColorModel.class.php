<?php
class AttributeColorModel extends AttributeModel{
		protected $_validate = array(
							     array('chs','require','颜色名称必须填写。',0,'',3),  
							  );	
	
		protected $_map = array(
								'chs'=>'name',
							);	
	
		protected $_auto = array(			 
								array('add_user_id','getUser',3,'callback'),
								array('add_time','time',3,'function'),
							);
}
?>
