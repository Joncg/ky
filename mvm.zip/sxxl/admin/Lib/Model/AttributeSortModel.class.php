<?php
class AttributeSortModel extends AttributeModel{
	protected $_validate = array(
		array('chs','require','类别名称必须填写。',0,'',3),
		array('order_id','require','序号必须填写。',0,'',3),	   
	);	

	protected $_map = array(
		'chs'=>'name',
		'order'=>'order_id'
	);	

	protected $_auto = array(			 
		array('add_user_id','getUser',3,'callback'),
		array('add_time','time',3,'function'),
	);
}
?>
