<?php

class SearchHotKeywrodModel extends AttributeModel {

}

?>
