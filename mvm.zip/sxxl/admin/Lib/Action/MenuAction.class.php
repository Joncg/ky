<?php
// +----------------------------------------------------------------------
// | 栏目设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class MenuAction extends AttributeAction{
	protected $model;
	protected $attributeArr = array(
		array('id'=>1,'name'=>'季度'),
		array('id'=>2,'name'=>'区域/国家/城市'),
		array('id'=>3,'name'=>'品牌'),
		array('id'=>4,'name'=>'设计师'),
		array('id'=>5,'name'=>'书名'),
		array('id'=>6,'name'=>'颜色'),
		array('id'=>7,'name'=>'款式'),
		array('id'=>8,'name'=>'风格'),
		array('id'=>9,'name'=>'图案'),
		array('id'=>10,'name'=>'配饰'),
		array('id'=>11,'name'=>'面/辅料'),
        array('id'=>12,'name'=>'细节'),
	);

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('Menu');
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'栏目设置'));
		$this->assign('listMenus', $listMenus);

		$pid = intval($_GET['pid']);
		$map['parent_id'] = array('eq',$pid);

		$action_link = array();
		if($pid >0){
			$mapTmp['id'] = array('eq',$pid);
			$pidTmp = $this->model->where($mapTmp)->getField('parent_id');
			$action_link[] = array('text'=>'返回上级', 'href'=>U('/Menu/index',array('pid'=>$pidTmp,'p'=>$_REQUEST['p'])));
		}
		$action_link[] = array('text'=>'新增栏目', 'href'=>"javascript:Box.open({'id':'insert','title':'新增栏目','iframe':'".U('/Menu/insert',array('pid'=>$pid))."','width':'465','height':'180'});");
		$this->assign('action_link', $action_link);

		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
			$map['parent_id'] = array('egt',0);
		}

		$field = 'id,name,name_en,add_user_id,add_time,order_id';

		$this->_list ($field ,$map,"order_id","desc");
		$this->display ();
    }

	public function insert(){
		$Arr['pid'] = $pid = intval($_GET['pid']);
		$Arr['attributeArr'] = $this->attributeArr;
		//保存
		if($_POST){
			if($data = $this->model->create()) {
				if($this->model->add() !== false){
					$this->ajaxReturn($data,'新增栏目成功！',1);
				}
				else{
					$this->ajaxReturn($data,'新增栏目失败！',0);
				}
			}
		}
		$this->assign($Arr);
		$this->display();
	}

	public function edit(){
		//保存
		if($_POST){
			if($data = $this->model->create()) {
				if($this->model->save() !== false){
					$this->ajaxReturn($data,'编辑栏目成功！',1);
				}
				else{
					$this->ajaxReturn($data,'编辑栏目失败！',0);
				}
			}
		}

		$id = intval($_GET['id']);
		$info = $this->model->find($id);
		$this->assign('info',$info);
		//格式化属性数据
		$attributeArrTmp = $this->attributeArr;
		$checkedAttrArr = explode(',', $info['attr_selected_subject']);
		foreach($attributeArrTmp as $key =>$val){
			if(in_array($val['id'],$checkedAttrArr)){
				$attributeArrTmp[$key]['checked'] = 1;
			}
            if((in_array(3,$checkedAttrArr) || in_array(4,$checkedAttrArr) || in_array(5,$checkedAttrArr)) && in_array($val['id'],array(3,4,5)) && $attributeArrTmp[$key]['checked'] !=1){
                $attributeArrTmp[$key]['disabled'] = 1;
            }
		}
		$this->assign('attributeArrS',$attributeArrTmp);
		//格式化属性数据
		$attributeArrTmp = $this->attributeArr;
		$checkedAttrArr = explode(',', $info['attr_selected_picture']);
		foreach($attributeArrTmp as $key =>$val){
			if(in_array($val['id'],$checkedAttrArr)){
				$attributeArrTmp[$key]['checked'] = 1;
			}
            if((in_array(3,$checkedAttrArr) || in_array(4,$checkedAttrArr) || in_array(5,$checkedAttrArr)) && in_array($val['id'],array(3,4,5)) && $attributeArrTmp[$key]['checked'] !=1){
                $attributeArrTmp[$key]['disabled'] = 1;
            }
		}
		$this->assign('attributeArrP',$attributeArrTmp);
		$this->display();
	}
}
?>
