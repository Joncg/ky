<?php
 //
 // +----------------------------------------------------+
 // | 后台节点模块 |
 // +----------------------------------------------------+
 // | Copyright (c) 2011-2011 baln |
 // | Email balncom@gmail.com |
 // | Web http://www.balns.com |
 // +----------------------------------------------------+
 // | This source file is subject to PHP License |
 // +----------------------------------------------------+
 //

class SysNodeAction extends CommonAction {

	public function _initialize() {
		parent::_initialize();
		$this->model = D('SysNode');
	}

	public function _filter(&$map) {
		if (empty($_POST['search']) && !isset($map['parent_id'])) {
			$map['parent_id'] = 0;
		}
		if ($_GET['parent_id'] != '') {
			$map['parent_id'] = $_GET['parent_id'];
		}
        Cookie::set('currentNodeId', $map['parent_id']);
		$map['title'] = array('like', "%" . $_POST['title'] . "%");
		//获取上级节点
		if (isset($map['parent_id'])) {
			if ($this->model->getById($map['parent_id'])) {
				$this->assign('level', $this->model->level + 1);
				$this->assign('nodeName', $this->model->name);
			} else {
				$this->assign('level', 1);
			}
		}
	}

	function index() {
		$listMenus = array(array('href' => __URL__, 'title' => '节点管理'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$pid = intval($_GET['parent_id']);
		if (!empty($pid)) {
			$where['id'] = array('eq',$pid);
			$parent_id = $this->model->where($where)->getField('parent_id');
			$action_link[] = array('text'=>'返回上级', 'href'=>U('/SysNode/index',array('parent_id'=>$parent_id)));
		}
		$action_link[] = array('text' => '添加节点', 'href' => "javascript:Box.open({'id':'add','title':'添加节点','iframe':'__URL__/add/parent_id/{$_GET['parent_id']}','width':'450','height':'200'});");
		$this->assign('action_link', $action_link);
		//列表过滤器，生成查询Map对象
		$map = $this->_search();
		if (method_exists($this, '_filter')) {
			$this->_filter($map);
		}
		$field = '*';
		$this->_list($field, $map, 'order_id');
		$this->display();
	}

	/**
	 * 根据表单生成查询条件
	 * 进行列表过滤
	 */
	protected function _list($field, $map, $sortBy = '', $asc = false) {
		//排序字段 默认为主键名
		if (isset($_REQUEST ['_order'])) {
			$order = $_REQUEST ['_order'];
		} else {
			$order = !empty($sortBy) ? $sortBy : $this->model->getPk();
		}
		//排序方式默认按照倒序排列
		//接受 sost参数 0 表示倒序 非0都 表示正序
		if (isset($_REQUEST ['_sort'])) {
			$sort = $_REQUEST ['_sort'] ? 'asc' : 'desc';
		} else {
			$sort = $asc ? 'asc' : 'desc';
		}
		//取得满足条件的记录数
		$count = $this->model->where($map)->count('id');
		if ($count > 0) {
			import("ORG.Util.Page");
			//创建分页对象
			if (!empty($_REQUEST ['listRows'])) {
				$listRows = $_REQUEST ['listRows'];
			} else {
				$listRows = '20';
			}
			$p = new Page($count, $listRows);
			//分页查询数据
			$voList = $this->model->where($map)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $this->model->getlastsql();
			//分页跳转的时候保证查询条件
			foreach ($map as $key => $val) {
				if (!is_array($val)) {
					$p->parameter .= "$key=" . urlencode($val) . "&";
				}
			}
			//分页显示
			$page = $p->show();
			//模板赋值显示
			$this->assign('list', $voList);
			$this->assign("page", $page);
		}
		Cookie::set('_currentUrl_', __SELF__);
		return;
	}

	public function add() {
		$parent_id = intval($_GET['parent_id']);
		if ($_POST) {
			if (!$this->model->create()) {
				$this->error($this->model->getError());
			} else {
				if ($parent_id) {
					$this->model->parent_id = $parent_id;
				}
				// 写入帐号数据
				if ($result = $this->model->add()) {
					$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success('用户添加成功！');
				} else {
					$this->error('用户添加失败！');
				}
			}
		} else {
			$this->assign('parent_id', $parent_id);
			$this->display('info');
		}
	}

	public function edit() {
		if ($_POST['id']) {
			if (!$this->model->create()) {
				$this->error($this->model->getError());
			} else {
				// 更新数据
				$result = $this->model->save();
				if (false !== $result) {
					//成功提示
					$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success('编辑成功!');
				} else {
					//错误提示
					$this->error('编辑失败!');
				}
			}
		} else {
			if ($_GET['id']) {
				$id = $_REQUEST[$this->model->getPk()];
				$info = $this->model->find($id);
				$this->assign('info', $info);
			}
			$this->display('info');
		}
	}

	/**
	 * 批量操作
	 */
	public function batch() {
		$actType = trim($_REQUEST['acttype']);
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if ($actType == 'remove') {
			if ($id > 0) {
				$this->model->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
			} elseif (is_array($ids) && !empty($ids)) {
				$errorNum = 0;
				foreach ($ids as $key => $id) {
					$this->model->delete(intval($id)) !== false ? '' : $errorNum++;
				}
				$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！');
			}
		} else {
			if ($actType == 'status_yes') {
				$this->model->status = 1;
			} else if ($actType == 'status_no') {
				$this->model->status = 0;
			}
			foreach ($ids as $key => $id) {
				$where = array('id'=>$id);
				$this->model->where($where)->save();
			}
			$this->success('批量操作成功！');
		}
	}
}

?>