<?php

// 关联属性更新
class UpdateSiftAction extends CommonAction {

    protected $id;                  //ID
    protected $cid;                 //栏目ID
    protected $cid_tmp;
    protected $cmid = 0;            //子栏目ID
    protected $ano;                 //区域NO
    protected $boid;                //书籍ID
    protected $did;                 //设计师ID
    protected $seid;                //季度ID
    protected $bid;                 //品牌ID
    protected $soid = 0;            //性别ID
    protected $sid = 0;             //专栏ID
    protected $act;
    protected $table;
    protected $menu_arr = array(
        array('id' => '11', 'title' => '流行趋势'),
        array('id' => '12', 'title' => '时装发布'),
        array('id' => '13', 'title' => 'T台趋势'),
        array('id' => '14', 'title' => '企划方案'),
        array('id' => '15', 'title' => '展会材料'),
        array('id' => '17', 'title' => '正在流行'),
        array('id' => '18', 'title' => '流行分析'),
        array('id' => '27', 'title' => '手稿趋势'),
        array('id' => '29', 'title' => '市场聚焦'),
        array('id' => '19', 'title' => '时尚杂志'),
        array('id' => '20', 'title' => '品牌画册'),
        array('id' => '22', 'title' => '时尚款式'),
        array('id' => '21', 'title' => '街头时尚'),
        array('id' => '23', 'title' => '高级陈列'),
        array('id' => '16', 'title' => '矢量款式'),
        array('id' => '24', 'title' => '图案'),
        array('id' => '25', 'title' => '配饰'),
        array('id' => '26', 'title' => '书籍'),
        array('id' => '28', 'title' => '秀场提炼'),
            //array('id'=>'30','title'=>'婴童专区'),
    );
    protected $action_sift = array(
        array('id' => '1', 'text' => '更新文件夹属性', 'type' => "folder"),
        array('id' => '2', 'text' => '更新主题属性', 'type' => "theme"),
        array('id' => '3', 'text' => '更新图片属性', 'type' => "picture"),
    );

    public function _initialize() {
        $this->cid = intval($_REQUEST['cid']);
        $this->act = trim($_REQUEST['act']);
        parent::_initialize();
        $this->init();
    }

    public function index() {
        if ($this->cid) {
            if ($this->cid > 29 || $this->cid < 11) {
                $this->error('error');
            }

            $this->data();
        } else {
            $this->assign('action_sift', $this->action_sift);
            $this->assign('menu_arr', $this->menu_arr);
            $this->display();
        }
    }

    protected function data() {
        $tag = intval($_REQUEST['tag']);
        $page = intval($_REQUEST['page']);
        $page = $page ? $page : 1;

        if ($this->act == 'all') {
            if ($tag == 0) {
                if (isset($this->m['folder'])) {
                    $this->table = 'folder';
                    $model = $this->modelF;
                } else {
                    $page = 0;
                    ++$tag;
                    echo "<script>window.location='?cid={$this->cid}&act={$this->act}&max={$max}&min={$min}&page={$page}&tag={$tag}&time_start={$time_start}&time_end={$time_end}';</script>";
                }
            } else if ($tag == 1) {
                if($this->cid != 11){
                    $this->table = 'subject';
                    $model = $this->modelT;
                }else{
                    exit('更新完毕');
                }
            } else if ($tag == 2) {
                if($this->cid == 22 || $this->cid == 17){
                    $this->table = 'picture';
                    $model = $this->modelP;
                }else{
                    exit('更新完毕');
                }
            } else if ($tag == 3) {
                exit('更新完毕');
            }
        } else if ($this->act == 'folder') {
            $this->table = 'folder';
            $model = $this->modelF;
        } else if ($this->act == 'theme') {
            if($this->cid != 11){
                $this->table = 'subject';
                $model = $this->modelT;
            }else{
                exit('更新完毕');
            }
        } else if ($this->act == 'picture') {
            if($this->cid == 22 || $this->cid == 17){
                $this->table = 'picture';
                $model = $this->modelP;
            }else{
                exit('更新完毕');
            }
        } else {
            exit('参数错误');
        }

        $map = array();
        if(in_array($this->cid,array(11,13,14,16,18,21,23,25,26,27,28,29))){
            $map['menu_id'] = $this->cid;
        }else if($this->cid == 20){//品牌画册特殊处理
            $map['menu_id'] = array(array('eq',20),array('eq',100),'or');
        }

        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        if ($time_start) {
            $map['publish_time'][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map['publish_time'][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        $map['is_publish'] = 1;
        if ($page == 1) {
            $tmp_info = $model->where($map)->field('min(id) as min_id,max(id) as max_id')->find();
            echo $model->getLastSql() . '<br/>';
            $max = $tmp_info['max_id'];
            $min = $tmp_info['min_id'];
        } else {
            $max = intval($_GET['max']);
            $min = intval($_GET['min']);
        }

        echo $max . '<br/>';

        $page_size = 60;
        $page_start = $min + ($page - 1) * $page_size;
        $page_end = $page_start + $page_size;
        $map['id'] = array(array('egt', $page_start), array('lt', $page_end));

        $field = "id,menu_id,child_menu_id,area_no,book_id,brand_id,designer_id,season_id";
        $order = array('id' => 'asc');

        $list = $model->where($map)->field($field)->order($order)->findAll();
        echo $model->getLastSql() . "<br>";
        $i = 0;
        if ($list) {
            foreach ($list as $key => $val) {
                $this->id = $val['id'];
                $this->cid_tmp = intval($val['menu_id']);
                $this->cmid = intval($val['child_menu_id']);
                $this->ano = $val['area_no'];
                $this->boid = $val['book_id'];
                $this->bid = $val['brand_id'];
                $this->did = $val['designer_id'];
                $this->seid = $val['season_id'];
                //性别
                $sort_list = D("{$this->m['ref_' . $this->table . '_sort']}")->where(array($this->table . '_id' => $this->id, 'menu_id' => $val['menu_id']))->findAll();
                //专栏
                $column_list = D("{$this->m['ref_' . $this->table . '_column']}")->where(array($this->table . '_id' => $this->id, 'menu_id' => $val['menu_id']))->findAll();
                if ($sort_list) {
                    foreach ($sort_list as $ke => $va) {
                        $this->soid = intval($va['sort_id']);
                        if ($column_list) {
                            foreach ($column_list as $k => $v) {
                                $this->sid = intval($v['special_column_id']);
                                //更新属性
                                $this->setPublicSift();
                            }
                        } else {
                            $this->sid = 0;
                            //更新属性
                            $this->setPublicSift();
                        }
                    }
                } else {
                    $this->soid = 0;
                    if ($column_list) {
                        foreach ($column_list as $ke => $va) {
                            $this->sid = intval($v['special_column_id']);
                            //更新属性
                            $this->setPublicSift();
                        }
                    } else {
                        $this->sid = 0;
                        //更新属性
                        $this->setPublicSift();
                    }
                }
                ++$i;
            }
        } else {
            if ($page_end < $max) {
                ++$i;
            }
        }

        if ($i > 0) {
            ++$page;
            echo "<script>window.location='?cid={$this->cid}&act={$this->act}&max={$max}&min={$min}&page={$page}&tag={$tag}&time_start={$time_start}&time_end={$time_end}';</script>";
        }

        if ($this->act == 'all' && $tag < 3) {
            $page = 0;
            ++$tag;
            echo "<script>window.location='?cid={$this->cid}&act={$this->act}&max={$max}&min={$min}&page={$page}&tag={$tag}&time_start={$time_start}&time_end={$time_end}';</script>";
        }
    }

    protected function sift($sift, $sift_field) {
        $this->$sift = intval($this->$sift);
        if (empty($this->$sift)) {
            return true;
        }

        if ($this->exist_sift['id']) {
            if (!$this->$sift || in_array($this->$sift, explode(',', $this->exist_sift[$sift_field]))) {
                return true;
            }

            $data = array();
            $data[$sift_field] = $this->exist_sift[$sift_field] ? $this->exist_sift[$sift_field] . ',' . $this->$sift : $this->$sift;
            $this->modelS->where(array('id' => $this->exist_sift['id']))->save($data);
            /*
            if($sift == 'did')
                echo $this->modelS->getLastSql()."</br>";
             *
             */
        } else {
            if (!$this->$sift) {
                return true;
            }
            $data = array();
            $data['menu_id'] = $this->cid_tmp;
            $data['child_menu_id'] = $this->cmid;
            $data['special_column_id'] = $this->sid;
            $data['sort_id'] = $this->soid;
            $row = $this->modelS->where($data)->field('id,' . $sift_field)->find();
            if ($row['id'] > 0) {
                if (in_array($this->$sift, explode(',', $row[$sift_field]))) {
                    return true;
                }

                $data[$sift_field] = $row[$sift_field] ? $row[$sift_field] . ',' . $this->$sift : $this->$sift;
                $exit_sift = $row[$sift_field];
                $this->modelS->where(array('id' => $this->exist_sift['id']))->save($data);
            } else {
                $data[$sift_field] = $this->$sift;
                $this->modelS->add($data);
            }
            /*
            if($sift == 'did')
                echo $this->modelS->getLastSql()."</br>";
             *
             */
        }
    }

    protected function otherSift($sift_field, $ex) {
        if (empty($this->m['ref_' . $this->table . '_' . $ex])) {
            return true;
        }

        $list = M($this->m['ref_' . $this->table . '_' . $ex])->field($ex . '_id')->where(array($this->table . '_id' => $this->id))->findAll();
        //echo M($this->m['ref_' . $this->table . '_' . $ex])->getLastSql() . "</br>";
        if ($list) {
            foreach ($list as $key => $val) {
                if ($this->exist_sift['id']) {
                    if (in_array($val[$ex . '_id'], explode(',', $this->exist_sift[$sift_field]))) {
                        return true;
                    }

                    $data = array();
                    $data[$sift_field] = $this->exist_sift[$sift_field] ? $this->exist_sift[$sift_field] . ',' . $val[$ex . '_id'] : $val[$ex . '_id'];
                    $this->modelS->where(array('id' => $this->exist_sift['id']))->save($data);
                    echo $this->modelS->getLastSql()."111111</br>";
                } else {
                    $data = array();
                    $data['menu_id'] = $this->cid_tmp;
                    $data['child_menu_id'] = $this->cmid;
                    $data['special_column_id'] = $this->sid;
                    $data['sort_id'] = $this->soid;
                    $data[$sift_field] = $val[$ex . '_id'];
                    $this->modelS->add($data);
                    echo $this->modelS->getLastSql()."222222</br>";
                }
                $this->exist_sift[$sift_field] = $data[$sift_field];
            }
        }
    }

    protected function getExistSift() {
        $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list';
        $map = array();
        $map['menu_id'] = $this->cid_tmp;
        $map['child_menu_id'] = $this->cmid;
        $map['special_column_id'] = $this->sid;
        $map['sort_id'] = $this->soid;
        $this->exist_sift = $this->modelS->field($field)->where($map)->find();
        //echo $this->modelS->getLastSql()."<br>";exit;
    }

    protected function setPublicSift() {
        if($this->cid == 27){
            $menu_list = M('RefSubjectMenu')->field('child_menu_id')->where(array('menu_id'=>$this->cid_tmp,'subject_id'=>$this->id))->select();
            if($menu_list){
                foreach($menu_list as $key=>$val){
                    $this->cmid = $val['child_menu_id'];
                    $this->getExistSift();

                    //区域
                    $this->sift('ano', 'area_no_list');
                    //书名
                    $this->sift('boid', 'book_id_list');
                    //品牌
                    $this->sift('bid', 'brand_id_list');
                    //设计师
                    $this->sift('did', 'designer_id_list');
                    //季度
                    $this->sift('seid', 'season_id_list');
                }
            }else{
                $this->cmid = 0;
                $this->getExistSift();

                //区域
                $this->sift('ano', 'area_no_list');
                //书名
                $this->sift('boid', 'book_id_list');
                //品牌
                $this->sift('bid', 'brand_id_list');
                //设计师
                $this->sift('did', 'designer_id_list');
                //季度
                $this->sift('seid', 'season_id_list');
                if ($this->cid == 25) {
                    $this->otherSift('acc_id_list', 'acc');
                }
            }
        }else{
            $this->getExistSift();

            //区域
            $this->sift('ano', 'area_no_list');
            //书名
            $this->sift('boid', 'book_id_list');
            //品牌
            $this->sift('bid', 'brand_id_list');
            //设计师
            $this->sift('did', 'designer_id_list');
            //季度
            $this->sift('seid', 'season_id_list');
            if ($this->cid == 25) {
                $this->otherSift('acc_id_list', 'acc');
            }
        }
    }

    protected function init() {
        $this->m = getCidModel($this->cid);
        if (isset($this->m['folder'])) {
            $this->modelF = D("{$this->m['folder']}");
        }
        $this->modelT = D("{$this->m['subject']}");
        $this->modelP = D("{$this->m['picture']}");
        $this->modelS = D("AttributeSift");
    }

}
