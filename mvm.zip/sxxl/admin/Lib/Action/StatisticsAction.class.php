<?php
 //
 // +----------------------------------------------------+
 // | 录入统计 |
 // +----------------------------------------------------+
 // | Copyright (c) 2011-2011 baln |
 // | Email balncom@gmail.com |
 // | Web http://www.balns.com |
 // +----------------------------------------------------+
 // | This source file is subject to PHP License |
 // +----------------------------------------------------+
 //

class StatisticsAction extends CommonAction {
	public $menus;

	public function _initialize() {
        exit('优化中！');
		parent::_initialize();
        //$this->tableArr = getCidModel($cid);
		//$modelSE = D($this->tableArr['subject']);
        
		$this->model = D('SysUser');
		$this->modelS = D('ShareSubject');
        $this->modelSC = D('CatwalkSubject');
        $this->modelSI = D('InvogueSubject');
        
		$this->modelP = D('SharePicture');
		$this->modelF = D('StylePictureSubsidiary');
		//栏目
		$menus = F('menuList','',C('DATA_CACHE_PATH'));
        //dump($menus);
		if ($menus) {
			$this->menus = array();
			foreach ($menus as $key => $val) {
				if ($val['parent_id'] == 0) {
					$this->menus[$key] = $val;
				}
			}
		}
		$c = count($this->menus);
		$this->menus[$c+99]['id'] = '0';
		$this->menus[$c+99]['name'] = '其它';
		$this->assign('menus', $this->menus);
		$this->assign($_REQUEST);
	}

	public function _filter(&$map) {
		$map['id'] = array('egt', 0);
		$where['account'] = array('like', "%" . $_POST['account'] . "%");
		$where['real_name'] = array('like', "%" . $_POST['account'] . "%");
		$where['_logic'] = 'or';
		$map['_complex'] = $where;
	}

	function index() {
		$listMenus = array(array('href' => __URL__, 'title' => '推荐位管理'));
		$this->assign('listMenus', $listMenus);
		
		//列表过滤器，生成查询Map对象
		$map = $this->_search();
		if (method_exists($this, '_filter')) {
			$this->_filter($map);
		}
		$field = '*';
		$this->_list($field, $map, 'id', true);
		$this->display();
	}

	/**
	 * 根据表单生成查询条件
	 * 进行列表过滤
	 */
	protected function _list($field, $map, $sortBy = '', $asc = false) {
		$listRows = '15';
		//排序字段 默认为主键名
		$order = !empty($sortBy) ? $sortBy : $this->modelP->getPk();
		//排序方式默认按照倒序排列
		//接受 sost参数 0 表示倒序 非0都 表示正序
		$sort = $asc ? 'asc' : 'desc';
		//取得满足条件的记录数
		$count = $this->model->where($map)->count('id');
		//echo $this->model->getlastsql();
		if ($count > 0) {
			import("ORG.Util.Page");
			//创建分页对象
			$p = new Page($count, $listRows);
			//分页查询数据
			$voList = $this->model->where($map)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
//			dump($voList);
//            echo $this->model->getlastsql();
			foreach ($voList as $key => $val) {
				$voList[$key]['sonColumn'] = $this->getColumnCount($val['id']);
			}
			//dump($voList);
			//分页跳转的时候保证查询条件
			foreach ($_REQUEST as $key => $val) {
				if (!is_array($val)) {
					$p->parameter .= "$key=" . urlencode($val) . "&";
				}
			}
			//分页显示
			$page = $p->show();
			//模板赋值显示
			$this->assign('list', $voList);
			$this->assign("page", $page);
		}
		Cookie::set('_currentStatisticsUrl_', __SELF__);
		return;
	}
	
	protected function getColumnCount($mid) {
		$mid = intval($mid);
		if (empty($mid)) return false;
		$map['is_publish'] = 1;
		//$map['is_delete'] = 0;
		$map['add_user_id'] = $mid;
		$time_start = $_REQUEST['time_start'];
		$time_end = $_REQUEST['time_end'];
		if ($time_start) {
			$map['add_time'][] = array('egt', strtotime($time_start . ' 00:00:00'));
		}
		if ($time_end) {
			$map['add_time'][] = array('elt', strtotime($time_end . ' 23:59:59'));
		}
		//dump($this->menus);exit;
		$row = $this->modelS->field('count(id) subject_count,SUM(picture_count) picture_count,menu_id')->where($map)->group('menu_id')->order(array('menu_id'=>'asc'))->findAll();
        $rowC = $this->modelSC->field('count(id) subject_count,SUM(picture_count) picture_count,menu_id')->where($map)->group('menu_id')->order(array('menu_id'=>'asc'))->findAll();
        $rowI = $this->modelSI->field('count(id) subject_count,SUM(picture_count) picture_count,menu_id')->where($map)->group('menu_id')->order(array('menu_id'=>'asc'))->findAll();
        
		//dump($rowI);exit;
        //$row = array_merge($row, $rowC);
        //echo $this->modelS->getLastSql() . '<br />';
		
		$where['add_user_id'] = $mid;
		$time_start = $_REQUEST['time_start'];
		$time_end = $_REQUEST['time_end'];
		if ($time_start) {
			$where['add_time'][] = array('egt', strtotime($time_start . ' 00:00:00'));
		}
		if ($time_end) {
			$where['add_time'][] = array('elt', strtotime($time_end . ' 23:59:59'));
		}
		$ft = $this->modelF->field('count(id) picture_count')->where($where)->find();
		//dump($ft);
		if ($row) {
			$rcount = count($row);
			$row[$rcount+1]['subject_count'] = 0;
			$row[$rcount+1]['picture_count'] = $ft['picture_count'];
			$row[$rcount+1]['menu_id'] = '0';
			$tm = array();
			foreach ($row as $key => $val) {
				$tm[] = $val['menu_id'];
			}
			$rcount = count($row);
			foreach ($this->menus as $key => $val) {
				if (!in_array($val['id'], $tm)) {
					$row[$rcount+$key]['subject_count'] = 0;
					$row[$rcount+$key]['picture_count'] = 0;
					$row[$rcount+$key]['menu_id'] = $val['id'];
				}
			}
		}
		return $row;
	}
}
?>