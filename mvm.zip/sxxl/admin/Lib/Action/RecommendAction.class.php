<?php
 //
 // +----------------------------------------------------+
 // | 推荐位管理 |
 // +----------------------------------------------------+
 // | Copyright (c) 2011-2011 baln |
 // | Email balncom@gmail.com |
 // | Web http://www.balns.com |
 // +----------------------------------------------------+
 // | This source file is subject to PHP License |
 // +----------------------------------------------------+
 //

class RecommendAction extends CommonAction {

	public function _initialize() {
		parent::_initialize();
		$this->model = D('SysRecommend');
		$this->modelP = D('SysRecommendPosition');
		$this->assign($_GET);
	}

	public function _filter(&$map) {
		if (empty($_POST['search']) && !isset($map['parent_id'])) {
			$map['parent_id'] = 0;
		}
		if ($_GET['parent_id'] != '') {
			$map['parent_id'] = $_GET['parent_id'];
		}
	}

	function index() {
		$listMenus = array(array('href' => __URL__, 'title' => '推荐位管理'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$pid = intval($_GET['parent_id']);
		if (!empty($pid)) {
			$where['id'] = array('eq',$pid);
			$parent_id = $this->modelP->where($where)->getField('parent_id');
			$tilte = $this->modelP->where($where)->field('title')->find();
			$action_link[] = array('text'=>'返回上级', 'href'=>U('/Recommend/index',array('parent_id'=>$parent_id)));
		}
		$action_link[] = array('text' => '添加推荐位', 'href' => "javascript:Box.open({'id':'add','title':'添加推荐位','iframe':'__URL__/add/parent_id/{$_GET['parent_id']}','width':'450','height':'200'});");
		$this->assign('action_link', $action_link);
		//列表过滤器，生成查询Map对象
		$map = $this->_search();
		if (method_exists($this, '_filter')) {
			$this->_filter($map);
		}
		$field = '*';
		$this->_list($field, $map, 'id', true);
		$this->assign("title",$tilte['title']);
		$this->display();
	}

	/**
	 * 根据表单生成查询条件
	 * 进行列表过滤
	 */
	protected function _list($field, $map, $sortBy = '', $asc = false) {
		//排序字段 默认为主键名
		if (isset($_REQUEST ['_order'])) {
			$order = $_REQUEST ['_order'];
		} else {
			$order = !empty($sortBy) ? $sortBy : $this->modelP->getPk();
		}
		//排序方式默认按照倒序排列
		//接受 sost参数 0 表示倒序 非0都 表示正序
		if (isset($_REQUEST ['_sort'])) {
			$sort = $_REQUEST ['_sort'] ? 'asc' : 'desc';
		} else {
			$sort = $asc ? 'asc' : 'desc';
		}
		//取得满足条件的记录数
		$count = $this->modelP->where($map)->count('id');
		if ($count > 0) {
			import("ORG.Util.Page");
			//创建分页对象
			if (!empty($_REQUEST ['listRows'])) {
				$listRows = $_REQUEST ['listRows'];
			} else {
				$listRows = '20';
			}
			$p = new Page($count, $listRows);
			//分页查询数据
			$voList = $this->modelP->where($map)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $this->modelP->getlastsql();
			//分页跳转的时候保证查询条件
			foreach ($map as $key => $val) {
				if (!is_array($val)) {
					$p->parameter .= "$key=" . urlencode($val) . "&";
				}
			}
			//分页显示
			$page = $p->show();
			//模板赋值显示
			$this->assign('list', $voList);
			$this->assign("page", $page);
		}
		Cookie::set('_currentRecommendUrl_', __SELF__);
		return;
	}

	public function add() {
		$parent_id = intval($_GET['parent_id']);
		if ($_POST) {
			if (!$this->modelP->create()) {
				$this->error($this->modelP->getError());
			} else {
				if ($parent_id) {
					$this->modelP->parent_id = $parent_id;
				}
				// 写入帐号数据
				if ($result = $this->modelP->add()) {
					$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success('用户添加成功！');
				} else {
					$this->error('用户添加失败！');
				}
			}
		} else {
			if ($parent_id) {
				$row = $this->modelP->field('name')->where(array('parent_id'=>$parent_id))->order(array('name'=>'desc'))->find();
				if ($row) {
					$no = intval(substr($row['name'], 1))+1;
					$info['name'] = substr($row['name'], 0, 1) . "$no";
				}
				else {
					$row = $this->modelP->field('name')->find($parent_id);
					$info['name'] = $row['name'] . '1';
				}
			}
			$info['max_count'] = 20;
			$this->assign('info', $info);
			$this->assign('parent_id', $parent_id);
			$this->display('info');
		}
	}

	public function edit() {
		if ($_POST['id']) {
			if (!$this->modelP->create()) {
				$this->error($this->modelP->getError());
			} else {
				// 更新数据
				$result = $this->modelP->save();
				if (false !== $result) {
					//成功提示
					$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success('编辑成功!');
				} else {
					//错误提示
					$this->error('编辑失败!');
				}
			}
		} else {
			if ($_GET['id']) {
				$id = $_REQUEST[$this->modelP->getPk()];
				$info = $this->modelP->find($id);
				$this->assign('info', $info);
			}
			$this->display('info');
		}
	}

	public function delete() {
		$id = intval($_GET['id']);
		if ($id > 0) {
			$row = $this->modelP->field('id')->where(array('parent_id'=>$id))->find();
			if (!empty($row)) {
				$this->error('请先删除子分类！');
			}
			else {
				$row = $this->model->field('id')->where(array('position_id'=>$id))->find();
				if (!empty($row)) {
					$this->error('对不起，该推荐位还有数据未删除！');
				}
				else {
					$this->modelP->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
				}
			}
		}
		else {
			$this->error('请选择数据！');
		}
	}

	public function dataList() {
		$listMenus = array(array('href' => __URL__, 'title' => '推荐位管理'));
		$this->assign('listMenus', $listMenus);
		$action_link[] = array('text'=>'返回上级', 'href'=>Cookie::get('_currentRecommendUrl_'));
		$this->assign('action_link', $action_link);
		$field = '*';
		$sortBy = 'recommend_time';
		$order = !empty($sortBy) ? $sortBy : $this->model->getPk();
		$sort = 'desc';
		$map['position_id'] = intval($_REQUEST['pid']);
		//取得满足条件的记录数
		$count = $this->model->where($map)->count('id');
		if ($count > 0) {
			import("ORG.Util.Page");
			//创建分页对象
			$listRows = '20';
			$p = new Page($count, $listRows);
			//分页查询数据
			$voList = $this->model->relation(true)->where($map)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $this->model->getlastsql();
			foreach ($voList as $key => $val) {
				$voList[$key]['recommend_time'] = $val['recommend_time'] ? date('Y-m-d H:i', $val['recommend_time']) : '';
			}
			//分页跳转的时候保证查询条件
			foreach ($map as $key => $val) {
				if (!is_array($val)) {
					$p->parameter .= "$key=" . urlencode($val) . "&";
				}
			}
			//分页显示
			$page = $p->show();
			//模板赋值显示
			$this->assign('list', $voList);
			$this->assign("page", $page);
		}
		$this->display('data_list');
		return;
	}
	
	public function dataEdit() {
		if ($_POST['id']) {
			$info['id'] = intval($_POST['id']);
			$info['title'] = $_POST['title'];
			$info['describe'] = $_POST['describe'];
			$files = _upload();
			if ($files[0]['file_path']) $info['picture_url'] = $files[0]['file_path'];
			$info['recommend_time'] = strtotime($_POST['recommend_time']);
			// 更新数据
			$result = $this->model->save($info);
			if (false !== $result) {
				//成功提示
				$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
				$this->success('编辑成功!');
			} else {
				//错误提示
				$this->error('编辑失败!');
			}
		} else {
			if ($_GET['id']) {
				$id = $_REQUEST[$this->model->getPk()];
				$info = $this->model->find($id);
				$position_id = $info['position_id'];
				
				$P = $this->modelP->find($position_id);
				$this->assign('P', $P);
				$info['picture_url'] = $info['picture_url'] ? show_pic_path($info['picture_url']) : '';
				$info['recommend_time'] = $info['recommend_time'] ? date('Y-m-d H:i:s', $info['recommend_time']) : date('Y-m-d H:i:s');
				$this->assign('info', $info);
			}
			$this->display('data_info');
		}
	}
	
	/**
	 * 批量操作
	 */
	public function batch() {
		$actType = trim($_REQUEST['acttype']);
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if ($actType == 'remove') {
			if ($id > 0) {
				$this->model->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
			} elseif (is_array($ids) && !empty($ids)) {
				$errorNum = 0;
				foreach ($ids as $key => $id) {
					$this->model->delete(intval($id)) !== false ? '' : $errorNum++;
				}
				$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！');
			}
		}
	}
}

?>