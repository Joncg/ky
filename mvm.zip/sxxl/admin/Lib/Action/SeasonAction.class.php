<?php
// +----------------------------------------------------------------------
// | 季度设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class SeasonAction extends AttributeAction{
	protected $model;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('AttributeSeason');
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'季度设置'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$action_link[] = array('text'=>'新增季度', 'href'=>"javascript:Box.open({'id':'insert','title':'新增季度','iframe':'".U('/Season/insert')."','width':'465','height':'160'});");
		$this->assign('action_link', $action_link);

		$name = $_REQUEST['chs'];
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
		}
		$en_name = $_REQUEST['eng'];
		if(!empty($en_name)){
			$this->assign('eng',$en_name);
			$map['en_name'] = array('like','%'.$en_name.'%');
		}
		$field = 'id,name,en_name,add_user_id,add_time,order_id';

		$this->_list ($field ,$map);
		$this->display ();
	}
    

	public function insert(){
		//保存
		if($_POST){
            $map['name'] = $_POST['chs'];
            $map['en_name'] = $_POST['eng'];
            $map['_logic'] = 'or';
            $row = $this->model->where($map)->find();
            $this->model->getLastSql();
			if ( $row ) {
				$this->ajaxReturn($data,'此季度已经存在！',0);
			}
			if($data = $this->model->create()) {
				if($this->model->add() !== false){
					$this->ajaxReturn($data,'新增成功！',1);
				}
				else{
					$this->ajaxReturn($data,'新增失败！',0);
				}
			}
		}
		if(MODULE_NAME == 'Area'){
            $pno = intval($_GET['pno']);
            $this->assign('pno',$pno);
        }
        elseif($_GET['pid']){
            $pid = intval($_GET['pid']);
            $this->assign('pid',$pid);
        }
        $this->assign('tab',$this->tab);
		$this->display();
	}

}
?>
