<?php
// +----------------------------------------------------------------------
// | 风格设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class FashionAction extends AttributeAction{
	protected $model;
    protected $refmodel;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('AttributeFashion');
        $this->refmodel = D ('RefStyleFashion');
        $this->menuModel = D ('Menu');
        //类别
        $this->sorts = F('sortList','',C('DATA_CACHE_PATH'));
        //款式
        $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
	}

    public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'风格设置'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$action_link[] = array('text'=>'新增风格', 'href'=>"javascript:Box.open({'id':'insert','title':'新增风格','iframe':'".U('/Fashion/insert')."','width':'630','height':'400'});");
		$this->assign('action_link', $action_link);

		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
		}

		$field = 'id,name,add_user_id,add_time,order_id,is_ny,sort_menu';

		$this->_list ($field ,$map);
		$this->display ();
	}
    
	public function insert(){
		if($_POST){ 
			if($data = $this->model->create()) {
                $data['sort_menu'] = get_muster($_POST['sort_id'],$_POST['menu_id']);
                $id = $this->model->add($data);
                $isok = $this->setStyleFashion($id);
				if($isok !== false){
					$this->ajaxReturn($data,'新增成功',1);
				}else{
					$this->ajaxReturn($data,'新增失败！',0);
				}
			}
		}
		if(MODULE_NAME == 'Area'){
            $pno = intval($_GET['pno']);
            $this->assign('pno',$pno);
        }
        elseif($_GET['pid']){
            $pid = intval($_GET['pid']);
            $this->assign('pid',$pid);
        }
        $menuList = $this->menuModel->where(array('parent_id'=>0))->field('id,name,name_en')->findAll();
        $this->assign('menuList',$menuList);
		$this->display();
	}
    
    public function setStyleFashion($id){
        if (empty ($id))
             return false;
        $this->delStyleFashion($id);
        $sortArray = $_POST['sort_id'];
        $styleArray = $_POST['style_id'];
		$menuArray = $_POST['menu_id'];
        foreach ($sortArray as $ksort => $vsort) {
            if ( isset($styleArray) && !empty ($styleArray)) {
                foreach ($styleArray as $kstyle => $vstyle) {
					if( $menuArray && is_array($menuArray) )
					foreach($menuArray as $k => $menu_id) {
						$this->refmodel->style_id = empty($vstyle) ? 0 : $vstyle;
						$this->refmodel->fashion_id = $id;
						$this->refmodel->sort_id = empty($vsort) ? 0 : $vsort;
						$this->refmodel->menu_id = $menu_id;
						$this->refmodel->add();
					}
					else {
						$this->refmodel->style_id = empty($vstyle) ? 0 : $vstyle;
						$this->refmodel->fashion_id = $id;
						$this->refmodel->sort_id = empty($vsort) ? 0 : $vsort;
						$this->refmodel->add();
					}
                }
            }else{
				if( $menuArray && is_array($menuArray) )
					foreach($menuArray as $k => $menu_id) {
						$this->refmodel->style_id = 0;
						$this->refmodel->fashion_id = $id;
						$this->refmodel->sort_id = empty($vsort) ? 0 : $vsort;
						$this->refmodel->menu_id = $menu_id;
						$this->refmodel->add();
					}
				else {
					$this->refmodel->style_id = 0;
					$this->refmodel->fashion_id = $id;
					$this->refmodel->sort_id = empty($vsort) ? 0 : $vsort;
					$this->refmodel->add();
				}
            }
        }
        return true;
    }

    public function delStyleFashion($id) {
        $id = intval($id);
        $where = array('fashion_id' => $id);
        $this->refmodel->where($where)->delete();
    }

	public function edit(){
		//保存
		if($_POST['id']){
			if($data = $this->model->create()) {
                $data['sort_menu'] = get_muster($_POST['sort_id'],$_POST['menu_id']);
                $id = $this->model->save($data);
                $isok = $this->setStyleFashion($_POST['id']);
				if( $isok !== false){
					$this->ajaxReturn($data,'编辑成功！',1);
				}
				else{
					$this->ajaxReturn($data,'编辑失败！',0);
				}
			}
		}
		$id = intval($_GET['id']);
		$info = $this->model->relation(array('style'))->find($id);
        $menu_arr = array();
        if ( isset($info['sort_menu']) && !empty ($info['sort_menu']) ) {
                $menu_arr = get_decomposition($info['sort_menu']);
        }
        if ($info['style']) {
            $sort = array();$style = array();
            foreach ($info['style'] as $k => $v) {
                $sort[] = $v['sort_id'];
                $style[] = $v['style_id'];
            }
            $info['sort_id'] = $sort;
            $info['style_id'] = $style;
        }
        $menuList = $this->menuModel->where(array('parent_id'=>0))->field('id,name,name_en')->findAll();
        $this->assign('menuList',$menuList);
		$this->assign('info',$info);
        $this->assign('menu_arr',$menu_arr);
		$this->display();
	}
    
}
?>
