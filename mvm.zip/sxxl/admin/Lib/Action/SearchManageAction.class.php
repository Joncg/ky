<?php
 //
 // +----------------------------------------------------+
 // | 搜索管理 |
 // +----------------------------------------------------+
 //

class SearchManageAction extends CommonAction {
	protected $model;
    public $tab;
    public function _initialize() {
		parent::_initialize();
		$this->getModel($_REQUEST['tab']);
	}

	public function index() {
        $this->getModel($_REQUEST['tab']);
		$listMenus = array(
            array('href'=>__URL__. '/index/tab/act','selected' => (in_array($this->tab, array('act')) ? 'now' : ''),'title'=>'统计关键字'),
            array('href'=>__URL__. '/index/tab/hot','selected' => (in_array($this->tab, array('hot')) ? 'now' : ''),'title'=>'热门关键字'),
            array('href'=>__URL__. '/index/tab/ass','selected' => (in_array($this->tab, array('ass')) ? 'now' : ''),'title'=>'预设关键字'),
            array('href'=>__URL__. '/index/tab/rel','selected' => (in_array($this->tab, array('rel')) ? 'now' : ''),'title'=>'关联关键字'),
            );
		$this->assign('listMenus', $listMenus);
        if ( $this->tab == 'ass' ) {
    		$action_link[] = array('text'=>'新增预设关键字', 'href'=>"javascript:Box.open({'id':'insert','title':'新增预设关键字','iframe':'".U('/SearchManage/info',array('tab'=>$this->tab))."','width':'480','height':'240'});");
            $action_link[] = array('text'=>'更新预设关键字统计总数', 'href'=>U('/SearchManage/setCount',array('tab'=>$this->tab)));
        } elseif ( $this->tab == 'hot' ) {
            $action_link[] = array('text'=>'新增热门关键字', 'href'=>"javascript:Box.open({'id':'insert','title':'新增热门关键字','iframe':'".U('/SearchManage/info',array('tab'=>$this->tab))."','width':'480','height':'240'});");
        } elseif ( $this->tab == 'rel' ) {
            $action_link[] = array('text'=>'新增关联关键字', 'href'=>"javascript:Box.open({'id':'insert','title':'新增关联关键字','iframe':'".U('/SearchManage/info',array('tab'=>$this->tab))."','width':'480','height':'240'});");
        }

        if ( $this->tab !== 'act' ) {
            $this->assign('action_link', $action_link);
        }
		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['key_word'] = array('like','%'.$name.'%');
		}
        $field = '*';
		$this->_list ($field ,$map);
        $this->assign('tab',$this->tab);
        if ( $this->tab == 'act' ) {
            $this->display ("SearchManage:index");
        } elseif ( $this->tab == 'ass' ) {
            $this->display ("SearchManage:assindex");
        } elseif ( $this->tab == 'hot' ) {
            $this->display ("SearchManage:hotindex");
        } elseif ( $this->tab == 'rel' ) {
            $this->display ("SearchManage:relindex");
        }

	}

    public function setCount(){
        import ('@.ORG.Search');
        $s = new Search();
        $i = 0;
        $page = empty($_GET['page']) ? 1 : $_GET['page'];
        $pageSize = 10;
        $pageStart = ($page-1)*$pageSize;
        $voList = $this->model->field('id,key_word')->order(array('id'=>'asc'))->limit($pageStart . ',' . $pageSize)->findAll();
        echo $this->model->getLastSql()."<br>";
        if($voList){
            foreach ($voList as $key => $val) {
                //dump($val);exit();
                $res = $s->queryAssCount($val['key_word']);
                $set['key_total'] = intval($res['total_found']);
				$this->model->where(array('id'=>$val['id']))->save($set);
                echo $this->model->getLastSql()."<br/>";
            }
            ++$i;
        }

        if($i>0) {
            ++$page;
            echo "<script>window.location='?tab=ass&page={$page}';</script>";
        } else {
            $this->assign('jumpUrl', Cookie::get('_currentParamUrl_'));
            $this->success('更新成功！');
        }
    }

    public function _list($field = '*', $map = '', $sortBy = '', $asc = false) {
		//排序字段 默认为主键名
		if (isset ( $_REQUEST ['_order'] )) {
			$order = $_REQUEST ['_order'];
		} else {
			$order = ! empty ( $sortBy ) ? $sortBy : $this->model->getPk ();
		}
		//排序方式默认按照倒序排列
		//接受 sost参数 0 表示倒序 非0都 表示正序
		if (isset ( $_REQUEST ['_sort'] )) {
			$sort = $_REQUEST ['_sort'] ? 'asc' : 'desc';
		} else {
			$sort = $asc ? 'asc' : 'desc';
		}
		//取得满足条件的记录数
		$count = $this->model->where ( $map )->count ();
		if ($count > 0) {
            import("ORG.Util.Page");
			//创建分页对象
			if (! empty ( $_REQUEST ['listRows'] )) {
				$listRows = $_REQUEST ['listRows'];
			} else {
				$listRows = '10';
			}
			$p = new Page ( $count, $listRows );
			//分页查询数据
			$voList = $this->model->where($map)->order( "`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->field($field)->findAll ( );
            //dump($voList);
            //分页跳转的时候保证查询条件
			foreach ( $_REQUEST as $key => $val ) {
				if (! is_array ( $val )) {
					$p->parameter .= "$key=" . urlencode ( $val ) . "&";
				}
			}
            $MODEL_U = D('Member');
            foreach ($voList as $key => $value) {
                if ( !empty($value['add_user_id']) ){
                    $voList[$key]['add_user_name'] = $MODEL_U->getField('name',array('id'=>$value['add_user_id']));
                } elseif (!empty($value['add_user']) ) {
                    $voList[$key]['add_user_name'] = $MODEL_U->getField('name',array('id'=>$value['add_user']));
                }
            }
            //dump($voList);
            //分页显示
			$page = $p->show();
			//模板赋值显示
			$this->assign ( 'list', $voList );
			$this->assign ( "page", $page );
            Cookie::set('_currentParamUrl_', __SELF__);
		}
	}

	public function info() {
		if ($_POST) {
			if (!$data = $this->model->create()) {
				$this->error($this->model->getError());
			} else {
                if ( $this->tab == 'hot' ) {
                    $data['add_user'] = Cookie::get(C('USER_AUTH_KEY'));
                }
				if ($result = $this->model->add($data)) {
					$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
					//$this->success('添加成功！');
                    $this->ajaxReturn($data,'新增成功！',1);
				} else {
					//$this->error('添加失败！');
                    $this->ajaxReturn($data,'添加失败！',0);
				}
			}
		} else {
            $this->assign('tab',$this->tab);
            if ( $this->tab == 'ass' ) {
                $this->display ("SearchManage:assinfo");
            } elseif ( $this->tab == 'hot' ) {
                $this->display ("SearchManage:hotinfo");
            } elseif ( $this->tab == 'rel' ) {
                $this->display ("SearchManage:relinfo");
            }
		}
	}

	public function edit(){
		//保存
		if($_POST['id']){
			if($data = $this->model->create()) {
				if($this->model->save($data) !== false){
					$this->ajaxReturn($data,'编辑成功！',1);
				}
				else{
					$this->ajaxReturn($data,'编辑失败！',0);
				}
			}
		}
		$id = intval($_GET['id']);
		$info = $this->model->find($id);
		$this->assign('info',$info);
        $this->assign('tab',$this->tab);
		if ( $this->tab == 'act' ) {
            $this->display ();
        } elseif ( $this->tab == 'ass' ) {
            $this->display ("SearchManage:assedit");
        } elseif ( $this->tab == 'hot' ) {
            $this->display ("SearchManage:hotedit");
        } elseif ( $this->tab == 'rel' ) {
            $this->display ("SearchManage:reledit");
        }
	}


	public function delete() {
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if($id >0){
			$this->model->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
		}
		elseif(is_array($ids) && !empty($ids)){
			$errorNum = 0;
			foreach($ids as $key => $id){
				$this->model->delete(intval($id)) !== false ?  '' : $errorNum++;
			}
			$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！') ;
		}
	}

    public function getModel($tab = ''){
        if(empty ($tab)){
            $this->model = D ('SearchActKeywrod');
            $this->tab = "act";
            return ;
        }else{
            switch ($tab) {
                case 'act':
                    $this->model = D ('SearchActKeywrod');
                    $this->tab = "act";
                    break;
                case 'ass':
                    $this->model = D ('SearchAssKeywrod');
                    $this->tab = "ass";
                    break;
                case 'hot':
                    $this->model = D ('SearchHotKeywrod');
                    $this->tab = "hot";
                    break;
                case 'rel':
                    $this->model = D ('SearchRelevance');
                    $this->tab = "rel";
                    break;
            }
        }
    }
}

?>