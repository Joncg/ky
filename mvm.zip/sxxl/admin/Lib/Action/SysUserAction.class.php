<?php
 //
 // +----------------------------------------------------+
 // | 后台用户模块 |
 // +----------------------------------------------------+
 // | Copyright (c) 2011-2011 baln |
 // | Email balncom@gmail.com |
 // | Web http://www.balns.com |
 // +----------------------------------------------------+
 // | This source file is subject to PHP License |
 // +----------------------------------------------------+
 //

class SysUserAction extends CommonAction {
	public function _initialize() {
		parent::_initialize();
		$this->model = D('SysUser');
	}
	
	function _filter(&$map) {
		$map['id'] = array('egt', 0);
		$map['account'] = array('like', "%" . $_POST['account'] . "%");
		$where['_logic'] = 'or';
		$where['account'] = array('like', "%" . $_POST['account'] . "%");
		$where['real_name'] = array('like', "%" . $_POST['account'] . "%");
		$map['_complex'] = $where;
		unset($map['account']);
	}
	
	function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'用户管理'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$action_link[] = array('text'=>'添加用户', 'href'=>"javascript:Box.open({'id':'add','title':'添加用户','iframe':'__URL__/add','width':'450','height':'200'});");
		$this->assign('action_link', $action_link);
		//parent::index();
		//列表过滤器，生成查询Map对象
		$map = $this->_search ();
		if (method_exists ( $this, '_filter' )) {
			$this->_filter ( $map );
		}
		$field = '*';
		$this->_list($field, $map);
		$this->display();
	}
	
	/**
	 * 根据表单生成查询条件
	 * 进行列表过滤
	 */
	protected function _list($field, $map, $sortBy = '', $asc = false) {
		//排序字段 默认为主键名
		$order = ! empty ( $sortBy ) ? $sortBy : $this->model->getPk ();
		//接受 sost参数 0 表示倒序 非0都 表示正序
		$sort = $asc ? 'asc' : 'desc';
		//取得满足条件的记录数
		$count = $this->model->where ( $map )->count ( 'id' );
		if ($count > 0) {
			import ( "ORG.Util.Page" );
			//创建分页对象
			if (! empty ( $_REQUEST ['listRows'] )) {
				$listRows = $_REQUEST ['listRows'];
			} else {
				$listRows = '20';
			}
			$p = new Page ( $count, $listRows );
			//分页查询数据
			$voList = $this->model->relation(true)->where($map)->field($field)->order( "`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll ( );
			//echo $this->model->getlastsql();
			//分页跳转的时候保证查询条件
			foreach ( $map as $key => $val ) {
				if (! is_array ( $val )) {
					$p->parameter .= "$key=" . urlencode ( $val ) . "&";
				}
			}
			//分页显示
			$page = $p->show ();
			//模板赋值显示
			$this->assign ( 'list', $voList );
			$this->assign ( 'page', $page );
		}
		Cookie::set ( '_currentUrl_', __SELF__ );
		return;
	}

	// 检查帐号
	public function checkAccount() {
		if (!preg_match('/^[a-z]\w{4,}$/i', $_POST['account'])) {
			$this->error('用户名必须是字母，且5位以上！');
		}
		// 检测用户名是否冲突
		$name = $_REQUEST['account'];
		$result = $this->model->getByAccount($name);
		if ($result) {
			$this->error('该用户名已经存在！');
		} else {
			$this->success('该用户名可以使用！');
		}
	}

	public function add() {
		if ($_POST) {
			if (!$this->model->create()) {
				$this->error($this->model->getError());
			} else {
				// 写入帐号数据
				if ($result = $this->model->add()) {
					$this->addRole($result);
					$this->assign ( 'jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success('用户添加成功！');
				} else {
					$this->error('用户添加失败！');
				}
			}
		} else {
			$list = $this->getRoleList();
			$this->assign("groupList",$list);
			$this->display('info');
		}
	}
	
	public function edit() {
		if ($_POST['id']) {
			if (!$this->model->create()) {
				$this->error($this->model->getError());
			} else {
				// 更新数据
				$result = $this->model->save();
				if (false !== $result) {
					$this->addRole($_POST['id']);
					//成功提示
					$this->assign ( 'jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success ('编辑成功!');
				} else {
					//错误提示
					$this->error ('编辑失败!');
				}
			}
		} else {
			if ($_GET['id']) {
				$id = $_REQUEST[$this->model->getPk()];
				$info = $this->model->relation(true)->find($id);
				$this->assign('info',$info);
			}
			$list = $this->getRoleList($info['roles'][0]['id']);
			$this->assign("groupList",$list);
			$this->display('info');
		}
	}
	
	public function pcPowerList() {
		$userId = intval($_GET['uid']);
		if (empty($userId)) {
			$this->error ('参数错误!');
		}
		$this->assign('uid', $userId);
		$listMenus = array(array('href'=>__ACTION__.'/uid/'.$userId,'title'=>'电脑授权'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$action_link[] = array('text'=>'返回用户列表', 'href'=>Cookie::get('_currentUrl_'));
		$this->assign('action_link', $action_link);
		$SysA = M('SysAuthorized');
		//排序字段 默认为主键名
		$order = ! empty ( $sortBy ) ? $sortBy : 'add_time';
		//接受 sost参数 0 表示倒序 非0都 表示正序
		$sort = 'desc';
		$map = array();
		$map['user_id'] = $userId;
		//取得满足条件的记录数
		$count = $SysA->where($map)->count('id');
		if ($count > 0) {
			import ( "ORG.Util.Page" );
			//创建分页对象
			$listRows = '20';
			$p = new Page ($count, $listRows );
			//分页查询数据
			$voList = $SysA->where($map)->field($field)->order( "`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $SysA->getlastsql();
			//分页跳转的时候保证查询条件
			foreach ( $map as $key => $val ) {
				if (! is_array ( $val )) {
					$p->parameter .= "$key=" . urlencode ( $val ) . "&";
				}
			}
			//分页显示
			$page = $p->show ();
			//模板赋值显示
			$this->assign ( 'list', $voList );
			$this->assign ( 'page', $page );
		}
		$this->display('pc_power');
	}
	
	/**
	 * 批量操作
	 */
	public function pcBatch() {
		$SysA = M('SysAuthorized');
		$actType = trim($_REQUEST['acttype']);
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if ($actType == 'remove') {
			if ($id > 0) {
				$SysA->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
			} elseif (is_array($ids) && !empty($ids)) {
				$errorNum = 0;
				foreach ($ids as $key => $id) {
					$SysA->delete(intval($id)) !== false ? '' : $errorNum++;
				}
				$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！');
			}
		} else {
			if ($actType == 'status_yes') {
				$info['status'] = '1';
			} else if ($actType == 'status_no') {
				$info['status'] = '0';
			}
			if ($id > 0) {
				$where = array('id'=>$id);
				$SysA->where($where)->save($info);
			} else {
				foreach ($ids as $key => $id) {
					$where = array('id'=>$id);
					$SysA->where($where)->save($info);
				}
			}
			$this->success('操作成功！');
		}
	}

	/**
	 * 角色列表
	 * @param type $id
	 * @return type 
	 */
	public function getRoleList($id = '') {
		$group = D("SysRole");
		//读取系统组列表
		$list=$group->field('id,name')->findAll();
		foreach ($list as $key => $val){
			$list[$key]['selected'] = $id == $val['id'] ? 'selected' : '';
		}
		return $list;
	}

	protected function addRole($userId) {
		//新增用户自动加入相应权限组
		$RoleUser = M("SysRoleUser");
		$RoleUser->user_id = $userId;
		// 默认加入网站编辑组
		$RoleUser->role_id = $_POST['role_id'];
		$where = array('user_id'=>$userId);
		$row = $RoleUser->where($where)->select();
		if ($row) {
			$RoleUser->where($where)->save();
		} else {
			$RoleUser->add();
		}
	}

	//重置密码
	public function resetPwd() {
		$id = $_GET['id'];
		//初始密码
		$password = '123456';
		if ('' == trim($id)) {
			$this->error('密码不能为空！');
		}
		$this->model->password = md5($password);
		$this->model->id = $id;
		$result = $this->model->save();
		if (false !== $result) {
			$this->success("密码修改为<strong>$password</strong>");
		} else {
			$this->error('重置密码失败！');
		}
	}

	/**
	 * 批量操作
	 */
	public function batch() {
		$actType = trim($_REQUEST['acttype']);
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if ($actType == 'remove') {
			$this->delete();
		} else {
			if ($actType == 'status_yes') {
				$this->model->status = 1;
			} else if ($actType == 'status_no') {
				$this->model->status = 0;
			}
			foreach ($ids as $key => $id) {
				$where = array('id'=>$id);
				$this->model->where($where)->save();
			}
			$this->success('批量操作成功！');
		}
	}
	
	public function delete() {
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if ($id > 0) {
			$this->model->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
		} elseif (is_array($ids) && !empty($ids)) {
			$errorNum = 0;
			foreach ($ids as $key => $id) {
				$this->model->delete(intval($id)) !== false ? '' : $errorNum++;
			}
			$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！');
		}
	}
    
    //登陆日志
	public function logLogin() {
		$id = intval($_GET['id']);
		if ($id > 0) {
            $this->_logLogin($id);
            $this->display('log_login');
            
		} else{
			$this->error('查看日志出错！');
		}
	}
    
	public function _logLogin($uid) {
		if (empty($uid)) {
			$this->error ('参数错误!');
		}
		//$this->assign('uid', $userId);
		$action_link = array();
		$action_link[] = array('text'=>'返回用户列表','href'=>Cookie::get('_currentUrl_'));
		$this->assign('action_link', $action_link);
		$logLogin = M("SysLogLogin");
        $field = '*';
		//排序字段 默认为主键名
		$order = ! empty ( $sortBy ) ? $sortBy : 'id';
		//接受 sost参数 0 表示倒序 非0都 表示正序
		$sort = 'desc';
		$map = array();
		$map['user_id'] = $uid;
		//取得满足条件的记录数
		$count = $logLogin->where($map)->count('id');
		if ($count > 0) {
            import ( "ORG.Util.Page" );
			//创建分页对象
			$listRows = '10';
			$p = new Page ($count, $listRows );
			//分页查询数据
			$voList = $logLogin->where($map)->field($field)->order( "`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->select();
			//分页跳转的时候保证查询条件
			foreach ( $map as $key => $val ) {
				if (! is_array ( $val )) {
					$p->parameter .= "$key=" . urlencode ( $val ) . "&";
				}
			}
			//分页显示
			$page = $p->show ();
			//模板赋值显示
			$this->assign ( 'list', $voList );
			$this->assign ( 'page', $page );
		}
	}

	/**
	 * 批量操作
	 */
	public function logBatch() {
		$SysL = M('SysLogLogin');
		$actType = trim($_REQUEST['acttype']);
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if ($actType == 'remove') {
			if ($id > 0) {
				$SysL->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
			} elseif (is_array($ids) && !empty($ids)) {
				$errorNum = 0;
				foreach ($ids as $key => $id) {
					$SysL->delete(intval($id)) !== false ? '' : $errorNum++;
				}
				$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！');
			}
		}
	}
}

?>