<?php

class SubjectAction extends CommonAction {

    public $modelF = '';
    public $modelT = '';
    public $modelP = '';
    public $modelS = '';
    public $trueTableFolder = '';
    public $trueTableTheme = '';
    public $trueTablePicture = '';
    public $upFiles = '';
    public $config = array();//图片
    public $configS = array();//主题

    public function _initialize() {
        parent::_initialize();
        $listMenus = array(
            array('href' => __URL__ . '/themeList', 'selected' => (in_array(ACTION_NAME, array('themeList', 'index')) ? 'now' : ''), 'title' => '主题管理'),
            array('href' => __URL__ . '/picList', 'selected' => (in_array(ACTION_NAME, array('picList')) ? 'now' : ''), 'title' => '图片管理'),
        );
        $this->m = getCidModel($this->cid);
        $this->assign('listMenus', $listMenus);
        if (isset($this->m['folder'])) {
            $this->modelF = D("{$this->m['folder']}");
        }
        $this->modelT = D("{$this->m['subject']}");
        $this->modelP = D("{$this->m['picture']}");

        if (isset($this->m['subsidiary'])) {
            $this->modelS = D("{$this->m['subsidiary']}");
        }
       	$this->model_picture_extend = M('ref_picture_extend');
        //栏目
        $this->menus = F('menuList','',C('DATA_CACHE_PATH'));
        $tStr = $this->menus[$this->cid]['attr_selected_picture'];
        if ($tStr)
            $this->config = explode(',', $tStr);
        $tStr = $this->menus[$this->cid]['attr_selected_subject'];
        if ($tStr)
            $this->configS = explode(',', $tStr);
        $this->assign('config', $this->config);
        $this->assign('configS', $this->configS);
        //$Cache = Cache::getInstance();
        //类别
        $this->sorts = F('sortList','',C('DATA_CACHE_PATH'));
        //用户
        $this->userLists = F('userList','',C('DATA_CACHE_PATH'));
        if ($this->menus) {
            $childMenus = array();
            foreach ($this->menus as $key => $val) {
                if ($val['parent_id'] == $this->cid) {
                    $childMenus[$key] = $val;
                }
            }
        }
        $this->assign('childMenus', $childMenus);
        //专栏
        $this->columns = F('columnList','',C('DATA_CACHE_PATH'));
        $this->assign('columns', $this->columns);

        $this->assign('cid', $this->cid);

        $this->assign($_REQUEST);
        if (in_array(ACTION_NAME, array('themeAdd', 'themeEdit', 'folderAdd', 'folderEdit'))) {
            $recomPositions = $this->getRecommendPosition();
            $this->assign('recomPositions', $recomPositions);
        }
    }

    protected function setConfig() {
        //$Cache = Cache::getInstance();
        //季度
        if (in_array('1', $this->config) || in_array('1', $this->configS))
            $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
            //$this->seasons = $Cache->get('seasonList');
        //区域
        if (in_array('2', $this->config) || in_array('2', $this->configS))
            $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
        //品牌
        if (in_array('3', $this->config) || in_array('3', $this->configS))
            $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
        //设计师
        if (in_array('4', $this->config) || in_array('4', $this->configS))
            $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
        //书名
        if (in_array('5', $this->config) || in_array('5', $this->configS))
            $this->books = F('bookList','',C('DATA_CACHE_PATH'));
        //color
        if (in_array('6', $this->config) || in_array('6', $this->configS))
            $this->colors = F('colorList','',C('DATA_CACHE_PATH'));
        //style
        if (in_array('7', $this->config) || in_array('7', $this->configS)){
            $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
            $this->parent_styles = $this->getParents($this->styles);
        }
        //fashion
        if (in_array('8', $this->config) || in_array('8', $this->configS))
            $this->fashions = F('fashionList','',C('DATA_CACHE_PATH'));
        //栏目所拥有的fashion
            $this->cidfashions = get_cid_fashions($this->fashions,  $this->cid);
        //pattern
        if (in_array('9', $this->config) || in_array('9', $this->configS))
            $this->patterns = F('patternList','',C('DATA_CACHE_PATH'));
        //acc
        if (in_array('10', $this->config) || in_array('10', $this->configS))
            $this->accs = F('accList','',C('DATA_CACHE_PATH'));
        //material
        if (in_array('11', $this->config) || in_array('11', $this->configS))
            $this->materials = F('materialList','',C('DATA_CACHE_PATH'));
        //detail
        if (in_array('12', $this->config) || in_array('12', $this->configS))
            $this->details = F('detailList','',C('DATA_CACHE_PATH'));
    }

    protected function getParents($arrs){
        if(empty($arrs)){
            return false;
        }
        $parent_arr = array();
        foreach ($arrs as $key => $val){
            if ( $val['parent_id'] == 0 ) {
                $parent_arr[] = $val;
            }
        }
        return $parent_arr;
    }

    protected function getRecommendPosition($fid = '0') {
        $MODEL = D('SysRecommendPosition');
        $map['parent_id'] = array('in', $fid);
        $row = $MODEL->field('*')->where($map)->order(array('name' => 'asc'))->findAll();
        return $row;
    }

    public function getRecommendList() {
        $fid = intval($_REQUEST['fid']);
        if (empty($fid))
            return false;
        $position_id = intval($_REQUEST['position_id']);
        $list = $this->getRecommendPosition("$fid");
        if ($list) {
            $reStr = "<select name='recomPosition' id='recomPosition' onchange='checkRecom();'><option value=''>选择位置</option>";
            foreach ($list as $key => $val) {
                $selected = $val['id'] == $position_id ? 'selected' : '';
                $reStr .= "<option value='{$val['id']}' {$selected}>{$val['name']}:{$val['title']}>{$val['picture_length']}x{$val['picture_heigth']}px</option>";
            }
            $reStr .= '</select>';
        }
        exit($reStr);
    }

    public function labelList($field = '*', $map = '', $sortBy = 'order_id', $asc = true) {
        $folder_id = intval($_REQUEST['folder_id']);
        $map['folder_id'] = $folder_id;
        $listMenus = array(
            array('href' => __URL__ . '/labelList/folder_id/' . $folder_id, 'title' => '标签列表'),
        );
        $this->assign('listMenus', $listMenus);
        $action_link = array();
        $action_link[] = array('text' => '返回主题', 'href' => Cookie::get('_currentThemeUrl_'));
        $action_link[] = array('text' => '添加标签', 'href' => "__URL__/labelAdd/folder_id/" . $folder_id);
        $this->assign('action_link', $action_link);
        $model = D("{$this->m['folder_lable']}");
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : $model->getPk();
        $sort = $asc ? 'desc' : 'asc';
        //取得满足条件的记录数
        $count = $model->where($map)->count('id');
        //echo $model->getlastsql();
        if ($count) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $model->where($map)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $model->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        Cookie::set('_currentLabelUrl_', __SELF__);
        $this->display('Subject/label_list');
    }

    public function labelAdd() {
        $this->assign('listMenus', '');
        $model = D("{$this->m['folder_lable']}");
        if ($_POST) {
            $info['lable'] = $_POST['lable'];
            $info['menu_id'] = $this->cid;
            $info['folder_id'] = $_POST['folder_id'];
            $info['order_id'] = $_POST['order_id'];
            $id = $model->add($info);
            //echo $model->getlastsql();exit();
            if ($id) {
                $this->assign('jumpUrl', Cookie::get('_currentLabelUrl_'));
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            $action_link = array();
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentLabelUrl_'));
            $this->assign('action_link', $action_link);
            $this->display('Subject/label_info');
        }
    }

    public function labelEdit() {
        $this->assign('listMenus', '');
        $model = D("{$this->m['folder_lable']}");
        $id = intval($_POST['id']);
        if ($id) {
            $info['id'] = $_POST['id'];
            $info['lable'] = $_POST['lable'];
            $info['folder_id'] = $_POST['folder_id'];
            $info['order_id'] = $_POST['order_id'];
            // 更新数据
            $result = $model->save($info);
            //echo $this->modelT->getlastsql();
            if (false !== $result) {
                //成功提示
                $this->assign('jumpUrl', Cookie::get('_currentLabelUrl_'));
                $this->success('编辑成功!');
            } else {
                //错误提示
                $this->error('编辑失败!');
            }
        } else {
            if ($_GET['id']) {
                $id = $_REQUEST[$model->getPk()];
                $info = $model->find($id);
                $this->assign('info', $info);
            }
            $action_link = array();
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentLabelUrl_'));
            $this->assign('action_link', $action_link);
            $this->assign('listMenus', '');
            $this->display('Subject/label_info');
        }
    }

    public function labelBatch() {
        $actType = trim($_REQUEST['acttype']);
        $ids = $_REQUEST['ids'];
        if (empty($ids))
            return false;
        if ($actType == 'remove') {
            $model = D("{$this->m['folder_lable']}");
            foreach ($ids as $id) {
                $model->delete($id);
            }
        }
        $this->success('操作成功！');
    }

    /**
     * 文件夹列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    public function folderList($field = '*', $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-文件夹  列表');
        $action_link = array();
        $action_link[] = array('text' => '添加文件夹', 'href' => "__URL__/folderAdd");
        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['folder_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);

        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $pattern_id = intval($_REQUEST['pattern_id']);
        if ($pattern_id)
            $map['pattern_id'] = $pattern_id;
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($designer_id){
            $checkDesignerName = $this->designers[$designer_id]['name'];
            $this->assign('checkDesigner',$checkDesignerName);
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : $this->modelF->getPk();
        $sort = $asc ? 'desc' : 'asc';
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_folder_sort_original'].' fs ON fs.folder_id='.$this->m['folder_original'].'.id';
            if ( $sort_id == 3 ){
                $map['fs.sort_id'] = array('egt',$sort_id);
            } else {
                $map['fs.sort_id'] = $sort_id;
            }
            $field .=",fs.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_folder_column_original'].' fc ON fc.folder_id='.$this->m['folder_original'].'.id';
			if($column_id == 6){
                $map['fc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['fc.special_column_id'] = $column_id;
            }
            $field .=",fc.special_column_id";
        }
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        } else {
            $map['is_publish'] = array('egt',0);
        }
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        //取得满足条件的记录数
        //$count = $this->modelF->join($join)->where($map)->count('id');
        //dump($map);
        import('ORG.Util.DataCount');
        $count = DataCount::getCount("{$this->m['folder']}", $map, $join);
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelF->relation(array('sort_id','special_column_id'))->where($map)->field($field)->join($join)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelF->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);
                    //$tc = $this->modelT->where("folder_id='{$val['id']}' and is_publish!=-1")->count('*');
                    //$voList[$key]['themeCount'] = intval($tc);
                    $voList[$key]['themeCount'] = $voList[$key]['child_subject_count'];
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    if ($this->patterns)
                        $voList[$key]['patternStr'] = $this->patterns[$val['pattern_id']]['name'];
                }
            }
            //dump($voList);
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        Cookie::set('_currentFolderUrl_', __SELF__);
        return;
    }

    public function folderAdd($is_display = null) {
        if ($_POST) {
            $info = $this->getFolderInfo();
            $id = $this->modelF->add($info);
            //echo $this->modelF->getLastSql();exit();
            if ($id) {
                $this->setFolderOther($id);
                $this->assign('jumpUrl',__URL__."/themeList/folder_id/{$id}");
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            $this->setConfig();
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentFolderUrl_'));
            $this->assign('action_link', $action_link);
            $areaOption = $this->getAreaOption(0);
            $this->assign('areaOption', $areaOption);
            $info['publish_time'] = date('Y-m-d H:i:s', time());
            //dump($info);
            $this->assign('info', $info);
            $this->assign('listMenus', '');
            if(empty($is_display))
                $this->display('Subject/folder_info');
        }
    }

    protected function getAreaOption($sid = 0) {
        import('@.ORG.Tree');
        $tree = new Tree($this->areas);
        $tree->set('gid', 'no');
        $tree->set('parent_id', 'parent_no');
        $phtml = "<option value='\$no' \$selected>\$spacer\$name</option>";
        $area_html = $tree->getTree(0, $phtml, $sid);
        return $area_html;
    }

    public function folderEdit($is_display = null) {
        $id = intval($_POST['id']);
        if ($id) {
            $info = $this->getFolderInfo();
            // 更新数据
            $map['id'] = $id;
            $result = $this->modelF->where($map)->save($info);
            //echo $this->modelT->getlastsql();
            $this->setFolderOther($id);
            //成功提示
            $this->assign('jumpUrl', Cookie::get('_currentFolderUrl_'));
            $this->success('编辑成功!');
        } else {
            $this->setConfig();
            if ($_GET['id']) {
                $id = $_REQUEST['id'];
                $info = $this->modelF->relation(true)->find($id);

                if($info['designer_id']){
                    $checkDesignerName = $this->designers[$info['designer_id']]['name'];
                    $this->assign('checkDesigner',$checkDesignerName);
                    $this->assign('designer_id',$info['designer_id']);
                }
                $info['title'] = stripslashes($info['title']);
                $info['publish_time'] = date('Y-m-d H:i:s', $info['publish_time']);
                $info['title_picture_url'] = show_pic_path($info['title_picture_url']);
                $info['sort_id'] = $this->getStrSort($info['sort_id']);
                $info['special_column_id'] = $this->getStrSpecialColumn($info['special_column_id']);
                $recom = $this->getRecommend($id, true);
                $info = array_merge($info, $recom);
                $areaOption = $this->getAreaOption($info['area_no']);
                $this->assign('areaOption', $areaOption);
                $this->assign('info', $info);
            }
            //dump($info);
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentFolderUrl_'));
            $this->assign('action_link', $action_link);
            $this->assign('listMenus', '');
            if(empty($is_display))
                $this->display('Subject/folder_info');
        }
    }

    protected function getStrSort($sort){
        $strSort = array();
        if(isset ($sort) && !empty ($sort)) foreach ($sort as $key => $val ){
            $strSort[$key] = $val['sort_id'];
        }
        return $strSort;
    }
    protected function getStrSpecialColumn($sort){
        $strSort = array();
        if(isset ($sort) && !empty ($sort)) foreach ($sort as $key => $val ){
            $strSort[$key] = $val['special_column_id'];
        }
        return $strSort;
    }
    /**
     * set subject other attr
     * @param type $id
     */
    protected function setFolderOther($id) {
        $this->setFolderExtend($id);
        $this->setFolderSort($id);
        $this->setFolderSpecialColumn($id);
        $this->setRecommend($id, true);
        $this->setFolderFashion($id);
        if( $this->cid == 12 ) {
            $this->updateCatwalThemePublic($id);
        }
    }

    public function updateCatwalThemePublic($id) {
        if ( empty ($id) ) {
            return false;
        }
        $where['folder_id'] = $id;
        $where['is_publish'] = array('egt',0);
        if ( $_POST['is_publish'] ) {
            $is_publish = $_POST['is_publish'];
        } else {
            $actType = trim($_REQUEST['acttype']);
            if ( $actType == 'display_yes' ) {
                $is_publish = 1;
                if($_REQUEST['display_time']){
                    $data['publish_time'] = strtotime($_REQUEST['display_time']);
                }
            } else if ($actType == 'display_no') {
                $is_publish = 0;
            }
        }
        $data['is_publish'] = $is_publish;
        $this->modelT->where($where)->save($data);
        $list_pic_id = $this->modelT->field('id')->where($where)->select();
        if ( $list_pic_id ) {
            foreach ( $list_pic_id as $key => $val ){
                $this->setPicPublish($val['id'],$is_publish);
            }
        }
        $this->updateCatwalkHasType($id);
    }

    protected function delFolderOther($id) {
        $this->delFolderExtend($id);
        //$this->delFolderSort($id);
        //$this->delFolderColumn($id);
        $this->delRecommend($id, true);
    }

    /**
     * add/update subject extend
     * @param type $id
     */
    protected function setFolderExtend($id) {
        $id = intval($id);
        $model = M("{$this->m['folder_extend']}");
        $info['folder_id'] = $id;
        $info['menu_id'] = $this->cid;
        $info['child_menu_id'] = intval($_POST['child_menu_id']);
        $info['fashion_desc'] = $_POST['fashion_desc'];
        $where = array('folder_id' => $id, 'menu_id' => $this->cid);
        $row = $model->where($where)->select();
        if ($row) {
            $model->where($where)->save($info);
        } else {
            $model->add($info);
        }
    }

    /**
     * delete Extend
     * @param type $id
     */
    protected function delFolderExtend($id) {
        $id = intval($id);
        $where = array('folder_id' => $id, 'menu_id' => $this->cid);
        $model = M("{$this->m['folder_extend']}");
        $model->where($where)->delete();
    }

    public function folderBatch() {
        $actType = trim($_REQUEST['acttype']);
        $columntype = intval($_REQUEST['columntype']);
        $ids = $_REQUEST['ids'];
        if ($actType == 'remove') {
            $this->redirect('folderDelete', array('ids' => implode(',', $ids)));
            exit;
        } elseif ($actType == 'column_yes') {
            $this->redirect('folderColumn', array('ids' => implode(',', $ids),'columntype' => $columntype));
            exit;
        } else {
            if ($actType == 'display_yes') {
                $this->modelF->is_publish = 1;
                if($_REQUEST['display_time'])
                    $this->modelF->publish_time = strtotime($_REQUEST['display_time']);
            } else if ($actType == 'display_no') {
                $this->modelF->is_publish = 0;
            }
            foreach ($ids as $key => $id) {
                if ( $actType == 'display_no' ) {
                    $this->setRecommend($id, true);
                }
                $where = array('id' => $id);
                $this->modelF->where($where)->save();
                $this->updateCatwalThemePublic($id);
            }
            $this->success('操作成功！');
        }
    }

    public function folderColumn() {
        $ids = $_REQUEST['ids'];
        $columntype = $_REQUEST['columntype'];
        if (empty($ids))
            return false;
        $ids = explode(',', $ids);
        $model = M("{$this->m['ref_folder_column']}");
        $modelS = M("{$this->m['subject']}");
        foreach ($ids as $id) {
            $where = array();
            $where['folder_id'] = $id;
            $where['menu_id'] = $this->cid;
            $data['special_column_id'] = $columntype;
            if ( $columntype == 0 ) {
                //删除
                $list = $model->where($where)->select();
                if($list) {
                    $model->where($where)->delete();
                }
            } else {
                //更新
                $list = $model->where($where)->select();
                if($list) {
                    $list = $model->where($where)->delete();
                }
                $data_add['special_column_id'] = $columntype;
                $data_add['folder_id'] = $id;
                $data_add['menu_id'] = $this->cid;
                $model->where($where)->add($data_add);
            }
            $where['is_publish'] = array('egt',0);
            $subject_list = $modelS->field('id')->where($where)->findall();
            $subject_list = $this->getIdList($subject_list);
            $this->themeColumn($subject_list);
        }
        $this->success('批量修改专栏成功！');
    }

    public function folderDelete() {
        $ids = $_REQUEST['ids'];
        if (empty($ids))
            return false;
        $ids = explode(',', $ids);
        $errorNum = 0;
        $noEmptyNum = 0;
        $tmpId ='';
        $info['is_publish'] = '-1';
        $info['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
        foreach ($ids as $id) {
            $count = $this->modelF->where(array('id' => $id))->field('child_subject_count')->find();
            //echo $this->modelF->getLastSql();
            if($count['child_subject_count'] > 0) {
                $noEmptyNum++;
                $tmpId .=$id.",";
            }
            $count = '';
        }
        if($noEmptyNum == 0){
            foreach ($ids as $id) {
                $this->modelF->where(array('id' => $id))->save($info) ? '' : $errorNum++;
                if ( $errorNum == 0 ) {
                    $this->delRecommend($id,true);
                }
            }
        }
        if($noEmptyNum == 0){
            $errorNum > 0 ? $this->error('放入回收站失败！') : $this->success('放入回收站成功！');
        }else{
            $this->error('ID号位'.$tmpId.'文件夹下面有主题，请先删掉主题！');
        }
    }

    /**
     * 主题列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function themeList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-主题列表');
        $action_link = array();
        $folder_id = $_REQUEST['folder_id'];
        if (isset($folder_id)) {
            $action_link[] = array('text' => '返回文件夹', 'href' => Cookie::get('_currentFolderUrl_'));
        }
        if (isset($folder_id) && !empty($folder_id)) {
            $folder_data = $this->modelF->getById($folder_id);
            $this->assign('folderTitle', "文件夹：".stripslashes($folder_data['title']));
            if (!in_array($this->cid,array(12))){$action_link[] = array('text' => '标签管理', 'href' => "__URL__/labelList/folder_id/{$folder_id}");}
            $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/folder_id/{$folder_id}");
        }
        if(in_array($this->cid,array('14','17','27','19','20','21','23','25','26','28','100')))
                $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/");

        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (intval($folder_id))
            $map['folder_id'] = intval($folder_id);
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['subject_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        if($designer_id){
            $checkDesignerName = $this->designers[$designer_id]['name'];
            $this->assign('checkDesigner',$checkDesignerName);
        }
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $this->assign('checkBrand',$checkBrandName);
        }
        if($book_id){
            $checkBookName = $this->books[$book_id]['name'];
            $this->assign('checkBook',$checkBookName);
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        if($this->cid == 12){
            $order = $this->modelT->getPk();
        } else {
            $order = !empty($sortBy) ? $sortBy : $this->modelT->getPk();
        }
        $sort = $asc ? 'desc' : 'asc';
        //风格筛选
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id){
			$join[] = $this->m['ref_subject_fashion_original'].' sf ON sf.subject_id='.$this->m['subject_original'].'.id';
			$map['sf.fashion_id'] = $fashion_id;
            $field .=",sf.fashion_id";
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_subject_sort_original'].' ss ON ss.subject_id='.$this->m['subject_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ss.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ss.sort_id'] = $sort_id;
            }
            $field .=",ss.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_subject_column_original'].' sc ON sc.subject_id='.$this->m['subject_original'].'.id';
            if($column_id == 6){
                $map['sc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['sc.special_column_id'] = $column_id;
            }
            $field .=",sc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_subject_style_original'].' sst ON sst.subject_id='.$this->m['subject_original'].'.id';
			$map['sst.style_id'] = $style_id;
            $field .=",style_id";
        }
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数
        //$map =array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } }
        import('ORG.Util.DataCount');
        $moldel = new DataCount();

        $count = $moldel->getCount("{$this->m['subject']}", $map, $join);
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelT->relation(array('sort_id','special_column_id','style','zipfile_url','fashion_id'))->where($map)->join($join)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //dump($map);dump($join); echo $this->modelT->getlastsql();exit;
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);

                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    $voList[$key]['styleStr'] = implode(',', $style);

                    if ($val['lable_id']) {
                        $m = D("{$this->m['folder_lable']}");
                        $la = $m->field('lable')->find($val['lable_id']);
                        $voList[$key]['lableStr'] = $la['lable'];
                    }
                    if ( $this->cid == 25 ) {
                        //品牌
                        $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
                        //设计师
                        $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
                    }
                    if ($this->fashions)
                        $voList[$key]['fashionStr'] = $this->fashions[$val['fashion_id'][0]['fashion_id']]['name'];
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    $voList[$key]['downloadid'] = urlencode(authcode("tid=".$val['id']."&cid=".$this->cid,"ENCODE"));
                    if($voList[$key]['zipfile_url']['zipfile_url']){
                        $voList[$key]['is_zipfile_url'] = 1;
                    }
                }
            }
            //模板赋值显示
            //dump($voList);
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        $this->assign('folder_id', $folder_id);
        Cookie::set('_currentThemeUrl_', __SELF__);
        return;
    }

    protected function themeAdd($is_display = null) {
        if ($_POST) {
            $info = $this->getSubjectInfo();
            $fid = $_REQUEST['folder_id'] ? $_REQUEST['folder_id'] : '';
            $info['lable_id'] = $_POST['lable_id'] ? $_POST['lable_id'] : 0;
            $id = $this->modelT->add($info);
            //echo $this->modelT->getLastSql();exit();

			//如果是 内衣专栏.品牌画册.内衣 款式的话，将写入款式关联表 (Jialiang Qin 2012.10.12)
			if( isset($_POST['special_column_id']) && in_array(4,$_POST['special_column_id']) ) {
				$m_share_subject_style = D('RefShareSubjectStyle');
				$info['subject_id'] = $id;
				$info['style_id'] = $_POST['neiyi_style'];
				$m_share_subject_style->add($info);
			}

            if ($id) {
                $this->setThemeOther($id,$fid);
                if(!empty($fid)){
                    $this->getFolderThemeCount($fid);
                }
                //处理二级栏目child_menu_id
                //$this->setChildMenu($id);
                $this->assign('jumpUrl',__URL__."/picList/subject_id/{$id}");
                //$this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            Cookie::delete('themeAdd');
            $randStr = '9999'.rand(10000, 99999);
            Cookie::set('themeAdd', $randStr);
            $this->assign('tid', $randStr);
            $this->setConfig();
            $folder_id = $_REQUEST['folder_id'];
            //获取对应标签
            if(!empty($folder_id)){
                $info = $this->modelF->getById($folder_id);
                $info['title'] = stripslashes($info['title']);
                $info['tmpTitle'] =$info['title'];
                $info['title'] = $info['id'] = '';
                $map['folder_id'] = $folder_id;
                $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                $this->assign('lableList', $lable_list);
                }
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $info['publish_time'] = date('Y-m-d H:i:s', time());
            $info['folder_id'] = $_REQUEST['folder_id'];
            $this->assign('info', $info);
            //区域格式化
            $areaOption = $this->getAreaOption(0);
            $this->assign('areaOption', $areaOption);
            $this->assign('listMenus', '');
            if(empty($is_display))
                $this->display('Subject/theme_info');
        }
    }
    //处理二级栏目
    protected function setChildMenu($id) {
        $id = intval($id);
        $child_menu_array = $_POST['child_menu_id'];
        $model = D("{$this->m['ref_subject_menu']}");
        if(is_array($child_menu_array) && isset($child_menu_array)) foreach ($child_menu_array as $key => $val) {
            $map['subject_id'] = $id;
            $map['menu_id'] = $this->cid;
            $map['child_menu_id'] = $val;
            $where = array('subject_id' => $id, 'menu_id' => $this->cid, 'child_menu_id' => $val);
            $row = $model->where($where)->select();
            if ($row) {
                $model->where($where)->save($map);
            } else {
                $model->add($map);
            }
        }
    }

    protected function themeEdit($is_display = null) {
        $id = intval($_POST['id']);
		$m_share_subject_style = D('RefShareSubjectStyle');
        if ($id) {
            $info = $this->getSubjectInfo();
            $fid = $_REQUEST['folder_id'] ? $_REQUEST['folder_id'] : '';
            if(is_array($_POST['child_menu_id']) && isset($_POST['child_menu_id'])){
                $child_menu_array = $_POST['child_menu_id'];
            }else{
                $info['child_menu_id'] = intval($_POST['child_menu_id']);
            }
            if($_POST['lable_id']){
                $info['lable_id'] = $_POST['lable_id'] ? $_POST['lable_id'] : 0;
            }
            //dump($_POST);exit();
            //dump($child_menu_array);exit();
            // 更新数据
            $where['id'] = $id;
            $result = $this->modelT->where($where)->save($info);
            //echo $this->modelT->getlastsql();exit();

			//如果是 内衣专栏.品牌画册.内衣 款式的话，将写入款式关联表 (Jialiang Qin 2012.10.12)
			if( isset($_POST['special_column_id']) && in_array(4,$_POST['special_column_id']) ) {
				$info['subject_id'] = $id;
				$info['style_id'] = $_POST['neiyi_style'];
				$have = $m_share_subject_style->where('subject_id='.$id)->find();
				if( ! $have ) {
					$m_share_subject_style->add($info);
				} else {
					$m_share_subject_style->where('subject_id='.$id)->save($info);
				}
			}

            $this->setThemeOther($id,$fid);
            //$this->setPictureCount($id);
            if (false !== $result) {
                //成功提示
                $this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('编辑成功!');
            } else {
                //错误提示
                $this->error('编辑失败!');
            }
        } else {
            $this->setConfig();
            if ( $this->cid == 25 ) {
                //品牌
                $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
                //设计师
                $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
            }
            if ($_GET['id']) {
                $folder_id = $_REQUEST['folder_id'] ? $_REQUEST['folder_id'] : '';
                $id = $_REQUEST[$this->modelT->getPk()];
                if ( ACTION_NAME == 'underwearThemeEdit' ) {
                    $where_menu_id = array( ' in ', array($this->ny_cid,100) );
                } else {
                    $where_menu_id = array( ' in ', array($this->cid,100) );
                }
                $info = $this->modelT->relation(true)->where(array('menu_id' => $where_menu_id, 'id' => $id))->find();
                //dump($info);
                //$info['content'] = str_replace(' bsrc=', ' bsss=', $info['content']);

				//如果是 内衣专栏.品牌画册 数据，则查对应的款式关联表
                $info['title'] = stripslashes($info['title']);
				if( $info['menu_id']==100 ) {
					$sssinfo = $m_share_subject_style->where('subject_id='.$info['id'])->find();
					$this->assign('sssinfo',$sssinfo);
				}

                if($info['book_id']){
                    $checkBookName = $this->books[$info['book_id']]['name'];
                    $this->assign('checkBook',$checkBookName);
                    $this->assign('book_id',$info['book_id']);
                }
				$info['content'] = stripslashes($info['content']);
                $info['publish_time'] = date('Y-m-d H:i:s', $info['publish_time']);
                $info['tmpTitle'] = $info['title'];
                $info['subject_id'] = $_GET['id'];
                if ($info['folder_id']) {
                    $map['folder_id'] = $info['folder_id'];
                    $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                    $this->assign('lableList', $lable_list);
                }
                if ($info['sort_id']) {
                    $tmp = array();
                    foreach ($info['sort_id'] as $key => $val) {
                        $tmp[] = $val['sort_id'];
                    }
                    $info['sort_id'] = $tmp;
                }
                if (empty($info['sort_id'])) {
                    $info['sort_id'] = array($info['sort_id']);
                }
                if ($info['fashion_id']) {
                    $tmp = array();
                    foreach ($info['fashion_id'] as $key => $val) {
                        $tmp[] = $val['fashion_id'];
                    }
                    $info['fashion_id'] = $tmp;
                }
                if (empty($info['fashion_id'])) {
                    $info['fashion_id'] = array($info['fashion_id']);
                }
                if ($info['style']) {
                    $tmp = array();
                    foreach ($info['style'] as $key => $val) {
                        $tmp[] = $val['style_id'];
                    }
                    $info['style'] = $tmp;
                }
                if (empty($info['style'])) {
                    $info['style'] = array($info['style']);
                }
                if ($info['child_menu_ids']) {
                    $tmp = array();
                    foreach ($info['child_menu_ids'] as $key => $val) {
                        $tmp[] = $val['child_menu_id'];
                    }
                    $info['child_menu_ids'] = $tmp;
                }
                if (empty($info['child_menu_ids'])) {
                    $info['child_menu_ids'] = array($info['child_menu_ids']);
                }

                if ($info['acc']) {
                    $tmp = array();
                    foreach ($info['acc'] as $key => $val) {
                        $tmp[] = $val['acc_id'];
                    }
                    $info['acc'] = $tmp;
                }
                if ($info['special_column_id']) {
                    $tmp = array();
                    foreach ($info['special_column_id'] as $key => $val) {
                        $tmp[] = $val['special_column_id'];
                    }
                    $info['special_column_id'] = $tmp;
                }
                if (empty($info['special_column_id'])) {
                    $info['special_column_id'] = array($info['special_column_id']);
                }
                $info['title_picture_url'] = show_pic_path($info['title_picture_url']);
                $recom = $this->getRecommend($id);
                $info = array_merge($info, $recom);
                $info['show_edit'] = $info['show_edit'] ? 'checked' : '';
                if (in_array($info['menu_id'], array('27'))) {
                    $map['menu_id'] = $info['menu_id'];
                    $map['subject_id'] = $info['id'];
                    $child_menu_array = D("{$this->m['ref_subject_menu']}")->field('child_menu_id')->where($map)->findAll();
                    $this->assign('child_menu_array', $child_menu_array);
                }
                if(!empty($info['brand_id'])){
                    $brand_name = $this->brands[$info['brand_id']]['name'];
                    $this->assign('brand_name', $brand_name);
                    $this->assign('brand_id', $info['brand_id']);
                }
                if(!empty($info['designer_id'])){
                    $designer_name = $this->designers[$info['designer_id']]['name'];
                    $this->assign('designer_name', $designer_name);
                    $this->assign('designer_id', $info['designer_id']);
                }
                //dump($info);
                $this->assign('info', $info);
                //区域格式化
                $areaOption = $this->getAreaOption(intval($info['area_no']));
                $this->assign('areaOption', $areaOption);
            }
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $this->assign('listMenus', '');
            $this->assign('tid', $id);
            $this->assign('folder_id', $folder_id);
            if(empty($is_display))
                $this->display('Subject/theme_info');
        }
    }

    function getSubjectInfo() {
        $this->setSift();
        $id = intval($_POST['id']);
        $info = array();
        $title = trim($_POST['title']);
        if (empty($title))
            $this->error('名称不能为空');
        $info['title'] = $_POST['title'];
        $info['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
        if ($_FILES['title_picture_url']['size'] > 0) {
            $this->upFiles = _upload();
            //dump($this->upFiles);exit();
            if ($this->upFiles[0]['file_path'])
                $info['title_picture_url'] = $this->upFiles[0]['file_path'];
        }
        if ($_POST['folder_id']) {
            $info['folder_id'] = intval($_POST['folder_id']);
        }
        if ($_POST['show_edit']) {
            $info['show_edit'] = intval($_POST['show_edit']);
        }
        if ($_POST['month']) {
            $info['month'] = intval($_POST['month']);
        }
        $info['is_publish'] = intval($_POST['is_publish']);
        $info['publish_time'] = strtotime($_POST['publish_time']);
        if (empty($id)) {
            $info['add_time'] = time();
        }
        /* 目前还没有主题需要
        $fashion_desc = trim($_POST['fashion_desc']);
            if ($fashion_desc) {
                $info['has_desc'] = 1;
            }else{
                $info['has_desc'] = 0;
            }
        */
        if ( ACTION_NAME == 'underwearThemeAdd' || ACTION_NAME == 'underwearThemeEdit' ) {
            $info['menu_id'] = 102;
        } else {
            $info['menu_id'] = $this->cid;
        }

		//如果是 内衣专栏.品牌画册.内衣 款式的话，将写入款式关联表 (Jialiang Qin 2012.10.12)
		if( MODULE_NAME=='Brandinsp' && isset($_POST['special_column_id']) && in_array(4,$_POST['special_column_id']) ) {
			$info['menu_id'] = 100;
		}

        $info['child_menu_id'] = is_array($_POST['child_menu_id']) ? 0 : intval($_POST['child_menu_id']);
        $info['season_id'] = intval($_POST['season_id']);
        $info['designer_id'] = intval($_POST['designer_id']);
        //if(intval($_POST['brand_id']))
            $info['brand_id'] = intval($_POST['brand_id']);
        $info['book_id'] = intval($_POST['book_id']);
        $info['area_no'] = intval($_POST['area_id']);
        return $info;
    }


    function getFolderInfo() {
        $this->setSift();
        $id = intval($_POST['id']);
        $info = array();
        $title = trim($_POST['title']);
        if (empty($title))
            $this->error('名称不能为空');
        $info['title'] = $_POST['title'];
        $info['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
        if ($_FILES['title_picture_url']['size'] > 0) {
            $this->upFiles = _upload();
            //dump($this->upFiles);exit();
            if ($this->upFiles[0]['file_path'])
                $info['title_picture_url'] = $this->upFiles[0]['file_path'];
        }
        if ($_POST['folder_id']) {
            $info['folder_id'] = intval($_POST['folder_id']);
        }
        if ($_POST['show_edit']) {
            $info['show_edit'] = intval($_POST['show_edit']);
        }
        $info['is_publish'] = intval($_POST['is_publish']);
        $info['publish_time'] = strtotime($_POST['publish_time']);
        if (empty($id)) {
            $info['add_time'] = time();
        }
        $fashion_desc = trim($_POST['fashion_desc']);
        if ($fashion_desc) {
            $info['has_desc'] = 1;
        }else{
            if(in_array($this->cid, array('12'))){
                $info['has_desc'] = 0;
            }
        }

        $info['menu_id'] = $this->cid;
        $info['child_menu_id'] = is_array($_POST['child_menu_id']) ? 0 : intval($_POST['child_menu_id']);
        $info['season_id'] = intval($_POST['season_id']);
        $info['designer_id'] = intval($_POST['designer_id']);
        $info['brand_id'] = intval($_POST['brand_id']);
        $info['book_id'] = intval($_POST['book_id']);
        $info['area_no'] = intval($_POST['area_id']);
        return $info;
    }

    function setSift() {
        $info['menu_id'] = $this->ny_cid ? ($_POST['special_column_id'] == 4) ? $this->ny_cid : $this->cid : $this->cid;
        if ($_POST['child_menu_id'])
            $info['child_menu_id'] = intval($_POST['child_menu_id']);
        //if ($_POST['sort'])
            //$info['sort_id_list'] = $_POST['sort'];
        if ($_POST['season_id'])
            $info['season_id_list'] = intval($_POST['season_id']);
        if ($_POST['designer_id'])
            $info['designer_id_list'] = intval($_POST['designer_id']);
        if ($_POST['brand_id'])
            $info['brand_id_list'] = intval($_POST['brand_id']);
        if ($_POST['book_id'])
            $info['book_id_list'] = intval($_POST['book_id']);
        if ($_POST['area_id'])
            $info['area_no_list'] = intval($_POST['area_id']);
        if ($_POST['detail_id'])
            $info['detail_id_list'] = intval($_POST['detail_id']);
        if ($_POST['acc'])
            $info['acc_id_list'] = $_POST['acc'];
        if ($_POST['color'])
            $info['color_id_list'] = $_POST['color'];
        if ($_POST['fashion'])
            $info['fashion_id_list'] = $_POST['fashion'];
        if ($_POST['material'])
            $info['material_id_list'] = $_POST['material'];
        if ($_POST['pattern'])
            $info['pattern_no_list'] = $_POST['pattern'];
        if ($_POST['style'])
            $info['style_id_list'] = $_POST['style'];
        $dInfo = $info;

        if(empty($info)){
            return false;
        }

        $model = M('AttributeSift');

        $columns = $_POST['special_column_id'];
        $sorts = $_POST['sort_id'];
        $map = array();
        $map['menu_id'] = $info['menu_id'];

        $info['child_menu_id'] ? $map['child_menu_id'] = $info['child_menu_id'] : '';
        if($sorts){
            foreach($sorts as $val){
                $info['sort_id'] = $map['sort_id'] = (int)$val;
                if($columns){
                    foreach($columns as $va){
                        $info['special_column_id'] = $map['special_column_id'] = (int)$va;
                        $exist_sift = $model->where($map)->find();
                        $exist_sift['menu_id'] = $this->ny_cid ? $exist_sift['special_column_id'] == 4 ? $this->ny_cid : $this->cid : $this->cid;
                        $this->formatSift($info,$exist_sift);
                    }
                }else{
                    $info['special_column_id'] = $map['special_column_id'] = 0;
                    $exist_sift = $model->where($map)->find();
                    $this->formatSift($info,$exist_sift);
                }
            }
        }else{
            $info['sort_id'] = $map['sort_id'] = 0;
            if($columns){
                foreach($columns as $va){
                    $info['special_column_id'] = $map['special_column_id'] = (int)$va;
                    $exist_sift = $model->where($map)->find();
                    $exist_sift['menu_id'] = $this->ny_cid ? $exist_sift['special_column_id'] == 4 ? $this->ny_cid : $this->cid : $this->cid;
                    $this->formatSift($info,$exist_sift);
                }
            }else{
                $info['special_column_id'] = $map['special_column_id'] = 0;
                $exist_sift = $model->where($map)->find();
                $this->formatSift($info,$exist_sift);
            }
        }
    }

    protected function formatSift($info,$exist_sift){
        $model = M('AttributeSift');
        if($exist_sift){
            foreach($info as $k=>$v){
                if(in_array($v,explode(',', $exist_sift[$k]))){
                    $info[$k] = $exist_sift[$k];
                }else{
                    $info[$k] = $exist_sift[$k].','.$info[$k];
                }
            }
            $model->where(array('id'=>$exist_sift['id']))->save($info);
        }else{
            $model->add($info);
        }
        //echo $model->getLastSql();exit;
    }
    public function getSiftInfo($info, $sInfo) {
        if ($info['season_id_list']) {
            $arr = $sInfo['season_id_list'] ? explode(',', $sInfo['season_id_list']) : array();
            foreach (explode(',', $info['season_id_list']) as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['season_id_list'] = implode(',', $arr);
        }
        if ($info['designer_id_list']) {
            $arr = $sInfo['designer_id_list'] ? explode(',', $sInfo['designer_id_list']) : array();
            foreach (explode(',', $info['designer_id_list']) as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['designer_id_list'] = implode(',', $arr);
        }
        if ($info['brand_id_list']) {
            $arr = $sInfo['brand_id_list'] ? explode(',', $sInfo['brand_id_list']) : array();
            foreach (explode(',', $info['brand_id_list']) as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['brand_id_list'] = implode(',', $arr);
        }
        if ($info['book_id_list']) {
            $arr = $sInfo['book_id_list'] ? explode(',', $sInfo['book_id_list']) : array();
            foreach (explode(',', $info['book_id_list']) as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['book_id_list'] = implode(',', $arr);
        }
        if ($info['area_no_list']) {
            $arr = $sInfo['area_no_list'] ? explode(',', $sInfo['area_no_list']) : array();
            foreach (explode(',', $info['area_no_list']) as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['area_no_list'] = implode(',', $arr);
        }
        if ($info['detail_id_list']) {
            $arr = $sInfo['detail_id_list'] ? explode(',', $sInfo['detail_id_list']) : array();
            foreach (explode(',', $info['detail_id_list']) as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['detail_id_list'] = implode(',', $arr);
        }
        if ($info['sort_id_list']) {
            $arr = $sInfo['sort_id_list'] ? explode(',', $sInfo['sort_id_list']) : array();
            foreach ($info['sort_id_list'] as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['sort_id_list'] = implode(',', $arr);
        }
        if ($info['acc_id_list']) {
            $arr = $sInfo['acc_id_list'] ? explode(',', $sInfo['acc_id_list']) : array();
            foreach ($info['acc_id_list'] as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['acc_id_list'] = implode(',', $arr);
        }
        if ($info['color_id_list']) {
            $arr = $sInfo['color_id_list'] ? explode(',', $sInfo['color_id_list']) : array();
            foreach ($info['color_id_list'] as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['color_id_list'] = implode(',', $arr);
        }
        if ($info['fashion_id_list']) {
            $arr = $sInfo['fashion_id_list'] ? explode(',', $sInfo['fashion_id_list']) : array();
            foreach ($info['fashion_id_list'] as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['fashion_id_list'] = implode(',', $arr);
        }
        if ($info['material_id_list']) {
            $arr = $sInfo['material_id_list'] ? explode(',', $sInfo['material_id_list']) : array();
            foreach ($info['material_id_list'] as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['material_id_list'] = implode(',', $arr);
        }
        if ($info['pattern_no_list']) {
            $arr = $sInfo['pattern_no_list'] ? explode(',', $sInfo['pattern_no_list']) : array();
            foreach ($info['pattern_no_list'] as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['pattern_no_list'] = implode(',', $arr);
        }
        if ($info['style_id_list']) {
            $arr = $sInfo['style_id_list'] ? explode(',', $sInfo['style_id_list']) : array();
            foreach ($info['style_id_list'] as $v) {
                if (!in_array($v, $arr)) {
                    $arr[] = $v;
                }
            }
            $info['style_id_list'] = implode(',', $arr);
        }
        return $info;
    }

    /**
     * set subject other attr
     * @param type $id 主题id
     * @param type $id 文件夹id
     */
    protected function setThemeOther($id,$fid = null) {
        $this->setPicPublish($id);
        $this->setThemeExtend($id);
        $this->setThemeSort($fid,$id);
        $this->setThemeFashion($fid,$id);
        $this->setThemeSpecialColumn($fid,$id);
        $this->setThemeStyle($fid,$id);
        $this->setThemeAcc($id);
        $this->setRecommend($id);
        $this->setThemeMenu($id);
        $this->setThemeCraft($id);
        if ( Cookie::get('themeAdd') ) {
            $this->updataRandPic($this->cid,$id);
        }
    }

    /**
     *在编辑主题的时候，图片要继承主题的显示
     * @param type $id
     */
    protected function setPicPublish($id,$is_publish=null){
        $id = intval($id);
        if ( empty($id) ){
            return FALSE;
        }
        $map['subject_id'] = $id;
        $map['is_publish'] = array('egt',0);
        $dataPP['is_publish'] = $is_publish ? $is_publish : intval($_REQUEST['is_publish']) ? 1 : 0;
        if ( $dataPP['is_publish'] ) {
            $publish_time = strtotime($_REQUEST['publish_time']);
            $dataPP['publish_time'] = $publish_time ? $publish_time : (strtotime($_REQUEST['display_time']) ? strtotime($_REQUEST['display_time']) : 0);
        }
//		$data['area_no'] = $_REQUEST['area_id'];
//		$data['season_id'] = $_REQUEST['season_id'];
//		$data['brand_id'] = $_REQUEST['brand_id'];
        $this->modelP->where($map)->save($dataPP);
        //echo $this->modelP->getLastSql();exit;
    }

    protected function setThemeFolder($fid) {
        if(empty($fid)) $this->error("文件夹has_type字段更新失败");
        $this->updateCatwalkHasType($fid);
//        $whereTmp['folder_id'] = $fid;
//        $where['id'] = $fid;
//        $field = "catwalk_type";
//        $list =$this->modelT->where($whereTmp)->field($field)->select();
//        $has_type = 0;
//        if(isset ($list) && !empty ($list)) foreach ($list as $v){
//            $has_type += $v['catwalk_type'];
//        }
//        $infoTmp['has_type'] = $has_type;
//        $this->modelF->where($where)->save($infoTmp);
    }
    protected function delThemeOther($id) {
        $this->delThemeExtend($id);
        $this->delThemeAcc($id);
        $this->delRecommend($id);
    }

    protected function getRecommend($id, $is_folder = false) {
        $id = intval($id);
        if (empty($id))
            return false;
        $is_folder = $is_folder ? 1 : 0;
        $where['subject_id'] = $id;
        $where['is_folder'] = $is_folder;
        $MODEL = D('SysRecommend');
        $info = $MODEL->field('picture_url,position_id')->where($where)->find();
        if ($info) {
            $MODELP = D('SysRecommendPosition');
            $row = $MODELP->field('parent_id')->find($info['position_id']);
            $info['position_parent_id'] = $row['parent_id'];
        }
        $info['recom_img'] = $info['picture_url'] ? show_pic_path($info['picture_url']) : '';
        unset($info['picture_url']);
        return $info;
    }

    protected function setRecommend($id, $is_folder = false) {
        $id = intval($id);
        if (empty($id))
            return false;
        $is_folder = $is_folder ? 1 : 0;
        $is_publish = intval($_POST['is_publish']);
        $info['position_id'] = intval($_POST['recomPosition']);
        if ($info['position_id'] && $is_publish) {
            if ($_FILES['recom_img']['size'] > 0) {
                if ($_FILES['title_picture_url']['size'] > 0) {
                    $key = 1;
                } else {
                    $key = 0;
                    $this->upFiles = _upload();
                }
                if ($this->upFiles[$key]['file_path'])
                    $info['picture_url'] = $this->upFiles[$key]['file_path'];
            }
            $info['subject_id'] = $id;
            $info['is_folder'] = $is_folder;
            $info['title'] = $_POST['title'];
            $info['menu_id'] = $this->cid;
            $info['recommend_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
            $info['recommend_time'] = time();
            $where['subject_id'] = $id;
            $where['is_folder'] = $is_folder;
            //dump($info);exit();
            $MODEL = D('SysRecommend');
            $row = $MODEL->field('id')->where($where)->find();
            if ($row) {
                $MODEL->where($where)->save($info);
            } else {
                //$info['describe'] = $_POST['content'];
                $MODEL->add($info);
            }
            //echo $MODEL->getLastSql();exit();
        } else {
            $this->delRecommend($id,$is_folder);
        }
    }

    protected function delRecommend($id, $is_folder = false) {
        $id = intval($id);
        if (empty($id))
            return false;
        $is_folder = $is_folder = $is_folder ? 1 : 0;
        $where['subject_id'] = $id;
        $where['is_folder'] = $is_folder;
        $model = M('SysRecommend');
        $model->where($where)->delete();
    }
    /**
     * add/update subject extend
     * @param type $id
     */
    protected function setThemeExtend($id) {
        $id = intval($id);
        $model = M("{$this->m['subject_extend']}");
        $info['subject_id'] = $id;
        $info['menu_id'] = $this->cid;
        $info['child_menu_id'] = intval($_POST['child_menu_id']);
        if ( $_POST['show_edit'] == 1 ){
            $info['content'] = stripslashes($_POST['content']);
        }
        $info['lable'] = $this->getLable($_POST);
        if( in_array($this->cid, array(14,17,101))){//企划方案
            $info['title_describe'] = trim($_POST['title_describe']);
        }
		if($this->cid == 24 && trim($_POST['title_describe'])){//图案
            $info['title_describe'] = trim($_POST['title_describe']);
        }
        $where = array('subject_id' => $id, 'menu_id' => $this->cid);
        $row = $model->where($where)->select();
        if ($row) {
            $model->where($where)->save($info);
        } else {
            $model->add($info);
        }
        //echo $model->getLastSql();exit();
    }

    /**
     * delete Extend
     * @param type $id
     */
    protected function delThemeExtend($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['subject_extend']}");
        $model->where($where)->delete();
    }

    /**
     * add/update acc
     * @param int $id
     */
    protected function setThemeAcc($id) {
        $id = intval($id);
        $model = M("{$this->m['ref_subject_acc']}");
        $info['subject_id'] = $id;
        $info['menu_id'] = $_POST['menu_id'];
        $info['child_menu_id'] = intval($_POST['child_menu_id']);
        $arrs = $_POST['acc'];
        $arrs = is_array($arrs) ? $arrs : array($arrs);
        if ($arrs) {
            $this->delThemeAcc($id);
            foreach ($arrs as $key => $val) {
                $info['acc_id'] = $val;
                $info['menu_id'] = $this->cid;;
                $model->add($info);
                //echo $model->getLastSql();
            }
        }
    }

    /**
     * delete acc
     * @param type $id
     */
    protected function delThemeAcc($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['ref_subject_acc']}");
        $model->where($where)->delete();
    }

    /**
     * batch action
     */
    public function themeBatch() {
        //dump($_REQUEST);exit;
        $actType = trim($_REQUEST['acttype']);
        $ids = $_REQUEST['ids'];
        $folder_id = intval($_REQUEST['folder']);
        $columntype = intval($_REQUEST['columntype']);
        $info_menu_id = $_REQUEST['is_ny'] ? $this->ny_cid : $this->cid;
        if ($actType == 'remove') {
            $this->redirect('themeDelete', array('ids' => implode(',', $ids),'folder' => $folder_id,'ny_cid'=>$info_menu_id));
            exit;
        } elseif ($actType == 'column_yes') {
            $this->redirect('themeColumn', array('ids' => implode(',', $ids),'columntype' => $columntype));
            exit;
        } else {
            if ($actType == 'display_yes') {
                $dataT['is_publish'] = $dataP['is_publish'] = $dataS['is_publish'] = 1;
                if($_REQUEST['display_time']){
                    $dataT['publish_time'] = $dataP['publish_time'] = $dataS['publish_time'] = strtotime($_REQUEST['display_time']);
                }
            } else if ($actType == 'display_no') {
                $dataT['is_publish'] = $dataP['is_publish'] = $dataS['is_publish'] = 0;
            } else if ($actType == 'folder_yes') {
                $folder_id = intval($_REQUEST['folder']);
                $lable_id = intval($_REQUEST['lable_id']);
                $dataT['folder_id'] = $folder_id;
                $dataT['lable_id'] = $lable_id;
                $dataT['publish_time'] = strtotime($_REQUEST['display_time']);
            } else if ($actType == 'folder_no') {
                $dataT['folder_id'] = 0;
                $dataT['lable_id'] = 0;
            }
            foreach ($ids as $key => $id) {
                if ( $actType == 'display_no' ) {
                    $this->setRecommend($id, false);
                }
                $where['id'] = $id;
                $this->modelT->where($where)->save($dataT);
                $whereP = array('subject_id' => $id);
                $whereP['is_publish'] = array('egt',0);
                $this->modelP->where($whereP)->save($dataP);
                //相应的调整搜索表中这个主题下的图片
                $picture_list = $this->modelP->field('id')->where($whereP)->findAll();
                if($picture_list){
                    foreach($picture_list as $ke=>$va){
                        if ( $this->cid == 22 || $this->cid == 102 ) {
                            $whereS = array('picture_id' => $va['id']);
                            $whereS['is_publish'] = array('egt',0);
                            $this->modelS->where($whereS)->save($dataS);
                        }
                        if( $dataP['is_publish'] == 0){
                            $this->delSearchPicture($va['id']);
                        }else{
                            $this->setSearchPicture($va['id'],$id);
                        }
                    }
                }
                if ( $this->cid == 12 ) {
                    $whereid['id'] = $id;
                    $tmp_fid = $this->modelT->where($whereid)->getfield('folder_id');
                    $this->updateCatwalkHasType($tmp_fid);
                }
            }
            if($info_menu_id == 12 && $folder_id) {
                $this->updateCatwalkHasType($folder_id);
            }
            $this->success('操作成功！');
        }
    }

    public function themeColumn($subid_arr = null) {
        $columntype = $_REQUEST['columntype'];
        if ( empty($subid_arr) ) {
            $ids = $_REQUEST['ids'];
            $ids = explode(',', $ids);
        } else {
            $ids = $subid_arr;
        }
        if (empty($ids))
            return false;
        
        $model = M("{$this->m['ref_subject_column']}");
        $modelS = M("{$this->m['subject']}");
        $modelSP = M("{$this->m['picture']}");
        foreach ($ids as $id) {
            $mapS = $where = array();
            $mapS['id'] = $where['subject_id'] = $id;
            $listS = $modelS->where($mapS)->find();
            if( $listS['menu_id'] == 100 ){
                continue;
            }
            //$where['menu_id'] = $this->cid;
            $data['special_column_id'] = $columntype;
            if ( $columntype == 0 ) {
                //删除
                $list = $model->where($where)->select();
                if($list) {
                    $model->where($where)->delete();
                }
            } else {
                //更新
                $list = $model->where($where)->select();
                if($list) {
                    $list = $model->where($where)->delete();
                }
                $data_add['special_column_id'] = $columntype;
                $data_add['subject_id'] = $id;
                if ( $this->cid == 20 && $columntype == 4 ) {
                    $data_add['menu_id'] = $this->ny_cid;
                }else{
                    $data_add['menu_id'] = $this->cid;
                }
                $model->where($where)->add($data_add);
            }
            $where['is_publish'] = array('egt',0);
            $pid_list = $modelSP->field('id')->where($where)->findall();
            $pid_list = $this->getIdList($pid_list);
            $this->pictureColumn($pid_list);
        }
        if ( empty($subid_arr) ) {
            $this->success('批量修改专栏成功！');
        }
    }

    public function updateCatwalkHasType($folder_id){
        $whereT = array('folder_id' => $folder_id, 'menu_id' => $this->cid, 'is_publish' => 1);
        $sum_catwalk_type = $this->modelT->where ( $whereT )->sum ('catwalk_type');
        $data['has_type'] = $sum_catwalk_type ? $sum_catwalk_type : 0;
        $whereF = array('id' => $folder_id, 'menu_id' => $this->cid);
        $this->modelF->where($whereF)->save($data);
    }

    //得到文件夹主题数
    public function getFolderThemeCount($folder_id){
        $where['id'] = $info['folder_id'] = $folder_id;
        $info['is_publish'] = array('neq',-1);
        $data['child_subject_count'] = $this->modelT->where($info)->count();
        $this->modelF->where($where)->save($data);
        //echo $this->modelT->getLastSql();
        //exit();
    }
    public function themeDelete() {
        $ids = $_REQUEST['ids'];
        $folder_id = $_REQUEST['folder'];
        $info_menu_id = $_REQUEST['ny_cid'];
        if (empty($ids))
            return false;
        $ids = explode(',', $ids);
        $errorNum = 0;
        $info = array('is_publish' => -1);
        $info['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
        foreach ($ids as $id) {
            //$this->modelT->where(array('id' => $id, 'menu_id' => $info_menu_id))->save($info) ? '' : $errorNum++;
			$selfinfo = $this->modelT->where(array('id' => $id ))->find();
			if( $selfinfo['menu_id'] == 100 )
				$info_menu_id = 100;

			$this->modelT->where(array('id' => $id ))->save($info) ? '' : $errorNum++;
            if ( $errorNum == 0 ) {
                $this->delRecommend($id,false);
            }
            //主题管理中主题删除后，对文件夹的child_subject_count进行修改
            if ( $folder_id == 0 && in_array($info_menu_id, array(11,12,13,15,18,24, 100)) ) {
                $this->setFCount($id);
            }
            $row = $this->modelP->field('id')->where(array('subject_id' => $id, 'menu_id' => $info_menu_id))->select();
            //dump($row);exit();
            if ($row) {
                $tmp = array();
                foreach ($row as $v) {
                    $tmp[] = $v['id'];
                }
            }
            if ($tmp)
                $this->picDelete($tmp);
        }
        if($info_menu_id == 12) {
            $this->updateCatwalkHasType($folder_id);
        }
        if(!empty($folder_id) && $errorNum == 0){
            $this->getFolderThemeCount($folder_id);
        }
        $errorNum > 0 ? $this->error('放入回收站失败！') : $this->success('放入回收站成功！');
    }

    public function setFCount($tid){
        if ( empty( $tid ) ) {
            return false;
        }
        $fid = $this->modelT->getField('folder_id',array('id'=>$tid));
        $this->getFolderThemeCount($fid);
    }
    /**
     * 图片列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function picList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } }
            $this->error('参数错误！');
        $action_link = array();
        $subject_id = intval($_REQUEST['subject_id']);
        if ($subject_id) {
            $themeI = $this->modelT->where(array('id' => $subject_id))->field('menu_id,title,picture_count')->find();
            //echo $this->modelT->getlastsql();var_dump($themeI);
			$this->cid = $themeI['menu_id'];

            $currentName = '-主题:' . $themeI['title'];
            $info['tmpTitle'] =  $themeI['title'];
            $action_link[] = array('text' => '返回主题列表', 'href' => Cookie::get('_currentThemeUrl_'));
        }
        $this->assign('info', $info);
        $this->assign('currentName', $currentName . '-图片列表');

        if (isset($subject_id) && !empty($subject_id) && !in_array($this->cid,array('12')) && ACTION_NAME !== 'underwearPicList') {
			$is_ny_str = '';
			if( isset($_GET['is_ny']) && $_GET['is_ny'] )
				$is_ny_str = '/is_ny/1';
			$action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加图片','url':'__URL__/picAdd/subject_id/{$subject_id}{$is_ny_str}','width':'750','height':'500'});");
        }
        if ( ACTION_NAME == 'underwearPicList' ) {
            $action_link[] = array('text' => '添加内衣图片', 'href' => "javascript:Box.open({'id':'add','title':'添加内衣图片','url':'__URL__/underwearPicAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        }
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $this->assign('action_link', $action_link);
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['picture_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }//dump($map);exit;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $this->assign('checkBrand',$checkBrandName);
        }
        if($book_id){
            $checkBookName = $this->books[$book_id]['name'];
            $checkBook = "";
            $checkBook .= "<option value=".$book_id." selected='selected'>$checkBookName</option>";
            $this->assign('checkBook',$checkBook);
        }

        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'publish_time';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
        if ($subject_id) {
            $map['subject_id'] = $subject_id;
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_picture_sort_original'].' ps ON ps.picture_id='.$this->m['picture_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ps.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ps.sort_id'] = $sort_id;
            }
            $field .=",ps.sort_id";
        }
        //风格筛选
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id){
			$join[] = $this->m['ref_picture_fashion_original'].' sf ON sf.subject_id='.$this->m['picture_original'].'.id';
			$map['sf.fashion_id'] = $fashion_id;
            $field .=",sf.fashion_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_picture_column_original'].' pc ON pc.picture_id='.$this->m['picture_original'].'.id';
            if($column_id == 6){
                //$map['pc.special_column_id'] = array('exp','is null');
                $map['pc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['pc.special_column_id'] = $column_id;
            }
            $field .=",pc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_style_original'].' pst ON pst.picture_id='.$this->m['picture_original'].'.id';
			$map['pst.style_id'] = $style_id;
            $field .=",pst.style_id";
        }
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数  主题表保存有图片数量字段 field:picture_count,前提是“$subject_id”不为空才能调用这个字段 暂时注销
//        if (!empty($subject_id)) {
//            $count = $themeI['picture_count'];
//        } else {
            import('ORG.Util.DataCount');
            $moldel = new DataCount();
            $count = $moldel->getCount("{$this->m['picture']}", $map, $join);
//        }
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelP->relation(array('sort_id','special_column_id','style'))->where($map)->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);exit();
            //echo $this->modelP->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['columnStr'] = implode(',', $column);

                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            if ($this->styles[$v['style_id']]['name'])
                                $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['styleStr'] = implode(',', $style);
                    if ($this->fashions)
                        $voList[$key]['fashionStr'] = $this->fashions[$val['fashion_id'][0]['fashion_id']]['name'];
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    if( in_array($this->cid,array(12,16,17,21,22,24))){
                        $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'650','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    }
                    if ( MODULE_NAME == 'UnderwearInvogue' ) {
                        $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}/is_ny/1','width':'650','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    }
                    if($this->cid == 14){
                        $voList[$key]['description'] = M('RefPictureExtend')->getField('description',array('menu_id'=>$this->cid,'picture_id'=>$val['id']));
                        $voList[$key]['description'] = strip_tags($voList[$key]['description']);
                    }
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }

    /**
     * 图片上传
     */
    protected function picAdd($is_display = null, $is_ny = null) {
        $this->assign('SESSIONID', session_id());
        $this->setConfig();
        $subject_id = intval($_GET['subject_id']);
		$is_ny = $is_ny ? $is_ny : $_GET['is_ny'];
        if ($subject_id) {
            $info_menu_id = $is_ny ? $this->ny_cid : $this->cid;
            $info = $this->modelT->relation(array('SysUser','sort_id','special_column_id','style'))->where(array('id' => $subject_id))->find();
			$this->cid = $this->ny_cid = $info_menu_id = $info['menu_id'];
            //dump($info);exit();
            if ($info['sort_id']) {
                $tmp = array();
                foreach ($info['sort_id'] as $key => $val) {
                    $tmp[] = $val['sort_id'];
                }
                $info['sort_id'] = $tmp;
                if (empty($info['sort_id'])) {
                    $info['sort_id'] = array($info['sort_id']);
                }
                $info['sort_id_str'] = implode(",", $info['sort_id']);
            }
            if ($info['special_column_id']) {
                $tmp = array();
                foreach ($info['special_column_id'] as $key => $val) {
                    $tmp[] = $val['special_column_id'];
                }
                $info['special_column_id'] = $tmp;
                if (empty($info['special_column_id'])) {
                    $info['special_column_id'] = array($info['special_column_id']);
                }
                $info['special_column_id_str'] = implode(",", $info['special_column_id']);
            }
            if ($info['style']) {
                $tmp = array();
                foreach ($info['style'] as $key => $val) {
                    $tmp[] = $val['style_id'];
                }
                $info['style'] = $tmp;
                if (empty($info['style'])) {
                    $info['style'] = array($info['style']);
                }
                $info['style_id_str'] = implode(",", $info['style']);
            }
            $info['publish_time'] = $info['publish_time'] ? date('Y-m-d H:i:s', $info['publish_time']) : '';
            //dump($info);
        }
        if (empty($info)) {
            $info['publish_time'] = date('Y-m-d H:i:s', time());
        }
        $this->assign('info', $info);
        //区域格式化
        $areaOption = $this->getAreaOption(0);
        $this->assign('areaOption', $areaOption);
        $this->assign('subject_id', $subject_id);
        Cookie::set('_currentTmpPicUrl_', __SELF__);
        $this->assign('listMenus', '');
        $this->assign('user_id', Cookie::get(C('USER_AUTH_KEY')));
        //品牌画册 内衣没有独立出去  所以在这里判断column是否为4
        $cid_tmp = $this->ny_cid ? ($info['special_column_id']['0'] == 4) ? $this->ny_cid : $this->cid : $this->cid;
        $this->assign('cid', $cid_tmp);
        if ( $cid_tmp == 100 ){
            $this->assign('is_ny', 1);
        }
        if ( $is_ny ) {
            $this->assign('is_ny', 1);
        }
        if(empty($is_display))
            $this->display('Subject/picture_info');
    }

    /**
     * 临时图片列表
     */
    public function picTmpList() {
        $listArr = $this->picTmpFormat();
        $this->assign('listArr', $listArr);
        $this->assign('subject_id', intval($_REQUEST['subject_id']));
        $action_link[] = array('text' => '返回上传', 'href' => Cookie::get('_currentTmpPicUrl_'));
        $this->assign('action_link', $action_link);
        $this->assign('listMenus', '');
        $this->display('Subject/picture_tmp_list');
    }

    /**
     * 样式化临时据列表
     * @param   $where  查询条件
     * @return  array
     */
    protected function picTmpFormat() {
        $where = array();
        $user_auth = Cookie::get(C('USER_AUTH_KEY'));
        intval($_REQUEST['is_ny']) ? $this->assign('is_ny', 1) : $this->assign('is_ny', 0);
        $where['add_user_id'] = intval($user_auth);
        $where['menu_id'] = intval($_REQUEST['is_ny']) ? $this->ny_cid : $this->cid;
        $where['subject_id'] = intval($_REQUEST['subject_id']);

        $model = D('SharePicturesTmp');
        $field = 'id,source_file_name AS img_name,url AS img_path,is_publish,publish_time,add_user_id,add_time,subject_id,menu_id,child_menu_id,season_id,area_no,brand_id,designer_id,book_id,sort_id,column_id,style_id,pattren_type_id,pattren_child_type_id,sort_id,column_id';
        $rows = $model->field($field)->where($where)->order(array('source_file_name' => 'ASC'))->findAll();
        //echo $model->getLastSql();exit();
        //dump($rows);exit();
        $listArr = array();
        if ($rows) {
            foreach ($rows as $key => $val) {
                $rows[$key]["img"] = show_pic_path($val["img_path"]);
            }
            foreach ($rows as $k => $v) {
                if (strlen($v["img_name"]) == 4) {//取大图
                    $listArr[$v["img_name"]] = $v;
                    $zip = array();
                    foreach ($rows as $ke => $va) {
                        $t_n = explode('_', $va["img_name"]);
                        if ($v["img_name"] == $t_n[0]) {
                            if (isset($t_n[1])) {
                                if ($t_n[1] == 'rar') {
                                    $zip['jrp'] = $va;//['img_path'];
                                }
                                if ($t_n[1] == 'ai') {
                                    $zip['ai'] = $va;//['img_path'];
                                }
                                if ($t_n[1] == 'cdr') {
                                    $zip['cdr'] = $va;//['img_path'];
                                }
                                if ($t_n[1] == 'psd') {
                                    $zip['psd'] = $va;//['img_path'];
                                }
                            }
                        }
                    }
                    $listArr[$v['img_name']]['zip'] = $zip;// ? serialize($zip) : '';
                }
                $t_n = explode('_', $v["img_name"]);
                if (in_array($t_n[1], array('rar','ai', 'cdr', 'psd'))) {
                    continue;
                }
                if (strlen($v["img_name"]) == 5) {//取大图的缩略图
                    $listArr[substr($v["img_name"], 0, 4)]["s"] = $v;
                }
                if (strlen($v["img_name"]) == 8) {//取副图
                    $listArr[substr($v["img_name"], 0, 4)]["f"][$v["img_name"]] = $v;
                }
                if (strlen($v["img_name"]) == 9) {//取副图的缩略图
                    $listArr[substr($v["img_name"], 0, 4)]["f"][substr($v["img_name"], 0, 8)]["s"] = $v;
                }
            }
        }
        return $listArr;
    }

    /**
     * 分类图片
     */
    public function picTmpBatch() {
        $subject_id = intval($_REQUEST['subject_id']);
        $acttype = trim($_REQUEST['acttype']);
        $batch_id = $_REQUEST['batch_id'];//全选
		$this->cid = intval($_REQUEST['is_ny']) ? $this->ny_cid : $this->cid;

        if (empty($acttype))
            $this->error('对不起，请选择操作类型！');
        $model = D('SharePicturesTmp');
        if ($acttype == 'remove') {
            foreach ($batch_id as $id) {
                $id = intval($id);
                $row = $model->field('url AS img_path')->find($id);
                @unlink($_SERVER['DOCUMENT_ROOT'] . '/' . C('IMG_ROOT') . $row["img_path"]);
                $model->delete($id);
            }
            $this->success('删除成功！');
        } else {
            $listArr = $this->picTmpFormat();
            //dump($listArr);exit();
            if ($listArr) {
                foreach ($listArr as $key => $val) {
                    if (!$val["s"]) {
                        $this->error($val["img_name"] . ' 的小图片似乎没有吧？');
                    } else if ( $val["f"] && $val["menu_id"] != 22  ){
                        $this->error('此栏目无需上传附图！');
                    } else {
                        $page_no = intval(substr($val["img_name"], 1, 4));
                        $picInfo = array();
                        $picInfo["small_picture_url"] = $val["s"]["img_path"];
                        $picInfo["big_picture_url"] = $val["img_path"];
                        $picInfo["add_user_id"] = $val["add_user_id"];
                        $picInfo["add_time"] = $val["add_time"];
                        $picInfo["publish_time"] = $val["add_time"];
                        $picInfo["menu_id"] = $val["menu_id"];
                        $picInfo["subject_id"] = $subject_id;
                        $picInfo['child_menu_id'] = $val['child_menu_id'];
                        $picInfo["area_no"] = $val["area_no"];
                        $picInfo["designer_id"] = $val["designer_id"];
                        $picInfo["brand_id"] = $val["brand_id"];
                        $picInfo["book_id"] = $val["book_id"];
                        $picInfo["season_id"] = $val["season_id"];
                        $picInfo["page_no"] = $page_no;
                        $picInfo["is_publish"] = $val["is_publish"];
                        $picInfo["publish_time"] = $val["publish_time"];
                        //$picInfo['sort_id'] = $val['sort_id'];
                        //$picInfo['special_column_id'] = $val['column_id'];
                        //echo '<pre>';
                        //dump($val);exit();
                        $pid = $this->modelP->add($picInfo);
                        //echo $this->modelP->getLastSql();exit();
                        //$pid = "17038 ";
                        $this->setSift();
                        //$this->setSubjectPicture($subject_id, $pid);
                        $this->setPicExtend($pid, $val);
                        $this->setPicSort($pid,$subject_id);
                        $this->setPicColumn($pid, $subject_id);
                        $this->setPicStyles($pid, $subject_id);
                        $this->setPicMenu($pid, $subject_id);
                        if ($pid && $type != 'detail') {
                            //插入附图
                            if ($val["f"]) {
                                foreach ($val["f"] as $k => $v) {
                                    if (!$v["s"]) {
                                        $this->error($v["img_name"] . ' 的小图片似乎没有吧？');
                                    } else {
                                        $aInfo = array();
                                        $aInfo["menu_id"] = $val["menu_id"];
                                        $aInfo['child_menu_id'] = $val['child_menu_id'];
                                        $aInfo["picture_id"] = $pid;
                                        $aInfo["add_user_id"] = $v["add_user_id"];
                                        $aInfo["small_picture_url"] = $v["s"]["img_path"];
                                        $aInfo["big_picture_url"] = $v["img_path"];
                                        $aInfo["add_time"] = $v['add_time'] + $k;
                                        $this->modelS->add($aInfo);
                                    }
                                }
                            }
                        }
                        //图片搜索表处理  这里不需要是因为在添加的时候默认是不显示的，所以不需要添加到搜索表
                        //$this->setSearchPicture($pid);
                        if ($type != 'detail' && $subject_id > 0) {
                            $this->setPictureCount($subject_id,'add');
                        }
                    }
                }
            }
//            if ($type != 'detail' && $subject_id > 0) {
//                $this->setPictureCount($subject_id,'add');
//            }
            $model->where(array('menu_id' => $this->cid, 'subject_id' => $subject_id))->delete();
            //成功提示
            $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
            $this->success('操作成功!');
        }
    }
    /**
     * 统计主题图片总数
     * @param int $id 主题ID
     * @return boolean
     */
    public function setPictureCount($id,$act = null) {
        $id = intval($id);
        if (empty($id))
            return false;
        $where_cid = intval($_REQUEST['is_ny']) ? $this->ny_cid : $this->cid;
        $where = array('menu_id' => $where_cid, 'id' => $id);
        $tmp_cid = $_REQUEST['cid'] ? $_REQUEST['cid'] : $this->cid;
        $m = getCidModel($tmp_cid);
        $this->assign('listMenus', $listMenus);
        if (isset($m['subject'])) {
            $modelTmp = D("{$m['subject']}");
        }
        $num = $modelTmp->where($where)->getField('picture_count');
        //echo $modelTmp->getlastsql();
        if($num == 0 && $act != 'add'){
            $modelTmp->where($where)->save(array('picture_count' => 0));
        }else{
            if($act == "add"){
                $data['picture_count'] = array('exp','picture_count+1');
                $modelTmp->where($where)->save($data);
            }elseif($act == "del"){
                $data['picture_count'] = array('exp','picture_count-1');
                $modelTmp->where($where)->save($data);
            }
        }
        //echo $modelTmp->getLastSql();;exit();
    }
    protected function setTotlePictureCount($id) {
        $id = intval($id);
        if (empty($id))
            return false;
        $map['subject_id'] = $id;
        $map['menu_id'] = $this->cid;
        $map['is_publish'] = array('egt', 0);
        $count = $this->modelP->where($map)->count('*');
        //echo $this->modelT->getlastsql();exit();
        $where = array('menu_id' => $this->cid, 'id' => $id);
        $this->modelT->where($where)->save(array('picture_count' => intval($count)));
    }

    /**
     * 图片分类   subject_id/34578/picture_id/134522/ids/134522
     */
    public function picCategory($is_display = null) {
        $picture_id = intval($_REQUEST['picture_id']);
        $this->assign('picture_id', $picture_id);
        $ids = $_REQUEST['ids'];
        if ($_POST) {
            $idArr = explode(',', $ids);
            if ($idArr) {
                $info = array();
                $user_auth = Cookie::get(C('USER_AUTH_KEY'));
                $info['add_user_id'] = intval($user_auth);
                $picture_id = $_REQUEST['picture_id'];
                if ((intval($_REQUEST['child_menu_id']) || intval($picture_id)) && $_POST['change_child_menu_id'])
                    $info['child_menu_id'] = intval($_REQUEST['child_menu_id']);
                if ((intval($_REQUEST['season_id']) || intval($picture_id)) && $_POST['change_season_id'])
                    $info['season_id'] = intval($_REQUEST['season_id']);
                if ((intval($_REQUEST['designer_id']) || intval($picture_id)) && $_POST['change_designer_id'])
                    $info['designer_id'] = intval($_REQUEST['designer_id']);
                if ((intval($_REQUEST['brand_id']) || intval($picture_id)) && $_POST['change_brand_id'])
                    $info['brand_id'] = intval($_REQUEST['brand_id']);
                if ((intval($_REQUEST['book_id']) || intval($picture_id)) && $_POST['change_book_id'])
                    $info['book_id'] = intval($_REQUEST['book_id']);
                if ((intval($_REQUEST['area_id']) || intval($picture_id)) && $_POST['change_area_id'])
                    $info['area_no'] = intval($_REQUEST['area_id']);
                if ((intval($_REQUEST['detail_id']) || intval($picture_id)) && $_POST['change_detail_id'])
                    $info['detail_id'] = intval($_REQUEST['detail_id']);
                if (($_POST['sort_id'] || intval($picture_id)) && $_POST['change_sort'])
                    $info['sort_id'] = intval($_REQUEST['sort_id']);
                if (($_POST['special_column_id'] || intval($picture_id)) && $_POST['change_column'])
                    $info['special_column_id'] = intval($_REQUEST['special_column_id']);
                foreach ($idArr as $pid) {
                    $pid = intval($pid);
                    $where = array('menu_id' => $this->cid, 'id' => $pid);
                    $this->modelP->where($where)->save($info);
                    //echo $this->modelP->getlastsql();exit;
                    $this->setPicExtend($pid, $_POST);
                    $this->setSift();
                    if (($_POST['acc'] || intval($picture_id)) && $_POST['change_acc'])
                        $this->setPicAcc($pid, $_POST['acc']);
                    if (($_POST['color'] || intval($picture_id)) && $_POST['change_color'])
                        $this->setPicColor($pid, $_POST['color']);
                    if (($_POST['fashion'] || intval($picture_id)) && $_POST['change_fashion'])
                        $this->setPicFashion($pid, $_POST['fashion']);
                    if (($_POST['material'] || intval($picture_id)) && $_POST['change_material'])
                        $this->setPicMaterial($pid, $_POST['material']);
                    if (($_POST['fpid'] || intval($picture_id)) && ($_POST['change_fpid'] || $_POST['change_spid'] || $_POST['change_pattern']))
                        $this->setPicPattern($pid, $_POST['fpid'], $_POST['spid'], $_POST['pattern']);

                    $style = $_POST['styles'] ? explode(',', $_POST['styles']) : '';
                    if ($style) {
                        foreach ($style as $k => $v) {
                            if ($this->styles[$v]['parent_id'] == 0) {
                                unset($style[$k]);
                            }
                            if ($this->styles[$v]['parent_id'] > 0) {
                                $style[] = $this->styles[$v]['parent_id'];
                            }
                        }
                    }
                    $style = array_unique($style);
                    //dump($style);exit();//4,5,1
                    $psid = in_array($_POST['psid'], $style) ? 0 : $_POST['psid'];
                    if (($_POST['psid'] || intval($picture_id)) && ($_POST['change_psid'] || $_POST['change_style']))
                        $this->setPicStyle($pid, $psid, $style,$_POST);
                    $keyword = $_POST['keywords'] ? explode(',', $_POST['keywords']) : '';
                    $keyword = array_unique($keyword);
                    if ($keyword) {
                        foreach ($keyword as $k => $v) {
                            if (in_array($v, array(145, 146, 147, 148, 149, 159)) || $v == 0) {
                                unset($keyword[$k]);
                            }
                        }
                    }
                    if ($_POST['pkid'] || intval($picture_id) && ($_POST['change_pkid'] || $_POST['change_keyword']))
                        $this->setPicKeyword($pid, $_POST['pkid'], $keyword);
                }
                //图片搜索表处理
                $this->setSearchPicture($pid);
                //exit('<script>self.parent.main.location.reload()</script>');
                //exit('<script>self.parent.main.closeBox();</script>');
                //成功提示
                $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('分类成功!');
            }
        } else {
            $info = $this->modelP->relation(true)->where(array('menu_id' => $this->cid, 'id' => $picture_id))->find();
            //dump($info);
            //echo $this->modelP->getlastsql();exit('#');
            //$info['big_picture_url'] = $info['big_picture_url'] ? show_pic_path($info['big_picture_url']) : '';

            //$Cache = Cache::getInstance();
            $type = $_REQUEST['type'];
            if ($type) {
                //區域
                if ($type == 'area') {
                    if (in_array('2', $this->config) || in_array('2', $this->configS))
                        $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
                    $str = '<option value="">区域选择</option>';
                    //区域格式化
                    $areaOption = $this->getAreaOption($info['area_no']);
                    exit($str . $areaOption);
                }
                //品牌
                else if ($type == 'brand') {
                    $str = '<option value="">品牌选择</option>';
                    if (in_array('3', $this->config) || in_array('3', $this->configS))
                        $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
                    if ($this->brands) {
                        foreach ($this->brands as $key => $val) {
                            $c = $info['brand_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //設計師
                else if ($type == 'designer') {
                    $str = '<option value="">設計師选择</option>';
                    if (in_array('4', $this->config) || in_array('4', $this->configS))
                        $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
                    if ($this->designers) {
                        foreach ($this->designers as $key => $val) {
                            $c = $info['designer_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //書名
                else if ($type == 'book') {
                    $str = '<option value="">書名选择</option>';
                    if (in_array('5', $this->config) || in_array('5', $this->configS))
                        $this->books = F('bookList','',C('DATA_CACHE_PATH'));
                    if ($this->books) {
                        foreach ($this->books as $key => $val) {
                            $c = $info['book_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
            }
            //季度
            if (in_array('1', $this->config) || in_array('1', $this->configS))
                $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
            //color
            if (in_array('6', $this->config) || in_array('6', $this->configS))
                $this->colors = F('colorList','',C('DATA_CACHE_PATH'));
            //style
            if (in_array('7', $this->config) || in_array('7', $this->configS))
                $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
            //fashion
            if (in_array('8', $this->config) || in_array('8', $this->configS))
                $this->fashions = F('fashionList','',C('DATA_CACHE_PATH'));
            //pattern
            if (in_array('9', $this->config) || in_array('9', $this->configS))
                $this->patterns = F('patternList','',C('DATA_CACHE_PATH'));
            //acc
            if (in_array('10', $this->config) || in_array('10', $this->configS))
                $this->accs = F('accList','',C('DATA_CACHE_PATH'));
            //material
            if (in_array('11', $this->config) || in_array('11', $this->configS))
                $this->materials = F('materialList','',C('DATA_CACHE_PATH'));
            //detail
            if (in_array('12', $this->config) || in_array('12', $this->configS))
                $this->details = F('detailList','',C('DATA_CACHE_PATH'));
            //关键词
            $this->keywords = F('keywordList','',C('DATA_CACHE_PATH'));

            if ($info['sort']) {
                $tmp = array();
                foreach ($info['sort'] as $key => $val) {
                    $tmp[] = $val['sort_id'];
                }
                $info['sort'] = $tmp;
            }
            if (empty($info['sort'])) {
                $info['sort'] = array($info['sort_id']);
            }
            if ($info['column']) {
                $tmp = array();
                foreach ($info['column'] as $key => $val) {
                    $tmp[] = $val['special_column_id'];
                }
                $info['column'] = $tmp;
            }
            if (empty($info['column'])) {
                $info['column'] = array($info['special_column_id']);
            }
            if ($info['acc']) {
                $tmp = array();
                foreach ($info['acc'] as $key => $val) {
                    if ($val['acc_id']) {
                        $tmp[] = $val['acc_id'];
                    }
                }
                $info['acc'] = $tmp;
            }
            if ($info['color']) {
                $tmp = array();
                foreach ($info['color'] as $key => $val) {
                    if ($val['color_id'] > 0) {
                        $tmp[] = $val['color_id'];
                    }
                }
                $info['color'] = $tmp;
            }
            if ($info['fashion']) {
                $tmp = array();
                foreach ($info['fashion'] as $key => $val) {
                    if ($val['fashion_id'] > 0) {
                        $tmp[] = $val['fashion_id'];
                    }
                }
                $info['fashion'] = $tmp;
            }
            if ($info['material']) {
                $tmp = array();
                foreach ($info['material'] as $key => $val) {
                    $tmp[] = $val['material_id'];
                }
                $info['material'] = $tmp;
            }
            if ($info['pattern']) {
                $tmp = array();
                foreach ($info['pattern'] as $key => $val) {
                    if ($val['pattern_no'] > 0) {
                        $tmp[] = $val['pattern_no'];
                    }
                }
                $info['pattern'] = $tmp;
            }
            $patternIds = $tmp ? implode(',', $info['pattern']) : '0';
            $this->assign('patternIds', $patternIds);
            if ($info['style']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['style'] as $key => $val) {
                    if ($val['style_no'] > 0) {
                        $tmp[] = $val['style_no'];
                        $tmpT[] = $this->styles[$val['style_no']]['name'];
                    }
                }
                $info['style'] = $tmp;
            }
            $styleIds = $tmp ? implode(',', $info['style']) : '0';
            $this->assign('styleIds', $styleIds);
            $this->assign('styleText', implode(',', array_unique($tmpT)));
            if ($info['keyword']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['keyword'] as $key => $val) {
                    if ($val['keyword_id'] > 0) {
                        $tmp[] = $val['keyword_id'];
                        $tmpT[] = $this->keywords[$val['keyword_id']]['name'];
                    }
                }
                $info['keyword'] = array_unique($tmp);
            }
            $keywordIds = $info['keyword'] ? implode(',', $info['keyword']) : '0';
            $this->assign('keywordIds', $keywordIds);
            $this->assign('keywordText', implode(',', array_unique($tmpT)));

            //款式分级处理
            if ($this->styles) {
                foreach ($this->styles as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $styleTmp[$key] = $val;
                        if (in_array($val['no'], $info['style'])) {
                            $public = A('Public');
                            $styleHtml = $public->getStyleByAjax($styleIds, $val['no'], 'yes');
                        }
                    }
                }
            }
            $this->assign('styleHtml', $styleHtml);
            $this->assign('styles', $styleTmp);
            //print_r($styleTmp);
            //关键词分级
            if ($this->keywords) {
                foreach ($this->keywords as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $keywordTmp[$key] = $val;
                        if (in_array($val['id'], $info['keyword'])) {
                            $public = A('Public');
                            $keywordHtml = $public->getKeywordByAjax($keywordIds, $val['id'], 'yes');
                        }
                    }
                }
            }
            $this->assign('keywordHtml', $keywordHtml);
            $this->assign('keywords', $keywordTmp);

            //图案分级处理
            if ($this->patterns) {
                foreach ($this->patterns as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $patternTmp[$key] = $val;
                        if (in_array($val['no'], $info['pattern'])) {
                            $public = A('Public');
                            $patternHtml = $public->getPatternByAjax($patternIds, $val['no'], true, 'yes');
                        }
                    }
                }
            }
            $paternHtmlArr = explode('::', $patternHtml);
            $this->assign('patternHtml', $paternHtmlArr[0]);
            $this->assign('subPatternHtml', $paternHtmlArr[1]);
            $this->assign('patterns', $patternTmp);

            if ($info['area_no']) {
                $model = D('AttributeArea');
                $row = $model->where(array('no' => $info['area_no']))->find();
                $info['areaStr'] = "<option value='{$row['no']}' selected>{$row['name']}</option>";
            }
            if ($info['brand_id']) {
                $model = D('AttributeBrand');
                $row = $model->where(array('id' => $info['brand_id']))->find();
                $info['brandStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
            if ($info['designer_id']) {
                $model = D('AttributeDesigner');
                $row = $model->where(array('id' => $info['designer_id']))->find();
                $info['designerStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
            if ($info['book_id']) {
                $model = D('AttributeBook');
                $row = $model->where(array('id' => $info['book_id']))->find();
                $info['bookStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
        }
        //echo '<pre>';
        //print_r($info);
        $this->assign('info', $info);
        $this->assign('subject_id', $subject_id);
        $this->assign('picture_id', $picture_id);
        $this->assign('ids', $ids);
        $this->assign('listMenus', '');
        if(empty($is_display))
            $this->display('Subject/picture_category');
    }

//	protected function setSubjectPicture($tid, $pid) {
//		if (empty($tid) || empty($pid))
//			return false;
//		$model = D('RefSubjectPicture');
//		$info['subject_id'] = $tid;
//		$info['picture_id'] = $pid;
//		$row = $model->field('id')->where($info)->find();
//		if (!$row) {
//			$model->add($info);
//		}
//	}
//	protected function delSubjectPicture($id) {
//		$id = intval($id);
//		$where = array('picture_id' => $id);
//		$model = M('RefSubjectPicture');
//		$model->where($where)->delete();
//	}

    protected function setPicExtend($id, $info) {
        if (empty($id))
            return false;
        $model = M("{$this->m['picture_extend']}");

        $lable = $this->getLable($info);

        $arr = array();
        if ($info['zip']) {
            $zip = $info['zip'];//unserialize($info['zip']);
            $zip_type = 0;
            if(isset($zip['jrp']['img_path'])){
                $zip_type = 1;
                $arr['zip_jrp'] = $zip['jrp']['img_path'];
            }

            if(isset($zip['psd']['img_path'])){
                $zip_type = 2;
                $arr['zip_psd'] = $zip['psd']['img_path'];
            }

            if(isset($zip['ai']['img_path'])){
                $zip_type = 3;
                $arr['zip_ai'] = $zip['ai']['img_path'];
            }

            if(isset($zip['cdr']['img_path'])){
                $zip_type = 3;
                $arr['zip_cdr'] = $zip['cdr']['img_path'];
            }
        }
        $arr['lable'] = $lable;
        $arr['menu_id'] = $info['menu_id'];
        if ($model->getField('id',array('picture_id'=>$id)) > 0) {
            if($model->where($where)->save($arr) !== false && $cid == 24){
                //图案特殊处理
                $old_zip_type = M("{$this->m['picture']}")->getField('zip_type',array('id'=>$id));
                if($zip_type > $old_zip_type){
                    M("{$this->m['picture']}")->save(array('id'=>$id,'zip_type'=>$zip_type));
                }
            }
        } else {
            $arr['picture_id'] = $id;
            if($model->add($arr) !== false){
                M("{$this->m['picture']}")->save(array('id'=>$id,'zip_type'=>$zip_type));
            }
        }

    }

    protected function delPicExtend($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['picture_extend']}");
        $model->where($where)->delete();
    }

    protected function setPicAcc($id, $info) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $this->delPicAcc($id);
        $model = M("{$this->m['ref_picture_acc']}");
        $model->picture_id = $id;
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->acc_id = $val;
                $model->add();
            }
        }
    }

    protected function delPicAcc($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_acc']}");
        $model->where($where)->delete();
    }

    protected function setPicColor($id, $info) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $this->delPicColor($id);
        $model = M("{$this->m['ref_picture_color']}");
        $model->picture_id = $id;
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->color_id = $val;
                $model->add();
            }
        }
    }

    protected function delPicColor($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_color']}");
        $model->where($where)->delete();
    }

    protected function setPicFashion($id, $info) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $this->delPicFashion($id);
        if( !isset($infos) ) return false;
        $model = M("{$this->m['ref_picture_fashion']}");
        $model->picture_id = $id;
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->fashion_id = $val;
                $model->menu_id = $this->cid;
                $model->add();
            }
        }
    }

    protected function delPicFashion($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_fashion']}");
        $model->where($where)->delete();
    }

    protected function setPicMaterial($id, $info) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $model = M("{$this->m['ref_picture_material']}");
        $this->delPicMaterial($id);
        $model->picture_id = $id;
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->material_id = $val;
                $model->menu_id = $this->cid;
                $model->add();
            }
        }
        //echo $model->getLastSql();
    }

    protected function delPicMaterial($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_material']}");
        $model->where($where)->delete();
    }

    protected function setPicPattern($id, $fpid, $spid, $info = '') {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $this->delPicPattern($id);
        $model = M("{$this->m['ref_picture_pattern']}");
        $model->picture_id = $id;

        //一级
        if ($fpid > 0) {
            $model->pattern_no = $fpid;
            $model->add();
        }
        //二级
        if (!empty($spid)) {
            $model->pattern_no = $spid;
            $model->add();
            foreach ($infos as $key => $val) {
                if ($val > 0) {
                    $model->pattern_no = $val;
                    $model->add();
                }
            }
        }
    }

    protected function delPicPattern($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_pattern']}");
        $model->where($where)->delete();
    }
    //用于在图片picture_category里面
    protected function setPicStyle($id, $psid, $info, $menus = null) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        if ( empty($_REQUEST['addup']) ){
            $this->delPicStyle($id);
        }
        $model = M("{$this->m['ref_picture_style']}");
        $model->picture_id = $data['picture_id'] = $id;

//        if ($psid > 0) {
//            //一级
//            $model->style_id = $psid;
//            $model->menu_id = $this->cid;
//            $model->child_menu_id = $menus['child_menu_id'];
//            $model->add();
//        }
        //二级（多选）
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->style_id = $data['style_id']  = $val;
                $model->menu_id = $data['menu_id']  = $this->cid;
                $model->child_menu_id = $data['child_menu_id']  = $menus['child_menu_id'];
                $row = $model->where($data)->find();
                if ( empty ($row) ){
                    $model->add($data);
                }
            }
        }
    }

    protected function delPicStyle($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_style']}");
        $model->where($where)->delete();
    }

    protected function setPicKeyword($id, $pkid, $info) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $this->delPicKeyword($id);
        $model = M("{$this->m['ref_picture_keyword']}");
        $model->picture_id = $id;
        //一级
        if ($pkid > 0) {
            $model->keyword_id = $pkid;
            $model->add();
            //echo $model->getLastSql();exit;
        }
        //二级（多选）
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->keyword_id = $val;
                $model->add();
            }
        }
    }

    protected function delPicKeyword($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_keyword']}");
        $model->where($where)->delete();
    }

    protected function delPicFt($id) {
        if ($this->modelS) {
            $id = intval($id);
            $where = array('picture_id' => $id);
            $this->modelS->where($where)->delete();
        }
    }

    /**
     * get lable info
     */
    protected function getLable($info) {
        $this->setConfig();
        if (empty($info))
            $this->error('抱歉，缺少属性');
        $lables = array();
        if ($info['menu_id'])
            $lables[] = $this->menus[$info['menu_id']]['name'] . $info['menu_id'];
        if ($info['child_menu_id'])
            $lables[] = $this->menus[$info['child_menu_id']]['name'] . $info['child_menu_id'];
        if ($info['area_id'])
            $lables[] = $this->areas[$info['area_id']]['name'] . $info['area_no'];
        if ($info['designer_id'])
            $lables[] = $this->designers[$info['designer_id']]['name'] . $info['designer_id'];
        if ($info['brand_id'])
            $lables[] = $this->brands[$info['brand_id']]['name'];
        if ($info['book_id'])
            $lables[] = $this->books[$info['book_id']]['name'];
        if ($info['season_id'])
            $lables[] = $this->seasons[$info['season_id']]['name'] . $info['season_id'] . ',' . $this->seasons[$info['season_id']]['en_name'];
        $data = !empty($info['sort_id']) ? $info['sort_id'] : $info['sort'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->sorts[$key]['name'] . $key;
            }
        }
        $data = !empty($info['column_id']) ? $info['column_id'] : $info['column'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->columns[$key]['name'] . $key;
            }
        }
        $data = $info['acc'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->accs[$key]['name'] . $key;
            }
        }
        $data = $info['color'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->colors[$key]['name'] . $key;
            }
        }
        $data = $info['fashion'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->fashions[$key]['name'] . $key;
            }
        }
        $data = $info['material'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->materials[$key]['name'] . $key;
            }
        }
        $data = $info['pattern'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->patterns[$key]['name'] . $key;
            }
        }
        $data = $info['style'];
        if ($data) {
            $datas = is_array($data) ? $data : explode(',', $data);
            foreach ($datas as $key) {
                $lables[] = $this->styles[$key]['name'] . $key;
            }
        }
        //dump($lables);exit;
        return implode(',', $lables);
    }

    /**
     * batch action
     */
    public function picBatch() {
        $actType = trim($_REQUEST['acttype']);
        $columntype = intval($_REQUEST['columntype']);
        $subject_id = intval($_REQUEST['subject_id']);
        $info_menu_id = $_REQUEST['is_ny'] ? $this->ny_cid : $this->cid;
        $ids = $_REQUEST['ids'];
        $data = array();
        if ($actType == 'remove') {
            //$this->picDelete();
            $this->redirect('picDelete', array('ids' => implode(',', $ids), 'subject_id' => $subject_id,'ny_cid'=>$info_menu_id));
        } elseif ($actType == 'sequence'){
            $page_arr = $this->getPageOnArr($_REQUEST);
            $page_key_arr = array_keys($page_arr);
            $this->redirect('picPageOn',array('ids' => implode(',', $ids), 'pages_key' => implode(',', $page_key_arr), 'pages' => implode(',', $page_arr)));
        } elseif ($actType == 'column_yes') {
            $this->redirect('pictureColumn', array('ids' => implode(',', $ids),'columntype' => $columntype));
            exit;
        } else {
            $display_time = $_POST['display_time'];
            if ($display_time){
                $data['publish_time'] = $dataS['publish_time'] =  strtotime($display_time);
            }
            if ($actType == 'display_yes') {
                $data['is_publish'] = $dataS['is_publish'] = 1;
            } else if ($actType == 'display_no') {
                $data['is_publish'] = $dataS['is_publish'] = 0;
            }
            foreach ($ids as $key => $id) {
                $where = array( 'id' => $id);
                if($this->modelP->where($where)->save($data) !== false){
                    if ( $this->cid == 22 || $this->cid == 102 ) {
                        $whereS = array('picture_id' => $id);
                        $whereS['is_publish'] = array('egt',0);
                        $this->modelS->where($whereS)->save($dataS);
                    }
                    //echo $this->modelP->getlastsql()."<br>";
                    //添加到搜索索引表
                    if($data['is_publish'] == 0){
                        $this->delSearchPicture($id);
                    }else{
                        $aa = $this->setSearchPicture($id,$this->modelP->getField('subject_id',array('id'=>$id)));
                    }
                }
                //echo $this->modelP->getlastsql();
            }
            $this->assign('is_main', '1');
            $this->assign('is_main_url',  Cookie::get('_currentPiclistUrl_'));
            $this->success('操作成功！');
        }
    }

    public function pictureColumn($pid_arr = null) {
        $columntype = $_REQUEST['columntype'];
        if ( $pid_arr ) {
            $ids = $pid_arr;
        } else {
            $ids = $_REQUEST['ids'];
            $ids = explode(',', $ids);
        }
        if (empty($ids))
            return false;
        
        $model = M("{$this->m['ref_picture_column']}");
        foreach ($ids as $id) {
            $where['picture_id'] = $id;
            $where['menu_id'] = $this->cid;
            $data['special_column_id'] = $columntype;
            if ( $columntype == 0 ) {
                //删除
                $list = $model->where($where)->select();
                if($list) {
                    $model->where($where)->delete();
                }
            } else {
                //更新
                $list = $model->where($where)->select();
                if($list) {
                    $list = $model->where($where)->delete();
                }
                $data_add['special_column_id'] = $columntype;
                $data_add['picture_id'] = $id;
                $data_add['menu_id'] = $this->cid;
                $model->where($where)->add($data_add);
            }
        }
        if ( empty($pid_arr) ) {
            $this->assign('is_main', '1');
            $this->assign('is_main_url',  Cookie::get('_currentPiclistUrl_'));
            $this->success('批量修改专栏成功！');
        }
    }

    public function getPageOnArr($array){
        if (empty($array)){
            return false;
        }
        $page_arr = array();
        foreach ($array as $key => $value) {
            if ( substr($key, 0, 7) == "page_no" ){
                $page_arr[substr($key,  7)] = $value;
            }
        }
        return $page_arr;
    }

    public function picPageOn(){
        $ids = $_REQUEST['ids'];
        $ids = !is_array($ids) ? explode(',', $ids) : $ids;
        $pages_key = $_REQUEST['pages_key'];
        $pages_key = !is_array($pages_key) ? explode(',', $pages_key) : $pages_key;
        $pages = $_REQUEST['pages'];
        $pages = !is_array($pages) ? explode(',', $pages) : $pages;
        if ( empty($ids) or empty($pages) or empty($pages_key) ){
            return false;
        }
        $page_on_arr = array_combine($pages_key, $pages);
        $errorNum = 0;
        foreach ( $ids as $id_k => $id_v ) {
            $id_v = intval($id_v);
            $info['page_no'] = $page_on_arr[$id_v];
            if($this->modelP->where(array('id' => $id_v))->save($info) === false){
                $errorNum++;
            }//echo $this->modelP->getLastSql()."<br />";
        }//exit;
        $this->assign('is_main', '1');
        $this->assign('is_main_url',  Cookie::get('_currentPiclistUrl_'));
        $errorNum > 0 ? $this->error('操作成失败！') : $this->success('操作成功！');
    }

    public function picDelete($mid = '', $subject_id='') {
        $ids = $mid ? $mid : $_REQUEST['ids'];
        $subject_id = $_REQUEST['subject_id'];
        $info_menu_id = $_REQUEST['ny_cid'];
        $ids = !is_array($ids) ? explode(',', $ids) : $ids;
        if (empty($ids))
            return false;
        $errorNum = 0;
        $info = array('is_publish' => -1);
        $info['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
        foreach ($ids as $key => $id) {
            $id = intval($id);
            if($this->modelP->where(array('id' => $id))->save($info) === false){
                $errorNum++;
            }else{
                //删除搜索表中相应数据
                $this->delSearchPicture($id);
            }
            //在图片管理里面删除图片，要更新主题的图片数量
            if ( $subject_id == 0 && !in_array($info_menu_id, array(16)) ) {
                $this->setPCount($id);
            }
            if ($subject_id > 0) {
                $this->setPictureCount($subject_id,'del');
            }
        }
        if (empty($mid)) {
            $this->assign('is_main', '1');
            $this->assign('is_main_url',  Cookie::get('_currentPiclistUrl_'));
            $errorNum > 0 ? $this->error('操作失败！') : $this->success('操作成功！');
        }
    }

    public function setPCount($pid){
        if ( empty( $pid ) ) {
            return false;
        }
        $tid = $this->modelP->getField('subject_id',array('id'=>$pid));
        $this->setPictureCount($tid,'del');
    }

    protected function delSearchPicture($id){
        if(!$id){
            return false;
        }
        $menu_id = $this->modelP->getField('menu_id',array('id'=>$id));
        $search_id = M("SearchPicture")->getField('id',array('menu_id'=>$menu_id,'picture_id'=>intval($id)));
        if($search_id){
            import('@.ORG.Search');
            $search = new Search();
            if($search->updateAttributes ("sxxl_search_picture",array("publish_time"),array($search_id=>array(1)) ) != -1){//删除索引中相应的数据
                M("SearchPicture")->where(array('id'=>$search_id))->delete();
                //echo D("SearchPicture")->getLastSql();
            }
        }
    }

    protected function delPicOther($id) {
        $id = intval($id);
        if (empty($id))
            return false;
        //$this->delSubjectPicture($id);
        $this->delPicExtend($id);
//		$this->delPicSort($id);
//		$this->delPicColumn($id);
        $this->delPicAcc($id);
        $this->delPicColor($id);
        $this->delPicFashion($id);
        $this->delPicMaterial($id);
        $this->delPicPattern($id);
        $this->delPicStyle($id);
        $this->delPicFt($id);
    }

    /*
     * 获取所有后台用户指定信息
     */
    public function getUserList() {
        $userTmp = F('userList','',C('DATA_CACHE_PATH'));
        return $userTmp;
//        $userTmp = S('userList');
//        if(empty($userTmp)){
//            $userList = D('SysUser')->field ('id,real_name')->findAll();
//            S('userList',$userList);
//            return S('userList');
//        }else{
//            return $userTmp;
//        }
    }

    public function setFolderSort($fid){
        if (empty($fid))
            return false;
        $sort_id = $_REQUEST['sort_id'];
        if(!isset($sort_id) && empty($sort_id)){
            $this->delFolderSort($fid);
            return ;
        }
        $this->delFolderSort($fid);
        $model = M("{$this->m['ref_folder_sort']}");
        foreach ($sort_id as $key => $val) {
            $model->folder_id = $fid;
            $model->sort_id = $val;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_REQUEST['child_menu_id']) ? $_REQUEST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br>";
        }
    }

    public function delFolderSort($id) {
        $id = intval($id);
        $where = array('folder_id' => $id);
        $model = M("{$this->m['ref_folder_sort']}");
        $model->where($where)->delete();
    }

    public function setFolderSpecialColumn($fid){
        if (empty($fid))
            return false;
        $special_column_id = $_REQUEST['special_column_id'];
        if(!isset($special_column_id) && empty($special_column_id)){
            $this->delFolderSpecialColumn($fid);
            return ;
        };
        $this->delFolderSpecialColumn($fid);
        $model = M("{$this->m['ref_folder_column']}");
        foreach ($special_column_id as $key => $val) {
            $model->folder_id = $fid;
            $model->special_column_id = $val;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_REQUEST['child_menu_id']) ? $_REQUEST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br>";
        }
    }

    public function delFolderSpecialColumn($id) {
        $id = intval($id);
        $where = array('folder_id' => $id);
        $model = M("{$this->m['ref_folder_column']}");
        $model->where($where)->delete();
    }

    public function setThemeStyle($fid = null, $sid){
        if (empty ($sid) or empty ($_POST['style_id']))
             return false;
        $this->delThemeStyle($sid);
        if ( $_POST['style_id'] == '-1' ) {
            return false;
        }
        if(empty ($fid)) {
            $folderStyleArray = $this->getPostStyle();
        }else{
            $folderStyleArray = $this->delThemeStyle($fid);
        }
        $model = M("{$this->m['ref_subject_style']}");
        foreach ($folderStyleArray as $key => $val) {
            $model->subject_id = $sid;
            $model->style_id = $val['style_id'];
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();exit();
        }
    }

    public function getPostStyle(){
        $postArray = array();
        if(is_array($_POST['style_id']) && !empty($_POST['style_id'])) foreach ($_POST['style_id'] as $key => $val){
            $postArray[$key]['style_id'] = $val;
            $postArray[$key]['child_menu_id'] = $_POST['child_menu_id'];
        }else{
            $postArray[0]['style_id'] = $_POST['style_id'];
            $postArray[0]['child_menu_id'] = $_POST['child_menu_id'];
        }
       return $postArray;
    }

    public function delThemeStyle($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['ref_subject_style']}");
        $model->where($where)->delete();
    }

    public function setThemeSort($fid,$sid){
        if (empty ($sid))
             return false;
        $this->delThemeSort($sid);
        if(empty ($fid)) {
            $folderSortArray = $this->getPostSort();
        }else{
            $folderSortArray = $this->getFolderSort($fid);
        }
        $model = M("{$this->m['ref_subject_sort']}");
        foreach ($folderSortArray as $key => $val) {
            $model->subject_id = $sid;
            $model->sort_id = $val['sort_id'];
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }

    public function getPostSort(){
        $postArray = array();
        $sort = $_POST['child_menu_id'];
        if(isset($_POST['sort_id']) && !empty($_POST['sort_id'])) foreach ($_POST['sort_id'] as $key => $val){
            $postArray[$key]['sort_id'] = $val;
            $postArray[$key]['child_menu_id'] = $_POST['child_menu_id'];
        }
       return $postArray;
    }

    public function delThemeSort($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['ref_subject_sort']}");
        $model->where($where)->delete();
    }

    public function getFolderSort($id) {
        $id = intval($id);
        $where['folder_id'] = $id;
        $model = M("{$this->m['ref_folder_sort']}");
        $list = $model->where($where)->select();
        return $list;
    }

    public function setThemeSpecialColumn($fid,$sid){
        if (empty ($sid))
             return false;
        $this->delThemeSpecialColumn($sid);
        if(empty ($fid)) {
            $folderSpecialColumnArray = $this->getPostSpecialColumn();
        }else{
            $folderSpecialColumnArray = $this->getFolderSpecialColumn($fid);
        }

		$menu_id = $this->cid;
		//如果是 内衣专栏.品牌画册.内衣 款式的话，将写入款式关联表 (Jialiang Qin 2012.10.12)
		if( $this->ny_cid == 100 && isset($_POST['special_column_id']) && in_array(4,$_POST['special_column_id']) ) {
			$menu_id = 100;
		}

        $model = M("{$this->m['ref_subject_column']}");
        foreach ($folderSpecialColumnArray as $key => $val) {
            $model->subject_id = $sid;
            $model->special_column_id = $val['special_column_id'];
            $model->menu_id = $menu_id;
            $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
            $model->add();
        }
    }

    public function getPostSpecialColumn(){
        $postArray = array();
        $sort = $_POST['child_menu_id'];
        if(isset($_POST['special_column_id']) && !empty($_POST['special_column_id'])) foreach ($_POST['special_column_id'] as $key => $val){
            $postArray[$key]['special_column_id'] = $val;
            $postArray[$key]['child_menu_id'] = $_POST['child_menu_id'];
        }
       return $postArray;
    }

    public function delThemeSpecialColumn($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['ref_subject_column']}");
        $model->where($where)->delete();
    }

    public function getFolderSpecialColumn($id) {
        $id = intval($id);
        $where['folder_id'] = $id;
        $model = M("{$this->m['ref_folder_column']}");
        $list = $model->where($where)->select();
        return $list;
    }

	public function setPicSort($pid, $sid, $sort_id = '') {
		if (empty($pid)) return false;
        $this->delPicSort($pid);
        // 取主题的sortid
        if(empty ($sid) && !empty($sort_id)) {
            $themeSortArray = array(array('sort_id'=>$sort_id));
        }else{
            $themeSortArray = $this->getThemeSort($sid);
        }
        $model = M("{$this->m['ref_picture_sort']}");
        $model->picture_id = $pid;
        foreach ($themeSortArray as $key => $val) {
                $model->sort_id = $val['sort_id'];
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
                $model->add();
        }
	}

	public function delPicSort($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_sort']}");
		$model->where($where)->delete();
	}

    public function getThemeSort($id) {
        $id = intval($id);
        $where['subject_id'] = $id;
        $model = M("{$this->m['ref_subject_sort']}");
        $list = $model->where($where)->select();
        return $list;
    }


	public function setPicMenu($pid, $sid) {
		if (empty($pid) || empty($sid)) return false;
        $themeMenuArray = $this->getThemeMenu($sid);
        $this->delPicMenu($pid);
        $model = M("{$this->m['ref_picture_menu']}");
        $model->picture_id = $pid;
        if( !empty ($themeMenuArray))foreach ($themeMenuArray as $key => $val) {
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
                $model->add();
                //echo $model->getLastSql();echo "<br />";
        }
	}
	public function delPicMenu($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_menu']}");
		$model->where($where)->delete();
	}
    public function getThemeMenu($id) {
        $id = intval($id);
        $where['subject_id'] = $id;
        $model = M("{$this->m['ref_subject_menu']}");
        $list = $model->where($where)->select();
        if (!isset ($list)){
            return ;
        }
        return $list;
    }

    //添加图片时调用
    public function setPicStyles($pid, $sid, $style_id = '') {
		if (empty($pid)) return false;
        $this->delPicStyles($pid);
        // 取主题的sortid
        if(empty ($sid) && !empty($style_id)) {
            $themeStylesArray = array(array('style_id'=>$style_id));
        }else{
            $themeStylesArray = $this->getThemeStyles($sid);
        }
        $model = M("{$this->m['ref_picture_style']}");
        $model->picture_id = $pid;
        foreach ($themeStylesArray as $key => $val) {
                $model->style_id = $val['style_id'];
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
                $model->add();
        }
	}
	public function delPicStyles($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_style']}");
		$model->where($where)->delete();
	}

    public function getThemeStyles($id) {
        $id = intval($id);
        $where['subject_id'] = $id;
        $model = M("{$this->m['ref_subject_style']}");
        $list = $model->where($where)->select();
        return $list;
    }

	public function setPicColumn($pid, $sid, $column_id = '') {
		if (empty($pid)) return false;
        $this->delPicColumn($pid);
        // 取主题的Columnid
        if(empty ($sid) && !empty($column_id)) {
            $themeColumnArray = array(array('special_column_id'=>$column_id));
        }else{
            $themeColumnArray = $this->getThemeColumn($sid);
        }
        $model = M("{$this->m['ref_picture_column']}");
        $model->picture_id = $pid;
        foreach ($themeColumnArray as $key => $val) {
                $model->special_column_id = $val['special_column_id'];
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
                $model->add();
        }
	}

	public function delPicColumn($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_column']}");
		$model->where($where)->delete();
	}

    public function getThemeColumn($id) {
        $id = intval($id);
        $where['subject_id'] = $id;
        $model = M("{$this->m['ref_subject_column']}");
        $list = $model->where($where)->select();
        return $list;
    }

    public function setThemeMenu($sid){
        if (empty ($sid))
             return false;
        if(!is_array($_POST['child_menu_id'])){return ;}
        $this->delThemeMenu($sid);
        $MenuArray = $this->getPostMenu();
        $model = M("{$this->m['ref_subject_menu']}");
        foreach ($MenuArray as $key => $val) {
            $model->subject_id = $sid;
            $model->menu_id = $this->cid;
            $model->child_menu_id = $val['child_menu_id'];
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }

    public function getPostMenu(){
        $postArray = array();
        $child = $_POST['child_menu_id'];
        if(isset($_POST['child_menu_id']) && !empty($_POST['child_menu_id'])) foreach ($_POST['child_menu_id'] as $key => $val){
            $postArray[$key]['child_menu_id'] = $val;
        }
       return $postArray;
    }

    public function delThemeMenu($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['ref_subject_menu']}");
        $model->where($where)->delete();
    }


    public function setFolderFashion($fid){
        $fashion_id = $_REQUEST['fashion_id'];
        if (empty($fid) || empty($fashion_id) || $this->cid !== 24)
            return ;

        $this->delFolderFashion($fid);
        if(!isset($fashion_id) && empty($fashion_id))
             return ;
        $model = M("{$this->m['ref_folder_fashion']}");
        $model->folder_id = $fid;
        $model->fashion_id = $fashion_id;
        $model->menu_id = $this->cid;
        $model->child_menu_id = !empty($_REQUEST['child_menu_id']) ? $_REQUEST['child_menu_id'] : 0;
        $model->add();
    }

    public function delFolderFashion($id) {
        $id = intval($id);
        $where = array('folder_id' => $id);
        $model = M("{$this->m['ref_folder_fashion']}");
        $model->where($where)->delete();
    }

    public function setThemeCraft($sid){
        $craft_id = $_REQUEST['craft_id'];
        if (empty ($sid) || $this->cid !== 24)
             return ;
        $this->delThemeCraft($sid);
        if(!isset($craft_id) && empty($craft_id))
             return ;
        $model = M("{$this->m['ref_subject_craft']}");
        $model->subject_id = $sid;
        $model->craft_id = $craft_id;
        $model->menu_id = $this->cid;
        $model->child_menu_id = !empty($_REQUEST['child_menu_id']) ? $_REQUEST['child_menu_id'] : 0;
        $model->add();
        //echo $model->getLastSql();echo "<br />";exit();
    }

    public function delThemeCraft($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['ref_subject_craft']}");
        $model->where($where)->delete();
    }
    //区别于public里面的getAllBrandByAjax需要接收$_REQUEST
    public function getAllBrandByAjax() {
        if(intval($_REQUEST['brandid'])){
            $brand_id = intval($_REQUEST['brandid']);
        }else{
            $brand_id = '';
        }
		//$Cache = Cache::getInstance();
        $brands = F('brandList','',C('DATA_CACHE_PATH'));
		$html = '';
        $html .= '<option value="">品牌选择</option>';
        foreach ($brands as $key => $val) {
            $html .= '<option value="' . $val['id'] .'"'. ($val['id'] == $brand_id ? 'selected="selected"' : '') .' title="'.$val['name'].'">' . $val['name'] . '</option>';
		}
		echo $html;
	}
    //区别于public里面的getAllDesignerByAjax需要接收$_REQUEST
    public function getAllDesignerByAjax() {
        if(intval($_REQUEST['designerid'])){
            $designer_id = intval($_REQUEST['designerid']);
        }else{
            $designer_id = '';
        }
		//$Cache = Cache::getInstance();
        $designers = F('designerList','',C('DATA_CACHE_PATH'));
		$html = '';
        $html .= '<option value="">设计师选择</option>';
        foreach ($designers as $key => $val) {
            $html .= '<option value="' . $val['id'] .'"'. ($val['id'] == $designer_id ? 'selected="selected"' : '') .' title="'.$val['name'].'">' . $val['name'] . '</option>';
		}
		echo $html;
	}
    public function getAllBookByAjax() {
        if(intval($_REQUEST['bookid'])){
            $book_id = intval($_REQUEST['bookid']);
        }else{
            $book_id = '';
        }
		//$Cache = Cache::getInstance();
        $designers = F('bookList','',C('DATA_CACHE_PATH'));
		$html = '';
        $html .= '<option value="">书名选择</option>';
        foreach ($designers as $key => $val) {
            $html .= '<option value="' . $val['id'] .'"'. ($val['id'] == $book_id ? 'selected="selected"' : '') .' title="'.$val['name'].'">' . $val['name'] . '</option>';
		}
		echo $html;
	}
    public function setThemeFashion($fid,$sid){
        if (empty ($sid))
             return false;
        $this->delThemeFashion($sid);
        if (empty ($_POST['fashion_id']))
             return ;
        if(empty ($fid)) {
            $folderFashionArray = $this->getPostFashion();
        }else{
            $folderFashionArray = $this->getFolderFashion($fid);
        }
        $model = M("{$this->m['ref_subject_fashion']}");
        foreach ($folderFashionArray as $key => $val) {
            $model->subject_id = $sid;
            $model->fashion_id = $val['fashion_id'];
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }

    public function getPostFashion(){
        $postArray = array();
        $postArray[0]['fashion_id'] = $_POST['fashion_id'];
        $postArray[0]['child_menu_id'] = $_POST['child_menu_id'];
        return $postArray;
    }

    public function delThemeFashion($id) {
        $id = intval($id);
        $where = array('subject_id' => $id);
        $model = M("{$this->m['ref_subject_fashion']}");
        $model->where($where)->delete();
    }

    public function getFolderFashion($id) {
        $id = intval($id);
        $where['folder_id'] = $id;
        $model = M("{$this->m['ref_subject_fashion']}");
        $list = $model->where($where)->select();
        return $list;
    }
    public function setPicDescrip($info){
    	$where = array('picture_id' => $info['picture_id']);
    	$descrip = $this->model_picture_extend->where($where)->find();
  		if($info['description'] && !$descrip){
  			$id = $this->model_picture_extend->add($info);
  		}elseif($descrip){
  			$this->model_picture_extend->where($where)->save($info);
  		}
    }
    //图片搜索
    //picture_id, publish_time, menu_id, child_menu_id, sort_id, season_id, area_no, brand_id, book_id, designer_id, style_id, acc_id, fashion_id,
	//keyword_id, color_id, column_id, detail_id, material_id, p_type_id, p_fashion_id, p_craft_id, p_detail_id, big_picture_url, small_picture_url,label_search
    public function setSearchPicture($pid, $sbj_id = ''){
        if(empty ($pid))
            return ;
        $this->getFileCache();
        $label_search = '';
        $this->m = getCidModel($this->cid);
        $modelP = D("{$this->m['picture']}");
        $modelT = D("{$this->m['subject']}");
        $info = $modelP->relation(true)->where(array('id'=>$pid))->find();
        //dump($info);exit();
        if ( $sbj_id ) {
            $theme_name = $modelT->getField('title',array('id'=>$sbj_id));
            $label_search .= $theme_name.",";
        }
        if(!empty ($info)){
            $searchArray['picture_id'] = $pid;
            $searchArray['publish_time'] = empty($info['publish_time']) ? '' : $info['publish_time'];
            $searchArray['sort_id'] = empty($info['sort_id']['0']['sort_id']) ? '' : $this->getCommaStr($info['sort_id'],"sort_id");
            if($searchArray['sort_id'])
                $label_search .= $this->getCommaStrName($this->sorts,$searchArray['sort_id']);
            $searchArray['column_id'] = empty($info['special_column_id']['0']['special_column_id']) ? '' : $this->getCommaStr($info['special_column_id'],'special_column_id');
            if($searchArray['column_id'] && $searchArray['column_id'] != 3)
                $label_search .= $this->getCommaStrName($this->columns,$searchArray['column_id']);
            $searchArray['big_picture_url'] = empty($info['big_picture_url']) ? '' : $info['big_picture_url'];
            $searchArray['small_picture_url'] = empty($info['small_picture_url']) ? '' : $info['small_picture_url'];
            $searchArray['menu_id'] = empty($info['menu_id']) ? '' : $info['menu_id'];
            if($searchArray['menu_id'])
                $label_search .= $this->menus[$searchArray['menu_id']]['name'].",";
            if($searchArray['menu_id'] == 27){
                $searchArray['child_menu_ids'] = empty($info['child_menu_ids']) ? '' : $info['child_menu_ids'];
                if($searchArray['child_menu_ids']){
                    foreach($searchArray['child_menu_ids'] as $key=>$val){
                        $searchArray['child_menu_id'] .= $val['child_menu_id'].',';
                        $label_search .= $this->menus[$val['child_menu_id']]['name'].",";
                    }
                }
            }else{
                $searchArray['child_menu_id'] = empty($info['child_menu_id']) ? '' : $info['child_menu_id'];
                if($searchArray['child_menu_id'])
                    $label_search .= $this->menus[$searchArray['child_menu_id']]['name'].",";
            }
            $searchArray['area_no'] = empty($info['area_no']) ? '' : $info['area_no'];
            if($searchArray['area_no'])
                $label_search .= $this->areas[$searchArray['area_no']]['name'].",";
            $searchArray['season_id'] = empty($info['season_id']) ? '' : $info['season_id'];
            if($searchArray['season_id'])
                $label_search .= $this->seasons[$searchArray['season_id']]['name'].",";
            $searchArray['designer_id'] = empty($info['designer_id']) ? '' : $info['designer_id'];
            if($searchArray['designer_id'])
                $label_search .= $this->designers[$searchArray['designer_id']]['name'].",";
            $searchArray['brand_id'] = empty($info['brand_id']) ? '' : $info['brand_id'];
            if($searchArray['brand_id'])
                $label_search .= $this->brands[$searchArray['brand_id']]['name'].",";
            $searchArray['book_id'] = empty($info['book_id']) ? '' : $info['book_id'];
            if($searchArray['book_id'])
                $label_search .= $this->books[$searchArray['book_id']]['name'].",";
            $searchArray['style_id'] = count($info['style']) == 0  ? '' : $this->getCommaStr($info['style'],'style_id');
            if($searchArray['style_id']){
                 $label_search .= $this->getCommaStrName($this->styles,$searchArray['style_id']);
            }
            $searchArray['acc_id'] = count($info['acc']) == 0  ? '' : $info['acc']['0']['acc_id'];
            if($searchArray['acc_id'])
                $label_search .= $this->accs[$searchArray['acc_id']]['name'].",";
            $searchArray['keyword_id'] = count($info['keyword']) == 0  ? '' : $this->getCommaStr($info['keyword'],'keyword_id');
            if($searchArray['keyword_id'])
                $label_search .= $this->getCommaStrName($this->keywords,$searchArray['keyword_id']);
            $searchArray['color_id'] = count($info['color']) == 0 ? '' : $this->getCommaStr($info['color'],'color_id');
            if($searchArray['color_id']){
                $label_search .= $this->getCommaStrName($this->colors,$searchArray['color_id']);
            }
            $searchArray['material_id'] = count($info['material']) == 0  ? '' : $this->getCommaStr($info['material'],'material_id');
            if($searchArray['material_id'])
                $label_search .= $this->getCommaStrName($this->materials,$searchArray['material_id']);
            $searchArray['description'] = empty($info['description']) ? '' : $info['description'];
            if($searchArray['description'])
                $label_search .= $searchArray['description'].",";
            if($this->cid == 24){
                $searchArray['p_type_id'] = count($info['type']) == 0 ? '' : $this->getCommaStr($info['type'],'type_id');
                if($searchArray['p_type_id'])
                    $label_search .= $this->getCommaStrName($this->types,$searchArray['p_type_id']);
                $searchArray['p_fashion_id'] = count($info['fashion']) == 0 ? '' : $this->getCommaStr($info['fashion'],'fashion_id');
                if($searchArray['p_fashion_id'])
                    $label_search .= $this->getCommaStrName($this->fashions,$searchArray['p_fashion_id']);
                $searchArray['p_craft_id'] = count($info['craft']) == 0 ? '' : $this->getCommaStr($info['craft'],'craft_id');
                if($searchArray['p_craft_id'])
                    $label_search .= $this->getCommaStrName($this->crafts,$searchArray['p_craft_id']);
                $searchArray['p_detail_id'] = count($info['detail']) == 0 ? '' : $this->getCommaStr($info['detail'],'detail_id');
                if($searchArray['p_detail_id'])
                    $label_search .= $this->getCommaStrName($this->details,$searchArray['p_detail_id']);
                $searchArray['p_pattern_id'] = count($info['pattern']) == 0 ? '' : $this->getCommaStr($info['pattern'],'pattern_id');
                if($searchArray['p_pattern_id'])
                    $label_search .= $this->getCommaStrName($this->p_patterns,$searchArray['p_pattern_id']);
            }else{
                $searchArray['fashion_id'] = count($info['fashion']) == 0 ? '' : $this->getCommaStr($info['fashion'],'fashion_id');
                if($searchArray['fashion_id'])
                    $label_search .= $this->getCommaStrName($this->fashions,$searchArray['fashion_id']);
                $searchArray['detail_id'] = count($info['detail']) == 0 ? '' : $this->getCommaStr($info['detail'],'detail_id');
                if($searchArray['detail_id'])
                    $label_search .= $this->getCommaStrName($this->details,$searchArray['detail_id']);
            }

            $searchArray['label_search'] = $label_search;
        }
        $searchPicModel = D("SearchPicture");
        $searchPicInfo = $searchPicModel->where(array('picture_id'=>$pid,'menu_id'=>$info['menu_id']))->count();
        //echo $searchPicModel->getLastSql();
        //exit();
        if($searchPicInfo > 0){
            $searchPicModel->where(array('picture_id'=>$pid,'menu_id'=>$info['menu_id']))->save($searchArray);
        }else{
            $searchPicModel->add($searchArray);
        }
        //echo $searchPicModel->getLastSql();
    }
    //区别于setConfig方法
    //由于图片是继承主题，所以有部分属性被隐藏，这里每个属性都需要重新加载一次
    public function getFileCache(){
    	//类别
        $this->sorts = F('sortList','',C('DATA_CACHE_PATH'));
        //栏目
        $this->menus = F('menuList','',C('DATA_CACHE_PATH'));
        //专栏
        $this->columns = F('columnList','',C('DATA_CACHE_PATH'));
        //季度
        $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
        //区域
        $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
        //品牌
        $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
        //设计师
        $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
        //书名
        $this->books = F('bookList','',C('DATA_CACHE_PATH'));
        //color
        $this->colors = F('colorList','',C('DATA_CACHE_PATH'));
        //style
        $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
        //pattern
        $this->patterns = F('patternList','',C('DATA_CACHE_PATH'));
        //acc
        $this->accs = F('accList','',C('DATA_CACHE_PATH'));
        //material
        $this->materials = F('materialList','',C('DATA_CACHE_PATH'));
        //关键词
        $this->keywords = F('keywordList','',C('DATA_CACHE_PATH'));
        if($this->cid == 24){
            //fashion 图案风格
            $this->fashions = F('patternFashionList','',C('DATA_CACHE_PATH'));
            //detail  图案细节
            $this->details = F('patternDetailList','',C('DATA_CACHE_PATH'));
            //craft   图案工艺
            $this->crafts = F('patternCraftList','',C('DATA_CACHE_PATH'));
            //types   图案分类
            $this->types = F('patternTypeList','',C('DATA_CACHE_PATH'));
            //types   图案图形
            $this->p_patterns = F('patternPatternList','',C('DATA_CACHE_PATH'));
        }else{
            //fashion
            $this->fashions = F('fashionList','',C('DATA_CACHE_PATH'));
            //detail
            $this->details = F('detailList','',C('DATA_CACHE_PATH'));
        }
    }
    //用逗号相连的字符串id eg: "1,2,3,4"
    public function getCommaStr($array,$keyid = 'sort_id'){
        $count = count($array);
        $str = '';
        if($count == 1){
            $str = $array['0']["$keyid"];
        }elseif($count > 1){
            foreach ($array as $key => $value) {
                $str .= $value["$keyid"].",";
            }
        }
        return $str;
    }
    //用逗号相连的字符串name eg: "男装,女装,童装,"
    //$arr ： 缓存信息
    //$commaStr ：用逗号相连的字符串id
    function getCommaStrName($arr,$commaStr){
        $commaStrArr = explode(',', $commaStr);
        $count = count($commaStrArr);
        $strName = '';
        if($count == 1){
            $strName = $arr[$commaStr]["name"].",";
        }elseif($count > 1){
            foreach ($commaStrArr as $key => $value) {
                if($value)
                    $strName .= $arr["$value"]["name"].",";
            }
            //$strName = substr($strName,0,-1);
        }
        return $strName;
    }

    /**
     *上传/编辑单个图片的压缩包
     */
    protected function picZip() {
        $pid = intval($_GET['pid']);
        if(!$pid){
            exit('参数错误，请联系技术部');
        }
        $arr['SESSIONID'] = session_id();
        $arr['pid'] = $pid;
        $arr['cmid'] = $this->modelP->getField('child_menu_id',array('id'=>$pid));
        $arr['listMenus'] = array();
        Cookie::set('_currentTmpPicUrl_', __SELF__);
        $this->assign($arr);
        $this->display('Subject/picture_zip');
    }

    protected function updateBookSort () {
        $pid = $_REQUEST['id'];
        $data['page_no'] = $page_no = $_REQUEST['val'];
        if ( empty ($pid) ) {
            return false;
        }
        $this->modelP->where(array('id'=>$pid))->save($data);
    }

    //品牌、设计师、书名弹出层数据
    public function getSiftAjax() {
        $type = $_GET['tp'];
        $siftName = $_GET['siftName'];
        $letter = iconv('GBK','utf-8',stripslashes($_GET['letter']));
        header("Content-Type:text/html; charset=utf-8");
        echo $type == 'id' ? $this->getSiftAjaxById($letter, $siftName) : $this->getSiftAjaxByText($letter, $siftName);
    }

	public function getSiftAjaxById($letter,$siftName= '' ) {
        $this->setConfig();
        if ( in_array($this->cid, array('24','25')) ) {
            //品牌
            $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
            //设计师
            $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
        }
		$letter = $letter ? $letter : $_REQUEST['letter'] ? $_REQUEST['letter'] : a;
        $letter = strtoupper($letter) == 'SIFTNAME' ? A : trim(strtoupper($letter));
		$html = '';
        $siftName = $siftName ? $siftName : $_REQUEST['siftName'] ? trim($_REQUEST['siftName']) : brands;
		$voList = $this->$siftName;
		if ($voList) {
			foreach ($voList as $key => $val) {
				$word = strtoupper(substr($val['name'], 0, strlen($letter)));
				if (preg_match('/^[a-zA-Z]+$/', $word)) {
					$voListTmp[$word][$key]["id"] = $val['id'];
					$voListTmp[$word][$key]["name"] = $val["name"];
				} else {
					$voListQt[$key]["id"] = $val['id'];
					$voListQt[$key]["name"] = trim($val["name"]);
				}
			}

			$voList = $voListTmp;
			ksort($voList);
			if (is_array($voListQt)){
				$voList['ALL'] = $voListQt;
            }
            $letter_str = $letter == 'ALL' ? '其他' : $letter;
            $html .= "<ul><li><h2 class='singleLetter'>{$letter_str}</h2>";
            if ($voList[$letter]) {
                uasort($voList[$letter], "cmp_for_bbd");
                foreach ($voList[$letter] as $key => $val) {
                    $tmp_name = $val['name'];
                    if ( $this->cid == 25 ){
                        $tmp_id = "setSiftValue({$val['id']},{$siftName})";
                    } else {
                        $tmp_id = "setSiftValue({$val['id']})";
                    }
                    $html .= "<a href='javascript:void(0)' onclick='".$tmp_id."' title=\"".$tmp_name."\" id='".$val['id']."sift'>" . $val['name'] . "</a>";
                }
            }
            $html .= '</li></ul>';
		}
		echo($html);
	}

    //品牌、设计师、书名弹出层数据
    public function getSiftAjaxByText($letter, $siftName = '') {
        $this->setConfig();
        if ( in_array($this->cid, array('24','25')) ) {
            //品牌
            $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
            //设计师
            $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
        }
        $length = strlen($letter);
        $letter = $letter ? $letter : NO;
        $html = '';
        $siftName = $siftName ? $siftName : $_REQUEST['siftName'] ? trim($_REQUEST['siftName']) : brands;
		$voList = $this->$siftName;

        if ($voList) {
            foreach ($voList as $key => $val) {
                $word = strtoupper(substr($val['name'], 0, $length));
                if ($word != strtoupper($letter))
                    continue;
                $voListTmp[$key]["id"] = $val['id'];
                $voListTmp[$key]["name"] = $val["name"];
            }
            //uasort($voListTmp, "cmp_for_bbd");
            $voList = $voListTmp;
            unset($voListTmp);
            $html .= "<ul><li><h2 class='singleLetter'>{$letter}</h2>";
            if ($voList) {
                //uasort($voList, "cmp_for_bbd");
                foreach ($voList as $key => $val) {
                    $tmp_name = $val['name'];
                    if ( $this->cid == 25 ){
                        $tmp_id = "setSiftValue({$val['id']},{$siftName})";
                    } else {
                        $tmp_id = "setSiftValue({$val['id']})";
                    }
                    $html .= "<a href='javascript:void(0)' onclick='".$tmp_id."' title=\"".$tmp_name."\" id='".$val['id']."sift'>" . $val['name'] . "</a>";
                }
            } else {
                $html .= '没有找相关数据!';
            }
            $html .= '</li></ul>';
        }
        return $html;
    }

    /***
     * 更新主题编辑中上传的图片（随即主题id）
     */
    public function updataRandPic($cid, $tid) {
        if(empty($cid) && empty($tid)){
            return false;
        }
        $m = getCidModel($cid);
        if ($tid) {
            $mS = D("{$m['subject']}");
            $tInfo = $mS->where(array('menu_id' => $cid, 'id' => $tid))->find();
        }
        //echo $mS->getLastSql();
        //dump($tInfo);
        $info = array();
        $info['subject_id'] = $tid;
        if ($tInfo) {
            $info['menu_id'] = $tInfo['menu_id'];
            $info['child_menu_id'] = $tInfo['child_menu_id'];
            $info['area_no'] = $tInfo['area_no'];
            $info['season_id'] = $tInfo['season_id'];
            $info['designer_id'] = $tInfo['designer_id'];
            $info['brand_id'] = $tInfo['brand_id'];
            $info['book_id'] = $tInfo['book_id'];
            $info['is_publish'] = $tInfo['is_publish'];
            $info['publish_time'] = $tInfo['publish_time'];
            $info['add_time'] = $_SERVER['REQUEST_TIME'];
        }
        $mP = D("{$m['picture']}");
        $mapR['subject_id'] = Cookie::get('themeAdd');
        $id_row = $mP->field('id')->where($mapR)->select();
        $is_row = $mP->where($mapR)->find();
        if ( $is_row ) {
            $pid = $mP->where($mapR)->save($info);
        }
        if ( $id_row )  foreach ($id_row as $key => $value) {
            //echo $value['id']."<br />";
            $this->setPicSort($value['id'], $tid);
            $this->setPicColumn($value['id'], $tid);
            $this->setPicStyles($value['id'], $tid);
            $this->setTotlePictureCount($tid);
        }
        Cookie::delete('themeAdd');
    }

    protected function getIdList($arr){
        if ( empty($arr) ) {
            return false;
        }
        $new_arr = array();
        foreach ($arr as $key => $value) {
            $new_arr[$key] = $value['id'];
        }
        return $new_arr;
    }
}
