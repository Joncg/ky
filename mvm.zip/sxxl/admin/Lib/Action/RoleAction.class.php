<?php
 //
 // +----------------------------------------------------+
 // | 前台角色模块 |
 // +----------------------------------------------------+
 // | Copyright (c) 2011-2011 perfectlstyle |
 // | Email perfectlystyle@gmail.com |
 // +----------------------------------------------------+
 // | This source file is subject to PHP License |
 // +----------------------------------------------------+
 //

class RoleAction extends CommonAction {

	public function _initialize() {
		parent::_initialize();
		$this->model = D('Role');
	}

	public function _filter(&$map) {
		$map['name'] = array('like', "%" . $_POST['title'] . "%");
	}

	function index() {
		$listMenus = array(array('href' => __URL__, 'title' => '角色管理'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$action_link[] = array('text' => '添加角色', 'href' => "javascript:Box.open({'id':'add','title':'添加角色','iframe':'__URL__/add','width':'500','height':'400'});");
		$this->assign('action_link', $action_link);
		//列表过滤器，生成查询Map对象
		$map = $this->_search();
		if (method_exists($this, '_filter')) {
			$this->_filter($map);
		}
		$field = '*';
		$this->_list($field, $map);
		$this->display();
	}

	/**
	 * 根据表单生成查询条件
	 * 进行列表过滤
	 */
	protected function _list($field, $map, $sortBy = '', $asc = false) {
		//排序字段 默认为主键名
		$order = !empty($sortBy) ? $sortBy : $this->model->getPk();
		$sort = $asc ? 'asc' : 'desc';
		//取得满足条件的记录数
		$count = $this->model->where($map)->count('id');
		if ($count > 0) {
			import("ORG.Util.Page");
			//创建分页对象
			if (!empty($_REQUEST ['listRows'])) {
				$listRows = $_REQUEST ['listRows'];
			} else {
				$listRows = '20';
			}
			$p = new Page($count, $listRows);
			//分页查询数据
			$voList = $this->model->where($map)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
			//echo $this->model->getlastsql();
			//分页跳转的时候保证查询条件
			foreach ($map as $key => $val) {
				if (!is_array($val)) {
					$p->parameter .= "$key=" . urlencode($val) . "&";
				}
			}
			//分页显示
			$page = $p->showOne();
			//模板赋值显示
			$this->assign('list', $voList);
			$this->assign("page", $page);
		}
		Cookie::set('_currentUrl_', __SELF__);
		return;
	}

	public function add() {
		$parent_id = intval($_GET['parent_id']);
		if ($_POST) {
			if (!$this->model->create()) {
				$this->error($this->model->getError());
			} else {
				// 写入帐号数据
				if ($result = $this->model->add()) {
					$this->savePowerNode($result);
					$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success('添加成功！');
				} else {
					$this->error('添加失败！');
				}
			}
		} else {
			$power = $this->getPowerNode($role_id);
			$this->assign('powerPublic', $power['public']);
			$this->assign('powerAll', $power['all']);
			$this->display('info');
		}
	}

	public function edit() {
		if ($_POST['id']) {
			if (!$this->model->create()) {
				$this->error($this->model->getError());
			} else {
				// 更新数据
				$result = $this->model->save();
				if (false !== $result) {
					$this->savePowerNode();
					//成功提示
					$this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
					$this->success('编辑成功!');
				} else {
					//错误提示
					$this->error('编辑失败!');
				}
			}
		} else {
			if ($_GET['id']) {
				$id = $_REQUEST[$this->model->getPk()];
				$info = $this->model->find($id);
				$this->assign('info', $info);
			}
			$role_id = intval($_GET['id']);
			$power = $this->getPowerNode($role_id);
			$this->assign('powerPublic', $power['public']);
			$this->assign('powerAll', $power['all']);
			$this->display('info');
		}
	}

	function savePowerNode($role_id = '') {
		$role_id = $role_id ? $role_id : intval($_POST['id']);
		$powers = $_POST['power'];
		$Access = M('RefAccess');
		if ($role_id) {
			$where['role_id'] = $Access->role_id = $role_id;
			$Access->where($where)->delete();
			if ($powers) {
                $size = sizeof($powers);
				foreach ($powers as $key => $node_id) {
                    //只要购买了任何一种VIP，则不能再拥有试用VIP的权限
                    if($size >2 && $role_id == 25) continue;
					$Access->node_id = $node_id;
					$Access->add();
				}
			}
		}
	}

	/**
	 * 获取角色权限
	 * @param int $role_id
	 * @return type
	 */
	function getPowerNode($role_id = '') {
        $authId = Cookie::get(C('USER_AUTH_KEY'));
		$role_id = $role_id ? $role_id : intval($_GET['id']);
		$power = array('0');
		if ($role_id) {
			$Access = M('RefAccess');
			$p = $Access->where(array('role_id'=>$role_id))->field('node_id')->select();
			if ($p) {
				foreach ($p as $val) {
					$power[] = $val['node_id'];
				}
			}
		}
		$Node = M("Node");
		$list = $Node->field('id,name,title,parent_id')->order('order_id asc')->select();
		//公共模块的权限
		$powerPublic = array();
		foreach ($list as $key => $val) {
			$moduleName = $val['name'];
			if ('PUBLIC' == strtoupper($moduleName)) {
				$powerPublic[$moduleName] = $val;
				$powerPublic[$moduleName]['checked'] = in_array($val['id'], $power) ? 'checked' : '';
				foreach ($list as $k => $v) {
					if ($v['parent_id'] == $val['id']) {
						$powerPublic[$val['name']]['child'][$k] = $v;
						$powerPublic[$val['name']]['child'][$k]['checked'] = in_array($v['id'], $power) ? 'checked' : '';
					}
				}
				unset($list[$key]);
				break;
			}
		}
		//全部模块的权限
		$powerAll = array();
		foreach ($list as $key => $val) {
			if ($val['parent_id'] == 0) {
				$powerAll[$key] = $val;
				$powerAll[$key]['checked'] = in_array($val['id'], $power) ? 'checked' : '';
				foreach ($list as $ke => $va) {
					if ($val['id'] == $va['parent_id']) {
						$powerAll[$key]['child'][$ke] = $va;
						$powerAll[$key]['child'][$ke]['checked'] = in_array($va['id'], $power) ? 'checked' : '';
						foreach ($list as $k => $v) {
							if ($va['id'] == $v['parent_id']) {
								$powerAll[$key]['child'][$ke]['child'][$k] = $v;
								$powerAll[$key]['child'][$ke]['child'][$k]['checked'] = in_array($v['id'], $power) ? 'checked' : '';
							}
						}
					}
				}
			}
		}
		return array('public'=>$powerPublic,'all'=>$powerAll);
	}

	/**
	 * 批量操作
	 */
	public function batch() {
		$actType = trim($_REQUEST['acttype']);
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if ($actType == 'remove') {
			if ($id > 0) {
				$this->model->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
			} elseif (is_array($ids) && !empty($ids)) {
				$errorNum = 0;
				foreach ($ids as $key => $id) {
					$this->model->delete(intval($id)) !== false ? '' : $errorNum++;
				}
				$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！');
			}
		} else {
			if ($actType == 'status_yes') {
				$this->model->status = 1;
			} else if ($actType == 'status_no') {
				$this->model->status = 0;
			}
			foreach ($ids as $key => $id) {
				$where = array('id'=>$id);
				$this->model->where($where)->save();
			}
			$this->success('批量操作成功！');
		}
	}
}
?>