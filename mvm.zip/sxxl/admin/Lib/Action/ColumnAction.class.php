<?php
// +----------------------------------------------------------------------
// | 专栏/国家/城市设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class ColumnAction extends AttributeAction{
	protected $model;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('SpecialColumn');
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'专栏设置'));
		$this->assign('listMenus', $listMenus);

		$action_link[] = array('text'=>'新增专栏', 'href'=>"javascript:Box.open({'id':'insert','title':'新增专栏','iframe':'".U('/Column/insert',array('pid'=>$pid))."','width':'465','height':'200'});");
		$this->assign('action_link', $action_link);

		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
		}

		$field = 'id,name,add_user_id,add_time,order_id';

		$this->_list ($field ,$map);
		$this->display ();
	}
}
?>
