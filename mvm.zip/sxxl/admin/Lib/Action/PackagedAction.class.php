<?php
class PackagedAction extends CommonAction {
    public function packaged (){
        $this->cid = $_REQUEST['cid'];
        //dump($_REQUEST);
        $id = $_REQUEST['id'];
        $cid = $_REQUEST['cid'];
        $downloadid = urlencode(authcode("tid=".$id."&cid=".$cid,"ENCODE"));
        
        $this->m = getCidModel($this->cid);
        $model = D("{$this->m['subject_extend']}");
        $where = array('subject_id' => $id);
        $row = $model->where($where)->field('zipfile_url')->find();
        if($row['zipfile_url']){
            $downloadUrl = show_pic_path($row['zipfile_url']);
            $this->assign('downloadUrl', $downloadUrl);
        }
        $this->assign('id', $id);
        $this->assign('downloadid', $downloadid);
        $this->display('Subject/packaged');
    }
    
    /**
     * 打包之后更新主题扩展表中的包字段
     */
    public function updateZipfileUrl(){
        $cid = $_REQUEST['cid'];
        $tid = $_REQUEST['tid'];
        $rearr_url = $_REQUEST['zipurl'];
        if ( empty($cid) || empty($tid) || empty($rearr_url) ){
            return false;
        }
        $this->tableArr = getCidModel($cid);
		$modelSE = D($this->tableArr['subject_extend']);
        if($modelSE->where(array('subject_id'=>$tid))->save(array('zipfile_url'=>$rearr_url)) !== false){
            echo TRUE;
        }
        else{
            echo false;
        }
    }
}