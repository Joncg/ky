<?php
// 后台主题模块
class StreetFashionAction extends SubjectAction {
	public $cid = 21;

	public function _initialize() {
		parent::_initialize();
		$this->assign('currentBase', '数据录入-街头时尚');
	}

	function index() {
		$this->themeList();
	}
	
	public function themeList() {
        $field = $this->m['subject_original'].'.id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::themeList($field,$map);
		$this->display('Subject/theme_list');
	}
	
	public function themeAdd() {
		parent::themeAdd('1');
        $this->display('Subject/invogue_theme_info');
	}
	
	public function themeEdit() {
		parent::themeEdit('1');
        $this->display('Subject/invogue_theme_info');
	}

	public function themeBatch() {
		parent::themeBatch();
	}
	
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/invogue_picture_list');
		} else {
			$this->display('Subject/trend_picture_list');
		}
	}
	
	public function picAdd() {
		parent::picAdd('1');
        $this->display('Subject/invogue_picture_info');
	}

	public function picCategory() {
		$this->_picCategory();
	}
    
    public function _picCategory() {
        $picture_id = intval($_REQUEST['picture_id']);
        $subject_id = intval($_REQUEST['subject_id']);
        $ids = $_REQUEST['ids'];
        $idArr = explode(',', $ids);
        if(empty($picture_id)){
            $picture_id = $idArr[count($idArr)-1];
        }
        $this->assign('picture_id', $picture_id);
        
        if ($_POST) {
            if(strlen($_POST['description']) > 50 ){
                $this->assign('waitSecond', 3);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('操作失败!<br />图片描述长度不能超过50!');
            }
            //dump($_POST);exit();
            if (in_array('7', $this->config) || in_array('7', $this->configS))
                $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
            if ($idArr) {
                $info = array();
                $user_auth = Cookie::get(C('USER_AUTH_KEY'));
                //$info['add_user_id'] = intval($user_auth);
                $picture_id = $_REQUEST['picture_id'];
                if ((intval($_REQUEST['child_menu_id']) || intval($picture_id)) && $_POST['change_child_menu_id'])
                    $info['child_menu_id'] = intval($_REQUEST['child_menu_id']);
                if ((intval($_REQUEST['season_id']) || intval($picture_id)) && $_POST['change_season_id'])
                    $info['season_id'] = intval($_REQUEST['season_id']);
                if ((intval($_REQUEST['designer_id']) || intval($picture_id)) && $_POST['change_designer_id'])
                    $info['designer_id'] = intval($_REQUEST['designer_id']);
                if ((intval($_REQUEST['brand_id']) || intval($picture_id)) && $_POST['change_brand_id'])
                    $info['brand_id'] = intval($_REQUEST['brand_id']);
                if ((intval($_REQUEST['book_id']) || intval($picture_id)) && $_POST['change_book_id'])
                    $info['book_id'] = intval($_REQUEST['book_id']);
                if ((intval($_REQUEST['area_id']) || intval($picture_id)) && $_POST['change_area_id'])
                    $info['area_no'] = intval($_REQUEST['area_id']);
                if ((intval($_REQUEST['detail_id']) || intval($picture_id)) && $_POST['change_detail_id'])
                    $info['detail_id'] = intval($_REQUEST['detail_id']);
                if (($_POST['sort_id'] || intval($picture_id)) && $_POST['change_sort'])
                    $info['sort_id'] = intval($_REQUEST['sort_id']);
                if (($_POST['special_column_id'] || intval($picture_id)) && $_POST['change_column'])
                    $info['special_column_id'] = intval($_REQUEST['special_column_id']);
                //print_r($info);exit;
                foreach ($idArr as $pid) {
                    $pid = intval($pid);
                    $where = array('menu_id' => $this->cid, 'id' => $pid);
                    $this->modelP->where($where)->save($info);
                    //echo $this->modelP->getlastsql();exit;
                    $this->setPicExtend($pid, $_POST);
                    
                    $this->setSift();
                    //添加图片描述
                   	$info['picture_id'] = $pid;
                   	$info['menu_id'] = $_POST['menu_id'];
                   	$info['child_menu_id'] =$_POST['child_menu_id'] ;
                   	$info['description'] = $_POST['description'];
                   	$this->setPicDescrip($info);
                   	
                    if (($_POST['acc'] || intval($picture_id)) && $_POST['change_acc'])
                        $this->setPicAcc($pid, $_POST['acc']);
                    if (($_POST['color'] || intval($picture_id)) && $_POST['change_color'])
                        $this->setPicColor($pid, $_POST['color']);
                    if (($_POST['fashion'] || intval($picture_id)) && $_POST['change_fashion'])
                        $this->setPicFashion($pid, $_POST['fashion']);
                    if (($_POST['material'] || intval($picture_id)) && $_POST['change_material'])
                        $this->setPicMaterial($pid, $_POST['material']);
                    if (($_POST['fpid'] || intval($picture_id)) && ($_POST['change_fpid'] || $_POST['change_spid'] || $_POST['change_pattern']))
                        $this->setPicPattern($pid, $_POST['fpid'], $_POST['spid'], $_POST['pattern']);

                    $style = $_POST['styles'] ? explode(',', $_POST['styles']) : '';
                    if ($style) {
                        foreach ($style as $k => $v) {
                            if ($this->styles[$v]['parent_id'] == 0) {
                                //unset($style[$k]);
                            }
                            if ($this->styles[$v]['parent_id'] > 0) {
                                $style[] = $this->styles[$v]['parent_id'];
                            }
                        }
                    }
                    $style = array_unique($style);
                    $psid = in_array($_POST['psid'], $style) ? 0 : $_POST['psid'];
                    if (($_POST['psid'] || intval($picture_id)) && ($_POST['change_psid'] || $_POST['change_style']))
                        $this->setPicStyle($pid, $psid, $style,$_POST);
                    $keyword = $_POST['keywords'] ? explode(',', $_POST['keywords']) : '';
                    $keyword = array_unique($keyword);
                    if ($keyword) {
                        foreach ($keyword as $k => $v) {
                            if (in_array($v, array(145, 146, 147, 148, 149, 159)) || $v == 0) {
                                unset($keyword[$k]);
                            }
                        }
                    }
                    if ($_POST['pkid'] || intval($picture_id) && ($_POST['change_pkid'] || $_POST['change_keyword']))
                        $this->setPicKeyword($pid, $_POST['pkid'], $keyword);
                    //图片搜索表处理
                    $this->setSearchPicture($pid, $_POST['subject_id']);
                }
                //exit('<script>self.parent.main.location.reload()</script>');
                //exit('<script>self.parent.main.closeBox();</script>');
                //成功提示
                $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('分类成功!');
            }
        } else {
            $info = $this->modelP->relation(array('style'))->where(array('menu_id' => $this->cid, 'id' => $picture_id))->find();
            $description = $this->model_picture_extend->where(array('picture_id' => $picture_id))->find();
            $info['description'] = $description['description'];
            //dump($info);
            //echo $this->modelP->getlastsql();exit('#');
            //$info['big_picture_url'] = $info['big_picture_url'] ? show_pic_path($info['big_picture_url']) : '';
            $type = $_REQUEST['type'];
            if ($type) {
                //區域
                if ($type == 'area') {
                    if (in_array('2', $this->config) || in_array('2', $this->configS))
                        $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
                    $str = '<option value="">区域选择</option>';
                    //区域格式化
                    $areaOption = $this->getAreaOption($info['area_no']);
                    exit($str . $areaOption);
                }
                //品牌
                else if ($type == 'brand') {
                    $str = '<option value="">品牌选择</option>';
                    if (in_array('3', $this->config) || in_array('3', $this->configS))
                        $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
                    if ($this->brands) {
                        foreach ($this->brands as $key => $val) {
                            $c = $info['brand_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //設計師
                else if ($type == 'designer') {
                    $str = '<option value="">設計師选择</option>';
                    if (in_array('4', $this->config) || in_array('4', $this->configS))
                        $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
                    if ($this->designers) {
                        foreach ($this->designers as $key => $val) {
                            $c = $info['designer_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //書名
                else if ($type == 'book') {
                    $str = '<option value="">書名选择</option>';
                    if (in_array('5', $this->config) || in_array('5', $this->configS))
                        $this->books = F('bookList','',C('DATA_CACHE_PATH'));
                    if ($this->books) {
                        foreach ($this->books as $key => $val) {
                            $c = $info['book_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
            }
            //季度
            if (in_array('1', $this->config) || in_array('1', $this->configS))
                $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
            //color
            if (in_array('6', $this->config) || in_array('6', $this->configS))
                $this->colors = F('colorList','',C('DATA_CACHE_PATH'));
            //style
            if (in_array('7', $this->config) || in_array('7', $this->configS))
                $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
            //fashion
            if (in_array('8', $this->config) || in_array('8', $this->configS))
                $this->fashions = F('fashionList','',C('DATA_CACHE_PATH'));
            //pattern
            if (in_array('9', $this->config) || in_array('9', $this->configS))
                $this->patterns = F('patternList','',C('DATA_CACHE_PATH'));
            //acc
            if (in_array('10', $this->config) || in_array('10', $this->configS))
                $this->accs = F('accList','',C('DATA_CACHE_PATH'));
            //material
            if (in_array('11', $this->config) || in_array('11', $this->configS))
                $this->materials = F('materialList','',C('DATA_CACHE_PATH'));
            //detail
            if (in_array('12', $this->config) || in_array('12', $this->configS))
                $this->details = F('detailList','',C('DATA_CACHE_PATH'));
            //关键词
            $this->keywords = F('keywordList','',C('DATA_CACHE_PATH'));

            if ($info['sort_id']) {
                $tmp = array();
                foreach ($info['sort_id'] as $key => $val) {
                    $tmp[] = $val['sort_id'];
                }
                $info['sort_id'] = $tmp;
            }
            if (empty($info['sort_id'])) {
                $info['sort_id'] = array($info['sort_id']);
            }
            if ($info['special_column_id']) {
                $tmp = array();
                foreach ($info['special_column_id'] as $key => $val) {
                    $tmp[] = $val['special_column_id'];
                }
                $info['special_column_id'] = $tmp;
            }
            if (empty($info['special_column_id'])) {
                $info['special_column_id'] = array($info['special_column_id']);
            }
            if ($info['acc']) {
                $tmp = array();
                foreach ($info['acc'] as $key => $val) {
                    if ($val['acc_id']) {
                        $tmp[] = $val['acc_id'];
                    }
                }
                $info['acc'] = $tmp;
            }
            if ($info['color']) {
                $tmp = array();
                foreach ($info['color'] as $key => $val) {
                    if ($val['color_id'] > 0) {
                        $tmp[] = $val['color_id'];
                    }
                }
                $info['color'] = $tmp;
            }
            if ($info['fashion']) {
                $tmp = array();
                foreach ($info['fashion'] as $key => $val) {
                    if ($val['fashion_id'] > 0) {
                        $tmp[] = $val['fashion_id'];
                    }
                }
                $info['fashion'] = $tmp;
            }
            if ($info['material']) {
                $tmp = array();
                foreach ($info['material'] as $key => $val) {
                    $tmp[] = $val['material_id'];
                }
                $info['material'] = $tmp;
            }
            if ($info['pattern']) {
                $tmp = array();
                foreach ($info['pattern'] as $key => $val) {
                    if ($val['pattern_no'] > 0) {
                        $tmp[] = $val['pattern_no'];
                    }
                }
                $info['pattern'] = $tmp;
            }
            $patternIds = $tmp ? implode(',', $info['pattern']) : '0';
            $this->assign('patternIds', $patternIds);
            if ($info['style']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['style'] as $key => $val) {
                    if ($val['style_id'] > 0) {
                        $tmp[] = $val['style_id'];
                        $tmpT[] = $this->styles[$val['style_id']]['name'];
                    }
                }
                $info['style'] = $tmp;
            }
            $styleIds = $tmp ? implode(',', $info['style']) : '0';
            $this->assign('styleIds', $styleIds);
            $this->assign('styleText', implode(',', array_unique($tmpT)));
            if ($info['keyword']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['keyword'] as $key => $val) {
                    if ($val['keyword_id'] > 0) {
                        $tmp[] = $val['keyword_id'];
                        $tmpT[] = $this->keywords[$val['keyword_id']]['name'];
                    }
                }
                $info['keyword'] = array_unique($tmp);
            }
            $keywordIds = $info['keyword'] ? implode(',', $info['keyword']) : '0';
            $this->assign('keywordIds', $keywordIds);
            $this->assign('keywordText', implode(',', array_unique($tmpT)));

            //款式分级处理
            if ($this->styles) {
                foreach ($this->styles as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $styleTmp[$key] = $val;
                        if (in_array($val['no'], $info['style'])) {
                            $public = A('Public');
                            $styleHtml = $public->getStyleByAjax($styleIds, $val['no'], 'yes');
                        }
                    }
                }
            }
            $this->assign('styleHtml', $styleHtml);
            $this->assign('styles', $styleTmp);
            //print_r($styleTmp);
            //关键词分级
            if ($this->keywords) {
                foreach ($this->keywords as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $keywordTmp[$key] = $val;
                        if (in_array($val['id'], $info['keyword'])) {
                            $public = A('Public');
                            $keywordHtml = $public->getKeywordByAjax($keywordIds, $val['id'], 'yes');
                        }
                    }
                }
            }
            $this->assign('keywordHtml', $keywordHtml);
            $this->assign('keywords', $keywordTmp);

            //图案分级处理
            if ($this->patterns) {
                foreach ($this->patterns as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $patternTmp[$key] = $val;
                        if (in_array($val['no'], $info['pattern'])) {
                            $public = A('Public');
                            $patternHtml = $public->getPatternByAjax($patternIds, $val['no'], true, 'yes');
                        }
                    }
                }
            }
            $paternHtmlArr = explode('::', $patternHtml);
            $this->assign('patternHtml', $paternHtmlArr[0]);
            $this->assign('subPatternHtml', $paternHtmlArr[1]);
            $this->assign('patterns', $patternTmp);

            if ($info['area_no']) {
                $model = D('AttributeArea');
                $row = $model->where(array('no' => $info['area_no']))->find();
                $info['areaStr'] = "<option value='{$row['no']}' selected>{$row['name']}</option>";
            }
            if ($info['brand_id']) {
                $model = D('AttributeBrand');
                $row = $model->where(array('id' => $info['brand_id']))->find();
                $info['brandStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
            if ($info['designer_id']) {
                $model = D('AttributeDesigner');
                $row = $model->where(array('id' => $info['designer_id']))->find();
                $info['designerStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
            if ($info['book_id']) {
                $model = D('AttributeBook');
                $row = $model->where(array('id' => $info['book_id']))->find();
                $info['bookStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
        }
        
        //echo '<pre>';
        //print_r($info);
        $this->assign('info', $info);
        $this->assign('subject_id', $subject_id);
        $this->assign('picture_id', $picture_id);
        $this->assign('ids', $ids);
        $this->assign('listMenus', '');
        $this->display('Subject/streefashion_picture_category');
    }

	public function picBatch() {
		parent::picBatch();
	}
}
?>
