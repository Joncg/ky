<?php

// 后台主题模块
class LayoutPlanAction extends SubjectAction {

    public $cid = 14;

    public function _initialize() {
        parent::_initialize();
        $this->assign('currentBase', '数据录入-企划方案');
    }

    function index() {
        $this->themeList();
    }

    public function themeList() {
        $field = $this->m['subject_original'] . '.id,title,title_picture_url,' . $this->m['subject_original'] . '.child_menu_id,' . $this->m['subject_original'] . '.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
        $map[$this->m['subject_original'] . '.menu_id'] = $this->cid;
        $map['is_publish'] = array('egt', 0);
        parent::themeList($field, $map);
        $this->display('Subject/theme_list');
    }

    public function themeAdd() {
        parent::themeAdd('1');
        $this->display('Subject/invogue_theme_info');
    }

    public function themeEdit() {
        parent::themeEdit('1');
        $this->display('Subject/invogue_theme_info');
    }

    public function themeBatch() {
        parent::themeBatch();
    }

    public function picList() {
        $field = $this->m['picture_original'] . '.id,subject_id,big_picture_url,small_picture_url,' . $this->m['picture_original'] . '.child_menu_id,' . $this->m['picture_original'] . '.menu_id,page_no,area_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
        $map[$this->m['picture_original'] . '.menu_id'] = $this->cid;
        $map['is_publish'] = array('egt', 0);
        parent::picList($field, $map);
        $isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
            $this->display('Subject/invogue_picture_list');
        } else {
            $this->display('Subject/trend_picture_list');
        }
    }

    public function picAdd() {
        parent::picAdd('1');
        $this->display('Subject/layoutplan_picture_info');
    }

    public function picUpload() {
        if (isset($_REQUEST['SESSIONID'])) {
            session_id($_REQUEST['SESSIONID']);
        }

        $image = _upload();
        if (empty($image)) {
            exit('0');
        }

        $original_img = $image['0']["savepath"] . $image['0']["savename"];
        $svae_name_arr = explode('.', $image['0']["savename"]);
        //生成大图
        $big_picture = $image['0']["savepath"] . $svae_name_arr['0'] . '_big.' . $svae_name_arr[1];
        $big_picture = $this->createThumbImg($original_img, $big_picture, 1200, 1800);
        //生成小图
        $small_picture = $image['0']["savepath"] . $svae_name_arr['0'] . '_small.' . $svae_name_arr[1];
        $small_picture = $this->createThumbImg($original_img, $small_picture, 460, 690);

        //生成缩略图成功则往数据库中添加数据
        if ($big_picture && $small_picture) {
            $tmp_id = intval(substr($image["img_name"], 1, 4));

            $data = array();
            $data['subject_id'] = $subject_id = intval($_REQUEST['subject_id']);
            $data['add_user_id'] = intval($_REQUEST['user_id']);
            $data['menu_id'] = intval($_REQUEST['cid']);
            $data['big_picture_url'] = str_replace(C('IMG_ROOT'), '', $big_picture);
            $data['small_picture_url'] = str_replace(C('IMG_ROOT'), '', $small_picture);
            $data['add_time'] = time() + $tmp_id;
            $data['child_menu_id'] = intval($_REQUEST['child_menu_id']);
            $data['season_id'] = intval($_REQUEST['season_id']);
            $data['designer_id'] = intval($_REQUEST['designer_id']);
            $data['brand_id'] = intval($_REQUEST['brand_id']);
            $data['book_id'] = intval($_REQUEST['book_id']);
            $data['area_no'] = intval($_REQUEST['area_no']);
            $data['page_no'] = intval(substr($image['0']['name'],1,3));
            $data['is_publish'] = intval($_REQUEST['is_publish']);
            $data['publish_time'] = $_REQUEST['publish_time'] ? strtotime($_REQUEST['publish_time']) + $tmp_id : $data['add_time'];
            $pid = $this->modelP->add($data);
            if ($pid > 0) {
                $this->setSift();
                $this->setPicExtend($pid, $data);
                $this->setPicSort($pid, $subject_id);
                $this->setPicColumn($pid, $subject_id);
                $this->setPicStyles($pid, $subject_id);
                $this->setPicMenu($pid, $subject_id);
                if ($subject_id > 0) {
                    $this->setPictureCount($subject_id, 'add');
                }
                exit('1');
            } else {
                exit('0');
            }
        } else {
            exit('0');
        }
    }

    protected function createThumbImg($original_img, $thumb_name, $width, $height) {
        if (file_exists($thumb_name)) {
            return $thumb_name;
        } else {
            import("ORG.Util.Thumb");
            $thumb = new Thumb();
            $thumb->SetVar($original_img, 'file');
            if ($thumb->BackFill($thumb_name, $width, $height) !== false) {
                //生成水印
                $water = C('UPLOAD_ROOT') . '/Public/Home/Images/water/water.png';
                $thumb->water($thumb_name, $water, null, 100);
                return $thumb_name;
            } else {
                return false;
            }
        }
    }

    public function picBatch() {
        parent::picBatch();
    }

   public function picDesAdd() {
       $model = M('RefPictureExtend');
       if($_POST){
            if(strlen($_POST['description']) > 50 ){
                $this->assign('waitSecond', 3);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('操作失败!<br />图片描述长度不能超过50!');
            }
           $data = array();
           $id = $_POST['id'];
           $data['picture_id'] = intval($_POST['pid']);
           $data['menu_id'] = $this->cid;
           $data['child_menu_id'] = 0;
           $data['description'] = trim($_POST['description']);
           if($id){
               $data['id'] = $id;
               if($model->save($data) === false){
                   $this->error('编辑失败!');
               }else{
                   $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
                   $this->success('编辑成功！');
               }
           }else{
               if($model->add($data) === false){
                   $this->error('添加失败!');
               }else{
                   $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
                   $this->success('添加成功！');
               }
           }
       }

       $pid = intval($_GET['pid']);
       if(empty($pid)){
           return false;
       }

       $Arr = array();
       $Arr['pid'] = $pid;
       $description_info = $model->where(array('menu_id'=>$this->cid,'picture_id'=>$pid))->field('id,description')->find();
       $Arr['id'] = intval($description_info['id']);
       $Arr['description'] = trim($description_info['description']);
       $this->assign($Arr);
       $this->display('Subject/layoutplan_picture_des');
   }
}

?>
