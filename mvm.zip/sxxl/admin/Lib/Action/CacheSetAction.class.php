<?php
// +----------------------------------------------------------------------
// | 缓存设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class CacheSetAction extends CommonAction{
	protected $setArr = array(
        array('key'=>'userList','title'=>'用户缓存','model'=>'SysUser'),
		array('key'=>'seasonList','title'=>'季度缓存','model'=>'AttributeSeason'),
		array('key'=>'sortList','title'=>'类别缓存','model'=>'AttributeSort','isOrder'=>1),
		array('key'=>'menuList','title'=>'栏目缓存','model'=>'Menu','isOrder'=>1),
		array('key'=>'colorList','title'=>'颜色缓存','model'=>'AttributeColor'),
		array('key'=>'accList','title'=>'配饰缓存','model'=>'AttributeAcc','isOrder'=>1),
		array('key'=>'patternList','title'=>'图案缓存','model'=>'AttributePattern','isOrder'=>1),
		array('key'=>'bookList','title'=>'书名缓存','model'=>'AttributeBook'),
		array('key'=>'areaList','title'=>'区域缓存','model'=>'AttributeArea'),
		array('key'=>'columnList','title'=>'专栏缓存','model'=>'SpecialColumn'),
		array('key'=>'materialList','title'=>'面/辅料缓存','model'=>'AttributeMaterial'),
		array('key'=>'fashionList','title'=>'风格缓存','model'=>'AttributeFashion','isOrder'=>1),
		array('key'=>'brandList','title'=>'品牌缓存','model'=>'AttributeBrand'),
		array('key'=>'designerList','title'=>'设计师缓存','model'=>'AttributeDesigner'),
		array('key'=>'styleList','title'=>'款式缓存','model'=>'AttributeStyle','isOrder'=>1),
        array('key'=>'detailList','title'=>'细节缓存','model'=>'AttributeDetail'),
        array('key'=>'keywordList','title'=>'关键词缓存','model'=>'AttributeKeyword'),
        array('key'=>'patternPatternList','title'=>'图案图形缓存','model'=>'AttributePattern'),
        array('key'=>'patternColorList','title'=>'图案颜色缓存','model'=>'AttributePatternColor'),
        array('key'=>'patternCraftList','title'=>'图案工艺缓存','model'=>'AttributePatternCraft'),
        array('key'=>'patternDetailList','title'=>'图案细节缓存','model'=>'AttributePatternDetail'),
        array('key'=>'patternFashionList','title'=>'图案风格缓存','model'=>'AttributePatternFashion'),
        array('key'=>'patternTypeList','title'=>'图案分类缓存','model'=>'AttributePatternType'),
	);

	public function _initialize(){
		$this->set();
	}
//文件缓存 路径为"../config/cache/"
	public function set(){
		foreach($this->setArr as $key=>$val){
            //$Cache = Cache::getInstance();
			$model = D($val['model']);
            if ( $val['key'] == 'seasonList' ) {
                $order = array('order_id'=>'desc');
            } else {
                $order = in_array($val['key'],array('menuList','fashionList')) ? array('order_id'=>'asc') : ($val['idOrder'] ? array('name'=>'asc') : '');
            }
            $field = in_array($val['key'],array('brandList','designerList','bookList')) ? 'id,name' : '*';
            $voList = $model->field($field)->order($order)->findAll();
            //echo $model->getLastSql()."</br>";
			if(!empty($voList)){
				$voListTmp = array();
				foreach($voList as $ke=>$va){
                    $keyTmp = $val['key'] == 'areaList' ? $va['no'] : $va['id'];
					$voListTmp[$keyTmp] = $va;
				}
				$voList = $voListTmp;
			}
			if($val['key']=='brandList'){
                uasort($voList, "cmp");
				//品牌，需要压缩
				//$voList = gzcompress(serialize($voList));
			}
            F($val['key'],$voList,C('DATA_CACHE_PATH'));
			//$Cache->set($val['key'],$voList);
		}
		$this->getPatternAttribute();//更新图片属性缓存
		$this->assign('jumpUrl', 'javascript:void(0);');
		$this->success('更新缓存成功！');
	}
	
	  //图案属性
    public function getPatternAttribute() {
        $Arr = array();
       // $cKey = md5( 'Patterns::getPatternAttribute::' .'::'.$this->soid.'::'.$this->sid.'::'.serialize($this->param));
        //$Arr = trim($_GET['cache']) == 'false' ? '' : $this->cache->get($cKey);
        if (!$Arr) {
            //图案类别
            //$voList = M('AttributePatternType')->where('parent_id = 0')->field('id,parent_id,`name`')->findAll();
            $pattern_type = F('patternTypeList','',C('DATA_CACHE_PATH'));
            $voList = $this->getPatternField($pattern_type,array('id','parent_id','name'));
            foreach ($voList as $key => $val) {
                $voList[$key]['url'] = U('/' . MODULE_NAME . '/pictureList', array('tyid' => $val['id']));
                $voList[$key]['selected'] = $this->param['tyid'] == $val['id'] ? 1 : 0;
                $subList = M('AttributePatternType')->where("parent_id = '{$val['id']}'")->field('id,parent_id,`name`')->findAll();
                if ($subList) {
                    foreach ($subList as $ke => $va) {
                        $subList[$ke]['url'] = U('/' . MODULE_NAME . '/pictureList', array('tyid' => $va['id']));
                        if ($this->param['tyid'] == $va['id']) {
                            $subList[$ke]['selected'] = 1;
                            $voList[$key]['selected'] = 1;
                        }
                    }
                }
                $voList[$key]['subList'] = $subList;
            }
            $Arr['1']['id'] = 1;
            $Arr['1']['name'] = '图案类别';
            $Arr['1']['subList'] = $voList;

            //图案
            //$voList = M('AttributePattern')->where('parent_id = 0')->field('id,parent_id,`name`')->findAll();
            $pattern = F('patternList','',C('DATA_CACHE_PATH'));
            $voList = $this->getPatternField($pattern,array('id','parent_id','name'));
            foreach ($voList as $key => $val) {
                $voList[$key]['url'] = U('/' . MODULE_NAME . '/pictureList', array_merge($this->param, array('paid' => $val['id'])));
                $voList[$key]['selected'] = $this->param['paid'] == $val['id'] ? 1 : 0;
                $subList = M('AttributePattern')->where("parent_id = '{$val['id']}'")->field('id,parent_id,`name`')->findAll();
                if ($subList) {
                    foreach ($subList as $ke => $va) {
                        $subList[$ke]['url'] = U('/' . MODULE_NAME . '/pictureList', array_merge($this->param, array('paid' => $va['id'])));
                        if ($this->param['paid'] == $va['id']) {
                            $subList[$ke]['selected'] = 1;
                            $voList[$key]['selected'] = 1;
                        }
                    }
                }
                $voList[$key]['subList'] = $subList;
            }
            $Arr['2']['id'] = 2;
            $Arr['2']['name'] = '图案';
            $Arr['2']['subList'] = $voList;

            //图案工艺
            //$voList = M('AttributePatternCraft')->field('id,`name`')->findAll();
            $pattern_craft = F('patternCraftList','',C('DATA_CACHE_PATH'));
            $voList = $this->getPatternField($pattern_craft,array('id','name'),1);
            foreach ($voList as $key => $val) {
                $voList[$key]['url'] = U('/' . MODULE_NAME . '/pictureList', array_merge($this->param, array('crid' => $val['id'])));
                $voList[$key]['selected'] = $this->param['crid'] == $val['id'] ? 1 : 0;
            }
            $Arr['3']['id'] = 3;
            $Arr['3']['name'] = '图案工艺';
            $Arr['3']['subList'] = $voList;

            //细节类别
            //$voList = M('AttributePatternDetail')->field('id,`name`')->findAll();
            $pattern_detail = F('patternDetailList','',C('DATA_CACHE_PATH'));
            $voList = $this->getPatternField($pattern_detail,array('id','name'),1);
            foreach ($voList as $key => $val) {
                $voList[$key]['url'] = U('/' . MODULE_NAME . '/pictureList', array_merge($this->param, array('deid' => $val['id'])));
                $voList[$key]['selected'] = $this->param['deid'] == $val['id'] ? 1 : 0;
            }
            $Arr['4']['id'] = 4;
            $Arr['4']['name'] = '细节类别';
            $Arr['4']['subList'] = $voList;

            $zipTypeTab['0']['id'] = '';
            $zipTypeTab['0']['name'] = 'CDR/AI格式';
            $zipTypeTab['0']['url'] = U('/' . MODULE_NAME . '/pictureList', array_merge($this->param, array('ztid' => 3)));
            $zipTypeTab['1']['id'] = '';
            $zipTypeTab['1']['name'] = 'PSD格式';
            $zipTypeTab['1']['url'] = U('/' . MODULE_NAME . '/pictureList', array_merge($this->param, array('ztid' => 2)));
            $Arr['5']['id'] = 5;
            $Arr['5']['name'] = '图案格式';
            $Arr['5']['subList'] = $zipTypeTab;
			$cache_path = C('CACHE_PATH_FILE') . "system/";
			F('patternsSubList', $Arr, $cache_path);
        }
    }
	
	
	  /**
     * @从图案相关属性中获取部分数据
     * @param type $arr 属性数组
     * @param type $fields  要获取的字段
     * @param type $is_p  是否判断父id
     * @return type  数组
     */
    protected function getPatternField($arr = array(), $fields = array(), $is_p = '', $where_field = 'parent_id', $where_value = 0){
        if ( isset($arr) && !empty($arr) ) {
            foreach ($arr as $key => $value) {
                if ( $is_p == '' ) {
                    if ( $value[$where_field] == $where_value ) {
                        foreach ( $fields as $v_field ) {
                            $voList[$key][$v_field] = $value[$v_field];
                        }
                    }
                } else {
                    foreach ( $fields as $v_field ) {
                        $voList[$key][$v_field] = $value[$v_field];
                    }
                }
            }
        }
        return $voList;
    }
}

function cmp($a, $b) {
    return $a['name'] > $b['name'];
}
?>
