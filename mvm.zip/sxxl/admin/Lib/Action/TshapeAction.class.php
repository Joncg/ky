<?php
// 后台主题模块
class TshapeAction extends SubjectAction {
	public $cid = 13;

	public function _initialize() {
		parent::_initialize();
		$listMenus = array(
			array('href' => __URL__ . '/folderList', 'selected'=>(in_array(ACTION_NAME, array('folderList','index')) ? 'now' : ''), 'title' => '文件夹'),
			array('href' => __URL__ . '/themeList', 'selected'=>(in_array(ACTION_NAME, array('themeList')) ? 'now' : ''), 'title' => '主题管理'),
			array('href' => __URL__ . '/picList', 'selected'=>(in_array(ACTION_NAME, array('picList')) ? 'now' : ''), 'title' => '图片管理'),
		);
		$this->assign('listMenus', $listMenus);
		$this->assign('currentBase', '数据录入-T台趋势');
	}

	function index() {
		$this->folderList();
	}
	
	public function labelList() {
		$folder_id = intval($_REQUEST['folder_id']);
		$field = '*';
		$map['folder_id'] = $folder_id;
		parent::labelList($field, $map);
		$this->display('Subject/label_list');
	}
	public function labelAdd() {
		parent::labelAdd();
	}
	public function labelEdit() {
		parent::labelEdit();
	}
	public function labelBatch() {
		parent::labelBatch();
	}

	public function folderList() {
        $field = $this->m['folder_original'].'.id,title,title_picture_url,'.$this->m['folder_original'].'.child_menu_id,'.$this->m['folder_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,is_publish,child_subject_count,add_user_id,publish_time,add_time';
		$map[$this->m['folder_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::folderList($field,$map);
		$this->display('Subject/folder_list');
	}
	
	public function folderAdd() {
		parent::folderAdd("1");
        $this->display('Subject/tshape_folder_info');
	}
	
	public function folderEdit() {
		parent::folderEdit();
	}

	public function folderBatch() {
		parent::folderBatch();
	}
	
	public function themeList() {
		$folder_id = $_REQUEST['folder_id'];
		$fid = $folder_id ? intval($folder_id) : intval($_REQUEST['fid']);
		if (isset($folder_id)) {
			$this->assign('listMenus', '');
		}
		$this->assign('fid', $fid);
		if ($folder_id == '0') $map['folder_id'] = 0;
        $field = $this->m['subject_original'].'.id,folder_id,lable_id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::themeList($field,$map,($folder_id ? 'lable_id' : ''));
		if (isset($folder_id)) {
			$this->display('Subject/trend_folder_theme_list');
		} else {
			$this->display('Subject/theme_list');
		}
	}
	
	public function themeAdd() {
		parent::themeAdd();
	}
	
	public function themeEdit() {
		parent::themeEdit();
	}

	public function themeBatch() {
		parent::themeBatch();
	}
	
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/picture_list');
		} else {
			$this->display('Subject/trend_picture_list');
		}
	}
    
	protected function _picList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } } 
            $this->error('参数错误！');
        $action_link = array();
        $subject_id = intval($_REQUEST['subject_id']);
        if ($subject_id) {
            $themeI = $this->modelT->where(array('menu_id' => $this->cid, 'id' => $subject_id))->field('title,picture_count')->find();
            //echo $this->modelT->getlastsql();var_dump($themeI);
            $currentName = '-主题:' . stripslashes($themeI['title']);
            $info['tmpTitle'] =  stripslashes($themeI['title']);
            $action_link[] = array('text' => '返回主题列表', 'href' => Cookie::get('_currentThemeUrl_'));
        }
        $this->assign('info', $info);
        $this->assign('currentName', $currentName . '-图片列表');
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (isset($subject_id) && !empty($subject_id) && !in_array($this->cid,array('12'))) {
             $action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加图片','url':'__URL__/picAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        }
        
        $this->assign('action_link', $action_link);
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['picture_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'publish_time';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
        if ($subject_id) {
            $map['subject_id'] = $subject_id;
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_picture_sort_original'].' ps ON ps.picture_id='.$this->m['picture_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ps.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ps.sort_id'] = $sort_id;
            }
            $field .=",sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_picture_column_original'].' pc ON pc.picture_id='.$this->m['picture_original'].'.id';
            if($column_id == 6){
                //$map['pc.special_column_id'] = array('exp','is null');
                $map['pc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['pc.special_column_id'] = $column_id;
            }
            $field .=",special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_style_original'].' pst ON pst.picture_id='.$this->m['picture_original'].'.id';
			$map['pst.style_id'] = $style_id;
            $field .=",style_id";
        }
        
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数  主题表保存有图片数量字段 field:picture_count,前提是“$subject_id”不为空才能调用这个字段 暂时注销
        if (!empty($subject_id)) {
            $count = $themeI['picture_count'];
        } else {
            import('ORG.Util.DataCount');
            $moldel = new DataCount();
            $count = $moldel->getCount("{$this->m['picture']}", $map, $join);
        }
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelP->relation(array('sort_id','special_column_id'))->where($map)->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelP->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['columnStr'] = implode(',', $column);

                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    if ($this->styles)
                        $voList[$key]['styleStr'] = $this->styles[$val['style_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    //$category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //dump($voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }


    public function picAdd() {
        parent::picAdd("1");
        $this->display('Subject/catwalk_picture_info');
	}


	public function picCategory() {
		parent::picCategory();
	}

	public function picBatch() {
		parent::picBatch();
	}
}
?>
