<?php
// 关联属性更新
class UpdateSiftAction extends CommonAction {
    protected $cid ;  //栏目id
    protected $cmid; //子栏目id
    protected $soid;  //性别id
    
    protected $arid;  //区域id 
    protected $boid; //书籍id
    protected $brid; //品牌id
    protected $deid; //设计师id
    protected $seid; //季度id
    protected $acid; //配饰id
    
    protected $fid;  //文件夹id
    protected $tid;  //主题id
    protected $pid;  //图片id
    protected $val_tmp = array(); //临时数据
    
    protected $modelF = '';//文件夹模型
    protected $modelT = '';//主题模型
    protected $modelP = '';//图片模型
    
    protected $page;        //页码
    protected $pageSize = 1;//每页显示数
    protected $page_i = 0;  //翻页标准
    protected $cid_i = 0;   //换栏目标准
    public static $cid_j = 0;   //递增栏目
    
    protected $menu_arr = array(
        array('id'=>'11','title'=>'流行趋势'),
        array('id'=>'12','title'=>'时装发布'),
        array('id'=>'13','title'=>'T台趋势'),
        array('id'=>'15','title'=>'展会材料'),
        array('id'=>'17','title'=>'正在流行'),
        array('id'=>'18','title'=>'流行分析'),
        array('id'=>'27','title'=>'手稿趋势'),
        array('id'=>'29','title'=>'市场聚焦'),
        array('id'=>'19','title'=>'时尚杂志'),
        array('id'=>'20','title'=>'品牌画册'),
        array('id'=>'22','title'=>'时尚款式'),
        array('id'=>'21','title'=>'街头时尚'),
        array('id'=>'23','title'=>'视觉营销'),
        array('id'=>'16','title'=>'矢量款式'),
        array('id'=>'24','title'=>'图案'),
        array('id'=>'25','title'=>'配饰'),
        array('id'=>'26','title'=>'书籍'),
        array('id'=>'28','title'=>'秀场提炼'),
        //array('id'=>'30','title'=>'婴童专区'),
    );
    protected $action_sift = array(
        array('id' => '1','text' => '更新文件夹属性', 'type' => "folder" ),
        array('id' => '2','text' => '更新主题属性', 'type' => "theme" ),
        array('id' => '3','text' => '更新图片属性', 'type' => "picture" ),
    );

    public function _initialize() {
        parent::_initialize();
        $this->page = empty($_REQUEST['page']) ? 1 : $_REQUEST['page'];
        $this->assign('action_sift', $this->action_sift);
        $this->assign('menu_arr', $this->menu_arr);
    }
    
    public function index(){
        $cid_j = intval($_REQUEST['cid_j']) ? intval($_REQUEST['cid_j']) : self::$cid_j;
        $tmp_cid = intval($_REQUEST['cid']) ? intval($_REQUEST['cid']) : $this->menu_arr[$cid_j]['id'];
        $this->cid = intval($_REQUEST['cid']) ? intval($_REQUEST['cid']) : "";
        $act = $_REQUEST['act'] ? $_REQUEST['act'] : '';
        if( $_REQUEST['is_do'] ) {
            $this->_getFreshCid($tmp_cid);
            if($this->cid) {
                $this->_actSift();
            } else {
                $this->_moreActSift();
            }
        }
        Cookie::set('_currentUpdateSiftUrl_', __SELF__);
		$this->display ();
    }
    
    /**
     * @每个栏目执行更新关联操作
     */
    protected function _moreActSift(){
        $cid_j = intval($_REQUEST['cid_j']) ? intval($_REQUEST['cid_j']) : self::$cid_j;
        $this->cid = intval($_REQUEST['cid']) ? intval($_REQUEST['cid']) : $this->menu_arr[$cid_j]['id'];
        if ( $_REQUEST['act'] ) {
            //echo "111111111111";
            $act = $_REQUEST['act'];
            $this->$act();
            if ( $this->page_i > 0 ) {
                ++$this->page;
            } elseif ( $this->page_i == 0 ) {
                $cid_j = ++$cid_j;
                echo "<script>window.location='?is_do=1&act={$act}&cid_j={$cid_j}';</script>";
            }
            if ( $this->cid_i == 0 ) {
                ++$cid_j;
            }
            //echo $cid_j."uuuuuuuuuu";
            echo "<script>window.location='?is_do=1&act={$act}&cid_j={$cid_j}&page={$this->page}';</script>";
        } else {
            //echo "222222222222";
            $this->folder();
            $this->theme();
            $this->picture();
            if ( $this->page_i > 0 ) {
                ++$this->page;
            } elseif ( $this->page_i == 0 ) {
                $cid_j = ++$cid_j;
                echo "<script>window.location='?is_do=1&cid_j={$cid_j}';</script>";
            }
            if ( $this->cid_i == 0 ) {
                ++$cid_j;
            }
            //echo $cid_j."uuuuuuuuuu";
            echo "<script>window.location='?is_do=1&cid_j={$cid_j}&page={$this->page}';</script>";
        }
    }
    
    /**
     * @单个栏目执行更新关联操作
     */
    protected function _actSift(){
        if ( $_REQUEST['act'] ) {
            //echo self::$cid_j."3333333333333";
            $act = $_REQUEST['act'];
            $this->$act();
            if ( $this->page_i > 0 ) {
                ++$this->page;
            }
            echo "<script>window.location='?is_do=1&cid={$this->cid}&act={$act}&page={$this->page}';</script>";
        } else {
            //echo self::$cid_j."4444444444444";
            $this->folder();
            $this->theme();
            $this->picture();
            if ( $this->page_i > 0 ) {
                ++$this->page;
            }
            echo "<script>window.location='?is_do=1&cid={$this->cid}&act={$act}&page={$this->page}';</script>";
        }
    }

    /**
     * 文件夹关联属性更新
     */
    public function folder(){
        $pageStart = ($this->page - 1) * $this->pageSize;
        
        $folder_original = $this->m['folder_original'];
        $field = $folder_original.".id,{$folder_original}.menu_id,{$folder_original}.child_menu_id,area_no,book_id,brand_id,designer_id,season_id";
        $order = array('id'=>'asc');
        $where[$folder_original.'.menu_id'] = $this->cid;
        
        $vo_list = $this->modelF->where($where)->field($field)->order($order)->limit($pageStart . ',' . $this->pageSize)->findAll();
        echo $this->modelF->getLastSql()."<br>";
        //dump($vo_list);exit();
        if($vo_list){
            foreach ($vo_list as $key => $val) {
                $this->fid = $val['id'];
                $this->cid = intval($val['menu_id']);
                $this->cmid = intval($val['child_menu_id']);
                $this->arid = $val['area_no'];
                $this->boid = $val['book_id'];
                $this->brid = $val['brand_id'];
                $this->deid = $val['designer_id'];
                $this->seid = $val['season_id'];
                //性别
                $so_list = D("{$this->m['ref_folder_sort']}")->where(array('folder_id'=>$this->fid,'menu_id'=>$val['menu_id']))->findAll();
                //专栏
                $s_list = D("{$this->m['ref_folder_column']}")->where(array('folder_id'=>$this->fid,'menu_id'=>$val['menu_id']))->findAll();
                foreach ( $so_list as $so_k => $so_v ) {
                    if ( count($s_list) > 0 ){
                        foreach ( $s_list as $s_k => $s_v ) {
                            $this->soid = intval($so_v['sort_id']);
                            $this->sid = intval($s_v['special_column_id']);
                            $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list';
                            $map['menu_id'] = $this->cid;
                            $map['child_menu_id'] = $this->cmid;
                            $map['special_column_id'] = $this->sid;
                            $map['sort_id'] = $this->soid;
                            $sift_list = $this->modelS->field($field)->where($map)->findAll();
                            echo $this->modelS->getLastSql()."<br>";
                            $this->val_tmp = $sift_list;
                            dump($this->val_tmp);
                            //公共属性更新
                            $this->publicSift();
                        }
                    } else {
                        $this->soid = intval($so_v['sort_id']);
                        $this->sid = 0;
                        $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list';
                        $map['menu_id'] = $this->cid;
                        $map['child_menu_id'] = $this->cmid;
                        $map['special_column_id'] = $this->sid;
                        $map['sort_id'] = $this->soid;
                        $sift_list = $this->modelS->field($field)->where($map)->findAll();
                        echo $this->modelS->getLastSql()."<br>";
                        $this->val_tmp = $sift_list;
                        dump($this->val_tmp);
                        
                        //公共属性更新
                        $this->publicSift();
                    }
                }
            }
            ++$this->page_i;
            ++$this->cid_i;
        }
    }
    
    /**
     * @主题关联属性更新
     */
    public function theme(){
        $pageStart = ($this->page - 1) * $this->pageSize;
        
        $subject_original = $this->m['subject_original'];
        $field = $subject_original.".id,{$subject_original}.menu_id,{$subject_original}.child_menu_id,area_no,book_id,brand_id,designer_id,season_id";
        $order = array('id'=>'asc');
        $where[$subject_original.'.menu_id'] = $this->cid;
        
        $is_acc = isset($this->m['ref_subject_acc']);
        if ( $is_acc ) {
            //配饰
            $join[] = $this->m['ref_subject_acc_original'].' sc ON sc.subject_id='.$this->m['subject_original'].'.id';
            $field .=",sc.acc_id";
        }
        
        $vo_list = $this->modelT->where($where)->join($join)->field($field)->order($order)->limit($pageStart . ',' . $this->pageSize)->findAll();
        echo $this->modelT->getLastSql()."<br>";
        //dump($vo_list);
        if($vo_list){
            foreach ($vo_list as $key => $val) {
                $this->tid = $val['id'];
                $this->cid = intval($val['menu_id']);
                $this->cmid = intval($val['child_menu_id']);
                $this->arid = $val['area_no'];
                $this->boid = $val['book_id'];
                $this->brid = $val['brand_id'];
                $this->deid = $val['designer_id'];
                $this->seid = $val['season_id'];
                if ( $is_acc ) $this->acid = $val['acc_id'];
                //性别
                $so_list = D("{$this->m['ref_subject_sort']}")->where(array('subject_id'=>$this->tid,'menu_id'=>$val['menu_id']))->findAll();
                //专栏
                $s_list = D("{$this->m['ref_subject_column']}")->where(array('subject_id'=>$this->tid,'menu_id'=>$val['menu_id']))->findAll();
                //dump($s_list);exit();
                foreach ( $so_list as $so_k => $so_v ) {
                    if ( count($s_list) > 0 ){
                        foreach ( $s_list as $s_k => $s_v ) {
                            $this->soid = intval($so_v['sort_id']);
                            $this->sid = intval($s_v['special_column_id']);
                            $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list,acc_id_list';
                            $map['menu_id'] = $this->cid;
                            $map['child_menu_id'] = $this->cmid;
                            $map['special_column_id'] = $this->sid;
                            $map['sort_id'] = $this->soid;
                            $sift_list = $this->modelS->field($field)->where($map)->findAll();
                            echo $this->modelS->getLastSql()."<br>";
                            $this->val_tmp = $sift_list;
                            //dump($this->val_tmp);
                            //公共属性更新
                            $this->publicSift();
                            //配饰
                            if ( $is_acc ) $this->arrSift('acid','acc_id_list');
                        }
                    } else {
                        $this->soid = intval($so_v['sort_id']);
                        $this->sid = 0;
                        $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list,acc_id_list';
                        $map['menu_id'] = $this->cid;
                        $map['child_menu_id'] = $this->cmid;
                        $map['special_column_id'] = $this->sid;
                        $map['sort_id'] = $this->soid;
                        $sift_list = $this->modelS->field($field)->where($map)->findAll();
                        echo $this->modelS->getLastSql()."<br>";
                        $this->val_tmp = $sift_list;
                        //dump($this->val_tmp);
                        //公共属性更新
                        $this->publicSift();
                        //配饰
                        if ( $is_acc ) $this->arrSift('acid','acc_id_list');
                    }
                }
            }
            ++$this->page_i;
            ++$this->cid_i;
        }
    }
    
    /**
     * @主题关联属性更新
     */
    public function picture(){
        $pageStart = ($this->page - 1) * $this->pageSize;
        
        $picture_original = $this->m['picture_original'];
        $field = $picture_original.".id,{$picture_original}.menu_id,{$picture_original}.child_menu_id,area_no,book_id,brand_id,designer_id,season_id";
        $order = array('id'=>'asc');
        $where[$picture_original.'.menu_id'] = $this->cid;
        
        $is_acc = isset($this->m['ref_picture_acc']);
        if ( $is_acc ) {
            //配饰
            $join[] = $this->m['ref_picture_acc_original'].' sc ON sc._picture_id='.$this->m['picture_original'].'.id';
            $field .=",sc.acc_id";
        }
        
        $vo_list = $this->modelP->where($where)->join($join)->field($field)->order($order)->limit($pageStart . ',' . $this->pageSize)->findAll();
        echo $this->modelP->getLastSql()."<br>";
        //dump($vo_list);exit();
        if($vo_list){
            foreach ($vo_list as $key => $val) {
                $this->pid = $val['id'];
                $this->cid = intval($val['menu_id']);
                $this->cmid = intval($val['child_menu_id']);
                $this->arid = $val['area_no'];
                $this->boid = $val['book_id'];
                $this->brid = $val['brand_id'];
                $this->deid = $val['designer_id'];
                $this->seid = $val['season_id'];
                if ( $is_acc ) $this->acid = $val['acc_id'];
                //性别
                $so_list = D("{$this->m['ref_picture_sort']}")->where(array('picture_id'=>$this->pid,'menu_id'=>$val['menu_id']))->findAll();
                //专栏
                $s_list = D("{$this->m['ref_picture_column']}")->where(array('picture_id'=>$this->pid,'menu_id'=>$val['menu_id']))->findAll();
                foreach ( $so_list as $so_k => $so_v ) {
                    if ( count($s_list) > 0 ){
                        foreach ( $s_list as $s_k => $s_v ) {
                            $this->soid = intval($so_v['sort_id']);
                            $this->sid = intval($s_v['special_column_id']);
                            $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list,acc_id_list';
                            $map['menu_id'] = $this->cid;
                            $map['child_menu_id'] = $this->cmid;
                            $map['special_column_id'] = $this->sid;
                            $map['sort_id'] = $this->soid;
                            $sift_list = $this->modelS->field($field)->where($map)->findAll();
                            echo $this->modelS->getLastSql()."<br>";
                            $this->val_tmp = $sift_list;
                            dump($this->val_tmp);
                            //公共属性更新
                            $this->publicSift();
                            //配饰
                            if ( $is_acc ) $this->arrSift('acid','acc_id_list');
                        }
                    } else {
                        $this->soid = intval($so_v['sort_id']);
                        $this->sid = 0;
                        $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list,acc_id_list';
                        $map['menu_id'] = $this->cid;
                        $map['child_menu_id'] = $this->cmid;
                        $map['special_column_id'] = $this->sid;
                        $map['sort_id'] = $this->soid;
                        $sift_list = $this->modelS->field($field)->where($map)->findAll();
                        echo $this->modelS->getLastSql()."<br>";
                        $this->val_tmp = $sift_list;
                        dump($this->val_tmp);
                        //公共属性更新
                        $this->publicSift();
                        //配饰
                        if ( $is_acc ) $this->arrSift('acid','acc_id_list');
                    }
                }
            }
            ++$this->page_i;
            ++$this->cid_i;
        }
    }
    
    /**
     * @公共属性更新
     */
    protected function publicSift(){
        //区域
        $this->arrSift('arid','area_no_list');
        //书名
        $this->arrSift('boid','book_id_list');
        //品牌
        $this->arrSift('brid','brand_id_list');
        //设计师
        $this->arrSift('deid','designer_id_list');
        //季度
        $this->arrSift('seid','season_id_list');
        //unset($this->val_tmp);
    }
    
    /**
     * 属性设置
     * @return type
     */
     protected function arrSift($sift,$sift_field){
        if(empty($this->$sift)) return false;
        if($this->val_tmp[0]['id']){
            if(in_array($this->$sift,explode(',',$this->val_tmp[0][$sift_field]))) return false;
            $info[$sift_field] = $this->val_tmp[0][$sift_field] ? $this->val_tmp[0][$sift_field].','.$this->$sift : $this->$sift;
            $this->modelS->where(array('id'=>$this->val_tmp[0]['id']))->save($info);
            echo $this->modelS->getLastSql()."</br>";
        }else{
            $info_add['special_column_id'] = $this->sid;
            $info_add['sort_id'] = $this->soid;
            $info_add['menu_id'] = $this->cid;
            $info_add['child_menu_id'] = $this->cmid;
            $is_add = $this->modelS->where($info_add)->find();
            if ( !$is_add ) {
                $this->modelS->add($info_add);
            }
            echo $this->modelS->getLastSql()."</br>";
        }
     } 
     
    /**
     * @选择模型
     * @param type $cid
     */
    protected function _getFreshCid($cid,$more = '0'){
        $this->m = getCidModel($cid);
        if (isset($this->m['folder'])) {
            $this->modelF = D("{$this->m['folder']}");
        }
        $this->modelT = D("{$this->m['subject']}");
        $this->modelP = D("{$this->m['picture']}");
        $this->modelS = D("AttributeSift");
    }
    
    
}
?>
