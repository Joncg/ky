<?php
// +----------------------------------------------------------------------
// | 款式设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class StyleAction extends AttributeAction{
	protected $model;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('AttributeStyle');
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'款式设置'));
		$this->assign('listMenus', $listMenus);
		$pid = intval($_GET['pid']);
		$map['parent_id'] = array('eq',$pid);
		$name = $_REQUEST['chs'];
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
			unset($map['parent_id']); //搜索关键字时应该去掉此项
		}
		$field = 'id,name,parent_id,type,add_user_id,add_time,order_id';
		$this->_list ($field ,$map);
        
        $action_link = array();
		if($pid >0){
			$mapTmp['id'] = array('eq',$pid);
			$pidTmp = $this->model->where($mapTmp)->getField('parent_id');
			$action_link[] = array('text'=>'返回上级', 'href'=>U('/Style/index',array('pid'=>$pidTmp)));
            //$action_link[] = array('text'=>'返回上级', 'href'=>Cookie::get('_currentParamUrl_'));
		}
        $action_link[] = array('text'=>'新增款式', 'href'=>"javascript:Box.open({'id':'insert','title':'新增款式','iframe':'".U('/Style/insert',array('pid'=>$pid))."','width':'465','height':'200'});");
		$this->assign('action_link', $action_link);
        
		$this->display ();
	}

	public function edit(){
		//保存
		if($_POST['id']){
            //dump($_POST);exit();
			if($data = $this->model->create()) {
				if($this->model->save() !== false){
                    $where['parent_id'] = $_POST['id'];
                    $save['type'] = $_POST['type'];
                    $this->model->where($where)->save($save);
					$this->ajaxReturn($data,'编辑成功！',1);
				}
				else{
					$this->ajaxReturn($data,'编辑失败！',0);
				}
			}
		}
		$id = intval($_GET['id']);
		$info = $this->model->find($id);
		$this->assign('info',$info);
        $this->assign('tab',$this->tab);
		$this->display();
	}

    
}
?>
