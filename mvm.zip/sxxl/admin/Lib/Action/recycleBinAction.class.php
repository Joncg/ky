<?php
// 后台主题模块
class RecycleBinAction extends SubjectAction {
    public $cid;
	public function _initialize() {
        $this->cid = intval($_REQUEST['menu_id']);
        $ny_cid_request = intval($_REQUEST['ny_cid']) ? intval($_REQUEST['ny_cid']) : 0;
		parent::_initialize();
		$this->assign('currentBase', '数据录入-回收站');
		$columnMenus = array(
			array('href' => __URL__ . '/index/is_publish/-1', 'selected'=>((!$_REQUEST['menu_id'] || intval($_REQUEST['menu_id']) == 0) ? 'now' : ''), 'title' => '其他公共'),//17
			array('href' => __URL__ . '/index/menu_id/12', 'selected'=>(in_array($_REQUEST['menu_id'], array('12')) ? 'now' : ''), 'title' => '时装发布'),//12
			array('href' => __URL__ . '/index/menu_id/15', 'selected'=>(in_array($_REQUEST['menu_id'], array('15')) ? 'now' : ''), 'title' => '展会材料'),//15
			array('href' => __URL__ . '/index/menu_id/17', 'selected'=>(in_array($_REQUEST['menu_id'], array('17')) && $ny_cid_request == 0 ? 'now' : ''), 'title' => '正在流行'),//17
			array('href' => __URL__ . '/index/menu_id/19', 'selected'=>(in_array($_REQUEST['menu_id'], array('19')) ? 'now' : ''), 'title' => '时尚杂志'),//19
			array('href' => __URL__ . '/index/menu_id/22', 'selected'=>(in_array($_REQUEST['menu_id'], array('22')) && $ny_cid_request == 0 ? 'now' : ''), 'title' => '时尚款式'),//22
			array('href' => __URL__ . '/index/menu_id/24', 'selected'=>(in_array($_REQUEST['menu_id'], array('24')) ? 'now' : ''), 'title' => '图案'),//24
            array('href' => __URL__ . '/index/menu_id/101/ny_cid/101/is_ny/101', 'selected'=>($_REQUEST['menu_id'] == 101 ? 'now' : ''), 'title' => '内衣-正在流行'),//101
            array('href' => __URL__ . '/index/menu_id/100/ny_cid/100/is_ny/100', 'selected'=>($_REQUEST['menu_id'] == 100 ? 'now' : ''), 'title' => '内衣-矢量款式'),//100
            array('href' => __URL__ . '/index/menu_id/102/ny_cid/102/is_ny/102', 'selected'=>($_REQUEST['menu_id'] == 102 ? 'now' : ''), 'title' => '内衣-时尚款式'),//102
		);
        
		$listMenus = array(
            array('href' => __URL__ . '/recycleFolderList/menu_id/'.$_REQUEST['menu_id'].'/ny_cid/'.$ny_cid_request.'/is_ny/'.$_REQUEST['is_ny'], 'selected'=>(in_array(ACTION_NAME, array('recycleFolderList','index')) ? 'now' : ''), 'title' => '文件夹'),
			array('href' => __URL__ . '/recycleThemeList/menu_id/'.$_REQUEST['menu_id'].'/ny_cid/'.$ny_cid_request.'/is_ny/'.$_REQUEST['is_ny'], 'selected'=>(in_array(ACTION_NAME, array('recycleThemeList')) ? 'now' : ''), 'title' => '主题'),
			array('href' => __URL__ . '/recyclePicList/menu_id/'.$_REQUEST['menu_id'].'/ny_cid/'.$ny_cid_request.'/is_ny/'.$_REQUEST['is_ny'], 'selected'=>(in_array(ACTION_NAME, array('recyclePicList')) ? 'now' : ''), 'title' => '图片'),
		);
        if ( $this->cid == 102 ) {
            $listMenus = array_merge($listMenus, array(array('href' => __URL__ . '/recycleSubPic/menu_id/'.$_REQUEST['menu_id'].'/ny_cid/'.$ny_cid_request.'/is_ny/'.$_REQUEST['is_ny'], 'selected'=>(in_array(ACTION_NAME, array('recycleSubPic')) ? 'now' : ''), 'title' => '附图')));
        }
        
        if ($this->menus) {
            $fatherMenusAll = $childMenusAll = array();
            foreach ($this->menus as $key => $val) {
                if ($val['parent_id'] == 0) {
                    $fatherMenusAll[$key] = $val;
                }
                if ($val['parent_id'] != 0) {
                    $childMenusAll[$key] = $val;
                }
            }
        } $this->assign('fatherMenusAll', $fatherMenusAll);
        $this->assign('childMenusAll', $childMenusAll);
		$this->assign('ny_cid', $ny_cid_request);
        $this->assign('memu_id', $_REQUEST['menu_id']);
		$this->assign('listMenus', $listMenus);
		$this->assign('columnMenus', $columnMenus);
	}

	function index() {
		$this->recycleFolderList();
	}

	public function recycleFolderList() {
        $field = $this->m['folder_original'].'.id,title,title_picture_url,'.$this->m['folder_original'].'.child_menu_id,'.$this->m['folder_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,child_subject_count,is_publish,add_user_id,publish_time,add_time';
		if ( $this->cid ) {
            $map[$this->m['folder_original'].'.menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $this->cid;
        }
        $map['is_publish'] = -1;
		$this->_folderList($field,$map);
        //类别
        $this->sorts = F('sortList','',C('DATA_CACHE_PATH'));
        $this->assign('sorts',$this->sorts);
		$this->assign('action_link', '');
		$this->display('Subject/recycle_folder_list');
	}
	
	public function recycleFolderBatch() {
		$actType = trim($_REQUEST['acttype']);
		$ids = $_REQUEST['ids'];
		if (empty($ids)) return false;
		if ($actType == 'remove') {
			foreach ($ids as $id) {
//				$row = $this->getSPid($id);
//				if ($row) {
//					foreach ($row as $v) {
//						$this->modelF->delete($v);
//					}
//				}
				$this->modelF->delete($id);	
			}
		} else {
			$info = array('is_publish' => 0);
			foreach ($ids as $id) {
				$where = array('id' => $id);
				$this->modelF->where($where)->save($info);
                //echo $this->modelF->getLastSql();
			}
		}
		$this->success('操作成功！');
	}
	
	public function recycleThemeList() {
		$field = $this->m['subject_original'].'.id,title,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		if (in_array($this->cid, array('11','12','13','15','18','24'))){
            $field .= ',folder_id';
        }
        if ( $this->cid ) {
            $map[$this->m['subject_original'].'.menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $this->cid;
        }
		$map['is_publish'] = -1;
		$this->_themeList($field,$map);
		$this->assign('action_link', '');
		$this->display('Subject/recycle_theme_list');
	}
	
	public function recycleThemeBatch() {
		$actType = trim($_REQUEST['acttype']);
		$ids = $_REQUEST['ids'];
		if (empty($ids)) return false;
		if ($actType == 'remove') {
			foreach ($ids as $id) {
//				$row = $this->getSPid($id);
//				if ($row) {
//					foreach ($row as $v) {
//						if ($v) {
//							parent::delPicOther($v);
//							$this->modelP->delete($v);
//						}
//					}
//				}
				
				//$info = $this->modelT->where('id='.$id)->find();
				$this->modelT->delete($id);

				parent::delThemeOther($id); //删除扩展/ACC/推荐 信息
				//删除 专栏/款式/图片 关联信息 (Jialiang Qin 2012.10.13)
				$this->modelP->where('subject_id='.$id)->delete();
				D('RefShareSubjectStyle')->where('subject_id='.$id)->delete();
				D('RefShareSubjectSpecialColumn')->where('subject_id='.$id)->delete();

                //echo $this->modelT->getLastSql();
                //exit ();
			}
		} else {
			$data['is_publish'] = $info['is_publish'] = 0;
			foreach ($ids as $id) {
                $row = $this->getSPid($id);
                $info['picture_count'] = count($row);
				$where = array('id' => $id);
				$this->modelT->where($where)->save($info);
                $cid = $this->modelT->getField('menu_id',array('id'=>$id));
                if (in_array($cid, array(11,12,13,15,18,24))){
                    parent::setFCount($id);
                }
				if ($row) {
					foreach ($row as $v) {
						$where = array('id'=>$v);
						$this->modelP->where($where)->save($data);
					}
				}
			}
		}
		$this->success('操作成功！');
	}

	protected function getSPid($id) {
		if ($this->cid) {
			$where['menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $this->cid;
		}
		$where['subject_id'] = $id;
		$row = $this->modelP->field('id')->where($where)->select();
        //echo $this->modelP->getLastSql();exit();
		$rarr = array();
		if ($row) {
			foreach ($row as $val) {
				$rarr[] = $val['id'];
			}
		}
		return $rarr;
	}
	
	public function recyclePicList() {
		$field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,page_no,season_id,designer_id,brand_id,book_id,is_publish,add_user_id,publish_time,add_time';
		if ( $this->cid ) {
            $map[$this->m['picture_original'].'.menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $this->cid;
        }
		$map['is_publish'] = -1;
		$this->_picList($field, $map);
		$this->assign('action_link', '');
		$this->display('Subject/recycle_picture_list');
	}
	
	public function recycleSubPic() {
		$field = $this->m['picture_subsidiary_original'].'.id,picture_id,big_picture_url,small_picture_url,'.$this->m['picture_subsidiary_original'].'.child_menu_id,'.$this->m['picture_subsidiary_original'].'.menu_id,area_no,page_no,season_id,designer_id,brand_id,book_id,is_publish,add_user_id,publish_time,add_time';
		if ( $this->cid ) {
            $map[$this->m['picture_subsidiary_original'].'.menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $this->cid;
        }
		$map['is_publish'] = -1;
		$this->_subPicList($field, $map);
		$this->assign('action_link', '');
		$this->display('Subject/recycle_sub_picture_list');
	}
	
	public function recyclePicBatch() {
		$actType = trim($_REQUEST['acttype']);
		$ids = $_REQUEST['ids'];
		if (empty($ids)) return false;
		if ($actType == 'remove') {
			foreach ($ids as $id) {
				parent::delPicOther($id);
				$this->modelP->delete($id);
			}
		} else {
            $info['is_publish'] = 0;
			foreach ($ids as $key => $id) {
				$where = array('id' => $id);
				$this->modelP->where($where)->save($info);
                //echo $this->modelP->getLastSql();
                $this->setPCount($id);
			}
		}
		$this->success('操作成功！');
	}
    
    public function recycleSubPicBatch() {
		$actType = trim($_REQUEST['acttype']);
		$ids = $_REQUEST['ids'];
		if (empty($ids)) return false;
		if ($actType == 'remove') {
			foreach ($ids as $id) {
				//parent::delSubPicOther($id);
				$this->modelS->delete($id);
			}
		} else {
            $info['is_publish'] = 0;
			foreach ($ids as $key => $id) {
				$where = array('id' => $id);
				$this->modelS->where($where)->save($info);
                //echo $this->modelP->getLastSql();
			}
		}
		$this->success('操作成功！');
	}
    
    public function setPCount($pid) {
        $pid = intval($pid);
        if (empty($pid))
            return false;
        $where = array('id' => $pid);
        $subject_id = $this->modelP->where($where)->getField('subject_id');
        $map['id'] = $subject_id;
        $data['picture_count'] = array('exp','picture_count+1');
        $this->modelT->where($map)->save($data);
        //echo $this->modelT->getLastSql();exit();
    }
    /**
     * 文件夹列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function _folderList($field = '*', $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-文件夹  列表');
        $action_link = array();
        $action_link[] = array('text' => '添加文件夹', 'href' => "__URL__/folderAdd");
        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $menu_id = intval($_REQUEST['one_menu_id']);
        if ($menu_id)
            $map[$this->m['folder_original'].'.menu_id'] = $menu_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['folder_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);

        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $pattern_id = intval($_REQUEST['pattern_id']);
        if ($pattern_id)
            $map['pattern_id'] = $pattern_id;
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($designer_id){
            $checkDesignerName = $this->designers[$designer_id]['name'];
            $this->assign('checkDesigner',$checkDesignerName);
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : $this->modelF->getPk();
        $sort = $asc ? 'desc' : 'asc';
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_folder_sort_original'].' fs ON fs.folder_id='.$this->m['folder_original'].'.id';
            if ( $sort_id == 3 ){
                $map['fs.sort_id'] = array('egt',$sort_id);
            } else {
                $map['fs.sort_id'] = $sort_id;
            }
            $field .=",fs.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_folder_column_original'].' fc ON fc.folder_id='.$this->m['folder_original'].'.id';
			if($column_id == 6){
                $map['fc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['fc.special_column_id'] = $column_id;
            }
            $field .=",fc.special_column_id";
        }
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        import('ORG.Util.DataCount');
        $count = DataCount::getCount("{$this->m['folder']}", $map, $join);
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelF->relation(array('sort_id','special_column_id'))->where($map)->field($field)->join($join)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelF->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);
                    //$tc = $this->modelT->where("folder_id='{$val['id']}' and is_publish!=-1")->count('*');
                    //$voList[$key]['themeCount'] = intval($tc);
                    $voList[$key]['themeCount'] = $voList[$key]['child_subject_count'];
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    if ($this->patterns)
                        $voList[$key]['patternStr'] = $this->patterns[$val['pattern_id']]['name'];
                }
            }
            //dump($voList);
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        Cookie::set('_currentFolderUrl_', __SELF__);
        return;
    }

    
    /**
     * 主题列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function _themeList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-主题列表');
        $action_link = array();
        $folder_id = $_REQUEST['folder_id'];
        if (isset($folder_id)) {
            $action_link[] = array('text' => '返回文件夹', 'href' => Cookie::get('_currentFolderUrl_'));
        }
        if (isset($folder_id) && !empty($folder_id)) {
            $folder_data = $this->modelF->getById($folder_id);
            $this->assign('folderTitle', "文件夹：".stripslashes($folder_data['title']));
            if (!in_array($this->cid,array(12))){$action_link[] = array('text' => '标签管理', 'href' => "__URL__/labelList/folder_id/{$folder_id}");}
            $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/folder_id/{$folder_id}");
        }
        if(in_array($this->cid,array('17','27','19','20','21','23','25','26','28')))
                $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/");

        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (intval($folder_id))
            $map['folder_id'] = intval($folder_id);
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id){
            $map[$this->m['subject_original'].'.menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $menu_id;
        }
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['subject_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        if($designer_id){
            $checkDesignerName = $this->designers[$designer_id]['name'];
            $this->assign('checkDesigner',$checkDesignerName);
        }
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $checkBrand = "";
            $checkBrand .= "<option value=".$brand_id." selected='selected'>$checkBrandName</option>";
            $this->assign('checkBrand',$checkBrand);
        }
        if($book_id){
            $checkBookName = $this->books[$book_id]['name'];
            $checkBook = "";
            $checkBook .= "<option value=".$book_id." selected='selected'>$checkBookName</option>";
            $this->assign('checkBook',$checkBook);
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        if($this->cid == 12){
            $order = $this->modelT->getPk();
        }  else {
            $order = !empty($sortBy) ? $sortBy : $this->modelT->getPk();;
        }
        $sort = $asc ? 'desc' : 'asc';
        //风格筛选
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id){
			$join[] = $this->m['ref_subject_fashion_original'].' sf ON sf.subject_id='.$this->m['subject_original'].'.id';
			$map['sf.fashion_id'] = $fashion_id;
            $field .=",sf.fashion_id";
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_subject_sort_original'].' ss ON ss.subject_id='.$this->m['subject_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ss.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ss.sort_id'] = $sort_id;
            }
            $field .=",ss.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_subject_column_original'].' sc ON sc.subject_id='.$this->m['subject_original'].'.id';
            if($column_id == 6){
                $map['sc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['sc.special_column_id'] = $column_id;
            }
            $field .=",sc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_subject_style_original'].' sst ON sst.subject_id='.$this->m['subject_original'].'.id';
			$map['sst.style_id'] = $style_id;
            $field .=",style_id";
        }
//        if (count($map) == 2 ) {
//            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
//            $this->assign('notice', 1);
//        }
        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        
        $count = $moldel->getCount("{$this->m['subject']}", $map, $join);
        
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelT->where($map)->relation(array('sort_id','special_column_id','style','zipfile_url'))->join($join)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelT->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);

                    if ($val['lable_id']) {
                        $m = D("{$this->m['folder_lable']}");
                        $la = $m->field('lable')->find($val['lable_id']);
                        $voList[$key]['lableStr'] = $la['lable'];
                    }
                    if ($this->fashions)
                        $voList[$key]['fashionStr'] = $this->fashions[$val['fashion_id']]['name'];
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    $voList[$key]['downloadid'] = urlencode(authcode("tid=".$val['id']."&cid=".$this->cid,"ENCODE"));
                    if($voList[$key]['zipfile_url']['zipfile_url']){
                        $voList[$key]['is_zipfile_url'] = 1;
                    }
                }
            }
            //模板赋值显示
            //dump($voList);
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        $this->assign('folder_id', $folder_id);
        Cookie::set('_currentThemeUrl_', __SELF__);
        return;
    }


    /**
     * 图片列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function _picList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } }
            $this->error('参数错误！');
        $action_link = array();
        $subject_id = intval($_REQUEST['subject_id']);
        if ($subject_id) {
            $themeI = $this->modelT->where(array('menu_id' => $this->cid, 'id' => $subject_id))->field('title,picture_count')->find();
            //echo $this->modelT->getlastsql();var_dump($themeI);
            $currentName = '-主题:' . stripslashes($themeI['title']);
            $info['tmpTitle'] =  stripslashes($themeI['title']);
            $action_link[] = array('text' => '返回主题列表', 'href' => Cookie::get('_currentThemeUrl_'));
        }
        $this->assign('info', $info);
        $this->assign('currentName', $currentName . '-图片列表');

        if (isset($subject_id) && !empty($subject_id) && !in_array($this->cid,array('12')) && ACTION_NAME !== 'underwearPicList') {
             $action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加图片','url':'__URL__/picAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        }
        if ( ACTION_NAME == 'underwearPicList' ) {
            $action_link[] = array('text' => '添加内衣图片', 'href' => "javascript:Box.open({'id':'add','title':'添加内衣图片','url':'__URL__/underwearPicAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        }
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $this->assign('action_link', $action_link);
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['picture_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map[$this->m['picture_original'].'.menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $checkBrand = "";
            $checkBrand .= "<option value=".$brand_id." selected='selected'>$checkBrandName</option>";
            $this->assign('checkBrand',$checkBrand);
        }
        if($book_id){
            $checkBookName = $this->books[$book_id]['name'];
            $checkBook = "";
            $checkBook .= "<option value=".$book_id." selected='selected'>$checkBookName</option>";
            $this->assign('checkBook',$checkBook);
        }

        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'publish_time';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
        if ($subject_id) {
            $map['subject_id'] = $subject_id;
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_picture_sort_original'].' ps ON ps.picture_id='.$this->m['picture_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ps.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ps.sort_id'] = $sort_id;
            }
            $field .=",ps.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_picture_column_original'].' pc ON pc.picture_id='.$this->m['picture_original'].'.id';
            if($column_id == 6){
                //$map['pc.special_column_id'] = array('exp','is null');
                $map['pc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['pc.special_column_id'] = $column_id;
            }
            $field .=",pc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_style_original'].' pst ON pst.picture_id='.$this->m['picture_original'].'.id';
			$map['pst.style_id'] = $style_id;
            $field .=",pst.style_id";
        }
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        $count = $moldel->getCount("{$this->m['picture']}", $map, $join);

        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelP->relation(array('sort_id','special_column_id','style'))->where($map)->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $this->modelP->getLastSql();
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['columnStr'] = implode(',', $column);

                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            if ($this->styles[$v['style_id']]['name'])
                                $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['styleStr'] = implode(',', $style);

                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
//                    if ($this->styles)
//                        $voList[$key]['styleStr'] = $this->styles[$val['style_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    if( in_array($this->cid,array(12,16,17,21,22,24))){
                        $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    }
                    if ( MODULE_NAME == 'UnderwearInvogue' ) {
                        $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}/is_ny/1','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    }
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }

    /**
     * 图片列表
     * @param type $field
     * @param type $map
     * @param type $sortBy
     * @param type $asc
     * @return type
     */
    protected function _subPicList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } }
            $this->error('参数错误！');
        $action_link = array();
        $subject_id = intval($_REQUEST['subject_id']);
        if ($subject_id) {
            $themeI = $this->modelT->where(array('menu_id' => $this->cid, 'id' => $subject_id))->field('title,picture_count')->find();
            //echo $this->modelT->getlastsql();var_dump($themeI);
            $currentName = '-主题:' . $themeI['title'];
            $info['tmpTitle'] =  $themeI['title'];
            $action_link[] = array('text' => '返回主题列表', 'href' => Cookie::get('_currentThemeUrl_'));
        }
        $this->assign('info', $info);
        $this->assign('currentName', $currentName . '-图片列表');

        if (isset($subject_id) && !empty($subject_id) && !in_array($this->cid,array('12')) && ACTION_NAME !== 'underwearPicList') {
             $action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加图片','url':'__URL__/picAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        }
        if ( ACTION_NAME == 'underwearPicList' ) {
            $action_link[] = array('text' => '添加内衣图片', 'href' => "javascript:Box.open({'id':'add','title':'添加内衣图片','url':'__URL__/underwearPicAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        }
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $this->assign('action_link', $action_link);
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['picture_subsidiary_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map[$this->m['picture_subsidiary_original'].'.menu_id'] = intval($_REQUEST['ny_cid']) ? $_REQUEST['ny_cid'] : $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $checkBrand = "";
            $checkBrand .= "<option value=".$brand_id." selected='selected'>$checkBrandName</option>";
            $this->assign('checkBrand',$checkBrand);
        }
        if($book_id){
            $checkBookName = $this->books[$book_id]['name'];
            $checkBook = "";
            $checkBook .= "<option value=".$book_id." selected='selected'>$checkBookName</option>";
            $this->assign('checkBook',$checkBook);
        }

        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'publish_time';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
        if ($subject_id) {
            $map['subject_id'] = $subject_id;
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_picture_sort_original'].' ps ON ps.picture_id='.$this->m['picture_subsidiary_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ps.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ps.sort_id'] = $sort_id;
            }
            $field .=",ps.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_picture_column_original'].' pc ON pc.picture_id='.$this->m['picture_subsidiary_original'].'.id';
            if($column_id == 6){
                //$map['pc.special_column_id'] = array('exp','is null');
                $map['pc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['pc.special_column_id'] = $column_id;
            }
            $field .=",pc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_style_original'].' pst ON pst.picture_id='.$this->m['picture_subsidiary_original'].'.id';
			$map['pst.style_id'] = $style_id;
            $field .=",pst.style_id";
        }
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        $count = $moldel->getCount("{$this->m['picture']}", $map, $join);

        if ($count == 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelS->where($map)->relation(array('sort_id','special_column_id','style'))->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $this->modelS->getLastSql();
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['columnStr'] = implode(',', $column);

                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            if ($this->styles[$v['style_id']]['name'])
                                $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['styleStr'] = implode(',', $style);

                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
//                    if ($this->styles)
//                        $voList[$key]['styleStr'] = $this->styles[$val['style_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    if( in_array($this->cid,array(12,16,17,21,22,24))){
                        $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    }
                    if ( MODULE_NAME == 'UnderwearInvogue' ) {
                        $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}/is_ny/1','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    }
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }
}
?>
