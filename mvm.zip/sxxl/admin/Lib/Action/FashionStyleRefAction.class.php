<?php
// +----------------------------------------------------------------------
// | 款式设置
// +----------------------------------------------------------------------
// | Author: hzw
// +----------------------------------------------------------------------
class FashionStyleRefAction extends CommonAction{
	protected $d_model;//detail
    protected $f_model;//fashion
    protected $k_model;//keyword
    protected $a_model;//area

	public function _initialize(){
		parent::_initialize();
		$this->d_model = D ('RefStyleDetail');
        $this->f_model = D ('RefStyleFashion');
        $this->k_model = D ('RefStyleKeyword');
        $this->a_model = D ('RefStyleArea');
        $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
	}

	public function index() {
		$action_link = array();
        $action_link[] = array('text' => '更新款式风格', 'href' => "__URL__/setRefAttribute/tag/f" );
        $action_link[] = array('text' => '更新款式细节', 'href' => "__URL__/setRefAttribute/tag/d" );
        $action_link[] = array('text' => '更新款式关键字', 'href' => "__URL__/setRefAttribute/tag/k" );
        $action_link[] = array('text' => '更新款式区域', 'href' => "__URL__/setRefAttribute/tag/a" );
        $this->assign('action_link', $action_link);
        Cookie::set('_currentStyleRefUrl_', __SELF__);
		$this->display ();
	}

    public function setRefAttribute(){
		import ('@.ORG.Search');
        $tag = trim($_REQUEST['tag']);
        $tag = in_array($tag,array('f','d','k','a')) ? $tag : 'f';
        $s = new Search();
        $page = intval($_GET['page']);
        $page = $page ? $page : 1;
		$page_size = 1;
        $page_start = ($page-1)*$page_size;
        $count = count($this->styles);
        $style = array_slice($this->styles, $page_start, $page_size);
        $s->arrQuery($style,$tag);
        if ($page_start < $count) {
            ++$page;
            echo " <script> window.location='?page={$page}'; </script> ";
        } else {
            exit('更新款式风格成功！');
        }
    }
}
?>
