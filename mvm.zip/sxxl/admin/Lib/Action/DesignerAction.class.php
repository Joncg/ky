<?php
// +----------------------------------------------------------------------
// | 设计师设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class DesignerAction extends AttributeAction{
	protected $model;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('AttributeDesigner');
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'设计师设置'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$action_link[] = array('text'=>'新增设计师', 'href'=>"javascript:Box.open({'id':'insert','title':'新增设计师','iframe':'".U('/Designer/insert')."','width':'465','height':'160'});");
		$this->assign('action_link', $action_link);

		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
		}

		$field = 'id,name,add_user_id,add_time';

		$this->_list ($field ,$map);
		$this->display ();
	}
}
?>
