<?php
/**
 * in_array($cid,array(11,13,16,18,20,21,23,25,26,27,28,29)),只导其中一个栏目$cid = 11 即可全部导完
 */
class GetSearchPictureInfoAction extends SubjectAction {
    public $cid;
    public function index (){
        $this->cid = intval($_GET['cid']);
        if(!$this->cid){
            exit('请传入栏目ID');
        }

        if(in_array($this->cid,array(13,14,16,18,20,21,23,25,26,27,28,29))){
            exit('此栏目的数据在传入cid = 11时已经导入到了搜索表中，只要确定cid = 11已经导过即可。');
        }

        $picture_arr = getCidModel($this->cid);
        $picture_model = D($picture_arr['picture']);
        $map = array();
        if(in_array($this->cid, array(100,101, 102))) {
            $map['menu_id'] = array($this->cid);
        }
        $map['add_time'] = array(array('gt', strtotime('2004-01-01 00:00:01')), array('elt', strtotime('2012-11-06 23:59:59')));

        $i = 0;
        $page = $_GET['page'];
        $page = empty($page) ? 1 : $page;
        if($page == 1){
            $tmp_info = $picture_model->where($map)->field('min(id) as min_id,max(id) as max_id')->find();
            echo $picture_model->getLastSql() . '<br>';
            $max = $tmp_info['max_id'];
            $min = $tmp_info['min_id'];
        }else{
            $max = intval($_GET['max']);
            $min = intval($_GET['min']);
        }

        if(!$min){
            exit('参数错误');
        }

        $pageSize = 60;
        $pageStart = $min + ($page-1)*$pageSize;
        $pageEnd = $pageStart + $pageSize;

        /*
        if($this->cid == 17 && $page > 24840 ){
            exit();
        }

       if($this->cid == 11 && $page > 59520 ){
            exit();
        }

       if($this->cid == 19 && $page > 11160 ){
            exit();
        }
        */

        $map['id'] = array(array('egt',$pageStart),array('lt',$pageEnd));
        $voList = $picture_model->where($map)->field('id,subject_id,small_picture_url,big_picture_url')->order(array('id'=>'asc'))->findAll();
        echo $picture_model->getLastSql()."<br>";
        if($voList){
            foreach ($voList as $key => $val) {
                if(empty($val['small_picture_url']) || empty($val['big_picture_url'])){
                    ++$i;
                    continue;
                }
                $this->setSearchPicture($val['id'],$val['subject_id']);
                ++$i;
            }
        }else{
            if($pageEnd < $max){
                ++$i;
            }
        }

        if($i>0) {
            ++$page;
            echo "<script>window.location='?cid={$this->cid}&page={$page}&max={$max}&min={$min}';</script>";
        }
    }

    //图片搜索
    //picture_id, publish_time, menu_id, child_menu_id, sort_id, season_id, area_no, brand_id, book_id, designer_id, style_id, acc_id, fashion_id,
	//keyword_id, color_id, column_id, detail_id, material_id, p_type_id, p_fashion_id, p_craft_id, p_detail_id, big_picture_url, small_picture_url,label_search
    public function setSearchPicture($pid, $sbj_id = ''){
        if(empty ($pid))
            return ;
        $this->getFileCache();
        $label_search = '';
        $this->m = getCidModel($this->cid);
        $modelP = D("{$this->m['picture']}");
        $modelT = D("{$this->m['subject']}");
        $info = $modelP->relation(true)->where(array('id'=>$pid))->find();
        //dump($info);exit();
        if ( $sbj_id ) {
            $theme_name = $modelT->getField('title',array('id'=>$sbj_id));
            $label_search .= $theme_name.",";
        }
        if(!empty ($info)){
            $searchArray['picture_id'] = $pid;
            $searchArray['publish_time'] = empty($info['publish_time']) ? '' : $info['publish_time'];
            $searchArray['sort_id'] = empty($info['sort_id']['0']['sort_id']) ? '' : $this->getCommaStr($info['sort_id'],"sort_id");
            if($searchArray['sort_id'])
                $label_search .= $this->getCommaStrName($this->sorts,$searchArray['sort_id']);
            $searchArray['column_id'] = empty($info['special_column_id']['0']['special_column_id']) ? '' : $this->getCommaStr($info['special_column_id'],'special_column_id');
            if($searchArray['column_id'] && $searchArray['column_id'] != 3)
                $label_search .= $this->getCommaStrName($this->columns,$searchArray['column_id']);
            $searchArray['big_picture_url'] = empty($info['big_picture_url']) ? '' : $info['big_picture_url'];
            $searchArray['small_picture_url'] = empty($info['small_picture_url']) ? '' : $info['small_picture_url'];
            $searchArray['menu_id'] = empty($info['menu_id']) ? '' : $info['menu_id'];
            if($searchArray['menu_id'])
                $label_search .= $this->menus[$searchArray['menu_id']]['name'].",";
            if($searchArray['menu_id'] == 27){
                $searchArray['child_menu_ids'] = empty($info['child_menu_ids']) ? '' : $info['child_menu_ids'];
                if($searchArray['child_menu_ids']){
                    foreach($searchArray['child_menu_ids'] as $key=>$val){
                        $searchArray['child_menu_id'] .= $val['child_menu_id'].',';
                        $label_search .= $this->menus[$val['child_menu_id']]['name'].",";
                    }
                }
            }else{
                $searchArray['child_menu_id'] = empty($info['child_menu_id']) ? '' : $info['child_menu_id'];
                if($searchArray['child_menu_id'])
                    $label_search .= $this->menus[$searchArray['child_menu_id']]['name'].",";
            }
            $searchArray['area_no'] = empty($info['area_no']) ? '' : $info['area_no'];
            if($searchArray['area_no'])
                $label_search .= $this->areas[$searchArray['area_no']]['name'].",";
            $searchArray['season_id'] = empty($info['season_id']) ? '' : $info['season_id'];
            if($searchArray['season_id'])
                $label_search .= $this->seasons[$searchArray['season_id']]['name'].",";
            $searchArray['designer_id'] = empty($info['designer_id']) ? '' : $info['designer_id'];
            if($searchArray['designer_id'])
                $label_search .= $this->designers[$searchArray['designer_id']]['name'].",";
            $searchArray['brand_id'] = empty($info['brand_id']) ? '' : $info['brand_id'];
            if($searchArray['brand_id'])
                $label_search .= $this->brands[$searchArray['brand_id']]['name'].",";
            $searchArray['book_id'] = empty($info['book_id']) ? '' : $info['book_id'];
            if($searchArray['book_id'])
                $label_search .= $this->books[$searchArray['book_id']]['name'].",";
            $searchArray['style_id'] = count($info['style']) == 0  ? '' : $this->getCommaStr($info['style'],'style_id');
            if($searchArray['style_id']){
                 $label_search .= $this->getCommaStrName($this->styles,$searchArray['style_id']);
            }
            $searchArray['acc_id'] = count($info['acc']) == 0  ? '' : $info['acc']['0']['acc_id'];
            if($searchArray['acc_id'])
                $label_search .= $this->accs[$searchArray['acc_id']]['name'].",";
            $searchArray['keyword_id'] = count($info['keyword']) == 0  ? '' : $this->getCommaStr($info['keyword'],'keyword_id');
            if($searchArray['keyword_id'])
                $label_search .= $this->getCommaStrName($this->keywords,$searchArray['keyword_id']);
            $searchArray['color_id'] = count($info['color']) == 0 ? '' : $this->getCommaStr($info['color'],'color_id');
            if($searchArray['color_id']){
                $label_search .= $this->getCommaStrName($this->colors,$searchArray['color_id']);
            }
            $searchArray['material_id'] = count($info['material']) == 0  ? '' : $this->getCommaStr($info['material'],'material_id');
            if($searchArray['material_id'])
                $label_search .= $this->getCommaStrName($this->materials,$searchArray['material_id']);
            $searchArray['description'] = empty($info['description']) ? '' : $info['description'];
            if($searchArray['description'])
                $label_search .= $searchArray['description'].",";
            if($this->cid == 24){
                $searchArray['p_type_id'] = count($info['type']) == 0 ? '' : $this->getCommaStr($info['type'],'type_id');
                if($searchArray['p_type_id'])
                    $label_search .= $this->getCommaStrName($this->types,$searchArray['p_type_id']);
                $searchArray['p_fashion_id'] = count($info['fashion']) == 0 ? '' : $this->getCommaStr($info['fashion'],'fashion_id');
                if($searchArray['p_fashion_id'])
                    $label_search .= $this->getCommaStrName($this->fashions,$searchArray['p_fashion_id']);
                $searchArray['p_craft_id'] = count($info['craft']) == 0 ? '' : $this->getCommaStr($info['craft'],'craft_id');
                if($searchArray['p_craft_id'])
                    $label_search .= $this->getCommaStrName($this->crafts,$searchArray['p_craft_id']);
                $searchArray['p_detail_id'] = count($info['detail']) == 0 ? '' : $this->getCommaStr($info['detail'],'detail_id');
                if($searchArray['p_detail_id'])
                    $label_search .= $this->getCommaStrName($this->details,$searchArray['p_detail_id']);
                $searchArray['p_pattern_id'] = count($info['pattern']) == 0 ? '' : $this->getCommaStr($info['pattern'],'pattern_id');
                if($searchArray['p_pattern_id'])
                    $label_search .= $this->getCommaStrName($this->p_patterns,$searchArray['p_pattern_id']);
            }else{
                $searchArray['fashion_id'] = count($info['fashion']) == 0 ? '' : $this->getCommaStr($info['fashion'],'fashion_id');
                if($searchArray['fashion_id'])
                    $label_search .= $this->getCommaStrName($this->fashions,$searchArray['fashion_id']);
                $searchArray['detail_id'] = count($info['detail']) == 0 ? '' : $this->getCommaStr($info['detail'],'detail_id');
                if($searchArray['detail_id'])
                    $label_search .= $this->getCommaStrName($this->details,$searchArray['detail_id']);
            }

            $searchArray['label_search'] = $label_search;
        }
        $searchPicModel = D("SearchPicture");
        $searchPicInfo = $searchPicModel->where(array('picture_id'=>$pid,'menu_id'=>$info['menu_id']))->count();
        //echo $searchPicModel->getLastSql();
        //exit();
        if($searchPicInfo > 0){
            $searchPicModel->where(array('picture_id'=>$pid,'menu_id'=>$info['menu_id']))->save($searchArray);
        }else{
            $searchPicModel->add($searchArray);
        }
        //echo $searchPicModel->getLastSql();
    }

}