<?php
// 后台主题模块
class ShowStuffAction extends SubjectAction {
	public $cid = 15;

	public function _initialize() {
		parent::_initialize();
		$listMenus = array(
			array('href' => __URL__ . '/folderList', 'selected'=>(in_array(ACTION_NAME, array('folderList','index')) ? 'now' : ''), 'title' => '文件夹'),
			array('href' => __URL__ . '/themeList', 'selected'=>(in_array(ACTION_NAME, array('themeList')) ? 'now' : ''), 'title' => '主题管理'),
			array('href' => __URL__ . '/picList', 'selected'=>(in_array(ACTION_NAME, array('picList')) ? 'now' : ''), 'title' => '图片管理'),
		);
		$this->assign('listMenus', $listMenus);
		$this->assign('currentBase', '数据录入-展会材料');
	}

	function index() {
		$this->folderList();
	}
	
	public function labelList() {
		$folder_id = intval($_REQUEST['folder_id']);
		$field = '*';
		$map['folder_id'] = $folder_id;
		parent::labelList($field, $map);
		$this->display('Subject/label_list');
	}
	public function labelAdd() {
		parent::labelAdd();
	}
	public function labelEdit() {
		parent::labelEdit();
	}
	public function labelBatch() {
		parent::labelBatch();
	}

	public function folderList() {
        $field = $this->m['folder_original'].'.id,title,title_picture_url,'.$this->m['folder_original'].'.child_menu_id,'.$this->m['folder_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,is_publish,child_subject_count,add_user_id,publish_time,add_time';
		$map[$this->m['folder_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::folderList($field,$map);
		$this->display('Subject/folder_list');
	}
	
	public function folderAdd() {
		parent::folderAdd("1");
        $this->display('Subject/showstuff_folder_info');
	}
	
	public function folderEdit() {
		parent::folderEdit();
	}

	public function folderBatch() {
		parent::folderBatch();
	}
	
	public function themeList() {
		$folder_id = $_REQUEST['folder_id'];
		$fid = $folder_id ? intval($folder_id) : intval($_REQUEST['fid']);
		if (isset($folder_id)) {
			$this->assign('listMenus', '');
		}
		$this->assign('fid', $fid);
		if ($folder_id == '0') $map['folder_id'] = 0;
        $field = $this->m['subject_original'].'.id,folder_id,lable_id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::themeList($field,$map,($folder_id ? 'lable_id' : ''));
		if (isset($folder_id)) {
			$this->display('Subject/showstuff_folder_theme_list');
		} else {
			$this->display('Subject/theme_list');
		}
	}
	
	public function themeAdd() {
		parent::themeAdd();
	}
	
	public function themeEdit() {
		parent::themeEdit();
	}

	public function themeBatch() {
		parent::themeBatch();
	}
	
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/picture_list');
		} else {
			$this->display('Subject/trend_picture_list');
		}
	}
	
	public function picAdd() {
		parent::picAdd("1");
        $this->display('Subject/catwalk_picture_info');
	}

	public function picCategory() {
		parent::picCategory();
	}

	public function picBatch() {
		parent::picBatch();
	}
}
?>
