<?php
// 后台主题模块
class MarketFocusAction extends SubjectAction {
	public $cid = 29;

	public function _initialize() {
		parent::_initialize();
		$this->assign('currentBase', '数据录入-市场聚焦');
	}

	function index() {
		$this->themeList();
	}
	
	public function themeList() {
        $field = $this->m['subject_original'].'.id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_themeList($field,$map);
		$this->display('Subject/books_theme_list');
	}
	
    protected function _themeList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-主题列表');
        $action_link = array();
        $folder_id = $_REQUEST['folder_id'];
        if (isset($folder_id)) {
            $action_link[] = array('text' => '返回文件夹', 'href' => Cookie::get('_currentFolderUrl_'));
        }
        if (isset($folder_id) && !empty($folder_id)) {
            $folder_data = $this->modelF->getById($folder_id);
            $this->assign('folderTitle', "文件夹：".stripslashes($folder_data['title'])); 
            if (!in_array($this->cid,array(12))){$action_link[] = array('text' => '标签管理', 'href' => "__URL__/labelList/folder_id/{$folder_id}");}
            $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/folder_id/{$folder_id}");
        }
        $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/");
        
        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (intval($folder_id))
            $map['folder_id'] = intval($folder_id);
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['subject_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        if($this->cid == 12){
            $order = $this->modelT->getPk();
        }  else {
            $order = !empty($sortBy) ? $sortBy : $this->modelT->getPk();
        }
        $sort = $asc ? 'desc' : 'asc';
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_subject_sort_original'].' ss ON ss.subject_id='.$this->m['subject_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ss.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ss.sort_id'] = $sort_id;
            }
            $field .=",ss.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_subject_column_original'].' sc ON sc.subject_id='.$this->m['subject_original'].'.id';
            if($column_id == 6){
                //$map['sc.special_column_id'] = array('exp','is null');
                $map['sc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['sc.special_column_id'] = $column_id;
            }
            $field .=",sc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_subject_style_original'].' sst ON sst.subject_id='.$this->m['subject_original'].'.id';
			$map['sst.style_id'] = $style_id;
            $field .=",style_id";
        }
        
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        $count = $moldel->getCount("{$this->m['subject']}", $map, $join);
        //echo $count;
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelT->where($map)->relation(array('sort_id','special_column_id','style','zipfile_url'))->join($join)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelT->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    
                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    $voList[$key]['styleStr'] = implode(',', $style);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);
                    if ($val['lable_id']) {
                        $m = D("{$this->m['folder_lable']}");
                        $la = $m->field('lable')->find($val['lable_id']);
                        $voList[$key]['lableStr'] = $la['lable'];
                    }
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    $voList[$key]['downloadid'] = urlencode(authcode("tid=".$val['id']."&cid=".$this->cid,"ENCODE"));
                    if($voList[$key]['zipfile_url']['zipfile_url']){
                        $voList[$key]['is_zipfile_url'] = 1;
                    }
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentThemeUrl_', __SELF__);
        return;
    }
    
    
	public function themeAdd() {
		parent::themeAdd('1');
        $this->display('Subject/invogue_theme_info');
	}
	
	public function themeEdit() {
		parent::themeEdit('1');
        $this->display('Subject/invogue_theme_info');
	}

	public function themeBatch() {
		parent::themeBatch();
	}
	
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/invogue_picture_list');
		} else {
			$this->display('Subject/trend_picture_list');
		}
	}
	
	public function picAdd() {
		parent::picAdd('1');
        $this->display('Subject/invogue_picture_info');
	}

	public function picCategory() {
		parent::picCategory();
	}

	public function picBatch() {
		parent::picBatch();
	}
}
?>
