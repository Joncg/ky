<?php
class AttributeAction extends CommonAction{
	protected $model;

    public function _initialize() {
        $this->assign('module',MODULE_NAME);
        if ($_REQUEST['chs']){
            $this->assign('chs',$_REQUEST['chs']);
        }
        $tmp_eng = stripslashes($_REQUEST['eng']);
        if ( $tmp_eng ) {
            $this->assign('eng',$tmp_eng);
        }
        $tmp_url = Cookie::get('_currentParamUrl_');
        $this->assign('tmp_url',$tmp_url);
    }
    
	public function _list($field = '*', $map = '', $sortBy = '', $asc = false) {
		//排序字段 默认为主键名
		if (isset ( $_REQUEST ['_order'] )) {
			$order = $_REQUEST ['_order'];
		} else {
			$order = ! empty ( $sortBy ) ? $sortBy : $this->model->getPk ();
		}
		//排序方式默认按照倒序排列
		//接受 sost参数 0 表示倒序 非0都 表示正序
		if (isset ( $_REQUEST ['_sort'] )) {
			$sort = $_REQUEST ['_sort'] ? 'asc' : 'desc';
		} else {
			$sort = $asc ? 'asc' : 'desc';
		}
		//取得满足条件的记录数
		$count = $this->model->where ( $map )->count ();
		if ($count > 0) {
            import("ORG.Util.Page");
			//创建分页对象
			if (! empty ( $_REQUEST ['listRows'] )) {
				$listRows = $_REQUEST ['listRows'];
			} else {
				$listRows = '10';
			}
			$p = new Page ( $count, $listRows );
			//分页查询数据
			$voList = $this->model->relation(TRUE)->where($map)->order( "`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->field($field)->findAll ( );
            //dump($voList);
            //分页跳转的时候保证查询条件
			foreach ( $_REQUEST as $key => $val ) {
				if (! is_array ( $val )) {
					$p->parameter .= "$key=" . urlencode ( $val ) . "&";
				}
			}
            //dump($p->parameter);
            foreach ($voList as $key => $val) {
                $voList[$key]['title_pic'] = 'http://img.www.sxxl.com' . $val['url'];
            }
            //dump($voList);
            //分页显示
			$page = $p->show();
			//模板赋值显示
			$this->assign ( 'list', $voList );
			$this->assign ( "page", $page );
            Cookie::set('_currentParamUrl_', __SELF__);
		}
	}

	public function insert(){
		//保存
		if($_POST){
			if($data = $this->model->create()) {
				if($this->model->add() !== false){
					$this->ajaxReturn($data,'新增成功！',1);
				}
				else{
					$this->ajaxReturn($data,'新增失败！',0);
				}
			}
		}
		if(MODULE_NAME == 'Area'){
            $pno = intval($_GET['pno']);
            $this->assign('pno',$pno);
        }
        elseif($_GET['pid']){
            $pid = intval($_GET['pid']);
            $this->assign('pid',$pid);
        }
        $this->assign('tab',$this->tab);
		$this->display();
	}

	public function edit(){
		//保存
		if($_POST['id']){
			if($data = $this->model->create()) {
				if($this->model->save() !== false){
					$this->ajaxReturn($data,'编辑成功！',1);
				}
				else{
					$this->ajaxReturn($data,'编辑失败！',0);
				}
			}
		}
		$id = intval($_GET['id']);
		$info = $this->model->find($id);
		$this->assign('info',$info);
        $this->assign('tab',$this->tab);
		$this->display();
	}

	public function delete() {
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if($id >0){
			$this->model->delete($id) !== false ? $this->success('删除成功！') : $this->error('删除失败！');
		}
		elseif(is_array($ids) && !empty($ids)){
			$errorNum = 0;
			foreach($ids as $key => $id){
				$this->model->delete(intval($id)) !== false ?  '' : $errorNum++;
			}
			$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！') ;
		}
	}

    public function checkNo(){
        $id = intval($_GET['id']);
        if($id) $map['id'] = array('neq',$id);
        $no = $_GET['no'];
        $noTmp = hexdec($no);
        if(empty($noTmp)){
            exit('0');
        }
        else{
            $map['no'] = hexdec($no);
        }
        $count = $this->model->where($map)->count();
        echo $count > 0 ? 0 : 1;
    }
}
?>
