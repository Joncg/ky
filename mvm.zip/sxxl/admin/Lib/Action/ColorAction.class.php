<?php
// +----------------------------------------------------------------------
// | 颜色设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class ColorAction extends AttributeAction{
	protected $model;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('AttributeColor');
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'颜色设置'));
		$this->assign('listMenus', $listMenus);
		$action_link = array();
		$action_link[] = array('text'=>'新增颜色', 'href'=>"javascript:Box.open({'id':'insert','title':'新增颜色','iframe':'".U('/Color/insert')."','width':'465','height':'160'});");
		$this->assign('action_link', $action_link);

		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
		}

		$field = 'id,name,add_user_id,add_time,url';

		$this->colorList($field ,$map);
		$this->display ();
		return;
	}

    public function insert(){
		//保存
		if($_POST){
			if($data = $this->model->create()) {
				if($this->model->add() !== false){
					$this->assign('special_jump', '1');
                    $this->assign('waitSecond', 0);
					$this->assign('jumpUrl', "self.parent.main.location.href='/Color/index'");
					if(!empty($_FILES['colorFile']['name'])){
						if($this->_upload()){
							$this->success('新增颜色成功！');
						}
					}
					else{
						$this->success('新增颜色成功！');
					}
				}
				else{
					$this->error($data,'新增颜色失败！',0);
				}
			}
		}
		$this->display();
	}

	public function edit(){
		//保存
		if($_POST){
			if($data = $this->model->create()) {
				if($this->model->save() !== false){
                    $this->assign('special_jump', '1');
                    $this->assign('waitSecond', 0);
					$this->assign('jumpUrl', "self.parent.main.location.href='/Color/index'");
					if(!empty($_FILES['colorFile']['name'])){
						if($this->_upload()){
							$this->success('编辑颜色成功！');
						}
					}
					else{
						$this->success('编辑颜色成功！');
					}
				}
				else{
					$this->error('编辑颜色失败！');
				}
			}
		}
		$id = intval($_GET['id']);
		$info = $this->model->find($id);
		$this->assign('info',$info);
		$this->display();
	}

	public function delete() {
		$id = intval($_GET['id']);
		$ids = $_POST['ids'];
		if($id >0){
			$imgFile = $this->model->where('id='.$id)->getField('url');
			if($this->model->delete($id) !== false){
				$this->_unlink('',$imgFile);
				$this->success('删除成功！');
			}
			else{
				$this->error('删除失败！');
			}
		}
		elseif(is_array($ids) && !empty($ids)){
			$errorNum = 0;
			foreach($ids as $key => $id){
				$idTmp = intval($id);
				$imgFile = $this->model->where('id='.$idTmp)->getField('url');
				$this->model->delete($idTmp) !== false ?  $this->_unlink('',$imgFile) : $errorNum++;
			}
			$errorNum > 0 ? $this->error('批量删除失败！') : $this->success('批量删除成功！') ;
		}
	}

	public function _upload(){
			$allowExts = array('jpg', 'gif', 'png', 'jpeg');
			$isThum = FALSE;
			$savePath = '/../images/Public/Images/color/';//用于实际存放的路径
            $sqlSavePath = '/Public/Images/color/';       //用于写入数据库的路径
			$savePathTmp = $_SERVER['DOCUMENT_ROOT'].$savePath;
			import("ORG.Net.UploadFile");
			$upload = new UploadFile();
			$upload->allowExts = $allowExts;
			$upload->savePath = str_replace('//','/',$savePathTmp);
			$upload->thumb = $isThum;
			$upload->saveRule = uniqid;
			if($upload->upload()){
				$info = $upload->getUploadFileInfo();
				//删除旧颜色文件
				$id = intval($_POST['id']);
				$id = $id ? $id : $this->model->getLastInsID();
				$this->_unlink($id);
				$url = $sqlSavePath.$info[0]["savename"];
				$this->model->where('id='.$id)->setField('url',$url);
				return true;
			}else{
				$this->error('颜色图片上传失败:'.$upload->getErrorMsg());
			}
	}

	public function _unlink($id,$imgFile = ''){
		if(empty($id) && empty($imgFile)) return;
		if(empty($imgFile))
			$imgFile = $this->model->where('id='.$id)->getField('url');
		$imgFile = $_SERVER['DOCUMENT_ROOT'].$imgFile;
		if(is_file($imgFile))
			unlink($imgFile);
		return true;
	}

	public function colorList($field = '*', $map = '', $sortBy = '', $asc = false) {
		//排序字段 默认为主键名
		if (isset ( $_REQUEST ['_order'] )) {
			$order = $_REQUEST ['_order'];
		} else {
			$order = ! empty ( $sortBy ) ? $sortBy : $this->model->getPk ();
		}
		//排序方式默认按照倒序排列
		//接受 sost参数 0 表示倒序 非0都 表示正序
		if (isset ( $_REQUEST ['_sort'] )) {
			$sort = $_REQUEST ['_sort'] ? 'asc' : 'desc';
		} else {
			$sort = $asc ? 'asc' : 'desc';
		}
		//取得满足条件的记录数
		$count = $this->model->where ( $map )->count ();
		if ($count > 0) {
            import("ORG.Util.Page");
			//创建分页对象
			if (! empty ( $_REQUEST ['listRows'] )) {
				$listRows = $_REQUEST ['listRows'];
			} else {
				$listRows = '10';
			}
			$p = new Page ( $count, $listRows );
			//分页查询数据
			$voList = $this->model->relation(TRUE)->where($map)->order( "`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->field($field)->findAll ( );
            //dump($voList);
            //分页跳转的时候保证查询条件
			foreach ( $_REQUEST as $key => $val ) {
				if (! is_array ( $val )) {
					$p->parameter .= "$key=" . urlencode ( $val ) . "&";
				}
			}
            //dump($p->parameter);
			preg_match("/[^\.\/]+\.[^\.\/]+$/", $_SERVER['SERVER_NAME'], $m);
            foreach ($voList as $key => $val) {
                $voList[$key]['title_pic'] = 'http://images.'.$m[0] . $val['url'];
            }
            //dump($voList);
            //分页显示
			$page = $p->show();
			//模板赋值显示
			$this->assign ( 'list', $voList );
			$this->assign ( "page", $page );
            Cookie::set('_currentParamUrl_', __SELF__);
		}
	}

}
?>
