<?php
// +----------------------------------------------------------------------
// | 图案设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class PatternAction extends AttributeAction{
	protected $model;
    public $tab;

	public function _initialize(){
		parent::_initialize();
        $this->getModel($_REQUEST['tab']);
	}

	public function index() {
        $this->getModel($_REQUEST['tab']);
		$listMenus = array(
            array('href'=>__URL__. '/index/tab/pattern','selected' => (in_array($this->tab, array('pattern')) ? 'now' : ''),'title'=>'图案设置'),
            array('href'=>__URL__. '/index/tab/fashion','selected' => (in_array($this->tab, array('fashion')) ? 'now' : ''),'title'=>'图案风格'),
            array('href'=>__URL__. '/index/tab/type','selected' => (in_array($this->tab, array('type')) ? 'now' : ''),'title'=>'图案分类'),
            array('href'=>__URL__. '/index/tab/detail','selected' => (in_array($this->tab, array('detail')) ? 'now' : ''),'title'=>'图案细节'),
            array('href'=>__URL__. '/index/tab/craft','selected' => (in_array($this->tab, array('craft')) ? 'now' : ''),'title'=>'图案工艺'),
            );
		$this->assign('listMenus', $listMenus);
        
		$pid = intval($_GET['pno']);
        if(in_array($this->tab, array('pattern','fashion','type')))
            $map['parent_id'] = array('eq',$pid);
		$action_link = array();
		if($pid >0){
			$mapTmp['id'] = array('eq',$pid);
			$pidTmp = $this->model->where($mapTmp)->getField('parent_id');
			$action_link[] = array('text'=>'返回上级', 'href'=>U('/Pattern/index',array('pid'=>$pidTmp,'tab'=>$this->tab)));
		}
		$action_link[] = array('text'=>'新增属性', 'href'=>"javascript:Box.open({'id':'insert','title':'新增属性','iframe':'".U('/Pattern/insert',array('pid'=>$pid,'tab'=>$this->tab))."','width':'480','height':'240'});");
		$this->assign('action_link', $action_link);

		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
			$map['parent_id'] = array('egt',0);
		}
        $field = '*';
		$this->_list ($field ,$map);
        $this->assign('tab',$this->tab);
		$this->display ();
	}
    
    public function getModel($tab){
        if(empty ($tab)){
            $this->model = D ('AttributePattern');
            $this->tab = "pattern";
            return ;
        }else{
            switch ($tab) {
                case 'pattern':
                    $this->model = D ('AttributePattern');
                    $this->tab = "pattern";
                    break;
                case 'fashion':
                    $this->model = D ('AttributePatternFashion');
                    $this->tab = "fashion";
                    break;
                case 'type':
                    $this->model = D ('AttributePatternType');
                    $this->tab = "type";
                    break;
                case 'detail':
                    $this->model = D ('AttributePatternDetail');
                    $this->tab = "detail";
                    break;
                case 'craft':
                    $this->model = D ('AttributePatternCraft');
                    $this->tab = "craft";
                    break;
            }
        }
    }
}
?>
