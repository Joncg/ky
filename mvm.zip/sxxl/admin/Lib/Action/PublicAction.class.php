<?php

// 本文档自动生成，仅供测试运行
class PublicAction extends Action {

    protected $cacheFileOption = array('temp' => '../config/cache/', 'expire' => '-1');

    // 检查用户是否登录
    public function checkUser() {
        //$this->checkPc();
        if (!Cookie::is_set(C('USER_AUTH_KEY'))) {
            $this->redirect(C('USER_AUTH_GATEWAY'));
            //$this->assign('jumpUrl', U(C('USER_AUTH_GATEWAY')));
            //$this->error('此模块不允许匿名用户访问！');
        }
    }

    public function checkPc($userId = '') {
        //return true;
        $SysA = M('SysAuthorized');
        $userId = !empty($userId) ? $userId : Cookie::get(C('USER_AUTH_KEY'));
//        if ($userId == 1) {
//            return true;
//        }
        $data = array();
        if ($userId && Cookie::get('computer_name') && Cookie::get('cpu_id') && Cookie::get('mac_id')) {
            $data['user_id'] = $userId;
            $data['computer_name'] = Cookie::get('computer_name');
            $data['cpu_id'] = Cookie::get('cpu_id');
			$data['mac_id'] = Cookie::get('mac_id');
			$data['storage_id'] = Cookie::get('hd_id');
            $row = $SysA->field('id,status')->where($data)->find();
            $data['add_time'] = time();
            if (!$row) {
                $SysA->add($data);
            }
        }
        if ($row['status'] != '1') {
            $this->assign('jumpUrl', U(C('USER_AUTH_GATEWAY')));
            $this->error('账号已被锁定，请联系相关人员！');
        }
    }

    public function index() {
        //如果通过认证跳转到首页
        $this->redirect(__APP__);
    }

    function EditorUpload() {
        if($_REQUEST['type'] == 's') {
            $_SESSION['surl'] = $_SESSION['info']['s'] = '';
            $_SESSION['info']['b'] = '';
        }
        $allowExts = array('jpg', 'jpeg', 'zip');
        $savePath = getFilePath(); //2012_A/0327/2706/
        $savePathTmp = C('IMG_ROOT') . $savePath;
        import("ORG.Net.UploadFile");
        $upload = new UploadFile();
        $upload->allowExts = $allowExts;
        $upload->savePath = str_replace('//', '/', $savePathTmp);
        $upload->saveRule = getFileName;
        if ($upload->upload()) {            
            $image = $upload->getUploadFileInfo();
            header('Content-type: text/html; charset=UTF-8');
            if(trim($_REQUEST['dir']) == 'file'){
                exit(json_encode(array('error' => 0, 'url' => show_pic_path($image[0]['file_path']))));
            }
            
            //dump($_SESSION);
            if ($_REQUEST['type'] == 's') {
                $_SESSION['surl'] = $_SESSION['info']['s'] = $image[0]['file_path'];
            }
            if ($_REQUEST['type'] == 'b') {
                $_SESSION['info']['b'] = $image[0]['file_path'];
            }
            if (!empty($_SESSION['info']['s']) && !empty($_SESSION['info']['b'])) {
                //dump($_REQUEST);
                $cid = $_REQUEST['cid'];
                $tid = $_REQUEST['tid'];
                $m = getCidModel($cid);
                if ($tid) {
                    $mS = D("{$m['subject']}");
                    $tInfo = $mS->where(array('menu_id' => $cid, 'id' => $tid))->find();
                }
                //echo $mS->getLastSql();
                //dump($tInfo);
                $info = array();
                $info['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
                $info['small_picture_url'] = $_SESSION['info']['s'];
                $info['big_picture_url'] = $_SESSION['info']['b'];
                $info['subject_id'] = $tid;
                if ($tInfo) {
                    $info['menu_id'] = $tInfo['menu_id'];
                    $info['child_menu_id'] = $tInfo['child_menu_id'];
                    $info['area_no'] = $tInfo['area_no'];
                    $info['season_id'] = $tInfo['season_id'];
                    $info['designer_id'] = $tInfo['designer_id'];
                    $info['brand_id'] = $tInfo['brand_id'];
                    $info['book_id'] = $tInfo['book_id'];
                    $info['is_publish'] = $tInfo['is_publish'];
                    $info['publish_time'] = $tInfo['publish_time'];
                    $info['add_time'] = $_SERVER['REQUEST_TIME'];
                }
                $mP = D("{$m['picture']}");
                $pid = $mP->add($info);
                //echo $mP->getLastSql();
                $subject = A('Subject');
                $subject->setPicSort($pid, $tid);
                $subject->setPicColumn($pid, $tid);
                $subject->setPicStyles($pid, $tid);
                $subject->setPictureCount($tid, 'add');
                $_SESSION['info'] = array();
            }
            //exit('is ok');
            //dump($image[0]['file_path']);
            if ($_REQUEST['type'] == 's') {
                //dump('ss');
                exit(json_encode(array('error' => 0, 'url' => show_pic_path($image[0]['file_path']))));
            }
            if ($_REQUEST['type'] == 'b') {
                $surl = $_SESSION['surl'];
                exit(json_encode(array('error' => 0, 'url' => show_pic_path($image[0]['file_path']), 'surl' => show_pic_path($surl))));
            }
            exit(json_encode(array('error' => 0)));
        }
    }

    public function picUpload() {
        if (isset($_REQUEST['SESSIONID'])) {
            session_id($_REQUEST['SESSIONID']);
        }
        $model = D('SharePicturesTmp');
        $image = _upload();
        if (empty($image)) {
            exit('0');
        }
        $t_name = explode('.', $image[0]["name"]);
        $image["img_name"] = $t_name[0];
        $image["img_path"] = $image[0]["file_path"];
        $info = array();
        $info['add_user_id'] = intval($_REQUEST['user_id']);
        $info['menu_id'] = intval($_REQUEST['cid']);
        $info['subject_id'] = intval($_REQUEST['subject_id']);
        $info['source_file_name'] = $image['img_name'];
        $row = $model->field('id')->where($info)->find();
        if (strlen($image['img_name']) > 9) {
            @unlink($image['savepath'] . $image['savename']);
            exit('1');
        }
        if (!$row) {
            $tmp_id = intval(substr($image["img_name"], 1, 4));
            $info['add_time'] = time() + $tmp_id;
            $info['child_menu_id'] = intval($_REQUEST['child_menu_id']);
            $info['season_id'] = intval($_REQUEST['season_id']);
            $info['designer_id'] = intval($_REQUEST['designer_id']);
            $info['brand_id'] = intval($_REQUEST['brand_id']);
            $info['book_id'] = intval($_REQUEST['book_id']);
            $info['area_no'] = intval($_REQUEST['area_no']);
            $info['url'] = $image['img_path'];
            $info['sort_id'] = trim($_REQUEST['sort_id']);
            $info['column_id'] = trim($_REQUEST['column_id']);
            $info['pattren_type_id'] = trim($_REQUEST['pattren_type_id']);
            $info['pattren_child_type_id'] = trim($_REQUEST['pattren_child_type_id']);
            $info['is_publish'] = intval($_REQUEST['is_publish']);
            $info['publish_time'] = $_REQUEST['publish_time'] ? strtotime($_REQUEST['publish_time']) + $tmp_id : $info['add_time'];
            $info['style_id'] = $_REQUEST['style_id'];
            $model->add($info);
            exit('1');
        } else {
            @unlink($image['savepath'] . $image['savename']);
            exit('0');
        }
    }

    public function zipUpload() {
        isset($_REQUEST['SESSIONID']) ? session_id($_REQUEST['SESSIONID']) : '';
        $cid = intval($_REQUEST['cid']);
        $ori_cid = intval($_REQUEST['ori_cid']);//矢量款式-内衣(坑爹)
        $pid = intval($_REQUEST['pid']);
        if(!$cid || !$pid){
           exit('0');
        }

        $table_arr = getCidModel($ori_cid ? $ori_cid : $cid);
        $model = M($table_arr['picture_extend']);
        $zip = _upload();
        if (empty($zip)) {
            exit('0');
        }

        $zip_name_arr = explode('.', $zip[0]["name"]);
        $zip["zip_name"] = $zip_name_arr[0];
        unset($zip_name_arr);
        $tmp = explode('_', $zip["zip_name"]);
        $zip_type = 0;
        switch($tmp[1]){
          case 'rar':
              $zip_type = 1;
              $field = 'zip_jrp';
              break;
          case 'ai':
              $zip_type = 3;
              $field = 'zip_ai';
              break;
          case 'cdr':
              $zip_type = 3;
              $field = 'zip_cdr';
              break;
          case 'psd':
              $zip_type = 2;
              $field = 'zip_psd';
              break;
          default :
              $zip_type = 1;
              $field = 'zip_jrp';
              break;
        }
        unset($tmp);

        if($field){
            $map = array();
            $map['picture_id'] = $pid;
            $data = array();
            $data['menu_id'] = $cid;
            $data['child_menu_id'] = intval($_REQUEST['cmid']);
            if($model->where($map)->count() > 0){
                $old_zip = $model->getField($field,$map);
                $old_zip_type = M($table_arr['picture'])->getField('zip_type',array('id'=>$pid));
                $data[$field] = $zip[0]["file_path"];
                if($model->where(array('picture_id'=>$pid))->save($data) !== false){
                    @unlink(show_pic_path($old_zip));
                    //图案特殊处理
                    if($cid == 24){
                        if($zip_type > $old_zip_type){
                            if(M($table_arr['picture'])->save(array('id'=>$pid,'zip_type'=>$zip_type)) === false){
                                exit('0');
                            }
                        }
                    }
                    exit('1');
                }else{
                    @unlink($zip['savepath'] . $zip['savename']);
                    exit('0');
                }
            }else{
                $data['picture_id'] = $pid;
                $data[$field] = $zip[0]["file_path"];
                if($model->add($data) !== false){
                    //图案特殊处理
                    if($cid == 24){
                        if(M($table_arr['picture'])->save(array('id'=>$pid,'zip_type'=>$zip_type)) === false){
                            exit('0');
                        }
                    }
                    exit('1');
                }else{
                    @unlink($zip['savepath'] . $zip['savename']);
                    exit('0');
                }
            }
        }else{
            @unlink($zip['savepath'] . $zip['savename']);
            exit('0');
        }
    }

    /**
     * 登录页面
     */
    public function login() {
//        $auth_key = Cookie::get(C('USER_AUTH_KEY'));
//        echo $auth_key;
        if (!Cookie::is_set(C('USER_AUTH_KEY'))) {
            //echo "no";exit();
            $this->display();
        } else {
            //echo "yes";exit();
            $this->assign('jumpUrl', U('Index/index'));
            $this->redirect('index');
        }
    }

    /**
     * 用户退出
     */
    public function logout() {
        $this->assign('jumpUrl', U(C('USER_AUTH_GATEWAY')));
        $auth_key = Cookie::get(C('USER_AUTH_KEY'));
		if (isset($auth_key)) {
			Cookie::clear();
            $this->assign('is_main', 1);
            $this->assign('is_main_url', U('Index/index'));
			$this->success('退出成功!');
		} else {
			$this->redirect(C('USER_AUTH_GATEWAY'));
			//$this->error('已经退出!');
		}
    }

    /**
     * 登录检测
     */
    public function checkLogin() {
        if (empty($_POST['username'])) {
            $this->error('请输入用户名');
        } elseif (empty($_POST['password'])) {
            $this->error('请输入密码');
        }
        //认证
        $map = array();
        $map['account'] = $_POST['username'];
        $map['status'] = array('gt', 0);
        import('@.ORG.Power');
        $authInfo = Power::authenticate($map);
        if (empty($authInfo)) {
            $this->error('账号不存在或已禁用!');
        } else {
            if ($authInfo['password'] != md5($_POST['password'])) {
                $this->error('帐户或者密码错误，请检查!');
            }
            //硬件信息
            Cookie::set('computer_name', trim($_POST['pc_name']) != 'undefined' ? trim($_POST['pc_name']) == '' ? 'undefined' : trim($_POST['pc_name']) : 'undefined');
            Cookie::set('cpu_id', trim($_POST['cpu_info']) != 'undefined' ? trim($_POST['cpu_info']) == '' ? 'undefined' : trim($_POST['cpu_info']) : 'undefined');
            Cookie::set('mac_id', trim($_POST['net_info']) != 'undefined' ? trim($_POST['net_info']) == '' ? 'undefined' : trim($_POST['net_info']) : 'undefined');
            Cookie::set('hd_id', trim($_POST['hd_info']) != 'undefined' ? trim($_POST['hd_info']) == '' ? 'undefined' : trim($_POST['hd_info']) : 'undefined');
            $this->checkPc($authInfo['id']);
            Cookie::set(C('USER_AUTH_KEY'), $authInfo['id']);
            Cookie::set('loginUser', $authInfo['account']);
            Cookie::set('loginUserName', $authInfo['real_name']);
            Cookie::set('lastLoginTime', date('Y-m-d H:i:s', $authInfo['last_login_time']));
            Cookie::set('last_login_ip', $authInfo['last_login_ip']);
            Cookie::set('login_count', $authInfo['login_count']);
            $User = D('SysUser');
            $info = $User->relation(true)->find($authInfo['id']);
            if ($info['roles'][0]['id'] == '1') {
                Cookie::set(C('ADMIN_AUTH_KEY'),true);
            }
            Cookie::set('loginUserRole',$info['roles'][0]['name']);

            //保存登录信息
            $User = M('SysUser');
            $ip = get_client_ip();
            $time = time();
            $data = array();
            $data['id'] = $authInfo['id'];
            $data['last_login_time'] = $time;
            $data['login_count'] = array('exp', 'login_count+1');
            $data['last_login_ip'] = $ip;
            $User->save($data);
            //保存登录日志
            $Loginlog = M('SysLogLogin');
            $dataLog = array();
			$dataLog['user_id'] = $authInfo['id'];
			$dataLog['login_time'] = $time;
			$dataLog['computer_name'] = Cookie::get('computer_name');
			$dataLog['mac_id'] = Cookie::get('mac_id');
            $dataLog['cpu_id'] = Cookie::get('cpu_id');
            $dataLog['storage_id'] = Cookie::get('hd_id');
			$Loginlog->add($dataLog);

            // 缓存访问权限
            Power::saveAccessList();
            $this->redirect('Index/index');
            //$this->assign('jumpUrl', U('Index/index'));
            //$this->success('登录成功！');
        }
    }

    // 更换密码
    public function password() {
        $this->checkUser();
        $auth_key = Cookie::get(C('USER_AUTH_KEY'));
        if ($_POST) {
            $map = array();
            $map['password'] = md5($_POST['oldpassword']);
            if (isset($_POST['account'])) {
                $map['account'] = $_POST['account'];
            } elseif (isset($auth_key)) {
                $map['id'] = $auth_key;
            }
            //检查用户
            $User = M('SysUser');
            if (!$User->where($map)->field('id')->find()) {
                $this->error('旧密码不符或者用户名错误！');
            } else {
                $User->password = md5($_POST['password']);
                $User->save();
                $this->success('密码修改成功！');
            }
        } else {
            $User = M('SysUser');
            $info = $User->getById($auth_key);
            $this->assign('info', $info);
            $this->display();
        }
    }

    /**
     * 修改资料
     */
    public function profile() {
        $this->checkUser();
        if ($_POST) {
            $User = D('SysUser');
            if (!$User->create()) {
                $this->error($User->getError());
            }
            $result = $User->save();
            if (false !== $result) {
                $this->success('资料修改成功！');
            } else {
                $this->error('资料修改失败!');
            }
        } else {
            $User = M('SysUser');
            $auth_key = Cookie::get(C('USER_AUTH_KEY'));
            $info = $User->getById($auth_key);
            $this->assign('info', $info);
            $this->display();
        }
    }

    public function main() {
        $this->checkUser();
        $action_link[] = array('text' => '添加主题', 'href' => "javascript:Box.open({'id':'add','title':'添加主题','iframe':'__APP__/Public/main1','width':'750','height':'500'});");
        //$this->assign('action_link', $action_link);
        //列表页菜单
        $listMenus = array(
            'theme' => array('title' => '主题管理', 'href' => '?mod=theme'),
            'picture' => array('title' => '款式录入', 'href' => '?mod=picture'),
            'detail' => array('title' => '细节管理', 'href' => '?mod=detail'),
                //'special' => array('title'=>'专题管理','href'=>'?mod=special')
        );
        //$this->assign('listMenus', $listMenus);
        $info = array(
            '操作系统' => PHP_OS,
            '运行环境' => $_SERVER["SERVER_SOFTWARE"],
            'PHP运行方式' => php_sapi_name(),
            //'ThinkPHP版本' => THINK_VERSION . ' [ <a href="http://thinkphp.cn" target="_blank">查看最新版本</a> ]',
            '上传附件限制' => ini_get('upload_max_filesize'),
            '执行时间限制' => ini_get('max_execution_time') . '秒',
            '服务器时间' => date("Y年n月j日 H:i:s"),
            '北京时间' => gmdate("Y年n月j日 H:i:s", time() + 8 * 3600),
            '服务器域名/IP' => $_SERVER['SERVER_NAME'] . ' [ ' . gethostbyname($_SERVER['SERVER_NAME']) . ' ]',
            '剩余空间' => round((@disk_free_space(".") / (1024 * 1024)), 2) . 'M',
            'register_globals' => get_cfg_var("register_globals") == "1" ? "ON" : "OFF",
            'magic_quotes_gpc' => (1 === get_magic_quotes_gpc()) ? 'YES' : 'NO',
            'magic_quotes_runtime' => (1 === get_magic_quotes_runtime()) ? 'YES' : 'NO',
        );
        $User = D('SysUser');
        $u = $User->relation(true)->getById(Cookie::get(C('USER_AUTH_KEY')));
        $this->assign('u', $u);
        $this->assign('info', $info);
        $this->display();
    }

    /**
     * 异步获取二级款式
     * @param $have 图片ID
     * @param $pno 父级NO
     * id/{{$picture_id}}/have/{{$keywordIds}}/cid/{{$cid}}/pno/"+pno+'/checked/'+styleV,
     */
    public function getStyleByAjax($have = '', $pid = '', $is_ajax = '') {
        $haveTmp = $have;
        $pidTmp = intval($pid);
        $have = $haveTmp ? $haveTmp : intval($_REQUEST['have']);
        $pid = $pidTmp ? $pidTmp : intval($_REQUEST['pid']);
        $checked = $_REQUEST['checked'];
        if (empty($pid))
            exit();
        $cid = $_REQUEST['cid'];
        //$info = D('Picture')->where(array('menu_id' => $cid))->relation(true)->find($id);
        //$Cache = Cache::getInstance();
        $styles = F('styleList', '', C('DATA_CACHE_PATH'));
        $have = $have ? explode(',', $have) : '';
        $html = '<strong>款式二级:</strong><br />';
        foreach ($styles as $key => $val) {
            if ($val['parent_id'] == $pid) {
                $c = in_array($val['id'], explode(',', $checked)) ? 'checked' : '';
                if (!$checked) {
                    $e = in_array($val['id'], $have) ? 'checked' : '';
                }
                $cd = $c ? $c : $e;
                $html .= '<div style="width:120px;float:left">';
                $html .= '<label for="style_id_' . $val['id'] . '"><input ' . $cd . ' name="style[]" onclick="cs(this);" id="style_id_' . $val['id'] . '" type="checkbox" ' . (in_array($val['id'], $have) ? 'checked' : '') . ' value="' . $val['id'] . '" text="' . $val['name'] . '"/>' . $val['name'] . '</label>';
                $html .= '</div>';
            }
        }
        if ($is_ajax)
            return $html;
        else
            exit($html);
    }

    public function getKeywordByAjax($have = '', $pid = '', $is_ajax = '') {
        $haveTmp = $have;
        $pidTmp = intval($pid);
        $have = $haveTmp ? $haveTmp : intval($_REQUEST['have']);
        $pid = $pidTmp ? $pidTmp : intval($_REQUEST['pid']);
        $checked = $_REQUEST['checked'];
        if (empty($pid))
            exit();
        $cid = $_REQUEST['cid'];
        //$info = D('Picture')->relation(true)->where(array('menu_id'=>$cid))->find($have);
        //$Cache = Cache::getInstance();
        $styles = F('keywordList', '', C('DATA_CACHE_PATH'));
        $have = $have ? explode(',', $have) : '';
        $html = '<strong>关键词二级:</strong><br />';
        foreach ($styles as $key => $val) {
            if ($val['parent_id'] == $pid) {
                $c = in_array($val['id'], explode(',', $checked)) ? 'checked' : '';
                if (!$checked) {
                    $e = in_array($val['id'], $have) ? 'checked' : '';
                }
                $cd = $c ? $c : $e;
                $html .= '<div style="width:120px;float:left">';
                $html .= '<label for="keyword_id_' . $val['id'] . '"><input ' . $cd . ' name="keyword[]" onclick="ck(this);" id="keyword_id_' . $val['id'] . '" type="checkbox" value="' . $val['id'] . '" text="' . $val['name'] . '"/>' . $val['name'] . '</label>';
                $html .= '</div>';
            }
        }
        if ($is_ajax)
            return $html;
        else
            exit($html);
    }

    /**
     * 导步获取二三级图案
     * @param $have 图片ID
     * @param $pno 父级NO
     */
    public function getPatternByAjax($have = '', $pno = '', $init = false, $is_ajax = '') {
        $haveTmp = $have;
        $pnoTmp = intval($pno);
        $have = $haveTmp ? $haveTmp : intval($_REQUEST['have']);
        $pno = $pnoTmp ? $pnoTmp : intval($_REQUEST['pno']);
        $spid = intval($_REQUEST['spid']);
        if (empty($pno))
            exit();
        $cid = $_REQUEST['cid'];
        //$info = D('Picture')->where(array('menu_id' => $cid))->relation(true)->find($have);
        $have = $have ? explode(',', $have) : '';
        $Cache = Cache::getInstance('file', $this->cacheFileOption);
        $patterns = F('patternList', '', C('DATA_CACHE_PATH'));
        $html = '';
        if ($init) {
            $html .= '<option value="">请选择</option>';
            foreach ($patterns as $key => $val) {
                if ($val['parent_id'] == $pno) {
                    $selected = '';
                    if (in_array($val['no'], $have)) {
                        $spidTmp = $val['no'];
                        $selected = 'selected="selected"';
                    }
                    $html .= '<option value="' . $val['no'] . '" ' . $selected . '>' . $val['name'] . '</option>';
                }
            }
            $html2 = '';
            if ($spidTmp) {
                foreach ($patterns as $key => $val) {
                    if ($val['parent_id'] == $spidTmp) {
                        $html2 .= '<label for="pattern_id_' . $val['no'] . '"><input name="pattern[]" id="pattern_id_' . $val['no'] . '" type="checkbox" ' . (in_array($val['no'], $have) ? 'checked' : '') . ' value="' . $val['no'] . '" text="' . $val['name'] . '"/>' . $val['name'] . '</label>';
                    }
                }
            }
            return $html . "::" . $html2;
        } else {
            if ($spid != 1) {
                $html .= '<option value="">请选择</option>';
                foreach ($patterns as $key => $val) {
                    if ($val['parent_id'] == $pno) {
                        $html .= '<option value="' . $val['no'] . '" ' . (in_array($val['no'], $have) ? 'selected="selected"' : '') . '>' . $val['name'] . '</option>';
                    }
                }
            } else {
                foreach ($patterns as $key => $val) {
                    if ($val['parent_id'] == $pno) {
                        $html .= '<label for="pattern_id_' . $val['no'] . '"><input name="pattern[]" id="pattern_id_' . $val['no'] . '" type="checkbox" ' . (in_array($val['no'], $have) ? 'checked' : '') . ' value="' . $val['no'] . '" text="' . $val['name'] . '"/>' . $val['name'] . '</label>';
                    }
                }
            }
        }
        if ($is_ajax)
            return $html;
        else
            exit($html);
    }

    /**
     * 导步获取品牌  多次获取 （部分）
     *
     * {{foreach item="item" name="brands"}}
      <option value="{{$item.id}}" {{if condition="$brand_id == $item['id']"}}selected{{/if}}>{{$item.name}}</option>
      {{/foreach}}
     */
    public function getBrandsByAjax($cat = '') {
        $act = $_REQUEST['act'];
        $bid = $_REQUEST['bid'];
        $lisitNum = 1000;
        if (empty($bid))
            exit();
        //$Cache = Cache::getInstance();
        $brands = F('brandList', '', C('DATA_CACHE_PATH'));
        //$lastStart = '';$lastEnd = '';
        $Start = $bid;
        $End = $bid + $lisitNum;
        if ($act == "last") {
            if ($bid < $lisitNum) {
                $Start = 1;
                $End = $lisitNum;
            } else {
                $Start = $bid - $lisitNum;
                $End = $bid;
            }
        } elseif ($act == "next") {
            $Start = $bid;
            $End = $bid + $lisitNum;
        }
        $html = '';
        $html .= '<option value="">品牌选择</option>';
        $html .= '<option value="last' . $Start . '">上' . $lisitNum . '条</option>';
        foreach ($brands as $key => $val) {
            if ($val['id'] >= $Start && $val['id'] <= $End) {
                $html .= '<option value="' . $val['id'] . '"' . ($val['id'] == $Start ? 'selected="selected"' : '') . ' title="' . $val['name'] . '">' . $val['name'] . '</option>';
            }
        }
        $html .= '<option value="next' . $End . '">下' . $lisitNum . '条</option>';
        echo $html;
    }

    /**
     * 导步获取品牌  一次获取
     */
    public function getAllBrandByAjax() {
        //$Cache = Cache::getInstance();
        $brands = F('brandList', '', C('DATA_CACHE_PATH'));
        $html = '';
        $html .= '<option value="">品牌选择</option>';
        foreach ($brands as $key => $val) {
            $html .= '<option value="' . $val['id'] . '"' . ($val['id'] == $brand_id ? 'selected="selected"' : '') . ' title="' . $val['name'] . '">' . $val['name'] . '</option>';
        }
        echo $html;
    }
    /**
     * 导步获取设计师  一次获取
     */
    public function getAllDesignerByAjax() {
        //$Cache = Cache::getInstance();
        $designers = F('designerList', '', C('DATA_CACHE_PATH'));
        $html = '';
        $html .= '<option value="">设计师选择</option>';
        foreach ($designers as $key => $val) {
            $html .= '<option value="' . $val['id'] . '"' . ($val['id'] == $brand_id ? 'selected="selected"' : '') . ' title="' . $val['name'] . '">' . $val['name'] . '</option>';
        }
        echo $html;
    }
    /**
     * 导步获取设计师  一次获取
     */
    public function getAllBookByAjax() {
        //$Cache = Cache::getInstance();
        $books = F('bookList', '', C('DATA_CACHE_PATH'));
        $html = '';
        $html .= '<option value="">书名选择</option>';
        foreach ($books as $key => $val) {
            $html .= '<option value="' . $val['id'] . '"' . ($val['id'] == $book_id ? 'selected="selected"' : '') . ' title="' . $val['name'] . '">' . $val['name'] . '</option>';
        }
        echo $html;
    }
    public function getTypeByAjax() {
        $tid = $_REQUEST['id'];
        $tcid = $_REQUEST['tcid'];
        if (empty($tid))
            exit();
        if (!empty($tcid)) {
            $tmpTcid = explode(',', $tcid);
        }
        //$Cache = Cache::getInstance();
        $types = F('patternTypeList', '', C('DATA_CACHE_PATH'));
        $html = '';
        $html .= '<select name="type_child_id" id="type_child_id">';
        $html .= '<option value="">图案二级选择</option>';
        foreach ($types as $key => $val) {
            if ($val['parent_id'] == $tid) {
                $html .= '<option value="' . $val['id'] . '" title="' . $val['name'] . '"' . (in_array($val['id'], $tmpTcid) ? 'selected="selected"' : '') . '>' . $val['name'] . '</option>';
            }
        }
        $html .= '</select>';
        echo $html;
    }
//图案专用
    public function getFashionByAjax() {
        $fid = $_REQUEST['fid'];
        $fcid = $_REQUEST['fcid'];
        if (empty($fid))
            exit();
        if (!empty($fcid)) {
            $tmpFcid = explode(',', $fcid);
        }
        //$Cache = Cache::getInstance();
        $fashions = F('patternFashionList', '', C('DATA_CACHE_PATH'));
        $html = '';
        foreach ($fashions as $key => $val) {
            if ($val['parent_id'] == $fid) {
                $html .= '<label for="'. $val['id'] . '"><input name="fashion_child_id[]" id="' . $val['id'] . '" type="checkbox" ' . (in_array($val['id'], $tmpFcid) ? 'checked' : '') . ' value="' . $val['id'] . '" text="' . $val['name'] . '"/>' . $val['name']. '</label>';
            }
        }
        echo $html;
    }
//图案专用
    public function getPatternsByAjax() {
        $pid = $_REQUEST['pid'];
        $pcid = $_REQUEST['pcid'];
        if (empty($pid))
            exit();
        if (!empty($pcid)) {
            $tmpFcid = explode(',', $pcid);
        }
        //$Cache = Cache::getInstance();
        $patterns = F('patternPatternList', '', C('DATA_CACHE_PATH'));
        $html = '';
        foreach ($patterns as $key => $val) {
            if ($val['parent_id'] == $pid) {
                $html .= '<div style="width:130px;height:20px;overflow:hidden;float:left" title ="' . $val['name'] . '">';
                $html .= '<label for="'. $val['id'] . '"><input name="pattern_child_id[]" id="' . $val['id'] . '" type="checkbox" ' . (in_array($val['id'], $tmpFcid) ? 'checked' : '') . ' value="' . $val['id'] . '" text="' . $val['name'] . '"/>' . $val['name']. '</label>';
                $html .= '</div>';
            }
        }
        echo $html;
    }

}