<?php
// 后台主题模块
class PatternsAction extends SubjectAction {
	public $cid = 24;

	public function _initialize() {
		parent::_initialize();
		$listMenus = array(
			array('href' => __URL__ . '/folderList', 'selected'=>(in_array(ACTION_NAME, array('folderList','index')) ? 'now' : ''), 'title' => '文件夹'),
			array('href' => __URL__ . '/themeList', 'selected'=>(in_array(ACTION_NAME, array('themeList')) ? 'now' : ''), 'title' => '主题管理'),
			array('href' => __URL__ . '/picList', 'selected'=>(in_array(ACTION_NAME, array('picList')) ? 'now' : ''), 'title' => '图片管理'),
		);
		$this->assign('listMenus', $listMenus);
		$this->assign('currentBase', '数据录入-图案');
	}

    public function setConfig() {
        //季度
        if (in_array('1', $this->config) || in_array('1', $this->configS))
            $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
        //区域
        if (in_array('2', $this->config) || in_array('2', $this->configS))
            $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
        //品牌
        if (in_array('3', $this->config) || in_array('3', $this->configS))
            $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
        //设计师
        if (in_array('4', $this->config) || in_array('4', $this->configS))
            $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
        //书名
        //if (in_array('5', $this->config) || in_array('5', $this->configS)){
            $this->books = F('bookList','',C('DATA_CACHE_PATH'));
        //}
        //color 图案颜色
        if (in_array('6', $this->config) || in_array('6', $this->configS))
            $this->colors = F('patternColorList','',C('DATA_CACHE_PATH'));
        //style
        if (in_array('7', $this->config) || in_array('7', $this->configS))
            $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
        //fashion 图案风格
        if (in_array('8', $this->config) || in_array('8', $this->configS)){
            $this->fashions = F('patternFashionList','',C('DATA_CACHE_PATH'));
            $this->parent_fashions = $this->getParents($this->fashions);
        }
        //pattern 图案图形
        if (in_array('9', $this->config) || in_array('9', $this->configS))
            $this->patterns = F('patternPatternList','',C('DATA_CACHE_PATH'));
        //acc
        if (in_array('10', $this->config) || in_array('10', $this->configS))
            $this->accs = F('accList','',C('DATA_CACHE_PATH'));
        //material
        if (in_array('11', $this->config) || in_array('11', $this->configS))
            $this->materials = F('materialList','',C('DATA_CACHE_PATH'));
        //detail 图案细节
        if (in_array('12', $this->config) || in_array('12', $this->configS))
            $this->details = F('patternDetailList','',C('DATA_CACHE_PATH'));
        //craft 图案工艺
        $this->crafts = F('patternCraftList','',C('DATA_CACHE_PATH'));
        //types 图案分类
        $this->types = F('patternTypeList','',C('DATA_CACHE_PATH'));
    }
	function index() {
		$this->folderList();
	}

	public function folderList() {
        $field = $this->m['folder_original'].'.id,title,title_picture_url,'.$this->m['folder_original'].'.child_menu_id,'.$this->m['folder_original'].'.menu_id,child_subject_count,area_no,season_id,designer_id,brand_id,book_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['folder_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_folderList($field,$map);
		$this->display('Subject/pattren_folder_list');
	}
    public function _folderList($field = '*', $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-文件夹  列表');
        $action_link = array();
        $action_link[] = array('text' => '添加文件夹', 'href' => "__URL__/folderAdd");
        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['folder_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $pattern_id = intval($_REQUEST['pattern_id']);
        if ($pattern_id)
            $map['pattern_id'] = $pattern_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : $this->modelF->getPk();
        $sort = $asc ? 'desc' : 'asc';
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_folder_sort_original'].' fs ON fs.folder_id='.$this->m['folder_original'].'.id';
			if ( $sort_id == 3 ){
                $map['fs.sort_id'] = array('egt',$sort_id);
            } else {
                $map['fs.sort_id'] = $sort_id;
            }
            $field .=",fs.sort_id";
        }
        //风格
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id) {
			$join[] = $this->m['ref_folder_fashion_original'].' ff ON ff.folder_id='.$this->m['folder_original'].'.id';
			$map['ff.fashion_id'] = $fashion_id;
            $field .=",ff.fashion_id";
        }
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);

        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数
        //$count = $this->modelF->join($join)->where($map)->count('id');
        import('ORG.Util.DataCount');
        $count = DataCount::getCount("{$this->m['folder']}", $map, $join);
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelF->relation(array('sort_id','fashion_id'))->where($map)->field($field)->join($join)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelF->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $fashion = array();
                    if ($val['fashion_id']) {
                        foreach ($val['fashion_id'] as $k => $v) {
                            if ($this->fashions[$v['fashion_id']]['name'])
                                $fashion[] = $this->fashions[$v['fashion_id']]['name'];
                        }
                    }
                    if (empty($fashion)) {
                        $fashion = array($this->fashions[$val['fashion_id']]['name']);
                    }
                    $voList[$key]['fashionStr'] = implode(',', $fashion);
                    //$tc = $this->modelT->where("folder_id='{$val['id']}' and is_publish!=-1")->count('*');
                    $voList[$key]['themeCount'] = $val['child_subject_count'];
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    if ($this->patterns)
                        $voList[$key]['patternStr'] = $this->patterns[$val['pattern_id']]['name'];
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        Cookie::set('_currentFolderUrl_', __SELF__);
        return;
    }
	public function folderAdd() {
        if ($_POST) {
            $info = $this->getFolderInfo();
            $id = $this->modelF->add($info);
            if ($id) {
                $this->setFolderOther($id);
                $this->assign('jumpUrl',__URL__."/themeList/folder_id/{$id}");
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            $this->setConfig();
            //dump($this->fashions);
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentFolderUrl_'));
            $this->assign('action_link', $action_link);
            $areaOption = $this->getAreaOption(0);
            $this->assign('areaOption', $areaOption);
            $info['publish_time'] = date('Y-m-d H:i:s', time());
            $this->assign('info', $info);
            $this->assign('listMenus', '');
            $this->display('Subject/pattern_folder_info');
        }
    }

	public function folderEdit() {
		parent::folderEdit('1');
        $this->display('Subject/pattern_folder_info');
	}

	public function themeList() {
		$folder_id = $_REQUEST['folder_id'];
		$fid = $folder_id ? intval($folder_id) : intval($_REQUEST['fid']);
		if (isset($folder_id)) {
			$this->assign('listMenus', '');
		}
		if ($fid) {
			$m = D("{$this->m['folder_lable']}");
			$lables = $m->field('id,lable')->where(array('folder_id'=>$fid))->select();
			$this->assign('lables', $lables);
		}
		$this->assign('fid', $fid);
		if ($folder_id == '0') $map['folder_id'] = 0;
        $field = $this->m['subject_original'].'.id,folder_id,lable_id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_themeList($field,$map,($folder_id ? 'lable_id' : ''));
		if (isset($folder_id)) {
			$this->display('Subject/folder_theme_list');
		} else {
			$this->display('Subject/pattren_theme_list');
		}
	}

    protected function _themeList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-主题列表');
        $action_link = array();
        $folder_id = $_REQUEST['folder_id'];
        if (isset($folder_id)) {
            $action_link[] = array('text' => '返回文件夹', 'href' => Cookie::get('_currentFolderUrl_'));
        }
        if (isset($folder_id) && !empty($folder_id)) {
            $folder_data = $this->modelF->getById($folder_id);
            $this->assign('folderTitle', "文件夹：".stripslashes($folder_data['title']));
            if (!in_array($this->cid,array(12))){$action_link[] = array('text' => '标签管理', 'href' => "__URL__/labelList/folder_id/{$folder_id}");}
            $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/folder_id/{$folder_id}");
        }
        if (!isset($folder_id) && empty($folder_id))
            $action_link[] = array('text' => '添加独立主题', 'href' => "__URL__/themeAdd/is_folder/1");

        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (intval($folder_id))
            $map['folder_id'] = intval($folder_id);
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['subject_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        if($this->cid == 12){
            $order = $this->modelT->getPk();
        }  else {
            $order = !empty($sortBy) ? $sortBy : $this->modelT->getPk();
        }
        $sort = $asc ? 'desc' : 'asc';
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_subject_sort_original'].' ss ON ss.subject_id='.$this->m['subject_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ss.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ss.sort_id'] = $sort_id;
            }
            $field .=",ss.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_subject_column_original'].' sc ON sc.subject_id='.$this->m['subject_original'].'.id';
            if($column_id == 6){
                //$map['sc.special_column_id'] = array('exp','is null');
                $map['sc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['sc.special_column_id'] = $column_id;
            }
            $field .=",sc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_subject_style_original'].' sst ON sst.subject_id='.$this->m['subject_original'].'.id';
			$map['sst.style_id'] = $style_id;
            $field .=",style_id";
        }

        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数
        //$map =array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } }
        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        $count = $moldel->getCount("{$this->m['subject']}", $map, $join);
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelT->relation(array('sort_id','special_column_id','style','fashion_id'))->where($map)->join($join)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelT->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);
                    if ($val['lable_id']) {
                        $m = D("{$this->m['folder_lable']}");
                        $la = $m->field('lable')->find($val['lable_id']);
                        $voList[$key]['lableStr'] = $la['lable'];
                    }
                    
                    $fashion = array();
                    if ($val['fashion_id']) {
                        foreach ($val['fashion_id'] as $k => $v) {
                            $fashion[] = $this->fashions[$v['fashion_id']]['name'];
                        }
                    }
                    if (empty($fashion)) {
                        $fashion = array($this->fashions[$val['fashion_id']]['name']);
                    }
                    $voList[$key]['fashionStr'] = implode(',', $fashion);
                    
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        $this->assign('folder_id', $folder_id);
        Cookie::set('_currentThemeUrl_', __SELF__);
        return;
    }

    public function themeAdd() {
        if ($_POST) {
            $info = $this->getSubjectInfo();
            $fid = $_REQUEST['folder_id'] ? $_REQUEST['folder_id'] : '';
            $info['lable_id'] = $_POST['lable_id'] ? $_POST['lable_id'] : 0;
            $id = $this->modelT->add($info);
            //echo $this->modelT->getLastSql();exit();
            if ($id) {
                $this->setThemeOther($id,$fid);
                if(!empty($fid)){
                    $this->getFolderThemeCount($fid);
                }
                $this->assign('jumpUrl',__URL__."/picList/subject_id/{$id}");
                //$this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            Cookie::delete('themeAdd');
            $randStr = '9999'.rand(10000, 99999);
            Cookie::set('themeAdd', $randStr);
            $this->assign('tid', $randStr);
            $this->setConfig();
            $this->setConfig();
            $folder_id = $_REQUEST['folder_id'];
            $is_folder = $_REQUEST['is_folder'];
            //获取对应标签
            if(!empty($folder_id)){
                $info = $this->modelF->getById($folder_id);
                $info['tmpTitle'] =$info['title'];
                $info['title'] = $info['id'] = '';
                $map['folder_id'] = $folder_id;
                $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                $this->assign('lableList', $lable_list);
                }
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $info['publish_time'] = date('Y-m-d H:i:s', time());
            $info['folder_id'] = $_REQUEST['folder_id'];
            $this->assign('info', $info);
            //区域格式化
            $areaOption = $this->getAreaOption(0);
            $this->assign('areaOption', $areaOption);
            $this->assign('listMenus', '');
            if(empty($is_folder)){
                $this->display('Subject/theme_info');
            }else{
                $this->display('Subject/pattren_theme_add');
            }
        }
    }

    public function themeEdit() {
        $id = intval($_POST['id']);
        if ($id) {
            $info = $this->getSubjectInfo();
            $fid = $_REQUEST['folder_id'] ? $_REQUEST['folder_id'] : '';
            if(is_array($_POST['child_menu_id']) && isset($_POST['child_menu_id'])){
                $child_menu_array = $_POST['child_menu_id'];
            }else{
                $info['child_menu_id'] = intval($_POST['child_menu_id']);
            }
            if($_POST['lable_id']){
                $info['lable_id'] = $_POST['lable_id'] ? $_POST['lable_id'] : 0;
            }
            // 更新数据
            $where['id'] = $id;
            $result = $this->modelT->where($where)->save($info);
            if (false !== $result) {
                $this->setThemeOther($id,$fid);
                //成功提示
                $this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('编辑成功!');
            } else {
                //错误提示
                $this->error('编辑失败!');
            }
        } else {
            $this->setConfig();
            if ($_GET['id']) {
                $folder_id = $_REQUEST['folder_id'] ? $_REQUEST['folder_id'] : '';
                $is_folder = $_REQUEST['is_folder'];
                $id = $_REQUEST[$this->modelT->getPk()];
                $info = $this->modelT->relation(true)->where(array('menu_id' => $this->cid, 'id' => $id))->find();
                //dump($info);
                $info['publish_time'] = date('Y-m-d H:i:s', $info['publish_time']);
                $info['tmpTitle'] = $info['title'];
                $info['subject_id'] = $_GET['id'];
                if ($info['folder_id']) {
                    $map['folder_id'] = $info['folder_id'];
                    $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                    $this->assign('lableList', $lable_list);
                }
                if ($info['sort_id']) {
                    $tmp = array();
                    foreach ($info['sort_id'] as $key => $val) {
                        $tmp[] = $val['sort_id'];
                    }
                    $info['sort_id'] = $tmp;
                }
                if (empty($info['sort_id'])) {
                    $info['sort_id'] = array($info['sort_id']);
                }

                if ($info['craft']) {
                    $tmp = array();
                    foreach ($info['craft'] as $key => $val) {
                        $tmp[] = $val['craft_id'];
                    }
                    $info['craft'] = $tmp;
                }
                if (empty($info['craft'])) {
                    $info['craft'] = array($info['craft']);
                }

                if ($info['style']) {
                    $tmp = array();
                    foreach ($info['style'] as $key => $val) {
                        $tmp[] = $val['style_id'];
                    }
                    $info['style'] = $tmp;
                }
                if (empty($info['style'])) {
                    $info['style'] = array($info['style']);
                }
                if ($info['child_menu_ids']) {
                    $tmp = array();
                    foreach ($info['child_menu_ids'] as $key => $val) {
                        $tmp[] = $val['child_menu_id'];
                    }
                    $info['child_menu_ids'] = $tmp;
                }
                if (empty($info['child_menu_ids'])) {
                    $info['child_menu_ids'] = array($info['child_menu_ids']);
                }

                if ($info['acc']) {
                    $tmp = array();
                    foreach ($info['acc'] as $key => $val) {
                        $tmp[] = $val['acc_id'];
                    }
                    $info['acc'] = $tmp;
                }
                if($info['book_id']){
                    $checkBookName = $this->books[$info['book_id']]['name'];
                    $this->assign('checkBook',$checkBookName);
                }
                if($info['designer_id']){
                    $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
                    $checkDesigner = $this->designers[$info['designer_id']]['name'];
                    $this->assign('checkDesigner',$checkDesigner);
                }
				//主题描述
				$title_describe = D("PatternSubjectExtend")->where(array('subject_id'=>$info['id'],'menu_id'=>$info['menu_id'],"child_menu_id" =>$info['child_menu_id'] ))->find();
				$info['title_describe'] = htmlspecialchars($title_describe['title_describe']);
                $info['title_picture_url'] = show_pic_path($info['title_picture_url']);
                $recom = $this->getRecommend($id);
                $info = array_merge($info, $recom);
                $info['show_edit'] = $info['show_edit'] ? 'checked' : '';
                $this->assign('info', $info);
            }
            //dump($info);
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $this->assign('listMenus', '');
            $this->assign('tid', $id);
            $this->assign('folder_id', $folder_id);
            //区域格式化
            $areaOption = $this->getAreaOption(intval($info['area_no']));
            $this->assign('areaOption', $areaOption);
            if(empty($is_folder)){
                $this->display('Subject/theme_info');
            }else{
                $this->display('Subject/pattren_theme_info');
            }
        }
    }

	public function themeBatch() {
		parent::themeBatch();
	}

	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,page_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/pattren_picture_list');
		} else {
			$this->display('Subject/pattren_theme_picture_list');
		}
	}

    protected function _picList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } }
            $this->error('参数错误！');
        $action_link = array();
        $subject_id = intval($_REQUEST['subject_id']);
        if ($subject_id) {
            $themeI = $this->modelT->where(array('menu_id' => $this->cid, 'id' => $subject_id))->field('title,picture_count')->find();
            //echo $this->modelT->getlastsql();var_dump($themeI);
            $currentName = '-主题:' . stripslashes($themeI['title']);
            $info['tmpTitle'] =  stripslashes($themeI['title']);
            $action_link[] = array('text' => '返回主题列表', 'href' => Cookie::get('_currentThemeUrl_'));
        }
        $this->assign('info', $info);
        $this->assign('currentName', $currentName . '-图片列表');
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (isset($subject_id) && !empty($subject_id)) {
             $action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加图片','url':'__URL__/picAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        }
        if (empty($subject_id))
            $action_link[] = array('text' => '添加独立图片', 'href' => "__URL__/picAdd/is_subject/1");
        $this->assign('action_link', $action_link);
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['picture_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'id';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
        if ($subject_id) {
            $map['subject_id'] = $subject_id;
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_picture_sort_original'].' ps ON ps.picture_id='.$this->m['picture_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ps.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ps.sort_id'] = $sort_id;
            }
            $field .=",sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_picture_column_original'].' pc ON pc.picture_id='.$this->m['picture_original'].'.id';
            if($column_id == 6){
                //$map['pc.special_column_id'] = array('exp','is null');
                $map['pc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['pc.special_column_id'] = $column_id;
            }
            $field .=",special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_style_original'].' pst ON pst.picture_id='.$this->m['picture_original'].'.id';
			$map['pst.style_id'] = $style_id;
            $field .=",style_id";
        }

        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数  主题表保存有图片数量字段 field:picture_count,前提是“$subject_id”不为空才能调用这个字段 暂时注销
        if (!empty($subject_id)) {
            $count = $themeI['picture_count'];
        } else {
            import('ORG.Util.DataCount');
            $moldel = new DataCount();
            $count = $moldel->getCount("{$this->m['picture']}", $map, $join);
        }
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelP->relation(array('sort_id','special_column_id','style','extend','fashion','detail','pattern','craft','type'))->where($map)->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelP->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);
                    
                    $fashion = array();
                    if ($val['fashion']) {
                        foreach ($val['fashion'] as $k => $v) {
                            if ($this->fashions[$v['fashion_id']]['name'])
                                $fashion[] = $this->fashions[$v['fashion_id']]['name'];
                        }
                    }
                    if (empty($fashion)) {
                        $fashion = array($this->fashions[$val['fashion_id']]['name']);
                    }
                    $voList[$key]['fashionStr'] = implode(',', $fashion);
                    
                    $detail = array();
                    if ($val['detail']) {
                        foreach ($val['detail'] as $k => $v) {
                            if ($this->details[$v['detail_id']]['name'])
                                $detail[] = $this->details[$v['detail_id']]['name'];
                        }
                    }
                    if (empty($detail)) {
                        $detail = array($this->details[$val['detail_id']]['name']);
                    }
                    $voList[$key]['detailStr'] = implode(',', $detail);
                    
                    $pattern = array();
                    if ($val['pattern']) {
                        foreach ($val['pattern'] as $k => $v) {
                            if ($this->patterns[$v['pattern_id']]['name'])
                                $pattern[] = $this->patterns[$v['pattern_id']]['name'];
                        }
                    }
                    if (empty($pattern)) {
                        $pattern = array($this->patterns[$val['pattern_id']]['name']);
                    }
                    $voList[$key]['patternStr'] = implode(',', $pattern);
                    
                    $craft = array();
                    if ($val['craft']) {
                        foreach ($val['craft'] as $k => $v) {
                            if ($this->crafts[$v['craft_id']]['name'])
                                $craft[] = $this->crafts[$v['craft_id']]['name'];
                        }
                    }
                    if (empty($craft)) {
                        $craft = array($this->crafts[$val['craft_id']]['name']);
                    }
                    $voList[$key]['craftStr'] = implode(',', $craft);
                    
                    $type = array();
                    if ($val['type']) {
                        foreach ($val['type'] as $k => $v) {
                            if ($this->types[$v['type_id']]['name'])
                                $type[] = $this->types[$v['type_id']]['name'];
                        }
                    }
                    if (empty($type)) {
                        $type = array($this->types[$val['type_id']]['name']);
                    }
                    $voList[$key]['typeStr'] = implode(',', $type);
                    
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    if ($this->styles)
                        $voList[$key]['styleStr'] = $this->styles[$val['style_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    //$voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic'  />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //dump($voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }
	public function picAdd() {
		parent::picAdd("1");
        $action_link[] = array('text' => '返回图片列表', 'href' => Cookie::get('_currentPiclistUrl_'));
        $this->assign('action_link', $action_link);
        $is_subject = $_REQUEST['is_subject'];
        if(empty($is_subject)){
            $this->display('Subject/catwalk_picture_info');
        }else{
            $this->display('Subject/pattren_picture_info');
        }
	}

	public function picCategory() {
		$this->_picCategory();
	}
    public function _picCategory() {
        $picture_id = intval($_REQUEST['picture_id']);
        $subject_id = intval($_REQUEST['subject_id']);
        $this->assign('picture_id', $picture_id);
        $ids = $_REQUEST['ids'];
        if ($_POST) {
            if(strlen($_POST['description']) > 50 ){
                $this->assign('waitSecond', 3);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('操作失败!<br />图片描述长度不能超过50!');
            }
            $idArr = explode(',', $ids);
            if ($idArr) {
                foreach ($idArr as $pid) {
                    $pid = intval($pid);
                    $this->setSift();
                    //添加图片描述
                   	$info['picture_id'] = $pid;
                   	$info['menu_id'] = $_POST['menu_id'];
                    if ( $_POST['fashion_id'] == 7 ) {
                        $info['child_menu_id'] = 69;
                        $map['id'] = $pid;
                        $this->modelP->where($map)->setField('child_menu_id',69);
                    } else {
                        $info['child_menu_id'] = $_POST['child_menu_id'];
                    }
                   	$info['description'] = $_POST['description'];
                   	$this->setPicDescrip($info);

                    if (($_POST['sort'] || intval($picture_id)) && $_POST['change_sort'])
                        $this->setPattrenSort($pid, $_POST);
                    if (($_POST['fashion_id'] || intval($picture_id)) && $_POST['change_fashion'])
                        $this->setPattrenFashion($pid, $_POST);
                    if (($_POST['type_id'] || intval($picture_id)) && $_POST['change_type'])
                        $this->setPattrenTypes($pid, $_POST);
                    if (($_POST['craft_id'] || intval($picture_id)) && $_POST['change_craft'])
                        $this->setPattrenCraft($pid, $_POST);
                    if (($_POST['detail_id'] || intval($picture_id)) && $_POST['change_detail']){
                        $this->setPattrenDetail($pid, $_POST);
                    }
                    if (($_POST['pattern_id'] || intval($picture_id)) && $_POST['change_pattern'])
                        $this->setPattrenPattern($pid, $_POST);
                    //图片搜索表处理
                    $this->setSearchPicture($pid, $_POST['subject_id']);
                }
                //exit('<script>self.parent.main.location.reload()</script>');
                //exit('<script>self.parent.main.closeBox();</script>');
                //成功提示
                $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('分类成功!');
            }
        } else {
            $info = $this->modelP->relation(array('sort_id','fashion','type','craft','detail','pattern'))->where(array('menu_id' => $this->cid, 'id' => $picture_id))->find();
            $description = $this->model_picture_extend->where(array('picture_id' => $picture_id))->find();
            $info['description'] = $description['description'];
            //dump($info);
            //echo $this->modelP->getlastsql();exit('#');
            $this->setConfig();
            //dump($this->crafts);
            if ($info['sort_id']) {
                $tmp = array();
                foreach ($info['sort_id'] as $key => $val) {
                    $tmp[] = $val['sort_id'];
                }
                $info['sort'] = $tmp;
            }
            if (empty($info['sort'])) {
                $info['sort'] = array($info['sort_id']);
            }

            if ($info['fashion']) {
                //$tmp_fashion_child = '';
                foreach ($info['fashion'] as $key => $val) {
                    if ($val['fashion_id'] > 0 && $this->fashions[$val['fashion_id']]['parent_id'] == 0 ) {
                        $info['fashions'] = $val['fashion_id'];
                    }else{
                        $tmp_fashion_child .= $val['fashion_id'].",";
                        //$tmp_fashion_child_text .= $this->fashions[$val['fashion_id']]['name'].",";
                    }
                }
                $info['fashion_child'] = substr($tmp_fashion_child, 0 ,-1);
                //$info['fashion_child_text'] = substr($tmp_fashion_child_text, 0 ,-1);
                $info['fashion_child_text'] = $this->getFashionByAjax($info['fashions'],$info['fashion_child']);
            }
            
           if ($info['type']) {
                $tmp_type_child = '';
                foreach ($info['type'] as $key => $val) {
                    if ($val['type_id'] > 0 && $this->types[$val['type_id']]['parent_id'] == 0 ) {
                        $info['types'] = $val['type_id'];
                    }else{
                        $tmp_type_child = $val['type_id'];
                        $tmp_type_child_text = $this->types[$val['type_id']]['name'];
                    }
                }
                $info['type_child'] = $tmp_type_child;
                $info['type_child_text'] = $tmp_type_child_text;
                
            }
            //dump($info['types']);
            if ($info['pattern']) {
                //$tmp_fashion_child = '';
                foreach ($info['pattern'] as $key => $val) {
                    if ($val['pattern_id'] > 0 && $this->patterns[$val['pattern_id']]['parent_id'] == 0 ) {
                        $info['patterns'] = $val['pattern_id'];
                    }else{
                        $tmp_pattern_child .= $val['pattern_id'].",";
                        //$tmp_pattern_child_text .= $this->patterns[$val['pattern_id']]['name'].",";
                    }
                }
                $info['pattern_child'] = substr($tmp_pattern_child, 0 ,-1);
                //$info['pattern_child_text'] = substr($tmp_pattern_child_text, 0 ,-1);
                $info['pattern_child_text'] = $this->getPatternsByAjax($info['patterns'],$info['pattern_child']);
            }
        }
        //dump($info);
        $this->assign('info', $info);
        $this->assign('subject_id', $subject_id);
        $this->assign('picture_id', $picture_id);
        $this->assign('ids', $ids);
        $this->assign('listMenus', '');
        $this->display('Subject/patterns_picture_category');
    }

    protected function getFashionByAjax($fid,$fcid) {
        if (empty($fid))
            exit();
        if (!empty($fcid)) {
            $tmpFcid = explode(',', $fcid);
        }
        $fashions = F('patternFashionList', '', C('DATA_CACHE_PATH'));
        $html = '';
        foreach ($fashions as $key => $val) {
            if ($val['parent_id'] == $fid) {
                $html .= '<label for="'. $val['id'] . '"><input name="fashion_child_id[]" id="' . $val['id'] . '" type="checkbox" ' . (in_array($val['id'], $tmpFcid) ? 'checked' : '') . ' value="' . $val['id'] . '" text="' . $val['name'] . '"/>' . $val['name']. '</label>';
            }
        }
        return $html;
    }
    
    protected function getPatternsByAjax($pid,$pcid) {
        if (empty($pid))
            exit();
        if (!empty($pcid)) {
            $tmpFcid = explode(',', $pcid);
        }
        $patterns = F('patternPatternList', '', C('DATA_CACHE_PATH'));
        $html = '';
        foreach ($patterns as $key => $val) {
            if ($val['parent_id'] == $pid) {
                $html .= '<div style="width:130px;height:20px;overflow:hidden;float:left" title ="' . $val['name'] . '">';
                $html .= '<label for="'. $val['id'] . '"><input name="pattern_child_id[]" id="' . $val['id'] . '" type="checkbox" ' . (in_array($val['id'], $tmpFcid) ? 'checked' : '') . ' value="' . $val['id'] . '" text="' . $val['name'] . '"/>' . $val['name']. '</label>';
                $html .= '</div>';
            }
        }
        return $html;
    }
	public function picBatch() {
		parent::picBatch();
	}

    public function picTmpBatch() {
        $subject_id = intval($_REQUEST['subject_id']);
        $acttype = trim($_REQUEST['acttype']);
        $batch_id = $_REQUEST['batch_id'];//全选
        if (empty($acttype))
            $this->error('对不起，请选择操作类型！');
        $model = D('SharePicturesTmp');
        if ($acttype == 'remove') {
            foreach ($batch_id as $id) {
                $id = intval($id);
                $row = $model->field('url AS img_path')->find($id);
                @unlink($_SERVER['DOCUMENT_ROOT'] . '/' . C('IMG_ROOT') . $row["img_path"]);
                $model->delete($id);
            }
            $this->success('删除成功！');
        } else {
            $listArr = $this->picTmpFormat();
            if ($listArr) {
                foreach ($listArr as $key => $val) {
                    if (!$val["s"]) {
                        $this->error($val["img_name"] . ' 的小图片似乎没有吧？');
                    } else {
                        $page_no = intval(substr($val["img_name"], 1, 4));
                        $picInfo = array();
                        $picInfo["small_picture_url"] = $val["s"]["img_path"];
                        $picInfo["big_picture_url"] = $val["img_path"];
                        $picInfo["add_user_id"] = $val["add_user_id"];
                        $picInfo["add_time"] = $val["add_time"];
                        $picInfo["publish_time"] = $val["add_time"];
                        $picInfo["menu_id"] = $val["menu_id"];
                        $picInfo["subject_id"] = $subject_id;
                        $picInfo['child_menu_id'] = $val['child_menu_id'];
                        $picInfo["area_no"] = $val["area_no"];
                        $picInfo["designer_id"] = $val["designer_id"];
                        $picInfo["brand_id"] = $val["brand_id"];
                        $picInfo["book_id"] = $val["book_id"];
                        $picInfo["season_id"] = $val["season_id"];
                        $picInfo["page_no"] = $page_no;
                        $picInfo["is_publish"] = $val["is_publish"];
                        $picInfo["publish_time"] = $val["publish_time"];
                        //dump($val);exit();
                        $pid = $this->modelP->add($picInfo);
                        //$pid = "17038";
                        $this->setSift();
                        $this->setPicExtend($pid, $val);
                        $this->setPicSort($pid,$subject_id,$val['sort_id']);
                        $this->setPattrenType($pid, $val);
                        $this->setPattrenFashion($pid, '',$subject_id);
                        $this->setPattrenPattern($pid, '',$subject_id);
                        $this->setPattrenCraft($pid, '',$subject_id);
                        if ($pid && $type != 'detail') {
                            //插入附图
                            if ($val["f"]) {
                                foreach ($val["f"] as $k => $v) {
                                    if (!$v["s"]) {
                                        $this->error($v["img_name"] . ' 的小图片似乎没有吧？');
                                    } else {
                                        $aInfo = array();
                                        $aInfo["menu_id"] = $val["menu_id"];
                                        $aInfo['child_menu_id'] = $val['child_menu_id'];
                                        $aInfo["picture_id"] = $pid;
                                        $aInfo["add_user_id"] = $v["add_user_id"];
                                        $aInfo["small_picture_url"] = $v["s"]["img_path"];
                                        $aInfo["big_picture_url"] = $v["img_path"];
                                        $aInfo["add_time"] = $v['add_time'] + $k;
                                        $this->modelS->add($aInfo);
                                    }
                                }
                            }
                        }
                        //图片搜索表处理
                        //$this->setSearchPicture($pid);
                        if ($type != 'detail' && $subject_id > 0) {
                            $this->setPictureCount($subject_id,'add');
                        }
                    }
                }
            }
            $model->where(array('menu_id' => $this->cid, 'subject_id' => $subject_id))->delete();
            //成功提示
            $this->assign('waitSecond', 0);
            if ( $subject_id > 0 ) {
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
            } else {
                $this->assign('jumpUrl', Cookie::get('_currentPiclistUrl_'));
            }
            $this->success('操作成功!');
        }
    }

	public function setPattrenType($pid, $array) {
		if (empty($pid)) return false;
        $this->delPattrenType($pid);
        $model = M("{$this->m['ref_picture_type']}");
        $tmpArray = $this->getTmpType($array);
        $model->picture_id = $pid;
        if (is_array($tmpArray) && isset ($tmpArray)) foreach ($tmpArray as $key => $val) {
            if($val['pattren_type_id'] > 0 || $val['pattren_child_type_id'] > 0){
                $model->type_id = !empty($val['pattren_type_id']) ? $val['pattren_type_id'] : $val['pattren_child_type_id'];
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
                $model->add();
                //echo $model->getLastSql();echo "<br />";
            }
        }
	}
    public function getTmpType($array){
        $tmpArray[0]['pattren_type_id'] = $array['pattren_type_id'];
        $tmpArray[1]['pattren_child_type_id'] = $array['pattren_child_type_id'];
        $tmpArray[0]['child_menu_id'] = $array['child_menu_id'];
        $tmpArray[1]['child_menu_id'] = $array['child_menu_id'];
        return $tmpArray;
    }
	public function delPattrenType($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_type']}");
		$model->where($where)->delete();
	}

    public function delPattrenFashion($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_fashion']}");
        $model->where($where)->delete();
    }

    public function getPostFashion($info){
        $tmp_fashion_id[0] = $info['fashion_id'];
        $tmp_fashion_child_id = $info['fashion_child_id'];
        if(!empty($tmp_fashion_child_id[0])){
            $tmp = array_merge($tmp_fashion_id,$tmp_fashion_child_id);
        }else{
            $tmp = $tmp_fashion_id;
        }
        return $tmp;
    }

    public function getSubjectFashion($tid){
        if ( !$tid ) {
            return false;
        }
        $SmodelF = M("{$this->m['ref_subject_fashion']}");
        $SwhereF['subject_id'] = $tid;
        $SwhereF['menu_id'] = 24;
        $f_list = $SmodelF->where($SwhereF)->select();
        if( $f_list ){
            foreach ($f_list as $key => $value) {
                $fashion_arr[$key] = $value['fashion_id'];
            }
        } 
        return $fashion_arr;
    }
    
    public function setPattrenFashion($id, $info = NULL, $tid = NULL) {
        if (empty($id))
            return false;
        if ( $tid ) {
            $getPostFashion = $this->getSubjectFashion($tid);
        } else {
            $getPostFashion = $this->getPostFashion($info);
        }
        //dump($getPostFashion);exit;
        $this->delPattrenFashion($id);
        if(empty($getPostFashion))
             return ;
        $model = M("{$this->m['ref_picture_fashion']}");
        $model->picture_id = $id;
        foreach ($getPostFashion as $key => $val) {
            if ($val > 0) {
                $model->fashion_id = $val;
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($_POST['child_menu_id']) ? $_POST['child_menu_id'] : 0;
                $model->add();
                //echo $model->getLastSql();echo "<br />";
            }
        }
    }

    public function delPattrenSort($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_sort']}");
        $model->where($where)->delete();
    }

    public function setPattrenSort($id, $info) {
        if (empty($id))
            return false;
        $getPostSort = $info['sort'];
        $this->delPattrenSort($id);
        if(empty($getPostSort))
             return ;
        $model = M("{$this->m['ref_picture_sort']}");
        $model->picture_id = $id;
        foreach ($getPostSort as $key => $val) {
            if ($val > 0) {
                $model->sort_id = $val;
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($_POST['child_menu_id']) ? $_POST['child_menu_id'] : 0;
                $model->add();
                //echo $model->getLastSql();echo "<br />";
            }
        }
    }
    public function setPattrenTypes($id, $info) {
        if (empty($id))
            return false;
        $getPostType = $info['type_id'];
        $getPostTypeChild = $info['type_child_id'];
        $this->delPattrenType($id);
        if(empty($getPostType) && empty($getPostTypeChild))
             return ;
        $model = M("{$this->m['ref_picture_type']}");
        $model->picture_id = $id;
        if ($getPostType) {
            $model->type_id = $getPostType;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_POST['child_menu_id']) ? $_POST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
        if ($getPostTypeChild) {
            $model->type_id = $getPostTypeChild;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_POST['child_menu_id']) ? $_POST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }

    public function getSubjectCraft($tid) {
        if ( !$tid ) {
            return false;
        }
        $SmodelF = M("{$this->m['ref_subject_craft']}");
        $SwhereF['subject_id'] = $tid;
        $SwhereF['menu_id'] = 24;
        $f_list = $SmodelF->where($SwhereF)->find();
        if( $f_list ){
            $pattren_arr = $f_list['craft_id'];
        } 
        return $pattren_arr;
        
    }
    public function setPattrenCraft($id, $info=null, $tid = null) {
        if (empty($id))
            return false;
        if ( $tid ) {
            $getPostCraft = $this->getSubjectCraft($tid);
        } else {
            $getPostCraft = $info['craft_id'];
        }
        $this->delPattrenCraft($id);
        if(empty($getPostCraft))
             return ;
        $model = M("{$this->m['ref_picture_craft']}");
        $model->picture_id = $id;
        if ($getPostCraft) {
            $model->craft_id = $getPostCraft;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_POST['child_menu_id']) ? $_POST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }
    public function delPattrenCraft($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_craft']}");
        $model->where($where)->delete();
        //echo $model->getLastSql();echo "<br />";
    }

    public function setPattrenDetail($id, $info) {
        if (empty($id))
            return false;
        $getPostDetail = $info['detail_id'];
        $this->delPattrenDetail($id);
        if(empty($getPostDetail))
             return ;
        $model = M("{$this->m['ref_picture_detail']}");
        $model->picture_id = $id;
        if ($getPostDetail) {
            $model->detail_id = $getPostDetail;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_POST['child_menu_id']) ? $_POST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }
    public function delPattrenDetail($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_detail']}");
        $model->where($where)->delete();
        //echo $model->getLastSql();echo "<br />";
    }


    public function delPattrenPattren($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_pattern']}");
        $model->where($where)->delete();
    }

    public function getPostPattren($info){
        $tmp_pattren_id[0] = $info['pattern_id'];
        $tmp_pattren_child_id = $info['pattern_child_id'];
        $tmp = array_merge($tmp_pattren_id,$tmp_pattren_child_id);
        return $tmp;
    }

    public function getSubjectPattren($tid){
        if ( !$tid ) {
            return false;
        }
        $SmodelF = M("{$this->m['ref_subject_pattren']}");
        $SwhereF['subject_id'] = $tid;
        $SwhereF['menu_id'] = 24;
        $f_list = $SmodelF->where($SwhereF)->select();
        if( $f_list ){
            foreach ($f_list as $key => $value) {
                $pattren_arr[$key] = $value['pattren_id'];
            }
        } 
        return $pattren_arr;
    }
    
    public function setPattrenPattern($id, $info = null, $tid = null) {
        if (empty($id))
            return false;
        if ( $tid ) {
            $getPostPattren = $this->getSubjectPattren($tid);
        } else {
            $getPostPattren = $this->getPostPattren($info);
        }
        $this->delPattrenPattren($id);
        if(empty($getPostPattren))
             return ;
        $model = M("{$this->m['ref_picture_pattern']}");
        $model->picture_id = $id;
        foreach ($getPostPattren as $key => $val) {
            if ($val > 0) {
                $model->pattern_id = $val;
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($_POST['child_menu_id']) ? $_POST['child_menu_id'] : 0;
                $model->add();
                //echo $model->getLastSql();echo "<br />";
            }
        }
    }

	public function picZip() {
		parent::picZip();
	}

    public function updateBookSort () {
       parent::updateBookSort();
    }
    //独立主题的风格
    public function setThemeFashion($fid,$sid){
        if (empty ($sid))
             return false;
        $this->delThemeFashion($sid);
        if (empty ($_POST['fashion_id']))
             return ;
        if(empty ($fid)) {
            $folderFashionArray = $this->getDuliPostFashion();
        }else{
            $folderFashionArray = $this->getFolderFashion($fid);
        }
        $model = M("{$this->m['ref_subject_fashion']}");
        foreach ($folderFashionArray as $key => $val) {
            $model->subject_id = $sid;
            $model->fashion_id = $val['fashion_id'];
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }

    public function getDuliPostFashion(){
        $postArray = array();
        $postArray[0]['fashion_id'] = $_POST['fashion_id'];
        $postArray[0]['child_menu_id'] = $_POST['child_menu_id'];
        return $postArray;
    }
}
?>
