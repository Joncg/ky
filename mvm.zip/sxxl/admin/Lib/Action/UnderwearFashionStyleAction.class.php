<?php
// 后台主题模块
class UnderwearFashionStyleAction extends SubjectAction {
	public $cid = 102;  //内衣.时尚款式 menu_id=102
    public $nycid = 102;
    public $ny_cid = 102;

    public function _initialize() {
		parent::_initialize();
        $this->m = getCidModel($this->cid);
        $listMenus = array(
            array('href' => '/FashionStyle/themeList', 'selected' => (in_array(ACTION_NAME, array('themeList', 'index')) ? '' : ''), 'title' => '主题管理'),
            array('href' => '/FashionStyle/picList', 'selected' => (in_array(ACTION_NAME, array('picList')) ? '' : ''), 'title' => '图片管理'),
            array('href' => '/FashionStyle/detailList', 'selected' => (in_array(ACTION_NAME, array('detailList')) ? '' : ''), 'title' => '细节管理'),
            array('href' => '/UnderwearFashionStyle/themeList', 'selected' => (in_array(ACTION_NAME, array('themeList')) ? 'now' : ''), 'title' => '内衣主题管理'),
            array('href' => '/UnderwearFashionStyle/picList', 'selected' => (in_array(ACTION_NAME, array('picList')) ? 'now' : ''), 'title' => '内衣图片管理'),
//            array('href' => '/UnderwearFashionStyle/detailList', 'selected' => (in_array(ACTION_NAME, array('detailList')) ? 'now' : ''), 'title' => '内衣细节管理'),
        );
        $this->assign('listMenus', $listMenus);
		$this->assign('currentBase', '数据录入-时尚款式');
	}

	function index() {
		$this->themeList();
	}
	
	public function themeList() {
        $field = $this->m['subject_original'].'.id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_themeList($field,$map);
		$this->display('Subject/fashionstyle_theme_list');
	}
	
    protected function _themeList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-主题列表');
        $action_link = array();
        $folder_id = $_REQUEST['folder_id'];
        if (isset($folder_id)) {
            $action_link[] = array('text' => '返回文件夹', 'href' => Cookie::get('_currentFolderUrl_'));
        }
        if (isset($folder_id) && !empty($folder_id)) {
            $folder_data = $this->modelF->getById($folder_id);
            $this->assign('folderTitle', "文件夹：".stripslashes($folder_data['title'])); 
            if (!in_array($this->cid,array(12))){$action_link[] = array('text' => '标签管理', 'href' => "__URL__/labelList/folder_id/{$folder_id}");}
            $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/folder_id/{$folder_id}");
        }
        $action_link[] = array('text' => '添加内衣主题', 'href' => "__URL__/themeAdd/");
        
        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (intval($folder_id))
            $map['folder_id'] = intval($folder_id);
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['subject_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $this->assign('checkBrand',$checkBrandName);
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        if($this->cid == 12){
            $order = $this->modelT->getPk();
        }  else {
            $order = !empty($sortBy) ? $sortBy : $this->modelT->getPk();
        }
        $sort = $asc ? 'desc' : 'asc';
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_subject_sort_original'].' ss ON ss.subject_id='.$this->m['subject_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ss.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ss.sort_id'] = $sort_id;
            }
            $field .=",ss.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_subject_column_original'].' sc ON sc.subject_id='.$this->m['subject_original'].'.id';
            if($column_id == 6){
                //$map['sc.special_column_id'] = array('exp','is null');
                $map['sc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['sc.special_column_id'] = $column_id;
            }
            $field .=",sc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_subject_style_original'].' sst ON sst.subject_id='.$this->m['subject_original'].'.id';
			$map['sst.style_id'] = $style_id;
            $field .=",style_id";
        }
        
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        $count = $moldel->getCount("{$this->m['subject']}", $map, $join);
        //echo $count;
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelT->relation(array('sort_id','special_column_id','zipfile_url'))->where($map)->join($join)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelT->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);
                    if ($val['lable_id']) {
                        $m = D("{$this->m['folder_lable']}");
                        $la = $m->field('lable')->find($val['lable_id']);
                        $voList[$key]['lableStr'] = $la['lable'];
                    }
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    if ($this->styles)
                        $voList[$key]['styleStr'] = $this->styles[$val['style_id']]['name'];
                    $voList[$key]['downloadid'] = urlencode(authcode("tid=".$val['id']."&cid=".$this->cid,"ENCODE"));
                    if($voList[$key]['zipfile_url']['zipfile_url']){
                        $voList[$key]['is_zipfile_url'] = 1;
                    }
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentThemeUrl_', __SELF__);
        return;
    }
	
	public function themeAdd() {
		$this->_themeAdd();
        $this->display('Subject/fashionstyle_underwear_theme_info');
	}
	
    protected function _themeAdd() {
        $this->assign('tid', 0);
        if ($_POST) {
            $info = $this->getSubjectInfo();
            //dump($info);exit();
            $id = $this->modelT->add($info);
            //echo $this->modelT->getLastSql();exit();
            if ($id) {
                $this->setThemeOther($id);
                //处理二级栏目child_menu_id
                $this->setChildMenu($id);
                $this->assign('jumpUrl',__URL__."/picList/subject_id/{$id}");
                //$this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            $this->setConfig();
            $folder_id = $_REQUEST['folder_id'];
            //获取对应标签
            if(!empty($folder_id)){
                $info = $this->modelF->getById($folder_id);
                $info['title'] = stripslashes($info['title']);
                $info['tmpTitle'] =$info['title'];
                $info['title'] = $info['id'] = '';
                $map['folder_id'] = $folder_id;
                $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                $this->assign('lableList', $lable_list);
                }
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $info['publish_time'] = date('Y-m-d H:i:s', time());
            $info['folder_id'] = $_REQUEST['folder_id'];
            $this->assign('info', $info);
            //区域格式化
            $areaOption = $this->getAreaOption(0);
            $this->assign('areaOption', $areaOption);
            $this->assign('listMenus', '');
        }
    }
    
	public function themeEdit() {
		parent::themeEdit('1');
        $this->display('Subject/fashionstyle_underwear_theme_info');
	}

	public function themeBatch() {
		parent::themeBatch();
	}
	
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/fashionstyle_underwear_picture_list');
		} else {
            $this->assign('nycid', $this->nycid);
			$this->display('Subject/fashionstyle_underwear_theme_picture_list');
		}
	}
    
    protected function _picList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } } 
            $this->error('参数错误！');
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $action_link = array();
        $subject_id = intval($_REQUEST['subject_id']);
        if ($subject_id) {
            $themeI = $this->modelT->where(array('menu_id' => $this->cid, 'id' => $subject_id))->field('title,picture_count')->find();
            //echo $this->modelT->getlastsql();var_dump($themeI);
            $currentName = '-主题:' . stripslashes($themeI['title']);
            $info['tmpTitle'] =  stripslashes($themeI['title']);
            $action_link[] = array('text' => '返回主题列表', 'href' => Cookie::get('_currentThemeUrl_'));
        }
        $this->assign('info', $info);
        $this->assign('currentName', $currentName . '-图片列表');
        $action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加图片','url':'__URL__/picAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        
        $this->assign('action_link', $action_link);
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['picture_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $this->assign('checkBrand',$checkBrandName);
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'publish_time';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
        if ($subject_id) {
            $map['subject_id'] = $subject_id;
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_picture_sort_original'].' ps ON ps.picture_id='.$this->m['picture_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ps.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ps.sort_id'] = $sort_id;
            }
            $field .=",sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_picture_column_original'].' pc ON pc.picture_id='.$this->m['picture_original'].'.id';
            if($column_id == 6){
                $map['pc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['pc.special_column_id'] = $column_id;
            }
            $field .=",pc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_style_original'].' pst ON pst.picture_id='.$this->m['picture_original'].'.id';
			$map['pst.style_id'] = $style_id;
            $field .=",style_id";
        }
        
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数  主题表保存有图片数量字段 field:picture_count,前提是“$subject_id”不为空才能调用这个字段 暂时注销
        if (!empty($subject_id)) {
            $count = $themeI['picture_count'];
        } else {
            import('ORG.Util.DataCount');
            $moldel = new DataCount();
            $count = $moldel->getCount("{$this->m['picture']}", $map, $join);
        }
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            //dump($map);exit();
            $voList = $this->modelP->relation(array('sort_id','special_column_id','style'))->where($map)->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelP->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['columnStr'] = implode(',', $column);
                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            if ($this->styles[$v['style_id']]['name'])
                                $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['styleStr'] = implode(',', $style);
                    
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
//                    if ($this->styles)
//                        $voList[$key]['styleStr'] = $this->styles[$val['style_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/subject_id/{$subject_id}/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //dump($voList);
            //模板赋值显示
            $this->assign('list', $voList);
            //dump($voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }
    
	public function picAdd() {
		parent::picAdd('1');
        if($_REQUEST['subject_id'] == 0){
            $this->display('Subject/fashionstyle_picture_add');
        }else{
            $this->display('Subject/invogue_picture_info');
        }
	}
    
    public function detailBatch() {
        $actType = trim($_REQUEST['acttype']);
        $subject_id = intval($_REQUEST['subject_id']);
        $ids = $_REQUEST['ids'];
        if ($actType == 'remove') {
            //$this->picDelete();
            $this->redirect('detailDelete', array('ids' => implode(',', $ids), 'subject_id' => $subject_id));
        } else {
            $display_time = $_POST['display_time'];
            if ($display_time)
                $this->modelS->publish_time = strtotime($display_time);
            if ($actType == 'display_yes') {
                $this->modelS->is_publish = 1;
            } else if ($actType == 'display_no') {
                $this->modelS->is_publish = 0;
            }
            foreach ($ids as $key => $id) {
                $where = array('menu_id' => $this->cid, 'id' => $id);
                $this->modelS->where($where)->save();
                //echo $this->modelP->getlastsql();exit();
            }
            $this->success('操作成功！');
        }
    }
    
    public function detailDelete($mid = '', $subject_id='') {
        $ids = $mid ? $mid : $_REQUEST['ids'];
        $subject_id = $_REQUEST['subject_id'];
        $ids = !is_array($ids) ? explode(',', $ids) : $ids;
        
        if (empty($ids))
            return false;
        $errorNum = 0;
        $info = array('is_publish' => -1);
        $info['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
        foreach ($ids as $key => $id) {
            $id = intval($id);
            $this->modelS->where(array('menu_id' => $this->cid, 'id' => $id))->save($info) ? '' : $errorNum++;
            if ($subject_id > 0) {
                $this->setPictureCount($subject_id,'del');
            }
        }
        
        if (empty($mid)) {
            $errorNum > 0 ? $this->error('操作成功！') : $this->success('操作成功！');
        }
    }

	public function picCategory() {
		$this->_picCategory();
	}
    
    public function _picCategory() {
        $picture_id = intval($_REQUEST['picture_id']);
        $this->assign('picture_id', $picture_id);
        if ( $_REQUEST['addup'] ) {
            $this->assign('addup', $_REQUEST['addup']);
        }
        $ids = $_REQUEST['ids'];
        if ($_POST) {
        //dump($_POST);exit();
            if(strlen($_POST['description']) > 50 ){
                $this->assign('waitSecond', 3);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('操作失败!<br />图片描述长度不能超过50!');
            }
            $idArr = explode(',', $ids);
            if ($idArr) {
                $info = array();$infoB = array();
                $user_auth = Cookie::get(C('USER_AUTH_KEY'));
                $infoB['add_user_id'] = $info['add_user_id'] = intval($user_auth);
                $picture_id = $_REQUEST['picture_id'];
                if ((intval($_REQUEST['child_menu_id']) || intval($picture_id)) && $_POST['change_child_menu_id'])
                    $infoB['child_menu_id'] = $info['child_menu_id'] = intval($_REQUEST['child_menu_id']);
                if ((intval($_REQUEST['season_id']) || intval($picture_id)) && $_POST['change_season_id'])
                    $infoB['season_id'] = $info['season_id'] = intval($_REQUEST['season_id']);
                if ((intval($_REQUEST['designer_id']) || intval($picture_id)) && $_POST['change_designer_id'])
                    $infoB['designer_id'] = $info['designer_id'] = intval($_REQUEST['designer_id']);
                if ((intval($_REQUEST['brand_id']) || intval($picture_id)))
                    $infoB['brand_id'] = $info['brand_id'] = intval($_REQUEST['brand_id']);
                if ((intval($_REQUEST['book_id']) || intval($picture_id)) && $_POST['change_book_id'])
                    $infoB['book_id'] = $info['book_id'] = intval($_REQUEST['book_id']);
                if ((intval($_REQUEST['area_id']) || intval($picture_id)) && $_POST['change_area_id'])
                    $infoB['area_no'] = $info['area_no'] = intval($_REQUEST['area_id']);
                if ((intval($_REQUEST['detail_id']) || intval($picture_id)) && $_POST['change_detail_id'])
                    $infoB['detail_id'] = $info['detail_id'] = intval($_REQUEST['detail_id']);
                if (($_POST['sort_id'] || intval($picture_id)) && $_POST['change_sort'])
                   $infoB['sort_id'] =  $info['sort_id'] = intval($_REQUEST['sort_id']);
                if (($_POST['special_column_id'] || intval($picture_id)) && $_POST['change_column'])
                    $infoB['special_column_id'] = $info['special_column_id'] = intval($_REQUEST['special_column_id']);
                
                
                foreach ($idArr as $pid) {
                    $pid = intval($pid);//dump($_POST);exit;
                    if ( $pid == 0 )  continue;
                    //echo $pid."<br />";
                    $where = array('menu_id' => $this->cid, 'id' => $pid);
                    $this->modelP->where($where)->save($infoB);
                    //echo $this->modelP->getlastsql();exit;
                    $this->setPicExtend($pid, $_POST);
                    $this->setSift();
                    //添加图片描述
                   	$info['picture_id'] = $pid;
                   	$info['menu_id'] = $_POST['menu_id'];
                   	$info['child_menu_id'] =$_POST['child_menu_id'];
                   	$info['description'] = $_POST['description'];
                   	$this->setPicDescrip($info);

                    if (($_POST['acc'] || intval($picture_id)) && $_POST['change_acc'])
                        $this->setPicAcc($pid, $_POST['acc']);
                    if (($_POST['color'] || intval($picture_id)) && $_POST['change_color'])
                        $this->setPicColor($pid, $_POST['color']);
                    if ($_POST['fashion'] ){
                        $this->setPicFashion($pid, $_POST['fashion']);
                    }
                    $this->setPicFashion($pid, $_POST['fashion_id']);
                    $this->setPicMaterial($pid, $_POST['material_id']);
                    
                    if (($_POST['fpid'] || intval($picture_id)) && ($_POST['change_fpid'] || $_POST['change_spid'] || $_POST['change_pattern']))
                        $this->setPicPattern($pid, $_POST['fpid'], $_POST['spid'], $_POST['pattern']);
                    //dump($_POST);exit;
                    $style = $_POST['styles'] ? explode(',', $_POST['styles']) : '';
                    if ($style) {
                        foreach ($style as $k => $v) {
//                            if ($this->styles[$v]['parent_id'] == 0) {
//                                //unset($style[$k]);
//                            }
                            if ($this->styles[$v]['parent_id'] > 0) {
                                $style[] = $this->styles[$v]['parent_id'];
                            }
                        }
                    }//dump($_POST);exit;
                    $style = array_unique($style);

                    $psid = in_array($_POST['styleCheck'], $style) ? 0 : $_POST['styleCheck'];
                    if (($_POST['styleCheck'] || intval($picture_id)) && ($_POST['change_psid'] || $_POST['change_style']))
                        $this->setPicStyle($pid, $psid, $style,$_POST);
                    //   ["keywordCheck"] => array(3) {
                    //    [0] => string(1) "1"
                    //    [1] => string(3) "123"
                    //    [2] => string(3) "229"
                    //  }
                    //  ["keywords"] => string(9) "1,123,229"
                    $keyword = $_POST['keywords'] ? explode(',', $_POST['keywords']) : '';
                    $keyword = array_unique($keyword);
                    if ($keyword) {
                        foreach ($keyword as $k => $v) {
                            if (in_array($v, array(145, 146, 147, 148, 149, 159)) || $v == 0) {
                                unset($keyword[$k]);
                            }
                        }
                    }
                    if ($_POST['keywordCheck'] || intval($picture_id) && ($_POST['change_pkid'] || $_POST['change_keyword']))
                        $this->setPicKeyword($pid, $_POST['pkid'], $keyword);
                    //图片搜索表处理
                    $this->setSearchPicture($pid);
                }
                //exit('<script>self.parent.main.location.reload()</script>');
                //exit('<script>self.parent.main.closeBox();</script>');
                //成功提示
                $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('分类成功!');
            }
        } else {
            $info = $this->modelP->relation(array('SysUser','style','fashion','material','color','keyword'))->where(array('id' => $picture_id))->find();
            //dump($info);exit();
            $description = $this->model_picture_extend->where(array('picture_id' => $picture_id))->find();
            $info['description'] = $description['description'];
            //dump($info);exit();
            //echo $this->modelP->getlastsql();exit('#');
            //$info['big_picture_url'] = $info['big_picture_url'] ? show_pic_path($info['big_picture_url']) : '';
            $type = $_REQUEST['type'];
            if ($type) {
                //區域
                if ($type == 'area') {
                    if (in_array('2', $this->config) || in_array('2', $this->configS))
                        $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
                    $str = '<option value="">区域选择</option>';
                    //区域格式化
                    $areaOption = $this->getAreaOption($info['area_no']);
                    exit($str . $areaOption);
                }
                //品牌
                else if ($type == 'brand') {
                    $str = '<option value="">品牌选择</option>';
                    if (in_array('3', $this->config) || in_array('3', $this->configS))
                        $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
                    if ($this->brands) {
                        foreach ($this->brands as $key => $val) {
                            $c = $info['brand_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //設計師
                else if ($type == 'designer') {
                    $str = '<option value="">設計師选择</option>';
                    if (in_array('4', $this->config) || in_array('4', $this->configS))
                        $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
                    if ($this->designers) {
                        foreach ($this->designers as $key => $val) {
                            $c = $info['designer_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //書名
                else if ($type == 'book') {
                    $str = '<option value="">書名选择</option>';
                    if (in_array('5', $this->config) || in_array('5', $this->configS))
                        $this->books = F('bookList','',C('DATA_CACHE_PATH'));
                    if ($this->books) {
                        foreach ($this->books as $key => $val) {
                            $c = $info['book_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
            }
            //季度
            if (in_array('1', $this->config) || in_array('1', $this->configS))
                $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
            //color
            if (in_array('6', $this->config) || in_array('6', $this->configS))
                $this->colors = F('colorList','',C('DATA_CACHE_PATH'));
            //style
            if (in_array('7', $this->config) || in_array('7', $this->configS))
                $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
            //fashion
            if (in_array('8', $this->config) || in_array('8', $this->configS))
                $this->fashions = F('fashionList','',C('DATA_CACHE_PATH'));
                $this->cidfashions = get_cid_fashions($this->fashions, 22);
            //pattern
            if (in_array('9', $this->config) || in_array('9', $this->configS))
                $this->patterns = F('patternList','',C('DATA_CACHE_PATH'));
            //acc
            if (in_array('10', $this->config) || in_array('10', $this->configS))
                $this->accs = F('accList','',C('DATA_CACHE_PATH'));
            //material
            if (in_array('11', $this->config) || in_array('11', $this->configS))
                $this->materials = F('materialList','',C('DATA_CACHE_PATH'));
            //detail
            if (in_array('12', $this->config) || in_array('12', $this->configS))
                $this->details = F('detailList','',C('DATA_CACHE_PATH'));
            //关键词
            $this->keywords = F('keywordList','',C('DATA_CACHE_PATH'));
            
            if ($info['sort_id']) {
                $tmp = array();
                foreach ($info['sort_id'] as $key => $val) {
                    $tmp[] = $val['sort_id'];
                }
                $info['sort_id'] = $tmp;
            }
            if (empty($info['sort_id'])) {
                $info['sort_id'] = array($info['sort_id']);
            }
            if ($info['special_column_id']) {
                $tmp = array();
                foreach ($info['special_column_id'] as $key => $val) {
                    $tmp[] = $val['special_column_id'];
                }
                $info['special_column_id'] = $tmp;
            }
            if (empty($info['special_column_id'])) {
                $info['special_column_id'] = array($info['special_column_id']);
            }
            if ($info['acc']) {
                $tmp = array();
                foreach ($info['acc'] as $key => $val) {
                    if ($val['acc_id']) {
                        $tmp[] = $val['acc_id'];
                    }
                }
                $info['acc'] = $tmp;
            }
            if ($info['color']) {
                $tmp = array();
                foreach ($info['color'] as $key => $val) {
                    if ($val['color_id'] > 0) {
                        $tmp[] = $val['color_id'];
                    }
                }
                $info['color'] = $tmp;
            }
            if ($info['fashion']) {
                $tmp = array();
                foreach ($info['fashion'] as $key => $val) {
                    if ($val['fashion_id'] > 0) {
                        $tmp[] = $val['fashion_id'];
                    }
                }
                $info['fashion'] = $tmp;
            }
            if ($info['material']) {
                $tmp = array();
                foreach ($info['material'] as $key => $val) {
                    $tmp[] = $val['material_id'];
                }
                $info['material'] = $tmp;
            }
            if ($info['pattern']) {
                $tmp = array();
                foreach ($info['pattern'] as $key => $val) {
                    if ($val['pattern_no'] > 0) {
                        $tmp[] = $val['pattern_no'];
                    }
                }
               
            } 
            $info['pattern'] = $tmp;
            $patternIds = $tmp ? implode(',', $info['pattern']) : '0';
            $this->assign('patternIds', $patternIds);
            if ($info['style']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['style'] as $key => $val) {
                    if ($val['style_id'] > 0) {
                        $tmp[] = $val['style_id'];
                        $tmpT[] = $this->styles[$val['style_id']]['name'];
                    }
                }
                
            }
            $info['style_id'] = $tmp;
            $styleIds = $tmp ? implode(',', $info['style_id']) : '';
            $ajaxStyleIds = $tmp ? implode(',', $info['style_id']) : '0';
            $this->assign('styleIds', $styleIds);
            $this->assign('ajaxStyleIds', $ajaxStyleIds);
            $this->assign('styleText', implode(',', array_unique($tmpT)));
            //dump($info);
            if ($info['keyword']) {
                $tmpk = array();
                $tmpkT = array();
                foreach ($info['keyword'] as $key => $val) {
                    if ($val['keyword_id'] > 0) {
                        $tmpk[] = $val['keyword_id'];
                        $tmpkT[] = $this->keywords[$val['keyword_id']]['name'];
                    }
                }
                
            }
            $info['keyword'] = array_unique($tmpk);
            $keywordIds = $info['keyword'] ? implode(',', $info['keyword']) : '';
            $ajaxKeywordIds = $info['keyword'] ? implode(',', $info['keyword']) : '0';
            $this->assign('keywordIds', $keywordIds);
            $this->assign('ajaxKeywordIds', $ajaxKeywordIds);
            $this->assign('keywordText', implode(',', array_unique($tmpkT)));
            //款式分级处理
            if ($this->styles) {
                foreach ($this->styles as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        if ( $val['type'] == 1) {$styleTmpUp[$key] = $val;}
                        if ( $val['type'] == 2) {$styleTmpDown[$key] = $val;}
                        if ( $val['type'] == 3) {$styleTmpNy[$key] = $val;}
                        if ( $val['type'] == 0) {$styleTmpOther[$key] = $val;}
                        //$styleTmp[$key] = $val;
                        if (in_array($val['no'], $info['style'])) {
                            $public = A('Public');
                            $styleHtml = $public->getStyleByAjax($styleIds, $val['no'], 'yes');
                        }
                    }
                }
            }
            $this->assign('styleHtml', $styleHtml);
            $this->assign('stylesUp', $styleTmpUp);
            $this->assign('stylesDown', $styleTmpDown);
            $this->assign('stylesOther', $styleTmpOther);
            $this->assign('styleTmpNy', $styleTmpNy);
            //$this->assign('styles', $styleTmp);
            //print_r($styleTmp);
            //关键词分级
            if ($this->keywords) {
                foreach ($this->keywords as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $keywordTmp[$key] = $val;
                        if (in_array($val['id'], $info['keyword'])) {
                            $public = A('Public');
                            $keywordHtml = $public->getKeywordByAjax($keywordIds, $val['id'], 'yes');
                        }
                    }
                }
                
            }
            $this->assign('keywordHtml', $keywordHtml);
            $this->assign('keywords', $keywordTmp);
            
            if($info['fashion']){
                $fashion = $info['fashion']['0'];
                $this->assign('fashion_checked_id', $fashion);
            }
            if($info['material']){
                $material = $info['material']['0']['material_id'];
                $this->assign('material_checked_id', $material);
            }
            
            //图案分级处理
            if ($this->patterns) {
                foreach ($this->patterns as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $patternTmp[$key] = $val;
                        if (in_array($val['no'], $info['pattern'])) {
                            $public = A('Public');
                            $patternHtml = $public->getPatternByAjax($patternIds, $val['no'], true, 'yes');
                        }
                    }
                }
                
            }
            $paternHtmlArr = explode('::', $patternHtml);
            $this->assign('patternHtml', $paternHtmlArr[0]);
            $this->assign('subPatternHtml', $paternHtmlArr[1]);
            $this->assign('patterns', $patternTmp);

            if ($info['area_no']) {
                $model = D('AttributeArea');
                $row = $model->where(array('no' => $info['area_no']))->find();
                $info['areaStr'] = "<option value='{$row['no']}' selected>{$row['name']}</option>";
            }
            if ($info['brand_id']) {
                $model = D('AttributeBrand');
                $row = $model->where(array('id' => $info['brand_id']))->find();
                $info['brand_name'] =$row['name'];
            }
            if ($info['designer_id']) {
                $model = D('AttributeDesigner');
                $row = $model->where(array('id' => $info['designer_id']))->find();
                $info['designerStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
            if ($info['book_id']) {
                $model = D('AttributeBook');
                $row = $model->where(array('id' => $info['book_id']))->find();
                $info['bookStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
        }
        //echo '<pre>';
        $this->assign('info', $info);
        $this->assign('subject_id', $subject_id);
        $this->assign('picture_id', $picture_id);
        $this->assign('ids', $ids);
        $this->assign('listMenus', '');
        $this->display('Subject/fashionstyle_underwear_picture_category');
    }
    
    public function detailList() {
        $field = $this->m['subsidiary_original'].'.id,'.$this->m['subsidiary_original'].'.picture_id,big_picture_url,small_picture_url,'.$this->m['subsidiary_original'].'.child_menu_id,'.$this->m['subsidiary_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,is_publish,add_user_id,publish_time,add_time';
        $map[$this->m['subsidiary_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_detailList($field, $map);
		$this->display('Subject/fashionstyle_detail_list');
	}
    
    protected function _detailList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } } 
            $this->error('参数错误！');
        $action_link = array();
        $themeI = $this->modelT->where(array('menu_id' => $this->cid))->field('title,picture_count')->find();
        //$currentName = '-主题:' . $themeI['title'];
        $this->assign('currentName', $currentName . '-细节列表');
        $action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加细节图片','url':'__URL__/detailAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $this->assign('action_link', $action_link);
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['subsidiary_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $detail_id = intval($_REQUEST['detail_id']);
        if ($detail_id)
            $map['detail_id'] = $detail_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'publish_time';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
         //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_subsidiary_sort_original'].' sus ON sus.picture_id='.$this->m['subsidiary_original'].'.id';
            if ( $sort_id == 3 ){
                $map['sus.sort_id'] = array('egt',$sort_id);
            } else {
                $map['sus.sort_id'] = $sort_id;
            }
            $field .=",sus.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_subsidiary_column_original'].' suc ON suc.picture_id='.$this->m['subsidiary_original'].'.id';
            if($column_id == 6){
                //$map['suc.special_column_id'] = array('exp','is null');
                $map['suc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['suc.special_column_id'] = $column_id;
            }
            $field .=",suc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_subsidiary_style_original'].' pss ON pss.picture_id='.$this->m['subsidiary_original'].'.id';
			$map['pss.style_id'] = $style_id;
            $field .=",pss.style_id";
        }
        
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数  主题表保存有图片数量字段 field:picture_count,前提是“$subject_id”不为空才能调用这个字段 暂时注销

        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        $count = $moldel->getCount("{$this->m['subsidiary']}", $map, $join);
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelS->relation(array('style','sort_id','special_column_id','detail_id'))->where($map)->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelP->getlastsql();exit;
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'] ;
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    
                    /*
                    ["detail"] => array(1) {
                      [0] => array(1) {
                        ["detail_id"] => string(2) "18"
                      }
                    }*/
                    $voList[$key]['detailStr'] = '';
                    if ($val['detail_id']) {
                        foreach ($val['detail_id'] as $k => $v) {
                            if ($this->details[$v['detail_id']]['name'])
                                $voList[$key]['detailStr'] .= $this->details[$v['detail_id']]['name'];
                        }
                    }
                    $voList[$key]['style'] = '';
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            if ($this->styles[$v['style_id']]['name'])
                                $voList[$key]['style'] .= $this->styles[$v['style_id']]['name']." ";
                        }
                    }
                    //echo '<pre>';
                    $voList[$key]['columnStr'] = implode(',', $column);
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/detailCategory/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //dump($this->styles);
            //模板赋值显示
            $this->assign('list', $voList);
            //dump($voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }
    
    protected function setDetailColor($id, $info) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $this->delDetailColor($id);
        $model = M("RefStyleSubsidiaryColor']}");
        $model->picture_id = $id;
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->color_id = $val;
                $model->add();
            }
        }
    }
    protected function delDetailColor($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("RefStyleSubsidiaryColor");
        $model->where($where)->delete();
    }
    
    protected function setDetailFashion($id, $info) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        $this->delPicFashion($id);
        $model = M("RefStyleSubsidiaryFashion}");
        $model->picture_id = $id;
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $model->fashion_id = $val;
                $model->add();
            }
        }
    }

    protected function delDetailFashion($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("RefStyleSubsidiaryFashion}");
        $model->where($where)->delete();
    }
    
	public function detailCategory() {
		$this->_detailCategory();
	}
    
    public function _detailCategory() {
        $picture_id = intval($_REQUEST['picture_id']);
        $this->assign('picture_id', $picture_id);
        $ids = $_REQUEST['ids'];
        if ($_POST) {
            parent::setConfig();
            //dump($_POST);exit();
            $idArr = explode(',', $ids);
            if ($idArr) {
                $info = array();
                //$user_auth = Cookie::get(C('USER_AUTH_KEY'));
                //$info['add_user_id'] = intval($user_auth);
                $picture_id = $_REQUEST['picture_id'];
                if ((intval($_REQUEST['child_menu_id']) || intval($picture_id)) && $_POST['change_child_menu_id'])
                    $info['child_menu_id'] = intval($_REQUEST['child_menu_id']);
                if ((intval($_REQUEST['season_id']) || intval($picture_id)) && $_POST['change_season_id'])
                    $info['season_id'] = intval($_REQUEST['season_id']);
                if ((intval($_REQUEST['designer_id']) || intval($picture_id)) && $_POST['change_designer_id'])
                    $info['designer_id'] = intval($_REQUEST['designer_id']);
                if ((intval($_REQUEST['brand_id']) || intval($picture_id)) && $_POST['change_brand_id'])
                    $info['brand_id'] = intval($_REQUEST['brand_id']);
                if ((intval($_REQUEST['book_id']) || intval($picture_id)) && $_POST['change_book_id'])
                    $info['book_id'] = intval($_REQUEST['book_id']);
                if ((intval($_REQUEST['area_id']) || intval($picture_id)) && $_POST['change_area_id'])
                    $info['area_no'] = intval($_REQUEST['area_id']);
                if ((intval($_REQUEST['detail_id']) || intval($picture_id)) && $_POST['change_detail_id'])
                    $info['detail_id'] = intval($_REQUEST['detail_id']);
                if (($_POST['sort_id'] || intval($picture_id)) && $_POST['change_sort'])
                    $info['sort_id'] = intval($_REQUEST['sort_id']);
                if (($_POST['special_column_id'] || intval($picture_id)) && $_POST['change_column'])
                    $info['special_column_id'] = intval($_REQUEST['special_column_id']);
                //dump($_POST);exit;
                foreach ($idArr as $pid) {
                    $pid = intval($pid);
                    $this->setSift();
                    //款式
                    $sid = $_POST['styleCheck']['0'] ? $_POST['styleCheck']['0'] : '';
                    if (($_POST['styleCheck'] || intval($picture_id)) && $_POST['change_style'])
                        $this->setDetailoneStyle($pid,$sid);
                    //细节
                    //$detail = $_POST['details'] ? explode(',', $_POST['details']) : '';
                    if ($_POST['detailCheck'] || $_POST['change_detail'])
                        $this->setDetailDetail($pid, $_POST['detailCheck'], $_POST);
                }
                
                //exit('<script>self.parent.main.location.reload()</script>');
                //exit('<script>self.parent.main.closeBox();</script>');
                //成功提示
                $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.closeBox()');
                $this->success('分类成功!');
            }
        } else {
            $info = $this->modelS->relation(array('SysUser','style','detail_id'))->where(array('menu_id' => $this->cid, 'id' => $picture_id))->find();
            //dump($info);exit();
            //echo $this->modelP->getlastsql();exit();
            //$info['big_picture_url'] = $info['big_picture_url'] ? show_pic_path($info['big_picture_url']) : '';
            $type = $_REQUEST['type'];
            if ($type) {
                //區域
                if ($type == 'area') {
                    if (in_array('2', $this->config) || in_array('2', $this->configS))
                        $this->areas = F('areaList','',C('DATA_CACHE_PATH'));
                    $str = '<option value="">区域选择</option>';
                    //区域格式化
                    $areaOption = $this->getAreaOption($info['area_no']);
                    exit($str . $areaOption);
                }
                //品牌
                else if ($type == 'brand') {
                    $str = '<option value="">品牌选择</option>';
                    if (in_array('3', $this->config) || in_array('3', $this->configS))
                        $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
                    if ($this->brands) {
                        foreach ($this->brands as $key => $val) {
                            $c = $info['brand_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //設計師
                else if ($type == 'designer') {
                    $str = '<option value="">設計師选择</option>';
                    if (in_array('4', $this->config) || in_array('4', $this->configS))
                        $this->designers = F('designerList','',C('DATA_CACHE_PATH'));
                    if ($this->designers) {
                        foreach ($this->designers as $key => $val) {
                            $c = $info['designer_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
                //書名
                else if ($type == 'book') {
                    $str = '<option value="">書名选择</option>';
                    if (in_array('5', $this->config) || in_array('5', $this->configS))
                        $this->books = F('bookList','',C('DATA_CACHE_PATH'));
                    if ($this->books) {
                        foreach ($this->books as $key => $val) {
                            $c = $info['book_id'] == $val['id'] ? 'selected' : '';
                            $str .= "<option value='{$val['id']}' {$c}>{$val['name']}</option>";
                        }
                    }
                    exit($str);
                }
            }
            //季度
            if (in_array('1', $this->config) || in_array('1', $this->configS))
                $this->seasons = F('seasonList','',C('DATA_CACHE_PATH'));
            //color
            if (in_array('6', $this->config) || in_array('6', $this->configS))
                $this->colors = F('colorList','',C('DATA_CACHE_PATH'));
            //style
            if (in_array('7', $this->config) || in_array('7', $this->configS))
                $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
            //fashion
            if (in_array('8', $this->config) || in_array('8', $this->configS))
                $this->fashions = F('fashionList','',C('DATA_CACHE_PATH'));
            //pattern
            if (in_array('9', $this->config) || in_array('9', $this->configS))
                $this->patterns = F('patternList','',C('DATA_CACHE_PATH'));
            //acc
            if (in_array('10', $this->config) || in_array('10', $this->configS))
                 $this->accs = F('accList','',C('DATA_CACHE_PATH'));
            //material
            if (in_array('11', $this->config) || in_array('11', $this->configS))
                $this->materials = F('materialList','',C('DATA_CACHE_PATH'));
            //detail
            if (in_array('12', $this->config) || in_array('12', $this->configS))
                $this->details = F('detailList','',C('DATA_CACHE_PATH'));
            //关键词
            $this->keywords = F('keywordList','',C('DATA_CACHE_PATH'));

            if ($info['sort_id']) {
                $tmp = array();
                foreach ($info['sort_id'] as $key => $val) {
                    $tmp[] = $val['sort_id'];
                }
                $info['sort_id'] = $tmp;
            }
            if (empty($info['sort_id'])) {
                $info['sort_id'] = array($info['sort_id']);
            }
            if ($info['special_column_id']) {
                $tmp = array();
                foreach ($info['special_column_id'] as $key => $val) {
                    $tmp[] = $val['special_column_id'];
                }
                $info['special_column_id'] = $tmp;
            }
            if (empty($info['special_column_id'])) {
                $info['special_column_id'] = array($info['special_column_id']);
            }
            if ($info['acc']) {
                $tmp = array();
                foreach ($info['acc'] as $key => $val) {
                    if ($val['acc_id']) {
                        $tmp[] = $val['acc_id'];
                    }
                }
                $info['acc'] = $tmp;
            }
            if ($info['color']) {
                $tmp = array();
                foreach ($info['color'] as $key => $val) {
                    if ($val['color_id'] > 0) {
                        $tmp[] = $val['color_id'];
                    }
                }
                $info['color'] = $tmp;
            }
            if ($info['fashion']) {
                $tmp = array();
                foreach ($info['fashion'] as $key => $val) {
                    if ($val['fashion_id'] > 0) {
                        $tmp[] = $val['fashion_id'];
                    }
                }
                $info['fashion'] = $tmp;
            }
            if ($info['material']) {
                $tmp = array();
                foreach ($info['material'] as $key => $val) {
                    $tmp[] = $val['material_id'];
                }
                $info['material'] = $tmp;
            }
            if ($info['pattern']) {
                $tmp = array();
                foreach ($info['pattern'] as $key => $val) {
                    if ($val['pattern_no'] > 0) {
                        $tmp[] = $val['pattern_no'];
                    }
                }
                $info['pattern'] = $tmp;
            }
            $patternIds = $tmp ? implode(',', $info['pattern']) : '0';
            $this->assign('patternIds', $patternIds);
            
            if ($info['style']) {
                $tmp = array();
                $tmpdT = array();
                foreach ($info['style'] as $key => $val) {
                    if ($val['style_id'] > 0) {
                        $tmp[] = $val['style_id'];
                        $tmpdT[] = $this->styles[$val['style_id']]['name'];
                    }
                }
                $info['style_id'] = $tmp;
            }
            $styleIds = $tmp ? implode(',', $info['style_id']) : '';
            $this->assign('styleIds', $styleIds);
            $this->assign('styleText', implode(',', array_unique($tmpdT)));
            
            if ($info['detail_id']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['detail_id'] as $key => $val) {
                    if ($val['detail_id'] > 0) {
                        $tmp[] = $val['detail_id'];
                        $tmpT[] = $this->details[$val['detail_id']]['name'];
                    }
                }
                $info['detail_id'] = array_unique($tmp);
            }
            $detail_ids = $info['detail_id'] ? implode(',', $info['detail_id']) : '0';
            $this->assign('detailIds', $detail_ids);
            $this->assign('detailText', implode(',', array_unique($tmpT)));
            //款式分级处理
            if ($this->styles) {
                foreach ($this->styles as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        if ( $val['type'] == 1) {$styleTmpUp[$key] = $val;}
                        if ( $val['type'] == 2) {$styleTmpDown[$key] = $val;}
                        if ( $val['type'] == 3) {$styleTmpNy[$key] = $val;}
                        if ( $val['type'] == 0) {$styleTmpOther[$key] = $val;}
                        $styleTmp[$key] = $val;
                        if (in_array($val['no'], $info['style'])) {
                            $public = A('Public');
                            $styleHtml = $public->getStyleByAjax($styleIds, $val['no'], 'yes');
                        }
                    }
                }
            }
            $this->assign('styleHtml', $styleHtml);
            $this->assign('stylesUp', $styleTmpUp);
            $this->assign('stylesDown', $styleTmpDown);
            $this->assign('stylesOther', $styleTmpOther);
            $this->assign('styleTmpNy', $styleTmpNy);
            $this->assign('styles', $styleTmp);
            //print_r($styleTmp);
            //关键词分级
            if ($this->keywords) {
                foreach ($this->keywords as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $keywordTmp[$key] = $val;
                        if (in_array($val['id'], $info['keyword'])) {
                            $public = A('Public');
                            $keywordHtml = $public->getKeywordByAjax($keywordIds, $val['id'], 'yes');
                        }
                    }
                }
            }
            $this->assign('keywordHtml', $keywordHtml);
            $this->assign('keywords', $keywordTmp);

            //图案分级处理
            if ($this->patterns) {
                foreach ($this->patterns as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        $patternTmp[$key] = $val;
                        if (in_array($val['no'], $info['pattern'])) {
                            $public = A('Public');
                            $patternHtml = $public->getPatternByAjax($patternIds, $val['no'], true, 'yes');
                        }
                    }
                }
            }
            $paternHtmlArr = explode('::', $patternHtml);
            $this->assign('patternHtml', $paternHtmlArr[0]);
            $this->assign('subPatternHtml', $paternHtmlArr[1]);
            $this->assign('patterns', $patternTmp);

            if ($info['area_no']) {
                $model = D('AttributeArea');
                $row = $model->where(array('no' => $info['area_no']))->find();
                $info['areaStr'] = "<option value='{$row['no']}' selected>{$row['name']}</option>";
            }
            if ($info['brand_id']) {
                $model = D('AttributeBrand');
                $row = $model->where(array('id' => $info['brand_id']))->find();
                $info['brandStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
            if ($info['designer_id']) {
                $model = D('AttributeDesigner');
                $row = $model->where(array('id' => $info['designer_id']))->find();
                $info['designerStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
            if ($info['book_id']) {
                $model = D('AttributeBook');
                $row = $model->where(array('id' => $info['book_id']))->find();
                $info['bookStr'] = "<option value='{$row['id']}' selected>{$row['name']}</option>";
            }
        }
        //echo '<pre>';
        //dump($info);
        $this->assign('info', $info);
        $this->assign('subject_id', $subject_id);
        $this->assign('picture_id', $picture_id);
        $this->assign('ids', $ids);
        $this->assign('listMenus', '');
        $this->display('Subject/fashionstyle_detail_category');
    }
    
    public function detailAdd() {
		parent::picAdd('1');
        $this->display('Subject/fashionstyle_detail_info');
	}

    /**
     * 分类图片
     */
    public function picTmpBatch() {
        $subject_id = intval($_REQUEST['subject_id']);
        $acttype = trim($_REQUEST['acttype']);
        $batch_id = $_REQUEST['batch_id'];//全选
        if (empty($acttype))
            $this->error('对不起，请选择操作类型！');
        $model = D('SharePicturesTmp');
        if ($acttype == 'remove') {
            foreach ($batch_id as $id) {
                $id = intval($id);
                $row = $model->field('url AS img_path')->find($id);
                @unlink($_SERVER['DOCUMENT_ROOT'] . '/' . C('IMG_ROOT') . $row["img_path"]);
                $model->delete($id);
            }
            $this->success('删除成功！');
        } else {
            $listArr = $this->picTmpFormat();
            if ($listArr) {
                foreach ($listArr as $key => $val) {
                    if (!$val["s"]) {
                        $this->error($val["img_name"] . ' 的小图片似乎没有吧？');
                    } else {
                        $page_no = intval(substr($val["img_name"], 1, 4));
                        $picInfo = array();
                        $picInfo["small_picture_url"] = $val["s"]["img_path"];
                        $picInfo["big_picture_url"] = $val["img_path"];
                        $picInfo["add_user_id"] = $val["add_user_id"];
                        $picInfo["add_time"] = $val["add_time"];
                        $picInfo["publish_time"] = $val["add_time"];
                        $picInfo["menu_id"] = $val["menu_id"];
                        $picInfo["subject_id"] = $subject_id;
                        $picInfo['child_menu_id'] = $val['child_menu_id'];
                        $picInfo["area_no"] = $val["area_no"];
                        $picInfo["designer_id"] = $val["designer_id"];
                        $picInfo["brand_id"] = $val["brand_id"];
                        $picInfo["book_id"] = $val["book_id"];
                        $picInfo["season_id"] = $val["season_id"];
                        $picInfo["page_no"] = $page_no;
                        $picInfo["is_publish"] = $val["is_publish"];
                        $picInfo["publish_time"] = $val["publish_time"];
                        //$picInfo['sort_id'] = $val['sort_id'];
                        //$picInfo['special_column_id'] = $val['column_id'];
                        //echo '<pre>';
                        //
                        $pid = $this->modelP->add($picInfo);
                        //echo $this->modelP->getLastSql();exit();
                        //echo $pid;exit();
                        $this->setSift();
                        //$this->setSubjectPicture($subject_id, $pid);
                        $this->setPicExtend($pid, $val);
                        $this->setPicSort($pid,$subject_id,$val['sort_id']);
                        $this->setPicColumn($pid, $subject_id,$val['column_id']);
                        $this->setPicStyles($pid, $subject_id,$val['style_id']);
                        if ($pid && $type != 'detail') {
                            //插入附图
                            if ($val["f"]) {
                                foreach ($val["f"] as $k => $v) {
                                    $s_page_no = intval(substr($val["img_name"], 6, 8));
                                    if (!$v["s"]) {
                                        $this->error($v["img_name"] . ' 的小图片似乎没有吧？');
                                    } else {
                                        $aInfo = array();
                                        $aInfo["menu_id"] = $val["menu_id"];
                                        $aInfo['child_menu_id'] = $val['child_menu_id'];
                                        $aInfo["picture_id"] = $pid;
                                        $aInfo["add_user_id"] = $v["add_user_id"];
                                        $aInfo["small_picture_url"] = $v["s"]["img_path"];
                                        $aInfo["big_picture_url"] = $v["img_path"];
                                        $aInfo["area_no"] = $v["area_no"];
                                        $aInfo["designer_id"] = $v["designer_id"];
                                        $aInfo["brand_id"] = $v["brand_id"];
                                        $aInfo["book_id"] = $v["book_id"];
                                        $aInfo["season_id"] = $v["season_id"];
                                        $aInfo["page_no"] = $s_page_no;
                                        $aInfo["is_publish"] = $v["is_publish"];
                                        $aInfo["publish_time"] = $v["publish_time"];
                                        $s_pic = $this->modelS->add($aInfo);
                                        $this->setDetailSort($s_pic, $val);
                                        $this->setDetailSpecialColumn($s_pic, $val);
                                        $this->setDetailStyle($s_pic, $val);
                                    }
                                }
                            }
                        }
                        //图片搜索表处理
                        $this->setSearchPicture($pid);
                        if ($type != 'detail' && $subject_id > 0) {
                            $this->setPictureCount($subject_id,'add');
                        }
                    }
                }
            }
            $model->where(array('menu_id' => $this->cid, 'subject_id' => $subject_id))->delete();
            //成功提示
            $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
            $this->success('操作成功!');
        }
    }
    
    public function detailTmpBatch() {
        $subject_id = intval($_REQUEST['subject_id']);
        $acttype = trim($_REQUEST['acttype']);
        $batch_id = $_REQUEST['batch_id'];//全选
        if (empty($acttype))
            $this->error('对不起，请选择操作类型！');
        $model = D('SharePicturesTmp');
        if ($acttype == 'remove') {
            foreach ($batch_id as $id) {
                $id = intval($id);
                $row = $model->field('url AS img_path')->find($id);
                @unlink($_SERVER['DOCUMENT_ROOT'] . '/' . C('IMG_ROOT') . $row["img_path"]);
                $model->delete($id);
            }
            $this->success('删除成功！');
        } else {
            $listArr = $this->detailTmpFormat();
            if ($listArr) {
                foreach ($listArr as $key => $val) {
                    if (!$val["s"]) {
                        $this->error($val["img_name"] . ' 的小图片似乎没有吧？');
                    } else {
                        $page_no = intval(substr($val["img_name"], 1, 4));
                        $picInfo = array();
                          $picInfo["small_picture_url"] = $val["s"]["img_path"];
                          $picInfo["big_picture_url"] = $val["img_path"];
                          $picInfo["add_user_id"] = $val["add_user_id"];
                          $picInfo["add_time"] = $val["add_time"];
                          $picInfo["menu_id"] = $val["menu_id"];
                          $picInfo['child_menu_id'] = $val['child_menu_id'];
                        $picInfo["area_no"] = $val["area_no"];
                        $picInfo["designer_id"] = $val["designer_id"];
                        $picInfo["brand_id"] = $val["brand_id"];
                        $picInfo["book_id"] = $val["book_id"];
                        $picInfo["season_id"] = $val["season_id"];
                        $picInfo["page_no"] = $page_no;
                        $picInfo["is_publish"] = $val["is_publish"];
                        $picInfo["publish_time"] = $val["publish_time"];
                        //$picInfo['sort_id'] = $val['sort_id'];
                        //$picInfo['special_column_id'] = $val['column_id'];
                        //dump($picInfo);
                        $pid = $this->modelS->add($picInfo);
                        //echo $this->modelS->getLastSql();echo "<br>";echo $pid;echo "<br>";
                        $this->setSift();
                        $this->setDetailSort($pid, $val);
                        $this->setDetailSpecialColumn($pid, $val);
                        $this->setDetailStyle($pid, $val);
                    }
                }
            }
            $model->where(array('menu_id' => $this->cid, 'subject_id' => $subject_id))->delete();
            //成功提示
            $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
            $this->success('操作成功!');
        }
    }


    protected function setDetailoneStyle($pid, $arr, $child_menu_id = null, $cat = null) {
		if (empty($pid)) return false;
        $this->delDetailStyle($pid);
        $model = M("{$this->m['ref_picture_subsidiary_style']}");
        $model->picture_id = $pid;
        $model->style_id = $arr;
        $model->menu_id = $this->cid;
        $model->child_menu_id = !empty($arr['child_menu_id']) ? $arr['child_menu_id'] : 0;
        $model->add();

	}
    protected function delDetailStyle($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_subsidiary_style']}");
        $model->where($where)->delete();
    }
    
    protected function setDetailSort($pid, $arr) {
		if (empty($pid)) return false;
        $this->delDetailSort($pid);
        // 取主题的sortid
        $model = M("RefStyleSubsidiarySort");
        $model->picture_id = $pid;
        $model->sort_id = $arr['sort_id'];
        $model->menu_id = $this->cid;
        $model->child_menu_id = !empty($arr['child_menu_id']) ? $arr['child_menu_id'] : 0;
        $model->add();
	}
	
    protected function delDetailSort($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("RefStyleSubsidiarySort");
		$model->where($where)->delete();
	}
    
    protected function setDetailSpecialColumn($pid, $arr) {
		if (empty($pid)) return false;
        $this->delDetailSpecialColumn($pid);
        // 取主题的sortid
        $model = M("RefStyleSubsidiarySpecialColumn");
        $model->picture_id = $pid;
        $model->special_column_id = $arr['column_id'];
        $model->menu_id = $this->cid;
        $model->child_menu_id = !empty($arr['child_menu_id']) ? $arr['child_menu_id'] : 0;
        $model->add();
	}
	
    protected function delDetailSpecialColumn($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("RefStyleSubsidiarySpecialColumn");
		$model->where($where)->delete();
	}
    
    protected function detailTmpFormat() {
        $where = array();
        $user_auth = Cookie::get(C('USER_AUTH_KEY'));
        $where['add_user_id'] = intval($user_auth);
        $where['menu_id'] = $this->cid;
        $where['subject_id'] = intval($_REQUEST['subject_id']);
        $model = D('SharePicturesTmp');
        $field = 'id,source_file_name AS img_name,url AS img_path,is_publish,publish_time,add_user_id,add_time,subject_id,menu_id,child_menu_id,season_id,area_no,brand_id,designer_id,book_id,sort_id,column_id,style_id';
        $rows = $model->field($field)->where($where)->order(array('source_file_name' => 'ASC'))->findAll();
        //echo $model->getLastSql();
        $listArr = array();
        if ($rows) {
            foreach ($rows as $key => $val) {
                $rows[$key]["img"] = show_pic_path($val["img_path"]);
            }
            foreach ($rows as $k => $v) {
                if (strlen($v["img_name"]) == 4) {//取大图
                    $listArr[$v["img_name"]] = $v;
                    $zip = array();
                    foreach ($rows as $ke => $va) {
                        $t_n = explode('_', $va["img_name"]);
                        if ($v["img_name"] == $t_n[0]) {
                            if (isset($t_n[1])) {
                                if ($t_n[1] == 'ai') {
                                    $zip['ai'] = $va['img_path'];
                                }
                                if ($t_n[1] == 'cdr') {
                                    $zip['cdr'] = $va['img_path'];
                                }
                                if ($t_n[1] == 'psd') {
                                    $zip['psd'] = $va['img_path'];
                                }
                            }
                        }
                    }
                    $listArr[$v['img_name']]['zip'] = $zip ? serialize($zip) : '';
                }
                $t_n = explode('_', $v["img_name"]);
                if (in_array($t_n[1], array('ai', 'cdr', 'psd'))) {
                    continue;
                }
                if (strlen($v["img_name"]) == 5) {//取大图的缩略图
                    $listArr[substr($v["img_name"], 0, 4)]["s"] = $v;
                }
                if (strlen($v["img_name"]) == 8) {//取副图
                    $listArr[substr($v["img_name"], 0, 4)]["f"][$v["img_name"]] = $v;
                }
                if (strlen($v["img_name"]) == 9) {//取副图的缩略图
                    $listArr[substr($v["img_name"], 0, 4)]["f"][substr($v["img_name"], 0, 8)]["s"] = $v;
                }
            }
        }
        return $listArr;
    }
    
    public function detailPicTmpList() {
        $listArr = $this->picTmpFormat();
        $this->assign('listArr', $listArr);
        $this->assign('subject_id', intval($_REQUEST['subject_id']));
        $action_link[] = array('text' => '返回上传', 'href' => Cookie::get('_currentTmpPicUrl_'));
        $this->assign('action_link', $action_link);
        $this->assign('listMenus', '');
        $this->display('Subject/detail_tmp_list');
    }
    
    protected function setDetailDetail($id, $did, $menus){
        if (empty($id))
            return false;
        $this->delDetailDetail($id);
        $model = M("{$this->m['ref_picture_subsidiary_detail']}");
        $model->picture_id = $id;
        if(is_array($did) && !empty($did)){
            foreach ($did as $key => $val) {
                $model->detail_id = $val;
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($menus['child_menu_id']) ? $menus['child_menu_id'] : 0;
                if($model->add() !== false){
                    $this->setSubDetail($id);
                }
            }
        }elseif(!empty($did)){
            //一级
            $model->detail_id = $did;
            $model->menu_id = $this->cid;
            $model->child_menu_id = $menus['child_menu_id'];
            if($model->add() !== false){
                $this->setSubDetail($id);
            }
        }
    }
    
    protected function setSubDetail($id){
        if( empty ($id) ) {
            return false;
        }
        $save['is_detail'] = 1;
        $this->modelS->where(array('id'=>$id))->save($save);
    }
    
    protected function delDetailDetail($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_subsidiary_detail']}");
        $model->where($where)->delete();
    }
    
    public function pictureSubsidiary(){
        parent::setConfig();
        $picture_id = intval($_REQUEST['pid']);
        if ( empty($picture_id) ) {
            return false;
        }
        
        $action_link[] = array('text' => '返回图片列表', 'href' => Cookie::get('_currentPiclistUrl_'));
        $action_link[] = array('text' => '添加附图', 'href' => "javascript:Box.open({'id':'add','title':'添加附图','url':'__URL__/picSubAdd/picture_id/{$picture_id}','width':'750','height':'500'});");
        $this->assign('action_link', $action_link);
        
        $listRows = '30';
        $where['picture_id'] = $picture_id;
        $where['is_publish'] = array('egt',0);
        $count = $this->modelS->where($where)->count();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            $res_s = $this->modelS->where($where)->relation(array('style','sort_id','special_column_id'))->order('id desc')->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //echo $this->modelS->getLastSql();
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ( isset($res_s) && !empty ($res_s) ) {
                foreach ( $res_s as $key => $val ){
                    $res_s[$key]['add_user_name'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    $res_s[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $res_s[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                    //性别
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $res_s[$key]['sortStr'] = implode(',', $sort);
                    //专栏
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $res_s[$key]['columnStr'] = implode(',', $column);
                    //款式
                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            if ($this->styles[$v['style_id']]['name'])
                                $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    $res_s[$key]['styleStr'] = implode(',', $style);
                    if ($this->seasons)
                        $res_s[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $res_s[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $res_s[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $res_s[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                }
            }
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
            $this->assign('list', $res_s);
        }
        $this->display('Subject/fashion_style_picture_sub_list');
    }
    
    /**
     * 图片上传至临时表
     */
    public function picSubAdd() {
		$this->_picSubAdd();
        $this->display('Subject/fashionstyle_picture_sub_info');
	}
    /**
     * 图片上传至临时表
     */
    protected function _picSubAdd($is_display = null) {
        $this->setConfig();
        $picture_id = intval($_GET['picture_id']);
        if ($picture_id) {
            $info = $this->modelP->relation(array('SysUser','sort_id','special_column_id','style'))->where(array('menu_id' => $this->cid, 'id' => $picture_id))->find();
            //dump($info);exit();
            if ($info['sort_id']) {
                $tmp = array();
                foreach ($info['sort_id'] as $key => $val) {
                    $tmp[] = $val['sort_id'];
                }
                $info['sort_id'] = $tmp;
                if (empty($info['sort_id'])) {
                    $info['sort_id'] = array($info['sort_id']);
                }
            }
            if ($info['special_column_id']) {
                $tmp = array();
                foreach ($info['special_column_id'] as $key => $val) {
                    $tmp[] = $val['special_column_id'];
                }
                $info['special_column_id'] = $tmp;
                if (empty($info['special_column_id'])) {
                    $info['special_column_id'] = array($info['special_column_id']);
                }
            }
            //款式
            $style = '';
            if ($info['style']) {
                foreach ($info['style'] as $k => $v) {
                    $style .= $v['style_id']."+";
                }
            }
            $info['style_ids'] = substr($style, 0 , -1);
            $info['publish_time'] = $info['publish_time'] ? date('Y-m-d H:i:s', $info['publish_time']) : '';
            //dump($info);
        }
        $this->assign('info', $info);
        //区域格式化
        $areaOption = $this->getAreaOption($info['area_no']);
        $this->assign('areaOption', $areaOption);
        $this->assign('subject_id', $picture_id);
        Cookie::set('_currentPicSubTmpPicUrl_', __SELF__);
        $this->assign('listMenus', '');
        $this->assign('user_id', Cookie::get(C('USER_AUTH_KEY')));
    }
    
    public function picSubTmpList() {
        $listArr = $this->picTmpFormat();
        $this->assign('listArr', $listArr);
        $this->assign('subject_id', intval($_REQUEST['subject_id']));
        $action_link[] = array('text' => '返回上传', 'href' => Cookie::get('_currentPicSubTmpPicUrl_'));
        $this->assign('action_link', $action_link);
        $this->assign('listMenus', '');
        $this->display('Subject/pic_sub_tmp_list');
    }
    
    /**
     * 分类图片
     */
    public function picSubTmpBatch() {
        $subject_id = intval($_REQUEST['subject_id']);
        $acttype = trim($_REQUEST['acttype']);
        $batch_id = $_REQUEST['batch_id'];//全选
        if (empty($acttype))
            $this->error('对不起，请选择操作类型！');
        $model = D('SharePicturesTmp');
        if ($acttype == 'remove') {
            foreach ($batch_id as $id) {
                $id = intval($id);
                $row = $model->field('url AS img_path')->find($id);
                @unlink($_SERVER['DOCUMENT_ROOT'] . '/' . C('IMG_ROOT') . $row["img_path"]);
                $model->delete($id);
            }
            $this->success('删除成功！');
        } else {
            $listArr = $this->picTmpFormat();
            if ($listArr) {
                //dump($listArr);exit();
                foreach ($listArr as $key => $value) {
                    if (!$value["f"]) {
                        $this->error('附图似乎没有吧？');
                    } else {
                        foreach ($value["f"] as $k => $val) {
                            //dump($val);exit();
                            if (!$val["s"]) {
                                 $this->error($v["img_name"] . ' 的小图片似乎没有吧？');
                            } else {
                                $page_no = intval(substr($val["img_name"], 6, 8));
                                $picInfo = array();
                                $picInfo["picture_id"] = $subject_id;
                                $picInfo["is_detail"] = 0;
                                $picInfo["small_picture_url"] = $val["s"]["img_path"];
                                $picInfo["big_picture_url"] = $val["img_path"];
                                $picInfo["menu_id"] = $val["menu_id"];
                                $picInfo['child_menu_id'] = $val['child_menu_id'];
                                $picInfo["page_no"] = $page_no;
                                $picInfo["area_no"] = $val["area_no"];
                                $picInfo["season_id"] = $val["season_id"];
                                $picInfo["designer_id"] = $val["designer_id"];
                                $picInfo["brand_id"] = $val["brand_id"];
                                $picInfo["book_id"] = $val["book_id"];
                                $picInfo["is_publish"] = $val["is_publish"];
                                $picInfo["publish_time"] = $val["publish_time"];
                                $picInfo["add_user_id"] = $val["add_user_id"];
                                $picInfo["add_time"] = time();
                                //dump($picInfo);exit();
                                $pid = $this->modelS->add($picInfo);
                                //echo $this->modelS->getLastSql()."<br />";
                            }
                            $this->setDetailSort($pid, $val);
                            $this->setDetailSpecialColumn($pid, $val);
                            $style_arr = $this->getStyleArr($val['style_id']);
                            $this->setDetailStyle($pid, $style_arr,$val['child_menu_id'],1);
                        }
                    }
                }
            }
            $model->where(array('menu_id' => $this->cid, 'subject_id' => $subject_id))->delete();
            //成功提示
            $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
            $this->success('操作成功!');
        }
    }
    
    protected function getStyleArr($str){
        if ( empty ($str) ) {
            return false;
        }
        $style_arr = explode(' ', $str);
        return $style_arr;
    }
    
    protected function setDetailStyle($pid, $arr, $child_menu_id = null, $cat = null) {
		if (empty($pid)) return false;
        $this->delDetailStyle($pid);
        $model = M("{$this->m['ref_picture_subsidiary_style']}");
        if(is_array($arr) && !empty($cat)){
            foreach ($arr as $key => $val) {
                $model->picture_id = $pid;
                $model->style_id = $val;
                $model->menu_id = $this->cid;
                $model->child_menu_id = !empty($child_menu_id) ? $child_menu_id : 0;
                $model->add();
                //echo $model->getLastSql();echo "<br />";
            }
        }else{
            $model->picture_id = $pid;
            $model->style_id = $arr['style_id'];
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($arr['child_menu_id']) ? $arr['child_menu_id'] : 0;
            $model->add();
        }
        //exit();
	}
}
?>