<?php

// 关联属性更新
class UpdateSiftAction extends CommonAction {

    protected $id;                  //ID
    protected $cid;                 //栏目ID
    protected $cmid = 0;            //子栏目ID
    protected $ano;                 //区域NO
    protected $boid;                //书籍ID
    protected $did;                 //设计师ID
    protected $seid;                //季度ID
    protected $bid;                 //品牌ID
    protected $soid = 0;            //性别ID
    protected $sid = 0;             //专栏ID
    protected $act;
    protected $table;
    protected $menu_arr = array(
        array('id' => '11', 'title' => '流行趋势'),
        array('id' => '12', 'title' => '时装发布'),
        array('id' => '13', 'title' => 'T台趋势'),
        array('id' => '14', 'title' => '企划方案'),
        array('id' => '15', 'title' => '展会材料'),
        array('id' => '17', 'title' => '正在流行'),
        array('id' => '18', 'title' => '流行分析'),
        array('id' => '27', 'title' => '手稿趋势'),
        array('id' => '29', 'title' => '市场聚焦'),
        array('id' => '19', 'title' => '时尚杂志'),
        array('id' => '20', 'title' => '品牌画册'),
        array('id' => '22', 'title' => '时尚款式'),
        array('id' => '21', 'title' => '街头时尚'),
        array('id' => '23', 'title' => '视觉营销'),
        array('id' => '16', 'title' => '矢量款式'),
        array('id' => '24', 'title' => '图案'),
        array('id' => '25', 'title' => '配饰'),
        array('id' => '26', 'title' => '书籍'),
        array('id' => '28', 'title' => '秀场提炼'),
        array('id' => '29', 'title' => '时尚款式内衣'),
        array('id' => '30', 'title' => '正在流行内衣'),
            //array('id'=>'30','title'=>'婴童专区'),
    );
    protected $action_sift = array(
        array('id' => '1', 'text' => '更新文件夹属性', 'type' => "folder"),
        array('id' => '2', 'text' => '更新主题属性', 'type' => "theme"),
        array('id' => '3', 'text' => '更新图片属性', 'type' => "picture"),
    );

    public function _initialize() {
        $cid = intval($_REQUEST['cid']);
        if($cid == 29){
            $this->cid = 10;
            $cid = 22;
        }else if($cid == 30){
            $this->cid = 10;
            $cid = 17;
        }else{
            $this->cid = $cid;
        }

        $this->act = trim($_REQUEST['act']);
        parent::_initialize();
        $this->init();
    }

    public function index() {
        if ($this->cid) {
            if ($this->cid > 28 || $this->cid < 11) {
                $this->error('error');
            }

            $this->data();
        } else {
            $this->assign('action_sift', $this->action_sift);
            $this->assign('menu_arr', $this->menu_arr);
            $this->display();
        }
    }

    protected function data() {
        $sort_id = intval($_REQUEST['sort']);
        if(!in_array($sort_id,array(0,1,2,3,4,5,6))){
            exit('参数错误');
        }
        $tag = intval($_REQUEST['tag']);
        if ($this->act == 'all') {
            if ($tag == 0) {
                if (isset($this->m['folder'])) {
                    $this->table = 'folder';
                    $model = $this->modelF;
                } else {
                    ++$tag;
                    echo "<script>window.location='?cid={$this->cid}&act={$this->act}&tag={$tag}';</script>";
                }
            } else if ($tag == 1) {
                $this->table = 'subject';
                $model = $this->modelT;
            } else if ($tag == 2) {
                if(!in_array($this->cid,array(17,27))){
                    $this->table = 'picture';
                    $model = $this->modelP;
                }else{
                    exit('更新完毕');
                }
            } else if ($tag == 3) {
                exit('更新完毕');
            }
        } else if ($this->act == 'folder') {
            $this->table = 'folder';
            $model = $this->modelF;
        } else if ($this->act == 'theme') {
            $this->table = 'subject';
            $model = $this->modelT;
        } else if ($this->act == 'picture' && !in_array($this->cid,array(17,27))) {
            $this->table = 'picture';
            $model = $this->modelP;
        } else {
            exit('参数错误');
        }

        echo $this->table.'性别'.$sort_id.'<br/>';

        //$sort_arr = array(0,1,2,3,4,5,6);
        $column_arr = array(0,1,2,4,5);

        $menu_arr = F('menuList','',C('DATA_CACHE_PATH'));
        $child_menu_arr = array();
        $child_menu_arr[] = 0;
        foreach($menu_arr as $key=>$val){
            if($val['parent_id'] == $this->cid){
                $child_menu_arr[] = $val['id'];
            }
        }

        $data = $map = $join = array();
        $data['menu_id'] = $map[$this->m[$this->table . '_original'].'.menu_id'] = $this->cid;
        if($sort_id){
            $data['sort_id'] = $map['fs.sort_id'] = $sort_id;
            $join['0'] = "{$this->m['ref_' . $this->table . '_sort_original']} as fs on fs.{$this->table}_id = {$this->m[$this->table . '_original']}.id";
        }else{
            $data['sort_id'] = 0;
        }

        $j = 0;
        foreach($column_arr as $ke=>$va){
            if($va){
                $data['special_column_id'] = $map['sp.special_column_id'] = $va;
                $join['1'] = "{$this->m['ref_' . $this->table . '_column_original']} as sp on sp.{$this->table}_id = {$this->m[$this->table . '_original']}.id";
            }else{
                $data['special_column_id'] = 0;
            }

            foreach($child_menu_arr as $k=>$v){
                $i = 0;

                $data['child_menu_id'] = $map[$this->m[$this->table . '_original'].'.child_menu_id'] = $v;

                $exist_sift = $this->getExistSift($data);

                $data['brand_id_list'] = $this->formatSift($model,'brand_id',$join,$map,$exist_sift);
                if(!$data['brand_id_list']){
                    unset($data['brand_id_list']);
                    ++$i;
                }

                $data['designer_id_list'] = $this->formatSift($model,'designer_id',$join,$map,$exist_sift);
                if(!$data['designer_id_list']){
                    unset($data['designer_id_list']);
                    ++$i;
                }

                $data['season_id_list'] = $this->formatSift($model,'season_id',$join,$map,$exist_sift);
                if(!$data['season_id_list']){
                    unset($data['season_id_list']);
                    ++$i;
                }

                $data['book_id_list'] = $this->formatSift($model,'book_id',$join,$map,$exist_sift);
                if(!$data['book_id_list']){
                    unset($data['book_id_list']);
                    ++$i;
                }

                $data['area_no_list'] = $this->formatSift($model,'area_no',$join,$map,$exist_sift);
                if(!$data['area_no_list']){
                    unset($data['area_no_list']);
                    ++$i;
                }

                if ($this->cid == 25) {
                    $join['2'] = "{$this->m['ref_' . $this->table . '_acc_original']} as ac on ac.{$this->table}_id = {$this->m[$this->table . '_original']}.id";
                    $acc_arr = $model->join($join)->field('ac.acc_id as acc_id')->where($map)->group('ac.acc_id')->findAll();
                    if($acc_arr){
                        $exist_sift_tmp = explode(',',$exist_sift['acc_id_list']);
                        foreach($acc_arr as $exk=>$exv){
                            if(empty($exv['acc_id']) || in_array($exv['acc_id'],$exist_sift_tmp)){
                                continue;
                            }
                            $data['acc_id_list'] .= $exv['acc_id'].',';
                        }
                        $data['acc_id_list'] = trim($data['acc_id_list'],',');
                    }else{
                        ++$i;
                    }
                }

                if(($this->cid != 25 && $i == 5) ||($this->cid == 25 && $i == 6)){
                    continue;
                }

                if($exist_sift['id']){
                    $this->modelS->where(array('id' => $exist_sift['id']))->save($data);
                }else{
                    $this->modelS->add($data);
                }
                echo $this->modelS->getLastSql().'<br/>';
            }
            ++$j;
        }
        if ($j > 0 && $sort_id < 6) {
            ++$sort_id;
            echo "<script>window.location='?cid={$this->cid}&act={$this->act}&sort={$sort_id}&tag={$tag}';</script>";
        }

        if ($this->act == 'all' && $tag < 3) {
            $sort_id = 0;
            ++$tag;
            echo "<script>window.location='?cid={$this->cid}&act={$this->act}&sort={$sort_id}&tag={$tag}';</script>";
        }
    }

   protected function formatSift($model,$field,$join,$map,$exist_sift = array()){
        $arr = $model->join($join)->field($field)->where($map)->group($field)->findAll();
        echo $model->getLastSql().'<br/>';
        $data = '';
        if($arr){
            $exist_sift_tmp = explode(',',$exist_sift[$field.'_list']);
            foreach($arr as $key=>$val){
                if(empty($val[$field]) || in_array($val[$field],$exist_sift_tmp)){
                    continue;
                }

                $data .= $val[$field].',';
            }
        }
        return trim($data,',');
   }

    protected function getExistSift($map) {
        $field = 'id,area_no_list,book_id_list,brand_id_list,designer_id_list,season_id_list';
        $row = $this->modelS->field($field)->where($map)->find();
        echo $this->modelS->getLastSql().'<br/>';
        return $row;
    }

    protected function init($cid) {
        $this->m = getCidModel($cid);
        if (isset($this->m['folder'])) {
            $this->modelF = D("{$this->m['folder']}");
        }
        $this->modelT = D("{$this->m['subject']}");
        $this->modelP = D("{$this->m['picture']}");
        $this->modelS = D("AttributeSift");
    }
}