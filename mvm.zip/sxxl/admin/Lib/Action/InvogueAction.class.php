<?php
// 后台主题模块
class InvogueAction extends SubjectAction {
	public $cid = 17;

	public function _initialize() {
		parent::_initialize();
        $listMenus = array(
            array('href' => '/Invogue/themeList', 'selected' => (in_array(ACTIONthemeEdit_NAME, array('themeList', 'index')) ? 'now' : ''), 'title' => '主题管理'),
            array('href' => '/Invogue/picList', 'selected' => (in_array(ACTION_NAME, array('picList')) ? 'now' : ''), 'title' => '图片管理'),
            array('href' => '/UnderwearInvogue/themeList', 'selected' => (in_array(ACTION_NAME, array('themeList')) ? '' : ''), 'title' => '内衣主题管理'),
            array('href' => '/UnderwearInvogue/picList', 'selected' => (in_array(ACTION_NAME, array('picList')) ? '' : ''), 'title' => '内衣图片管理'),
		);
		$this->assign('listMenus', $listMenus);
		$this->assign('currentBase', '数据录入-正在流行');
	}

	function index() {
		$this->themeList();
	}

	public function themeList() {
        $field = $this->m['subject_original'].'.id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_themeList($field,$map);
		$this->display('Subject/invogue_theme_list');
	}

    protected function _themeList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))
            $this->error('参数错误！');
        $this->assign('currentName', '-主题列表');
        $action_link = array();
        $folder_id = $_REQUEST['folder_id'];
        if (isset($folder_id)) {
            $action_link[] = array('text' => '返回文件夹', 'href' => Cookie::get('_currentFolderUrl_'));
        }
        if (isset($folder_id) && !empty($folder_id)) {
            $folder_data = $this->modelF->getById($folder_id);
            $this->assign('folderTitle', "文件夹：".stripslashes($folder_data['title']));
            if (!in_array($this->cid,array(12))){$action_link[] = array('text' => '标签管理', 'href' => "__URL__/labelList/folder_id/{$folder_id}");}
            $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/folder_id/{$folder_id}");
        }

        if(in_array($this->cid,array('17','27','19','20','21','23','25','26','28'))){
            $action_link[] = array('text' => '添加主题', 'href' => "__URL__/themeAdd/");
        }
        
        $this->assign('action_link', $action_link);
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        if (intval($folder_id))
            $map['folder_id'] = intval($folder_id);
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['subject_original'].'.child_menu_id'] = $child_menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        if($brand_id){
            $checkBrandName = $this->brands[$brand_id]['name'];
            $this->assign('checkBrand',$checkBrandName);
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //dump($map);
        //排序字段 默认为主键名
        $listRows = '30';
        if($this->cid == 12){
            $order = $this->modelT->getPk();
        }  else {
            $order = !empty($sortBy) ? $sortBy : $this->modelT->getPk();
        }
        $sort = $asc ? 'desc' : 'asc';
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_subject_sort_original'].' ss ON ss.subject_id='.$this->m['subject_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ss.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ss.sort_id'] = $sort_id;
            }
            $field .=",ss.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_subject_column_original'].' sc ON sc.subject_id='.$this->m['subject_original'].'.id';
            if($column_id == 6){
                //$map['sc.special_column_id'] = array('exp','is null');
                $map['sc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['sc.special_column_id'] = $column_id;
            }
            $field .=",sc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_subject_style_original'].' sst ON sst.subject_id='.$this->m['subject_original'].'.id';
			$map['sst.style_id'] = $style_id;
            $field .=",style_id";
        }
        
        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //区域格式化
        $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
        $this->assign('areaOption', $areaOption);
        //取得满足条件的记录数
        //$map =array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } } 
        import('ORG.Util.DataCount');
        $moldel = new DataCount();
        $count = $moldel->getCount("{$this->m['subject']}", $map, $join);
        //echo $this->modelT->getlastsql();
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelT->relation(array('sort_id','special_column_id','style','zipfile_url'))->where($map)->join($join)->field($field)->order("`" . $order . "` " . $sort)->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelT->getlastsql();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['title'] = stripslashes($val['title']);
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    $voList[$key]['columnStr'] = implode(',', $column);
                    
                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    $voList[$key]['styleStr'] = implode(',', $style);
                    
                    if ($val['lable_id']) {
                        $m = D("{$this->m['folder_lable']}");
                        $la = $m->field('lable')->find($val['lable_id']);
                        $voList[$key]['lableStr'] = $la['lable'];
                    }
                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    $voList[$key]['downloadid'] = urlencode(authcode("tid=".$val['id']."&cid=".$this->cid,"ENCODE"));
                    if($voList[$key]['zipfile_url']['zipfile_url']){
                        $voList[$key]['is_zipfile_url'] = 1;
                    }
                }
            }
            //模板赋值显示
            $this->assign('list', $voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
            $this->assign('folder_id', $folder_id);
        }
        Cookie::set('_currentThemeUrl_', __SELF__);
        return;
    }

	public function themeAdd() {
		$this->_themeAdd();
        $this->display('Subject/invogue_theme_info');
	}

    //没有lable_id字段
    protected function _themeAdd() {
        $this->assign('tid', 0);
        if ($_POST) {
            $info = $this->getSubjectInfo();
            //dump($_POST);exit();
            $id = $this->modelT->add($info);
            //echo $this->modelT->getLastSql();exit();
            if ($id) {
                $this->setThemeOther($id);
                $this->assign('jumpUrl',__URL__."/picList/subject_id/{$id}");
                //$this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            $this->setConfig();
            $folder_id = $_REQUEST['folder_id'];
            //获取对应标签
            if(!empty($folder_id)){
                $info = $this->modelF->getById($folder_id);
                $info['title'] = stripslashes($info['title']);
                $info['tmpTitle'] =$info['title'];
                $info['title'] = $info['id'] = '';
                $map['folder_id'] = $folder_id;
                $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                $this->assign('lableList', $lable_list);
                }
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $info['publish_time'] = date('Y-m-d H:i:s', time());
            $info['folder_id'] = $_REQUEST['folder_id'];
            $this->assign('info', $info);
            //区域格式化
            $areaOption = $this->getAreaOption(0);
            $this->assign('areaOption', $areaOption);
            $this->assign('listMenus', '');
        }
    }

	public function themeEdit() {
		$this->_themeEdit();
        $this->display('Subject/invogue_theme_info');
	}

    protected function _themeEdit() {
        $id = intval($_POST['id']);
        if ($id) {//dump($_POST);
            $info = $this->getSubjectInfo();
            //dump($info);exit;
            if(is_array($info['child_menu_id']) && isset($info['child_menu_id'])){
                $child_menu_array = $_POST['child_menu_id'];
            }else{
                $info['child_menu_id'] = intval($_POST['child_menu_id']);
            }
            //dump($info);exit();
            // 更新数据
            $where['id'] = $id;
            $where['menu_id'] = $this->cid;
            $result = $this->modelT->where($where)->save($info);
            //echo $this->modelT->getlastsql();exit();
            $this->setThemeOther($id);
            $this->setPictureCount($id);
            if (false !== $result) {
                //成功提示
                $this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('编辑成功!');
            } else {
                //错误提示
                $this->error('编辑失败!');
            }
        } else {
            $this->setConfig();
            if ($_GET['id']) {
                $id = $_REQUEST[$this->modelT->getPk()];
                $info_menu_id = $this->cid;
                $info = $this->modelT->relation(true)->where(array('menu_id' => $info_menu_id, 'id' => $id))->find();
                $info['title'] = stripslashes($info['title']);
                $info['publish_time'] = date('Y-m-d H:i:s', $info['publish_time']);
                $info['tmpTitle'] = $info['title'];
                $info['subject_id'] = $_GET['id'];
                if ($info['lable_id']) {
                    $map['folder_id'] = $info['folder_id'];
                    $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                    $this->assign('lableList', $lable_list);
                }
                if ($info['sort_id']) {
                    $tmp = array();
                    foreach ($info['sort_id'] as $key => $val) {
                        $tmp[] = $val['sort_id'];
                    }
                    $info['sort_id'] = $tmp;
                }
                if (empty($info['sort_id'])) {
                    $info['sort_id'] = array($info['sort_id']);
                }
                if ($info['style']) {
                    $tmp = array();
                    foreach ($info['style'] as $key => $val) {
                        $tmp[] = $val['style_id'];
                    }
                    $info['style'] = $tmp;
                }
                if (empty($info['style'])) {
                    $info['style'] = array($info['style']);
                }
                if ($info['acc']) {
                    $tmp = array();
                    foreach ($info['acc'] as $key => $val) {
                        $tmp[] = $val['acc_id'];
                    }
                    $info['acc'] = $tmp;
                }
                if ($info['special_column_id']) {
                    $tmp = array();
                    foreach ($info['special_column_id'] as $key => $val) {
                        $tmp[] = $val['special_column_id'];
                    }
                    $info['special_column_id'] = $tmp;
                }
                if (empty($info['special_column_id'])) {
                    $info['special_column_id'] = array($info['special_column_id']);
                }
                //dump($info);
                $info['title_picture_url'] = show_pic_path($info['title_picture_url']);
                $recom = $this->getRecommend($id);
                $info = array_merge($info, $recom);
                $info['show_edit'] = $info['show_edit'] ? 'checked' : '';
                if (in_array($info['menu_id'], array('27'))) {
                    $map['menu_id'] = $info['menu_id'];
                    $map['subject_id'] = $info['id'];
                    $child_menu_array = D("{$this->m['ref_subject_menu']}")->field('child_menu_id')->where($map)->findAll();
                    $this->assign('child_menu_array', $child_menu_array);
                }
                if(!empty($info['brand_id'])){
                    $brand_name = $this->brands[$info['brand_id']]['name'];
                    $this->assign('brand_name', $brand_name);
                    $this->assign('brand_id', $info['brand_id']);
                }
                //dump($info);
                $this->assign('info', $info);
                //区域格式化
                $areaOption = $this->getAreaOption(intval($info['area_no']));
                $this->assign('areaOption', $areaOption);
            }
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $this->assign('listMenus', '');
            $this->assign('tid', $id);
        }
    }
	/**
	 * 批量操作
	 */
	public function themeBatch() {
		parent::themeBatch();
	}
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::picList($field, $map);
        $isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/invogue_picture_list');
		} else {
			$this->display('Subject/invogue_theme_picture_list');
		}
	}

	public function picAdd() {
		parent::picAdd('1');
        $this->display('Subject/invogue_picture_info');
	}

	public function picCategory() {
		$this->_picCategory();
	}
    
    public function _picCategory() {
        $picture_id = intval($_REQUEST['picture_id']);
        $subject_id = intval($_REQUEST['subject_id']);
        if ( $_REQUEST['addup'] ) {
            $this->assign('addup', $_REQUEST['addup']);
        }
        $this->assign('picture_id', $picture_id);
        if (in_array('7', $this->config) || in_array('7', $this->configS))
            $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
        if (in_array('3', $this->config) || in_array('3', $this->configS))
            $this->brands = F('brandList','',C('DATA_CACHE_PATH'));
        $ids = $_REQUEST['ids'];
        if ($_POST) {
            if(strlen($_POST['description']) > 50 ){
                $this->assign('waitSecond', 3);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('操作失败!<br />图片描述长度不能超过50!');
            }
            $idArr = explode(',', $ids);
            if ($idArr) {
                $info['brand_id'] = $Pinfo['brand_id'] = intval($_REQUEST['brand_id']);
                $Pinfo['add_user_id'] = Cookie::get(C('USER_AUTH_KEY'));
                foreach ($idArr as $pid) {
                    $pid = intval($pid);
                    $where_cid = intval($_REQUEST['is_ny']) ? $this->ny_cid : $this->cid;
                    $where = array('menu_id' => $where_cid, 'id' => $pid);
                    $this->modelP->where($where)->save($Pinfo);
                    $this->setSift();
                    //添加图片描述
                   	$info['picture_id'] = $pid;
                   	$info['menu_id'] = $_POST['menu_id'];
                   	$info['child_menu_id'] =$_POST['child_menu_id'];
                   	$info['description'] = $_POST['description'];
                   	$this->setPicDescrip($info);
                   	//图片属性编辑
                    $this->setInvoguePicSort($pid);
                    
                    $sid = $_POST['styleCheck']['0'] ? $_POST['styleCheck']['0'] : '';
//                    if (($_POST['styleCheck'] || intval($picture_id)) && ($_POST['change_style'] || $sid == 448))
//                        $this->setPicStyle($pid,$sid,$_POST['child_style']);
                    if (($_POST['styleCheck'] || intval($picture_id)) && ($_POST['change_style'] || $sid == 448)){
                        $style = $_POST['styles'] ? explode(',', $_POST['styles']) : '';
                        if ($style) {
                            foreach ($style as $k => $v) {
                                if ($this->styles[$v]['parent_id'] == 0) {
                                    //unset($style[$k]);
                                }
                                if ($this->styles[$v]['parent_id'] > 0) {
                                    $style[] = $this->styles[$v]['parent_id'];
                                }
                            }
                        }
                        $style = array_unique($style);
                        $psid = in_array($_POST['styleCheck'], $style) ? 0 : $_POST['styleCheck'];
                        if (($_POST['styleCheck'] || intval($picture_id)) && ($_POST['change_psid'] || $_POST['change_style'])){
                            $this->setPicStyle($pid, $psid, $style,$_POST);
                        }   
                    }
                    
                    if($sid == 448){
                        $this->setPicFashion($pid,$_POST['fashion_id']);
                        $this->setPicMaterial($pid,$_POST['material_id']);
                    }
                    //图片搜索表处理
                    $this->setSearchPicture($pid, $_POST['subject_id']);
                }
                //exit('<script>self.parent.main.location.reload()</script>');
                //exit('<script>self.parent.main.closeBox();</script>');
                //成功提示
                $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('分类成功!');
            }
        } else {
            $info = $this->modelP->relation(array('sort_id','style','fashion','material'))->where(array('id' => $picture_id))->find();
            $description = $this->model_picture_extend->where(array('picture_id' => $picture_id))->find();
            $info['description'] = $description['description'];
            //dump($info);exit();
            //echo $this->modelP->getlastsql();exit('#');
            if ($info['style']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['style'] as $key => $val) {
                    if ($val['style_id'] > 0) {
                        $tmp[] = $val['style_id'];
                        $tmpT[] = $this->styles[$val['style_id']]['name'];
                    }
                }
            }
            $info['style_id'] = $tmp;
            
            $styleIds = $tmp ? implode(',', $info['style_id']) : '';
            $ajaxStyleIds = $tmp ? implode(',', $info['style_id']) : '0';
            $this->assign('styleIds', $styleIds);
            $this->assign('ajaxStyleIds', $ajaxStyleIds);
            $this->assign('styleText', implode(',', array_unique($tmpT)));
            
            $sort = array();
            if ($info['sort_id']) {
                foreach ($info['sort_id'] as $k => $v) {
                    $sort[$k] = $v['sort_id'];
                }
            }
            $info['sort'] = $sort;
            
            //款式分级处理
            if ($this->styles) {
                foreach ($this->styles as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        if ( $val['type'] == 1) {$styleTmpUp[$key] = $val;}
                        if ( $val['type'] == 2) {$styleTmpDown[$key] = $val;}
                        if ( $val['type'] == 3) {$styleTmpNy[$key] = $val;}
                        if ( $val['type'] == 0) {$styleTmpOther[$key] = $val;}
                        if (in_array($val['no'], $info['style'])) {
                            $public = A('Public');
                            $styleHtml = $public->getStyleByAjax($styleIds, $val['no'], 'yes');
                        }
                    }
                }
            }
            $this->assign('styleHtml', $styleHtml);
            $this->assign('stylesUp', $styleTmpUp);
            $this->assign('stylesDown', $styleTmpDown);
            $this->assign('stylesOther', $styleTmpOther);
            $this->assign('styleTmpNy', $styleTmpNy);
            //$this->assign('styles', $styleTmp);
            //品牌
            $brand_id = $info['brand_id'] ? $info['brand_id'] : 0;
            $brand_name = $this->brands[$brand_id]['name'];
            $this->assign('brand_name', $brand_name);
            $this->assign('brand_id', $brand_id);
            
            if($info['fashion']){
                $fashion = $info['fashion']['0']['fashion_id'];
                $this->assign('fashion_checked_id', $fashion);
            }
            if($info['material']){
                $material = $info['material']['0']['material_id'];
                $this->assign('material_checked_id', $material);
            }
            //print_r($styleTmp);
        }
        //echo '<pre>';
        //dump($info);
        intval($_REQUEST['is_ny']) ? $this->assign('is_ny', 1) : $this->assign('is_ny', 0);
        $this->assign('info', $info);
        $this->assign('subject_id', $subject_id);
        $this->assign('picture_id', $picture_id);
        $this->assign('ids', $ids);
        $this->assign('listMenus', '');
        $this->display('Subject/invogue_picture_category');
    }
     
	public function picBatch() {
		parent::picBatch();
	}
    
	public function getStyleByAjax($have = '', $pid = '', $is_ajax = '') {
		$haveTmp = $have;
		$pidTmp = intval($pid);
		$have = $haveTmp ? $haveTmp : intval($_REQUEST['have']);
		$pid = $pidTmp ? $pidTmp : intval($_REQUEST['pid']);
		$checked = $_REQUEST['checked'];
		if (empty($pid)) exit();
		$cid = $_REQUEST['cid'];
		//$info = D('Picture')->where(array('menu_id' => $cid))->relation(true)->find($id);
		$styles = F('styleList','',C('DATA_CACHE_PATH'));
		$have = $have ? explode(',', $have) : '';
		$html = '<strong>款式二级:</strong><br />';
		foreach ($styles as $key => $val) {
			if ($val['parent_id'] == $pid) {
				$c = in_array($val['id'], explode(',', $checked)) ? 'checked' : '';
				if (!$checked) {
					$e = in_array($val['id'], $have) ? 'checked' : '';
				}
				$cd = $c ? $c : $e;
                $html .= '<div style="width:120px;float:left">';
				$html .= '<label for="style_id_' . $val['id'] . '"><input ' . $cd . ' name="child_style[]" onclick="cs(this);" id="style_id_' . $val['id'] . '" type="checkbox" ' . (in_array($val['id'], $have) ? 'checked' : '') . ' value="' . $val['id'] . '" text="' . $val['name'] . '"/>' . $val['name'] . '</label>';
                $html .= '</div>';
			}
		}
		if ($is_ajax)
			return $html;
		else
			exit($html);
	}
    
    public function getFashionsByAjax() {
        $fashionChecked = $_REQUEST['have'];
		$fashionall = F('fashionList','',C('DATA_CACHE_PATH'));
        $cidfashions = get_cid_fashions($fashionall,  $this->cid);
        $html .= '<strong>内衣风格:</strong>';
		$html .= '<select name="fashion_id" id="fashion_id">';
        $html .= '<option value="">风格选择</option>';
        foreach ($cidfashions as $key => $val) {
            if ($val['is_ny'] == 1) {
                $html .= '<option value="' . $val['id'] .'"'. ($val['id'] == $fashionChecked ? 'selected="selected"' : '') .' title="'.$val['name'].'">' . $val['name'] . '</option>';
            }
		}
        $html .= '</select>';
		echo $html;
	}
    
    public function getMaterialByAjax() {
        $fashionChecked = $_REQUEST['have'];
		$materials = F('materialList','',C('DATA_CACHE_PATH'));
        $html .= '<strong>内衣面料:</strong>';
		$html .= '<select name="material_id" id="material_id">';
        $html .= '<option value="">面料选择</option>';
        foreach ($materials as $key => $val) {
            $html .= '<option value="' . $val['id'] .'"'. ($val['id'] == $fashionChecked ? 'selected="selected"' : '') .' title="'.$val['name'].'">' . $val['name'] . '</option>';
		}
        $html .= '</select>';
		echo $html;
	}
    
    
    //用于在图片picture_category里面
    protected function setPicStyle($id, $psid, $info, $menus = null) {
        if (is_array($info) && !empty($info)) {
            $infos = $info;
        } else {
            $infos = explode(',', $info);
        }
        if (empty($id))
            return false;
        if ( empty($_REQUEST['addup']) ){
            $this->delPicStyle($id);
        }
        $model = M("{$this->m['ref_picture_style']}");
        $data['picture_id'] = $id;
        foreach ($infos as $key => $val) {
            if ($val > 0) {
                $data['style_id'] = $val;
                $data['menu_id'] = $this->cid;
                $data['child_menu_id'] = $menus['child_menu_id'];
                $row = $model->where($data)->find();
                if ( empty ($row) ){
                    $model->add($data);
                } 
            }
        }
    }

    protected function delPicStyle($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_style']}");
        $model->where($where)->delete();
    }
    
    
    public function setPicFashion($id,$fid) {
        if (empty($id))
            return false;
        $this->delPicFashion($id);
        $model = M("{$this->m['ref_picture_fashion']}");
        $model->picture_id = $id;
        if ($fid) {
            $model->fashion_id = $fid;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_REQUEST['child_menu_id']) ? $_REQUEST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br>";
        }
    }
    public function delPicFashion($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_fashion']}");
        $model->where($where)->delete();
        //echo $model->getLastSql();echo "<br>";
    }

    public function setPicMaterial($id,$fid) {
        if (empty($id))
            return false;
        $this->delPicmaterial($id);
        $model = M("{$this->m['ref_picture_material']}");
        $model->picture_id = $id;
        if ($fid) {
            $model->material_id = $fid;
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($_REQUEST['child_menu_id']) ? $_REQUEST['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br>";
        }
    }
    public function delPicmaterial($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_material']}");
        $model->where($where)->delete();
        //echo $model->getLastSql();echo "<br>";
    }
    
    public function setInvoguePicSort($pid){
        if (empty ($pid))
             return false;
        $this->delInvoguePicSort($pid);
        $pic_sort_arr = $this->getInvoguePicPostSort();
        $model = M("{$this->m['ref_picture_sort']}");
        foreach ($pic_sort_arr as $key => $val) {
            $model->picture_id = $pid;
            $model->sort_id = $val['sort_id'];
            $model->menu_id = $this->cid;
            $model->child_menu_id = !empty($val['child_menu_id']) ? $val['child_menu_id'] : 0;
            $model->add();
            //echo $model->getLastSql();echo "<br />";
        }
    }

    public function getInvoguePicPostSort(){
        $post_arr = array();
        if(isset($_POST['sort']) && !empty($_POST['sort'])) {
            foreach ($_POST['sort'] as $key => $val){
                $post_arr[$key]['sort_id'] = $val;
                $post_arr[$key]['child_menu_id'] = $_POST['child_menu_id'];
            }
        }
        return $post_arr;
    }

    public function delInvoguePicSort($id) {
        $id = intval($id);
        $where = array('picture_id' => $id);
        $model = M("{$this->m['ref_picture_sort']}");
        $model->where($where)->delete();
    }
    
}
?>
