<?php
// 后台主题模块
class VectorStyleAction extends SubjectAction {
	public $cid = 16;

	public function _initialize() {
		parent::_initialize();
		$listMenus = array(
			array('href' => '/VectorStyle/picList', 'selected'=>(in_array(ACTION_NAME, array('picList','index')) ? 'now' : ''), 'title' => '图片管理'),
            array('href' => '/UnderwearVectorStyle/picList', 'selected'=>(in_array(ACTION_NAME, array('picList','index')) ? '' : ''), 'title' => '内衣图片管理'),
		);
		$this->assign('listMenus', $listMenus);
		$this->assign('currentBase', '数据录入-矢量款式');
	}

	function index() {
		$this->picList();
	}
    
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		$this->_picList($field, $map);
		$this->display('Subject/vectorstyle_picture_list');
	}

    protected function _picList($field, $map, $sortBy = 'id', $asc = true) {
        $this->setConfig();
        if (empty($map))//array(2) { ["menu_id"]=> int(17) ["is_publish"]=> array(2) { [0]=> string(3) "egt" [1]=> int(0) } }
            $this->error('参数错误！');
        $action_link = array();
        $this->assign('currentName', $currentName . '-图片列表');
        $userList = $this->getUserList();
        $this->assign("userList", $userList);
        $action_link[] = array('text' => '添加图片', 'href' => "javascript:Box.open({'id':'add','title':'添加图片','url':'__URL__/picAdd/subject_id/{$subject_id}','width':'750','height':'500'});");
        $this->assign('action_link', $action_link);
        $child_menu_id = intval($_REQUEST['child_menu_id']);
        if ($child_menu_id)
            $map[$this->m['picture_original'].'.child_menu_id'] = $child_menu_id;
        $menu_id = intval($_REQUEST['menu_id']);
        if ($menu_id)
            $map['menu_id'] = $menu_id;
        $season_id = intval($_REQUEST['season_id']);
        if ($season_id)
            $map['season_id'] = $season_id;
        $area_id = intval($_REQUEST['area_id']);
        if ($area_id)
            $map['area_no'] = $area_id;
        $designer_id = intval($_REQUEST['designer_id']);
        if ($designer_id)
            $map['designer_id'] = $designer_id;
        $book_id = intval($_REQUEST['book_id']);
        if ($book_id)
            $map['book_id'] = $book_id;
        $add_user_id = intval($_REQUEST['add_user_id']);
        if ($add_user_id)
            $map['add_user_id'] = $add_user_id;
        $fashion_id = intval($_REQUEST['fashion_id']);
        if ($fashion_id)
            $map['fashion_id'] = $fashion_id;
        $brand_id = intval($_REQUEST['brand_id']);
        if ($brand_id)
            $map['brand_id'] = $brand_id;
        $is_publish = $_REQUEST['is_publish'];
        if ($is_publish != '') {
            $map['is_publish'] = $is_publish;
        }
        $key_type = intval($_REQUEST['key_type']);
        $keyword = trim($_REQUEST['keyword']);
        if ($keyword) {
            if ($key_type == 1) {
                $map['id'] = $keyword;
            } elseif ($key_type == 2) {
                $map['title'] = $keyword;
            } elseif ($key_type == 3) {
                $BM = D('AttributeBrand');
                $bo = $BM->field('id')->where(array('name' => $keyword))->find();
                $map['brand_id'] = $bo['id'];
            }
        }
        $time_start = $_REQUEST['time_start'];
        $time_end = $_REQUEST['time_end'];
        $time_type = intval($_REQUEST['time_type']);
        $time_field = $time_type == 1 ? 'publish_time' : 'add_time';
        if ($time_start) {
            $map[$time_field][] = array('egt', strtotime($time_start . ' 00:00:00'));
        } else {
            //$map[$time_field][] = array('egt', strtotime('2011-01-01' . ' 00:00:00'));
        }
        if ($time_end) {
            $map[$time_field][] = array('elt', strtotime($time_end . ' 23:59:59'));
        }
        //排序字段 默认为主键名
        $listRows = '30';
        $order = !empty($sortBy) ? $sortBy : 'publish_time';
        $sort = $asc ? 'desc' : 'asc';
        $join = '';
        if ($subject_id) {
            $map['subject_id'] = $subject_id;
        }
        //筛选性别
        $sort_id = intval($_REQUEST['sort_id']);
        if ($sort_id) {
			$join[] = $this->m['ref_picture_sort_original'].' ps ON ps.picture_id='.$this->m['picture_original'].'.id';
            if ( $sort_id == 3 ){
                $map['ps.sort_id'] = array('egt',$sort_id);
            } else {
                $map['ps.sort_id'] = $sort_id;
            }
            $field .=",ps.sort_id";
        }
        //筛选专栏
        $column_id = intval($_REQUEST['column_id']);
        if ($column_id) {
			$join[] = $this->m['ref_picture_column_original'].' pc ON pc.picture_id='.$this->m['picture_original'].'.id';
            if($column_id == 6){
                //$map['pc.special_column_id'] = array('exp','is null');
                $map['pc.special_column_id'] = array(array('exp','is null'),array('eq',0),'or');
            }else{
                $map['pc.special_column_id'] = $column_id;
            }
            $field .=",pc.special_column_id";
        }
        //筛选款式
        $style_id = intval($_REQUEST['style_id']);
        if ($style_id) {
			$join[] = $this->m['ref_picture_style_original'].' pst ON pst.picture_id='.$this->m['picture_original'].'.id';
			$map['pst.style_id'] = $style_id;
            $field .=",pst.style_id";
        }

        if (count($map) == 2 ) {
            $map['publish_time'] = array('egt', strtotime(date("Y-m-d", $_SERVER['REQUEST_TIME']) . " 23:59:59") - 6 * 30 * 86400);
            $this->assign('notice', 1);
        }
        //取得满足条件的记录数  主题表保存有图片数量字段 field:picture_count,前提是“$subject_id”不为空才能调用这个字段 暂时注销
        if (!empty($subject_id)) {
            $count = $themeI['picture_count'];
        } else {
            import('ORG.Util.DataCount');
            $moldel = new DataCount();
            $count = $moldel->getCount("{$this->m['picture']}", $map, $join);
        }
        if ($count > 0) {
            import("ORG.Util.Page");
            //创建分页对象
            $p = new Page($count, $listRows);
            //分页查询数据
            $voList = $this->modelP->where($map)->relation(array('sort_id','special_column_id','style','extend'))->join($join)->field($field)->order(array($order => $sort))->limit($p->firstRow . ',' . $p->listRows)->findAll();
            //dump($voList);
            //echo $this->modelP->getlastsql();exit();
            //分页跳转的时候保证查询条件
            foreach ($_REQUEST as $key => $val) {
                if (!is_array($val)) {
                    $p->parameter .= "$key=" . urlencode($val) . "&";
                }
            }
            if ($voList) {
                foreach ($voList as $key => $val) {
                    $voList[$key]['menu'] = $this->menus[$val['menu_id']]['name'];
                    $voList[$key]['menuStr'] = $this->menus[$val['child_menu_id']]['name'];
                    $voList[$key]['add_user_id'] = $this->userLists[$val['add_user_id']]['real_name'];
                    $style = array();
                    if ($val['style']) {
                        foreach ($val['style'] as $k => $v) {
                            $style[] = $this->styles[$v['style_id']]['name'];
                        }
                    }
                    if (empty($style)) {
                        $style = array($this->styles[$val['style_id']]['name']);
                    }
                    $voList[$key]['styleStr'] = implode(',', $style);

                    $sort = array();
                    if ($val['sort_id']) {
                        foreach ($val['sort_id'] as $k => $v) {
                            $sort[] = $this->sorts[$v['sort_id']]['name'];
                        }
                    }
                    if (empty($sort)) {
                        $sort = array($this->sorts[$val['sort_id']]['name']);
                    }
                    $voList[$key]['sortStr'] = implode(',', $sort);
                    $column = array();
                    if ($val['special_column_id']) {
                        foreach ($val['special_column_id'] as $k => $v) {
                            if ($this->columns[$v['special_column_id']]['name'])
                                $column[] = $this->columns[$v['special_column_id']]['name'];
                        }
                    }
                    if (empty($column)) {
                        $column = array($this->columns[$val['special_column_id']]['name']);
                    }
                    //echo '<pre>';
                    $voList[$key]['columnStr'] = implode(',', $column);

                    if ($this->seasons)
                        $voList[$key]['seasonStr'] = $this->seasons[$val['season_id']]['name'];
                    if ($this->areas)
                        $voList[$key]['areaStr'] = $this->areas[$val['area_no']]['name'];
                    if ($this->brands)
                        $voList[$key]['brandStr'] = $this->brands[$val['brand_id']]['name'];
                    if ($this->designers)
                        $voList[$key]['designerStr'] = $this->designers[$val['designer_id']]['name'];
                    if ($this->books)
                        $voList[$key]['bookStr'] = $this->books[$val['book_id']]['name'];
                    //if ($this->styles)
                       // $voList[$key]['styleStr'] = $this->styles[$val['style_id']]['name'];
                    $pic_small = show_pic_path($val['small_picture_url']);
                    $pic_big = show_pic_path($val['big_picture_url']);
                    $category = "javascript:Box.open({'id':'category','title':'图片分类:{$val["id"]}','url':'__URL__/picCategory/picture_id/{$val["id"]}/ids/{$val["id"]}','width':'600','height':'500','lock':0,left:548,top:10});sbp('{$pic_big}');";
                    $voList[$key]['imgStr'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' onclick=\"{$category}\" />";
                    $voList[$key]['img'] = "<img height='40' src='{$pic_small}' bsrc='{$pic_big}' alt='' class='bigpic' />";
                }
            }
            //print_r($this->brands);
            //模板赋值显示
            $this->assign('list', $voList);
            //dump($voList);
            //分页显示
            $page = $p->showThree();
            $this->assign("page", $page);
            //区域格式化
            $areaOption = $this->getAreaOption(intval($_REQUEST['area_id']));
            $this->assign('areaOption', $areaOption);
        }
        Cookie::set('_currentPiclistUrl_', __SELF__);
        return;
    }

	public function picAdd() {
		parent::picAdd();
	}

	public function picCategory() {
		$this->_picCategory();
	}

	public function picZip() {
		parent::picZip();
	}

    public function _picCategory() {
        $picture_id = intval($_REQUEST['picture_id']);
        $this->assign('picture_id', $picture_id);
        //style
        if (in_array('7', $this->config) || in_array('7', $this->configS))
            $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
        $ids = $_REQUEST['ids'];
        if ($_POST) {
            //dump($_POST);exit();
            if(strlen($_POST['description']) > 50 ){
                $this->assign('waitSecond', 3);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('操作失败!<br />图片描述长度不能超过50!');
            }
            $idArr = explode(',', $ids);
            if ($idArr) {
                //dump($info);exit;
                foreach ($idArr as $pid) {
                    $this->setSift();
                    //添加图片描述
                   	$info['picture_id'] = $pid;
                   	$info['menu_id'] = $_POST['menu_id'];
                   	$info['child_menu_id'] =$_POST['child_menu_id'] ;
                   	$info['description'] = $_POST['description'];
                   	$this->setPicDescrip($info);

                    $sid = $_POST['styleCheck']['0'] ? $_POST['styleCheck']['0'] : '';
                    if (($_POST['styleCheck'] || intval($picture_id)) && $_POST['change_style'])
                        $this->setVectorPicStyle($pid,$sid);
                    //图片搜索表处理
                    $this->setSearchPicture($pid);
                }
                //exit('<script>self.parent.main.location.reload()</script>');
                //exit('<script>self.parent.main.closeBox();</script>');
                //成功提示
                $this->assign('waitSecond', 0);
                $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload();javascript:self.parent.main.closeBox();');
                $this->success('分类成功!');
            }
        } else {
            $info = $this->modelP->relation(array('style'))->where(array('id' => $picture_id))->find();
            $description = $this->model_picture_extend->where(array('picture_id' => $picture_id))->find();
            $info['description'] = $description['description'];
            //dump($info);exit();
            //echo $this->modelP->getlastsql();exit('#');
            if ($info['style']) {
                $tmp = array();
                $tmpT = array();
                foreach ($info['style'] as $key => $val) {
                    if ($val['style_id'] > 0) {
                        $tmp[] = $val['style_id'];
                        $tmpT[] = $this->styles[$val['style_id']]['name'];
                    }
                }
            }
            $info['style_id'] = $tmp;

            $styleIds = $tmp ? implode(',', $info['style_id']) : '';
            $ajaxStyleIds = $tmp ? implode(',', $info['style_id']) : '0';
            $this->assign('styleIds', $styleIds);
            $this->assign('ajaxStyleIds', $ajaxStyleIds);
            $this->assign('styleText', implode(',', array_unique($tmpT)));
            if ($info['keyword']) {
                $tmpk = array();
                $tmpkT = array();
                foreach ($info['keyword'] as $key => $val) {
                    if ($val['keyword_id'] > 0) {
                        $tmpk[] = $val['keyword_id'];
                        $tmpkT[] = $this->keywords[$val['keyword_id']]['name'];
                    }
                }

            }
            $info['keyword'] = array_unique($tmpk);
            $keywordIds = $info['keyword'] ? implode(',', $info['keyword']) : '';
            $ajaxKeywordIds = $info['keyword'] ? implode(',', $info['keyword']) : '0';
            $this->assign('keywordIds', $keywordIds);
            $this->assign('ajaxKeywordIds', $ajaxKeywordIds);
            $this->assign('keywordText', implode(',', array_unique($tmpkT)));
            //款式分级处理
            if ($this->styles) {
                foreach ($this->styles as $key => $val) {
                    if ($val['parent_id'] == 0) {
                        if ( $val['type'] == 1) {$styleTmpUp[$key] = $val;}
                        if ( $val['type'] == 2) {$styleTmpDown[$key] = $val;}
                        if ( $val['type'] == 3) {$styleTmpNy[$key] = $val;}
                        if ( $val['type'] == 0) {$styleTmpOther[$key] = $val;}
                        $styleTmp[$key] = $val;
                        if (in_array($val['no'], $info['style'])) {
                            $public = A('Public');
                            $styleHtml = $public->getStyleByAjax($styleIds, $val['no'], 'yes');
                        }
                    }
                }
            }
            $this->assign('styleHtml', $styleHtml);
            $this->assign('styles', $styleTmp);
            //print_r($styleTmp);

            $this->assign('stylesUp', $styleTmpUp);
            $this->assign('stylesDown', $styleTmpDown);
            $this->assign('stylesOther', $styleTmpOther);
            $this->assign('styleTmpNy', $styleTmpNy);

        }
        //echo '<pre>';
        //dump($info);
        $this->assign('info', $info);
        $this->assign('subject_id', $subject_id);
        $this->assign('picture_id', $picture_id);
        $this->assign('ids', $ids);
        $this->assign('listMenus', '');
        $this->display('Subject/vactorstyle_picture_category');
    }

	public function picBatch() {
		parent::picBatch();
	}

    protected function picTmpFormat() {
        $where = array();
        $user_auth = Cookie::get(C('USER_AUTH_KEY'));
        $where['add_user_id'] = intval($user_auth);
        $where['menu_id'] = $this->cid;
        $where['subject_id'] = intval($_REQUEST['subject_id']);
        $model = D('SharePicturesTmp');
        $field = 'id,source_file_name AS img_name,url AS img_path,is_publish,publish_time,add_user_id,add_time,subject_id,menu_id,child_menu_id,season_id,area_no,brand_id,designer_id,book_id,sort_id,column_id,style_id';
        $rows = $model->field($field)->where($where)->order(array('source_file_name' => 'ASC'))->findAll();
        //echo $model->getLastSql();
        $listArr = array();
        if ($rows) {
            foreach ($rows as $key => $val) {
                $rows[$key]["img"] = show_pic_path($val["img_path"]);
            }
            foreach ($rows as $k => $v) {
                if (strlen($v["img_name"]) == 4) {//取大图
                    $listArr[$v["img_name"]] = $v;
                    $zip = array();
                    foreach ($rows as $ke => $va) {
                        $t_n = explode('_', $va["img_name"]);
                        if ($v["img_name"] == $t_n[0]) {
                            if (isset($t_n[1])) {
                                if ($t_n[1] == 'rar') {
                                    $zip['jrp'] = $va;//['img_path'];
                                }
                                if ($t_n[1] == 'ai') {
                                    $zip['ai'] = $va;//['img_path'];
                                }
                                if ($t_n[1] == 'cdr') {
                                    $zip['cdr'] = $va;//['img_path'];
                                }
                                if ($t_n[1] == 'psd') {
                                    $zip['psd'] = $va;//['img_path'];
                                }
                            }
                        }
                    }
                    $listArr[$v['img_name']]['zip'] = $zip;// ? serialize($zip) : '';
                }
                $t_n = explode('_', $v["img_name"]);
                if (in_array($t_n[1], array('rar','ai', 'cdr', 'psd'))) {
                    continue;
                }
                if (strlen($v["img_name"]) == 5) {//取大图的缩略图
                    $listArr[substr($v["img_name"], 0, 4)]["s"] = $v;
                }
                if (strlen($v["img_name"]) == 8) {//取副图
                    $listArr[substr($v["img_name"], 0, 4)]["f"][$v["img_name"]] = $v;
                }
                if (strlen($v["img_name"]) == 9) {//取副图的缩略图
                    $listArr[substr($v["img_name"], 0, 4)]["f"][substr($v["img_name"], 0, 8)]["s"] = $v;
                }
            }
        }
        return $listArr;
    }
    public function picTmpBatch() {
        $subject_id = intval($_REQUEST['subject_id']);
        $acttype = trim($_REQUEST['acttype']);
        $batch_id = $_REQUEST['batch_id'];//全选
        if (empty($acttype))
            $this->error('对不起，请选择操作类型！');
        $model = D('SharePicturesTmp');
        if ($acttype == 'remove') {
            foreach ($batch_id as $id) {
                $id = intval($id);
                $row = $model->field('url AS img_path')->find($id);
                @unlink($_SERVER['DOCUMENT_ROOT'] . '/' . C('IMG_ROOT') . $row["img_path"]);
                $model->delete($id);
            }
            $this->success('删除成功！');
        } else {
            $listArr = $this->picTmpFormat();
            if ($listArr) {
                foreach ($listArr as $key => $val) {
                    if (!$val["s"]) {
                        $this->error($val["img_name"] . ' 的小图片似乎没有吧？');
                    } else {
                        $page_no = intval(substr($val["img_name"], 1, 4));
                        $picInfo = array();
                        $picInfo["small_picture_url"] = $val["s"]["img_path"];
                        $picInfo["big_picture_url"] = $val["img_path"];
                        $picInfo["add_user_id"] = $val["add_user_id"];
                        $picInfo["add_time"] = $val["add_time"];
                        $picInfo["publish_time"] = $val["add_time"];
                        $picInfo["menu_id"] = $val["menu_id"];
                        $picInfo["subject_id"] = $subject_id;
                        $picInfo['child_menu_id'] = $val['child_menu_id'];
                        $picInfo["area_no"] = $val["area_no"];
                        $picInfo["designer_id"] = $val["designer_id"];
                        $picInfo["brand_id"] = $val["brand_id"];
                        $picInfo["book_id"] = $val["book_id"];
                        $picInfo["season_id"] = $val["season_id"];
                        $picInfo["page_no"] = $page_no;
                        $picInfo["is_publish"] = $val["is_publish"];
                        $picInfo["publish_time"] = $val["publish_time"];
                        //$picInfo['sort_id'] = $val['sort_id'];
                        //$picInfo['special_column_id'] = $val['column_id'];
                        //echo '<pre>';
                        //dump($val);exit();
                        $pid = $this->modelP->add($picInfo);
                        //$pid = "17038 ";
                        $this->setSift();
                        //$this->setSubjectPicture($subject_id, $pid);
                        $this->setPicExtend($pid, $val);
                        $this->setPicSort($pid,$val['sort_id']);
                        $this->setPicColumn($pid, $val['column_id']);
                        $this->setVectorPicStyle($pid, $val['style_id']);
                        //$this->setPicMenu($pid, $subject_id);
                        if ($pid && $type != 'detail') {
                            //插入附图
                            if ($val["f"]) {
                                foreach ($val["f"] as $k => $v) {
                                    if (!$v["s"]) {
                                        $this->error($v["img_name"] . ' 的小图片似乎没有吧？');
                                    } else {
                                        $aInfo = array();
                                        $aInfo["menu_id"] = $val["menu_id"];
                                        $aInfo['child_menu_id'] = $val['child_menu_id'];
                                        $aInfo["picture_id"] = $pid;
                                        $aInfo["add_user_id"] = $v["add_user_id"];
                                        $aInfo["small_picture_url"] = $v["s"]["img_path"];
                                        $aInfo["big_picture_url"] = $v["img_path"];
                                        $aInfo["add_time"] = $v['add_time'] + $k;
                                        $this->modelS->add($aInfo);
                                    }
                                }
                            }
                        }
                        //图片搜索表处理
                        //$this->setSearchPicture($pid);
                        if ($type != 'detail' && $subject_id > 0) {
                            $this->setPictureCount($subject_id,'add');
                        }
                    }
                }
            }
            $model->where(array('menu_id' => $this->cid, 'subject_id' => $subject_id))->delete();
            //成功提示
            $this->assign('jumpUrl', 'javascript:self.parent.main.location.reload()');
            $this->success('操作成功!');
        }
    }

	public function setPicSort($pid, $sort_id) {
		if (empty($pid)) return false;
        $this->delPicSort($pid);
        // 取主题的sortid
        $model = M("{$this->m['ref_picture_sort']}");
        $model->picture_id = $pid;
        $model->sort_id = $sort_id;
        $model->menu_id = $this->cid;
        $model->child_menu_id = 0;
        $model->add();
        //echo $model->getLastSql();exit();
	}

	public function delPicSort($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_sort']}");
		$model->where($where)->delete();
	}


	public function setPicColumn($pid, $column_id) {
		if (empty($pid)) return false;
        $this->delPicColumn($pid);
        // 取主题的sortid
        $model = M("{$this->m['ref_picture_column']}");
        $model->picture_id = $pid;
        $model->special_column_id = $column_id;
        $model->menu_id = $this->cid;
        $model->child_menu_id = 0;
        $model->add();
        //echo $model->getLastSql();exit();
	}

	public function delPicColumn($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_column']}");
		$model->where($where)->delete();
	}

	public function setVectorPicStyle($pid, $style_id) {
		if (empty($pid)) return false;
        $this->delPicStyle($pid);
        // 取主题的sortid
        $model = M("{$this->m['ref_picture_style']}");
        $model->picture_id = $pid;
        $model->style_id = $style_id;
        $model->menu_id = $this->cid;
        $model->child_menu_id = !empty($_REQUEST['child_menu_id']) ? $_REQUEST['child_menu_id'] : 0;
        $model->add();
	}

	public function delPicStyle($id) {
		$id = intval($id);
		$where = array('picture_id' => $id);
		$model = M("{$this->m['ref_picture_style']}");
		$model->where($where)->delete();
	}


}
?>
