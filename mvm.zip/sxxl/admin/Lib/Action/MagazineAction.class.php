<?php
// 后台主题模块
class MagazineAction extends SubjectAction {
	public $cid = 19;
    public $months = array(
        array('id' => '1','name'=>'01月'),
        array('id' => '2','name'=>'02月'),
        array('id' => '3','name'=>'03月'),
        array('id' => '4','name'=>'04月'),
        array('id' => '5','name'=>'05月'),
        array('id' => '6','name'=>'06月'),
        array('id' => '7','name'=>'07月'),
        array('id' => '8','name'=>'08月'),
        array('id' => '9','name'=>'09月'),
        array('id' => '10','name'=>'10月'),
        array('id' => '11','name'=>'11月'),
        array('id' => '12','name'=>'12月')
        );//月份，暂时记录在这里，只有时尚杂志栏目才会用到月份
    protected $fashions_array = array(
        array('id'=>'25','name'=>'成熟优雅系列'),
        array('id'=>'26','name'=>'纺织品趋势系列'),
        array('id'=>'28','name'=>'婚纱系列'),
        array('id'=>'29','name'=>'街头休闲系列'),
        array('id'=>'30','name'=>'内衣/泳装'),
        array('id'=>'32','name'=>'年轻时尚系列'),
        array('id'=>'35','name'=>'皮衣皮草'),
        array('id'=>'6','name'=>'商务'),
        array('id'=>'8','name'=>'休闲'),
        array('id'=>'37','name'=>'少女街头系列'),
        array('id'=>'38','name'=>'时尚杂志系列'),
        array('id'=>'39','name'=>'时装走秀系列'),
        array('id'=>'40','name'=>'斯文优雅系列'),
        array('id'=>'41','name'=>'田园淑女系列'),
        array('id'=>'42','name'=>'晚装系列'),
        array('id'=>'45','name'=>'运动装'),
        array('id'=>'46','name'=>'针织毛衣系列'),
    );
    
    public function _initialize() {
		parent::_initialize();
		$this->assign('currentBase', '数据录入-时尚杂志');
	}

	function index() {
		$this->themeList();
	}
    
	public function themeList() {
        $field = $this->m['subject_original'].'.id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
        $this->assign('fashions_array', $this->fashions_array);
		parent::themeList($field,$map);
		$this->display('Subject/magazine_theme_list');
	}
	
	public function themeAdd() {
		$this->_themeAdd();
        $this->display('Subject/magazine_theme_info');
	}
    //没有lable_id字段
    protected function _themeAdd() {
        $this->assign('tid', 0);
        if ($_POST) {
            $info = $this->getSubjectInfo();
            //dump($_POST);exit();
            $id = $this->modelT->add($info);
            //echo $this->modelT->getLastSql();exit();
            if ($id) {
                if($this->cid == 12){
                    $f_id = $info['folder_id'];
                    $this->setThemeFolder($f_id);
                }
                $this->setThemeOther($id);
                $this->assign('jumpUrl',__URL__."/picList/subject_id/{$id}");
                //$this->assign('jumpUrl', Cookie::get('_currentThemeUrl_'));
                $this->success('添加成功！');
            } else {
                $this->error('添加失败！');
            }
        } else {
            $this->setConfig();
            $folder_id = $_REQUEST['folder_id'];
            //获取对应标签
            if(!empty($folder_id)){
                $info = $this->modelF->getById($folder_id);
                $info['title'] = stripslashes($info['title']);
                $info['tmpTitle'] =$info['title'];
                $info['title'] = $info['id'] = '';
                $map['folder_id'] = $folder_id;
                $lable_list = M("{$this->m['folder_lable']}")->where($map)->findAll();
                $this->assign('lableList', $lable_list);
                }
            $action_link[] = array('text' => '返回列表', 'href' => Cookie::get('_currentThemeUrl_'));
            $this->assign('action_link', $action_link);
            $info['publish_time'] = date('Y-m-d H:i:s', time());
            $info['folder_id'] = $_REQUEST['folder_id'];
            $this->assign('info', $info);
            $this->assign('months', $this->months);
            //dump($this->fashions);
            $this->assign('fashions_array', $this->fashions_array);
            //dump($this->months);dump($this->books);
            //区域格式化
            $areaOption = $this->getAreaOption(0);
            $this->assign('areaOption', $areaOption);
            $this->assign('listMenus', '');
        }
    }
	
	public function themeEdit() {
		parent::themeEdit('1');
        $this->assign('months', $this->months);
        $this->assign('fashions_array', $this->fashions_array);
        $this->display('Subject/magazine_theme_info');
	}

	public function themeBatch() {
		parent::themeBatch();
	}
	
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,page_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = $this->cid;
		$map['is_publish'] = array('egt',0);
		parent::picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/magazine_picture_list');
		} else {
			$this->display('Subject/trend_picture_list');
		}
	}
	
	public function picAdd() {
		parent::picAdd('1');
        $this->display('Subject/invogue_picture_info');
	}

	public function picCategory() {
		parent::picCategory();
	}

	public function picBatch() {
		parent::picBatch();
	}
    
    public function updateBookSort () {
       parent::updateBookSort();
    }
}
?>
