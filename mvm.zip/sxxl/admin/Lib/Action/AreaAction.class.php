<?php
// +----------------------------------------------------------------------
// | 区域/国家/城市设置
// +----------------------------------------------------------------------
// | Author: xieweijun <xieweijun@sxxl.com>
// +----------------------------------------------------------------------

class AreaAction extends AttributeAction{
	protected $model;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('AttributeArea');
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'区域设置'));
		$this->assign('listMenus', $listMenus);

		$pno = intval($_GET['pno']);
		$map['parent_no'] = array('eq',$pno);

		$action_link = array();
		if($pno >0){
			$mapTmp['no'] = array('eq',$pno);
			$pnoTmp = $this->model->where($mapTmp)->getField('parent_no');
			$action_link[] = array('text'=>'返回上级', 'href'=>U('/Area/index',array('pno'=>$pnoTmp)));
		}
		$action_link[] = array('text'=>'新增区域', 'href'=>"javascript:Box.open({'id':'insert','title':'新增区域','iframe':'".U('/Area/insert',array('pno'=>$pno))."','width':'480','height':'220'});");
		$this->assign('action_link', $action_link);

		if($_POST['search']) $map['parent_no'] = array('egt',0);
		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
		}
		$en_name = trim($_REQUEST['eng']);
		if(!empty($en_name)){
			$this->assign('eng',$en_name);
			$map['en_name'] = array('like','%'.$en_name.'%');
		}

		$field = 'id,name,en_name,parent_no,no,add_user_id,add_time';

		$this->_list ($field ,$map);
		$this->display ();
	}
}
?>
