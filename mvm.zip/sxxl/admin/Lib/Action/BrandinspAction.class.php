<?php
// 后台主题模块
class BrandinspAction extends SubjectAction {
	public $cid = 20;
	public $ny_cid = 100;

	public function _initialize() {
		parent::_initialize();
		$this->assign('currentBase', '数据录入-品牌灵感');
	}

	function index() {
		$this->themeList();
	}
	
	public function themeList() {
        $field = $this->m['subject_original'].'.id,title,title_picture_url,'.$this->m['subject_original'].'.child_menu_id,'.$this->m['subject_original'].'.menu_id,area_no,season_id,designer_id,brand_id,book_id,picture_count,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['subject_original'].'.menu_id'] = array(' in ',array($this->cid,100)); //内衣品牌画册menu_id=100
		$map['is_publish'] = array('egt',0);
		parent::themeList($field,$map);
		$this->display('Subject/invogue_theme_list');
	}
	
	public function themeAdd() {
		parent::themeAdd('1');
        $this->display('Subject/invogue_theme_info');
	}
	
	public function themeEdit() {
		parent::themeEdit('1');
        $this->display('Subject/invogue_theme_info');
	}

	public function themeBatch() {
		parent::themeBatch();
	}
	
	public function picList() {
        $field = $this->m['picture_original'].'.id,subject_id,big_picture_url,small_picture_url,'.$this->m['picture_original'].'.child_menu_id,'.$this->m['picture_original'].'.menu_id,area_no,page_no,season_id,designer_id,brand_id,book_id,detail_id,is_publish,add_user_id,publish_time,add_time';
		$map[$this->m['picture_original'].'.menu_id'] = array( ' in ', array($this->cid,100));
		$map['is_publish'] = array('egt',0);
		parent::picList($field, $map);
		$isset_sid = intval($_REQUEST['subject_id']);
        if (!$isset_sid) {
			$this->display('Subject/invogue_picture_list');
		} else {
			$this->display('Subject/trend_picture_list');
		}
	}
	
	public function picAdd() {
		parent::picAdd('1');
        $this->display('Subject/invogue_picture_info');
	}

	public function picCategory() {
		parent::picCategory();
	}
    
	public function picBatch() {
		parent::picBatch();
	}
    
    public function updateBookSort () {
       parent::updateBookSort();
    }
    
}
?>
