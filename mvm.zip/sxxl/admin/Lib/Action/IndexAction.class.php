<?php
// 本文档自动生成，仅供测试运行
class IndexAction extends CommonAction {
	public function index() {
		//读取数据库模块列表生成菜单项
		$node = M("SysNode");
		$where['status'] = 1;
		$where['is_menu'] = 1;
		$list = $node->where($where)->field('id,name,title,parent_id')->order('order_id asc')->select();
		if(C('USER_AUTH_TYPE') == 2) {
			import('@.ORG.Power');
            $user_key = Cookie::get(C('USER_AUTH_KEY'));
            $accessList = Power::getAccessList($user_key);
		}else{
            $accessList = unserialize(Cookie::get('_ACCESS_LIST'));
        }
		$menu = array();
		foreach ($list as $key => $val) {
			if ($val['parent_id'] == 0) {
				$menu[$key] = $val;
				foreach ($list as $k => $v) {
					if ($val['id'] == $v['parent_id']) {
                        if (isset($accessList[strtoupper($v['name'])]) || Cookie::is_set(C('ADMIN_AUTH_KEY'))) {
							//设置模块访问权限
							$module['access'] = 1;
							$menu[$key]['child'][] = $v;
						}
					}
				}
			}
		}
		//var_dump($list);exit;
		$this->assign('menu', $menu);
        $this->assign('loginUser', Cookie::get('loginUser'));
        $this->assign('loginUserName', Cookie::get('loginUserName'));
		$this->display();
	}
}