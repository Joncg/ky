<?php
/**
 * 前台sql count缓存表数据更新
 * author perfectlystyle@gmail.com
 */
class UpdateSysCountAction extends CommonAction {
    public function _initialize() {
        parent::_initialize();
    }

    public function index(){
        if($_REQUEST){
            $i = 0;
            $page = $_GET['page'];
            $page = empty($page) ? 1 : $page;
            $page_size = 1;
            echo '这是第'.$page.'页<br/>';

            $map = array();
            //$map['id'] = 4530;
            $time_start = $_REQUEST['time_start'];
            $time_end = $_REQUEST['time_end'];
            if ($time_start) {
                $map['update_time'][] = array('egt', strtotime($time_start . ' 00:00:00'));
            }

            if ($time_end) {
                $map['update_time'][] = array('elt', strtotime($time_end . ' 23:59:59'));
            }

            $model_sc = M('SysCount');
            $list = $model_sc->field('id,table_name,clause,`join`')->where($map)->order(array('id'=>'asc'))->limit("0,{$page_size}")->findAll();
            echo $model_sc->field('id,table_name,clause,join')->getLastSql().'<br/><br/>';
            if($list){
                foreach($list as $key=>$val){
                    $model = M($val['table_name']);
                    $map_tmp = array();
                    $map_tmp = unserialize($val['clause']);
                    $join_tmp = unserialize($val['join']);
                    $count = $model->where($map_tmp)->join($join_tmp)->count();
                    echo $model->getLastSql().'<br/><br/>';
                    if($count !== false){
                        $update_time = time();
                        $model_sc->where(array('id'=>$val['id']))->save(array('number'=>$count,'update_time'=>$update_time));
                        echo $model_sc->getLastSql().'<br/><br/>';
                    }else{
                        exit('出错了，错误原因是：'.$model->getDbError());
                    }
                    ++$i;
                }
            }

            if ($i > 0) {
                $page++;
                echo "<script>window.location='?page={$page}&time_start={$_REQUEST['time_start']}&time_end={$_REQUEST['time_end']}';</script>";
            }else{
                exit('更新完毕，共'.($page*$page_size).'条数据');
            }
        }

        $this->display();
    }
}