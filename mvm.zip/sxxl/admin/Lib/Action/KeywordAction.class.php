<?php
/**
 * 关键词设置
 * @author ChengguoZhang <balncom@gmail.com>
 */

class KeywordAction extends AttributeAction {
	protected $model;

	public function _initialize(){
		parent::_initialize();
		$this->model = D ('AttributeKeyword');
        $this->refmodel = D ('RefStyleKeyword');
        //类别
        $this->sorts = F('sortList','',C('DATA_CACHE_PATH'));
        //款式
        $this->styles = F('styleList','',C('DATA_CACHE_PATH'));
	}

	public function index() {
		$listMenus = array(array('href'=>__URL__,'title'=>'关键词设置'));
		$this->assign('listMenus', $listMenus);

		$pid = intval($_GET['pid']);
		$map['parent_id'] = array('eq',$pid);

		$action_link = array();
		if($pid >0){
			$mapTmp['id'] = array('eq',$pid);
			$pidTmp = $this->model->where($mapTmp)->getField('parent_id');
			$action_link[] = array('text'=>'返回上级', 'href'=>U('/Keyword/index',array('pid'=>$pidTmp)));
		}
		$action_link[] = array('text'=>'新增关键词', 'href'=>"javascript:Box.open({'id':'insert','title':'新增关键词','iframe':'".U('/Keyword/insert',array('pid'=>$pid))."','width':'630','height':'400'});");
		$this->assign('action_link', $action_link);

		$name = trim($_REQUEST['chs']);
		if(!empty($name)){
			$this->assign('chs',$name);
			$map['name'] = array('like','%'.$name.'%');
			$map['parent_id'] = array('egt',0);
		}

		$field = 'id,name,add_user_id,add_time';
		$this->_list ($field ,$map);

		$this->display ();
	}
    
    
	public function insert(){
		if($_POST){ 
			if($data = $this->model->create()) {
                $id = $this->model->add();
                $isok = $this->setRefkeyword($id);
				if($isok !== false){
					$this->ajaxReturn($data,'新增成功',1);
				}else{
					$this->ajaxReturn($data,'新增失败！',0);
				}
			}
		}
		if(MODULE_NAME == 'Area'){
            $pno = intval($_GET['pno']);
            $this->assign('pno',$pno);
        }
        elseif($_GET['pid']){
            $pid = intval($_GET['pid']);
            $this->assign('pid',$pid);
        }
		$this->display();
	}

    public function setRefkeyword($id){
        if (empty ($id))
             return false;
        $this->delRefkeyword($id);
        $sortArray = $_POST['sort_id'];
        $styleArray = $_POST['style_id'];
        foreach ($sortArray as $ksort => $vsort) {
            if ( isset($styleArray) && !empty ($styleArray)) {
                foreach ($styleArray as $kstyle => $vstyle) {
                    $this->refmodel->style_id = empty($vstyle) ? 0 : $vstyle;
                    $this->refmodel->keyword_id = $id;
                    $this->refmodel->sort_id = empty($vsort) ? 0 : $vsort;
                    $this->refmodel->add();
                }
            }else{
                $this->refmodel->style_id = 0;
                $this->refmodel->keyword_id = $id;
                $this->refmodel->sort_id = empty($vsort) ? 0 : $vsort;
                $this->refmodel->add();
            }
        }
        return ture;
    }

    public function delRefkeyword($id) {
        $id = intval($id);
        $where = array('keyword_id' => $id);
        $this->refmodel->where($where)->delete();
    }
    
	public function edit(){
		//保存
		if($_POST['id']){
			if($data = $this->model->create()) {
                $id = $this->model->save();
                $isok = $this->setRefkeyword($_POST['id']);
				if( $isok !== false){
					$this->ajaxReturn($data,'编辑成功！',1);
				}
				else{
					$this->ajaxReturn($data,'编辑失败！',0);
				}
			}
		}
		$id = intval($_GET['id']);
		$info = $this->model->relation(array('sort_id'))->find($id);
        if ($info['sort_id']) {
            $sort = array();$style = array();
            foreach ($info['sort_id'] as $k => $v) {
                $sort[] = $v['sort_id'];
                $style[] = $v['style_id'];
            }
            $info['sort_id'] = $sort;
            $info['style_id'] = $style;
        }
		$this->assign('info',$info);
		$this->display();
	}
    
    
}
?>