<?php
/**
 * 通用的树形类,可以生成任何树形结构
 * @author baln
 * @id class.tree.php 2010-01-12 21:56
 */

class Tree extends Think {
	public $arr; // 树数组
	public $icon; // 修饰符号,可换成图片
	public $gid; // ID名,根据不同的情况定义
	public $parent_id;
	public $restr; // 树

	/**
	 * 构造函数,初始化类
	 * @param array $arr 2维数组
	 * @param array $icon 图标
	 */
	function  __construct($arr = array(), $icon = array(), $gid = '') {
		$this->arr = $arr;
		$this->icon = $icon ? $icon : array('│ ', '├- ', '└- ');
		$this->gid = $gid ? $gid : 'id';
		$this->parent_id = 'parent_id';
		$this->restr = '';

	}

	/**
	 * 设置属性
	 * @param string $key 属性名
	 * @param string $value 属性值
	 */
	function set($key, $value) {
		if (empty($key)) return false;
		$this->$key = $value;
	}

	/**
	 * 获取父级数组
	 * @param int $id
	 * @return array
	 */
	function getParent($id) {
		if (empty($this->arr[$id])) return false;
		$pid = $this->arr[$id][$this->parent_id];
		$pid = $this->arr[$pid][$this->parent_id];
		if (is_array($this->arr)) {
			$newarr = array();
			foreach($this->arr as $key => $val) {
				if ($val[$this->parent_id] == $pid) {
					$newarr[$key] = $val;
				}
			}
		}
		return $newarr;
	}

	/**
	 * 获取子级数组
	 * @param int $id
	 * @return array
	 */
	function getChild($id) {
		if (is_array($this->arr)) {
			$newarr = $val = array();
			foreach ($this->arr as $key => $val) {
				if ($val[$this->parent_id] == $id) {
					$newarr[$key] = $val;
				}
			}
		}
		return $newarr ? $newarr : false;
	}

	/**
	 * 获取当前位置数组
	 * @param int $id
	 * @return array
	 */
	function getThis($id, &$newarr) {
		if (empty($this->arr[$id])) return false;
		$newarr[] = $this->arr[$id];
		$pid = $this->arr[$id][$this->parent_id];
		if (!empty($this->arr[$pid])) {
			$this->getThis($pid, $newarr);
		}
		if (is_array($newarr)) {
			krsort($newarr);
			$arrs = array();
			foreach ($newarr as $val) {
				$arrs[$val[$this->gid]] = $val;
			}
		}
		return $arrs;
	}

	/**
	 * 获得树形结构
	 * @param int $id 获取这个ID下所有的子级,为0获取整个树
	 * @param string $str 树的基本代码,如: "<div>\$spacer\$name</div>" OR "<option value='\$id' \$selected>\$spacer\$name</option>"
	 * @param string $sid 选中ID,可多选如:'6,7'时为选两个.树形下拉框时用
	 * @return string
	 */
	function getTree($id, $str, $sid = 0, $adds = '') {
		$number = 1;
		$child = $this->getChild($id);
		if (is_array($child)) {
			$total = count($child);
			foreach ($child as $key => $val) {
				$j = $k = '';
				if ($number == $total) {
					$j .= $this->icon[2];
				}
				else {
					$j .= $this->icon[1];
					$k  = $adds ? $this->icon[0] : '';
				}
				$spacer = $adds ? $adds.$j : '';
				$selected = $this->have("$sid", "$key") !== false ? 'selected' : '';
				@extract($val);
				eval("\$nstr = \"$str\";");
				$this->restr .= $nstr;
				$this->getTree($key, $str, $sid, $adds.$k.'&nbsp;&nbsp;');
				$number++;
			}
		}
		return $this->restr;
	}

	function have($list, $item) {
		return strpos(',' . $list . ',', ','.$item.',');
	}
}