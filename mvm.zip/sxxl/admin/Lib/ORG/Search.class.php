<?php
class Search{
	//public $h_hosts = '192.168.1.14'; //主服务器
    public $h_hosts = '192.168.1.23';   //搜索服务器
	private $h_ports = 9312;
	private $h_limits = 5000000;
	private $h_cl;
	private $h_opts = array(
			"before_match"          => "<i>",
			"after_match"           => "</i>",
			"chunk_separator"       => "..",
			"limit"                 => 10,
			"around"                => 3
	);
	private $s_index;	//索引文件
	private $s_keywords; //搜索的关键词
	private $s_pagesize = 5;
	private $s_page = 1;
    private $m = array(
        'f' => 'RefStyleFashion',
        'd' => 'RefStyleDetail',
        'k' => 'RefStyleKeyword',
        'a' => 'RefStyleArea',
    );
    private $fields = array(
        'f' => 'fashion_id',
        'd' => 'detail_id',
        'k' => 'keyword_id',
        'a' => 'area_no',
    );

    public function __construct() {

		import ('@.ORG.SphinxClient');
		$this->h_cl = new SphinxClient();
		$this->h_cl->SetServer($this->h_hosts, $this->h_ports);
		$this->setMatchMode('SPH_MATCH_ANY');
		$this->h_cl->SetArrayResult(true);
		$this->h_cl->SetRankingMode(SPH_RANK_PROXIMITY_BM25);
	}

	public function query($str) {
		$this->s_keywords = $str;
        //$this->h_cl->SetFilter('menu_id',array(19,22));
		$page = $this->s_page;
		$page = empty($page) ? 1 : intval($page);
		$pageSize = $this->s_pagesize;
		$pageStart = ($page-1) * $pageSize;
		$this->h_cl->SetLimits($pageStart, $pageSize, $this->h_limits);
		$this->setIndex();
		$res = $this->h_cl->Query($this->s_keywords, $this->s_index);
		return $res;
	}

	public function queryAssCount($str) {
		$this->s_keywords = $str;
        $this->setIndex();
		$res = $this->h_cl->Query($this->s_keywords, $this->s_index);
//        $this->h_cl->ResetFilters();
//        $this->h_cl->SetFilter('label_search', array($str));
//        $this->h_cl->AddQuery();
//        $res = $this->h_cl->RunQueries();
		return $res;
	}

    public function arrQuery($style_arr,$tag){
        $ref_field = $this->fields[$tag];
        foreach($style_arr as $key=>$val){
            foreach(array(1,2,3,4,5) as $ke=>$va){
                echo '正在导入与款式：'.$val['id'].'性别：'.$va.'相关的数据。。。<br/>';
                $i = 0;
				$this->h_cl->ResetFilters();
                $this->h_cl->ResetGroupBy();
                $this->h_cl->SetFilter('menu_id', array(22));
                $this->h_cl->SetFilter('style_id', array($val['id']));
                $this->h_cl->SetFilter('sort_id', array($va));
                $this->h_cl->SetGroupBy($ref_field,SPH_GROUPBY_ATTR);
                $res = $this->h_cl->Query();
				$this->_saveData($res ,$val['id'],$va,$tag);
            }
        }
    }

    protected function _saveData($res,$style_id,$sort_id,$tag){
        $model = D($this->m[$tag]);
        $field = $this->fields[$tag];
        if ( $res['total_found'] > 0 ){
            foreach($res['matches'] as $key =>$val){
                if($val['attrs'][$field]){
                    if(is_array($val['attrs'][$field])){
                        foreach($val['attrs'][$field] as $ke=>$va){
                            $data = array();
                            $data['style_id'] = $style_id;
                            $data[$field] = $va;
                            $data['sort_id'] = $sort_id;
                            $data['menu_id'] = $val['attrs']['menu_id'];
                            if($model->where($data)->count() == 0){
                                $model->add($data);
                                echo $model->getLastSql()."<br />";
                            }
                        }
                    }else{
                        $data = array();
                        $data['style_id'] = $style_id;
                        $data[$field] = $val['attrs'][$field];
                        $data['sort_id'] = $sort_id;
                        $data['menu_id'] = $val['attrs']['menu_id'];
                        if($model->where($data)->count() == 0){
                            $model->add($data);
                            echo $model->getLastSql()."<br />";
                        }
                    }
                }
            }
        }
    }

    public function arrQueryBak($styles = array(), $ref_arrs = array(), $model){
        echo '<pre>';
        $ref_field = $this->fields[$model];
        foreach($styles as $style_k => $style_v){
            $i = 0;
            $j = 0;
            //女装
            foreach($ref_arrs as $ref_arrs_k => $ref_arrs_v){
                $filed_id = '';
                $this->h_cl->ResetFilters();
                $this->h_cl->SetFilter('sort_id', array(2));
                $this->h_cl->SetFilter('style_id', array($style_v['id']));
                $this->h_cl->SetFilter($ref_field, array($ref_arrs_v['id']));
                $this->h_cl->AddQuery();
                $i++;
                //临时记录款式对应的风格/细节/关键字id
                $res['extends'][$style_v['id']][] = $ref_arrs_v['id'];
                if($i > 30) {
                    $i = 0;
                    $res['res'][$j] = $this->h_cl->RunQueries();
                    $j++;
                }
            }
            if($i != 0) {
                $res['res'][$j] = $this->h_cl->RunQueries();
            }

            $this->_saveData($res , $model, $style_v['id'] , 2);
            unset($res);

            //男装
            foreach($ref_arrs as $ref_arrs_k => $ref_arrs_v){
                $this->h_cl->ResetFilters();
                $this->h_cl->SetFilter('sort_id', array(1));
                $this->h_cl->SetFilter('style_id', array($style_v['id']));
                $this->h_cl->SetFilter($ref_field, array($ref_arrs_v['id']));
                $this->h_cl->AddQuery();
                $i++;
                //临时记录款式对应的风格/细节/关键字id
                $res['extends'][$style_v['id']][] = $ref_arrs_v['id'];
                if($i > 30) {
                    $i = 0;
                    $res['res'][$j] = $this->h_cl->RunQueries();
                    $j++;
                }
            }
            if($i != 0) {
                $res['res'][$j] = $this->h_cl->RunQueries();
            }
            $this->_saveData($res , $model, $style_v['id'] , 1);
            unset($res);

            //童装
            foreach($ref_arrs as $ref_arrs_k => $ref_arrs_v){
                $this->h_cl->ResetFilters();
                $this->h_cl->SetFilter('sort_id', array(3));
                $this->h_cl->SetFilter('style_id', array($style_v['id']));
                $this->h_cl->SetFilter($ref_field, array($ref_arrs_v['id']));
                $this->h_cl->AddQuery();
                $i++;
                //临时记录款式对应的风格/细节/关键字id
                $res['extends'][$style_v['id']][] = $ref_arrs_v['id'];
                if($i > 30) {
                    $i = 0;
                    $res['res'][$j] = $this->h_cl->RunQueries();
                    $j++;
                }
            }
            if($i != 0) {
                $res['res'][$j] = $this->h_cl->RunQueries();
            }
            $this->_saveData($res , $model, $style_v['id'] , 3);
            unset($res);

            //print_r($this->h_cl);exit;
            //print_r($res);exit;
        }
        return TRUE;
    }

    public function _saveDataBak($res, $m_str, $style_id, $sort_id  ){
        $model = D($this->m[$m_str]);
        $field = $this->fields[$m_str];
        $i = 0;
        if ( isset($res['res']) && !empty ($res['res'])){
            foreach ( $res['res'] as $key => $value ){
                foreach ( $value as $k => $val ){
                    if ( $val['total_found'] > 0 ){
                         foreach ( $val['matches'] as $m_k => $m_v ){
                            $info['style_id'] = $style_id;
                            $info[$field] = $res['extends'][$style_id][$i];
                            $info['sort_id'] = $sort_id;
                            $info['picture_count'] = $val['total_found'];
                            $info['menu_id'] = $m_v['attrs']['menu_id'];
                            $model->add($info);
                            echo $model->getLastSql()."<br />";
                        }
                    }
                    $i++;
                }
            }
        }
    }
    public function getPicInfo($id) {
		$MODEL = M('SearchPicture');
		$row = $MODEL->field('picture_id,small_picture_url,big_picture_url')->find($id);
        //echo $MODEL->getLastSql()."<br/>";
		return $row;
	}

    public function setFilter( $attribute, $values, $exclude=false ){
        $this->h_cl->SetFilter($attribute,$values,$exclude);
    }

    public function setFilterRange($attribute, $min, $max, $exclude=false ){
        $this->h_cl->SetFilterRange($attribute, $min, $max, $exclude);
    }

	public function setPageSize($p) {
		$p = intval($p);
		$this->s_pagesize = $p;
	}

	public function setPage($p) {
		$p = empty($p) ? 1 : intval($p);
		$this->s_page = $p;
	}

	public function setIndex($index) {
		$this->s_index = empty($index) ? '*' : $index;
	}

	public function setSortMode($key = '', $val = '') {
		$key = empty($key) ? SPH_SORT_TIME_SEGMENTS : $key;
		$val = trim($val) ? trim($val) : 'publish_time';
		$this->h_cl->SetSortMode($key, $val);
	}

	public function setMatchMode($key = '') {
		$key = empty($key) ? SPH_MATCH_ALL : $key;
		$this->h_cl->SetMatchMode($key);
	}

    public function updateAttributes($index, $attrs, $values){
        return $this->h_cl->UpdateAttributes($index, $attrs, $values);
    }
}