<!--
            for(i=1;i<13;i++) document.write('<option>'+i)
            //-->