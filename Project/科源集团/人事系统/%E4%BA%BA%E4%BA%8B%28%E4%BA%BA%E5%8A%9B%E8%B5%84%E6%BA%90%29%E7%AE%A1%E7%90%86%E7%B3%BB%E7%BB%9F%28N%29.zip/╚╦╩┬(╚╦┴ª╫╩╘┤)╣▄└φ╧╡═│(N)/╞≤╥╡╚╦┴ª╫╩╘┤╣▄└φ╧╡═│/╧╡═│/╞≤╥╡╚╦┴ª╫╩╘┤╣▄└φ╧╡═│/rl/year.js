<!--
            for(i=1900;i<2051;i++) document.write('<option>'+i)
            //-->